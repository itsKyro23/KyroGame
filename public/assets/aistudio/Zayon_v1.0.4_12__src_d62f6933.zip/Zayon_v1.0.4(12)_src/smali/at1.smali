.class public final Lat1;
.super Llv2;
.source "SourceFile"


# instance fields
.field public final synthetic h:Landroid/content/Context;

.field public final synthetic i:Lyu1;


# direct methods
.method public constructor <init>(Lyu1;Landroid/content/Context;)V
    .locals 0

    iput-object p2, p0, Lat1;->h:Landroid/content/Context;

    iput-object p1, p0, Lat1;->i:Lyu1;

    invoke-direct {p0}, Llv2;-><init>()V

    return-void
.end method


# virtual methods
.method public final j2(Lh23;)V
    .locals 2

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lat1;->h:Landroid/content/Context;

    iget-object p1, p1, Lh23;->i:Ljava/lang/String;

    iget-object p0, p0, Lat1;->i:Lyu1;

    const/4 v1, 0x1

    invoke-virtual {p0, v0, p1, v1, v1}, Lyu1;->i(Landroid/content/Context;Ljava/lang/String;ZZ)V

    return-void
.end method
