.class public final Lb40;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public final c:Landroid/os/Handler;

.field public final d:Llk0;

.field public e:Lyk0;

.field public f:Z

.field public g:Z

.field public h:Z

.field public i:Z

.field public j:F

.field public k:I

.field public final l:[J

.field public m:J

.field public final n:Lf7;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;Landroid/os/Handler;Lyk0;Llk0;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x7fc00000    # Float.NaN

    iput v0, p0, Lb40;->j:F

    const/4 v0, 0x3

    new-array v1, v0, [J

    fill-array-data v1, :array_0

    iput-object v1, p0, Lb40;->l:[J

    const-wide/32 v1, -0x493e0

    iput-wide v1, p0, Lb40;->m:J

    new-instance v1, Lf7;

    invoke-direct {v1, v0, p0}, Lf7;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Lb40;->n:Lf7;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lb40;->a:Landroid/content/Context;

    iput-object p2, p0, Lb40;->b:Ljava/util/concurrent/ExecutorService;

    iput-object p3, p0, Lb40;->c:Landroid/os/Handler;

    invoke-virtual {p4}, Lyk0;->a()Lyk0;

    move-result-object p1

    iput-object p1, p0, Lb40;->e:Lyk0;

    iput-object p5, p0, Lb40;->d:Llk0;

    return-void

    :array_0
    .array-data 8
        0x0
        -0xea60
        -0xea60
    .end array-data
.end method


# virtual methods
.method public final a(F)V
    .locals 10

    iget-boolean v0, p0, Lb40;->f:Z

    if-eqz v0, :cond_7

    iget-object v0, p0, Lb40;->e:Lyk0;

    iget-boolean v0, v0, Lyk0;->c:Z

    if-eqz v0, :cond_7

    iget-boolean v0, p0, Lb40;->g:Z

    if-nez v0, :cond_7

    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_1

    :cond_0
    invoke-static {p1}, Ljava/lang/Float;->isNaN(F)Z

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    :cond_1
    move v0, v2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lb40;->e:Lyk0;

    iget v3, v0, Lyk0;->b:I

    int-to-float v3, v3

    cmpl-float v3, p1, v3

    if-ltz v3, :cond_3

    move v0, v1

    goto :goto_0

    :cond_3
    iget v0, v0, Lyk0;->a:I

    int-to-float v0, v0

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_1

    const/4 v0, 0x1

    :goto_0
    iget v3, p0, Lb40;->k:I

    iput v0, p0, Lb40;->k:I

    if-gt v0, v3, :cond_4

    goto :goto_1

    :cond_4
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-object v5, p0, Lb40;->l:[J

    aget-wide v6, v5, v0

    sub-long v6, v3, v6

    const-wide/32 v8, 0xea60

    cmp-long v6, v6, v8

    if-gez v6, :cond_5

    goto :goto_1

    :cond_5
    aput-wide v3, v5, v0

    if-ne v0, v1, :cond_6

    iget-object v5, p0, Lb40;->e:Lyk0;

    iget-boolean v5, v5, Lyk0;->d:Z

    if-eqz v5, :cond_6

    iget-wide v5, p0, Lb40;->m:J

    sub-long v5, v3, v5

    const-wide/32 v7, 0x493e0

    cmp-long v5, v5, v7

    if-ltz v5, :cond_6

    iget-object v5, p0, Lb40;->a:Landroid/content/Context;

    invoke-static {v5}, Lu1;->e(Landroid/content/Context;)Lu1;

    move-result-object v5

    invoke-virtual {v5}, Lu1;->m()Lrb1;

    move-result-object v5

    if-eqz v5, :cond_6

    iput-wide v3, p0, Lb40;->m:J

    new-instance p1, Ln00;

    invoke-direct {p1, p0, v0, v1}, Ln00;-><init>(Ljava/lang/Object;II)V

    iget-object p0, p0, Lb40;->b:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_6
    iget-object p0, p0, Lb40;->d:Llk0;

    invoke-virtual {p0, v0, p1, v2}, Llk0;->c(IFZ)V

    :cond_7
    :goto_1
    return-void
.end method

.method public final b(Landroid/content/Intent;)V
    .locals 2

    const-string v0, "temperature"

    const/high16 v1, -0x80000000

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    if-eq p1, v1, :cond_4

    iget-boolean v0, p0, Lb40;->i:Z

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    int-to-float p1, p1

    const/high16 v0, 0x41200000    # 10.0f

    div-float/2addr p1, v0

    iget v0, p0, Lb40;->j:F

    cmpl-float v0, p1, v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iput p1, p0, Lb40;->j:F

    if-eqz v0, :cond_3

    iget-object v0, p0, Lb40;->d:Llk0;

    iget-object v0, v0, Llk0;->a:Lvk0;

    iget-object v0, v0, Lvk0;->x0:Lc40;

    if-eqz v0, :cond_3

    iget v1, v0, Lc40;->p:F

    cmpl-float v1, p1, v1

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    iput p1, v0, Lc40;->p:F

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_3
    :goto_1
    invoke-virtual {p0, p1}, Lb40;->a(F)V

    :cond_4
    :goto_2
    return-void
.end method

.method public final c()V
    .locals 6

    iget-boolean v0, p0, Lb40;->i:Z

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lb40;->g:Z

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lb40;->f:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lb40;->e:Lyk0;

    iget-boolean v0, v0, Lyk0;->c:Z

    if-eqz v0, :cond_1

    :cond_0
    move v0, v2

    goto :goto_0

    :cond_1
    move v0, v1

    :goto_0
    iget-object v3, p0, Lb40;->n:Lf7;

    iget-object v4, p0, Lb40;->a:Landroid/content/Context;

    if-eqz v0, :cond_2

    iget-boolean v5, p0, Lb40;->h:Z

    if-nez v5, :cond_2

    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.intent.action.BATTERY_CHANGED"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v5, 0x0

    invoke-static {v4, v3, v0, v5, v1}, Lvm;->i(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v0

    iput-boolean v2, p0, Lb40;->h:Z

    if-eqz v0, :cond_4

    invoke-virtual {p0, v0}, Lb40;->b(Landroid/content/Intent;)V

    return-void

    :cond_2
    if-nez v0, :cond_4

    iget-boolean v0, p0, Lb40;->h:Z

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    iput-boolean v1, p0, Lb40;->h:Z

    :try_start_0
    invoke-virtual {v4, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_4
    :goto_1
    return-void
.end method
