.class public final Lal1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lvi1;

.field public final b:Lzi1;

.field public c:Lwi1;

.field public final d:I


# direct methods
.method public constructor <init>(Lxi1;Lzi1;JJJJJI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lal1;->b:Lzi1;

    iput p13, p0, Lal1;->d:I

    move-object p2, p1

    new-instance p1, Lvi1;

    invoke-direct/range {p1 .. p12}, Lvi1;-><init>(Lxi1;JJJJJ)V

    iput-object p1, p0, Lal1;->a:Lvi1;

    return-void
.end method

.method public static final c(Llj1;JLoj1;)I
    .locals 2

    invoke-interface {p0}, Llj1;->o()J

    move-result-wide v0

    cmp-long p0, p1, v0

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    iput-wide p1, p3, Loj1;->h:J

    const/4 p0, 0x1

    return p0
.end method

.method public static synthetic d(I[B)I
    .locals 3

    aget-byte v0, p1, p0

    and-int/lit16 v0, v0, 0xff

    add-int/lit8 v1, p0, 0x1

    aget-byte v1, p1, v1

    and-int/lit16 v1, v1, 0xff

    add-int/lit8 v2, p0, 0x2

    aget-byte v2, p1, v2

    and-int/lit16 v2, v2, 0xff

    add-int/lit8 p0, p0, 0x3

    aget-byte p0, p1, p0

    and-int/lit16 p0, p0, 0xff

    shl-int/lit8 p1, v0, 0x18

    shl-int/lit8 v0, v1, 0x10

    or-int/2addr p1, v0

    shl-int/lit8 v0, v2, 0x8

    or-int/2addr p1, v0

    or-int/2addr p0, p1

    return p0
.end method


# virtual methods
.method public final a(J)V
    .locals 18

    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    iget-object v3, v0, Lal1;->c:Lwi1;

    if-eqz v3, :cond_0

    iget-wide v3, v3, Lwi1;->a:J

    cmp-long v3, v3, v1

    if-nez v3, :cond_0

    return-void

    :cond_0
    new-instance v3, Lwi1;

    iget-object v4, v0, Lal1;->a:Lvi1;

    iget-object v5, v4, Lvi1;->a:Lxi1;

    invoke-interface {v5, v1, v2}, Lxi1;->d(J)J

    move-result-wide v6

    iget-wide v10, v4, Lvi1;->c:J

    iget-wide v12, v4, Lvi1;->d:J

    iget-wide v14, v4, Lvi1;->e:J

    iget-wide v4, v4, Lvi1;->f:J

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-wide v1, v3, Lwi1;->a:J

    iput-wide v6, v3, Lwi1;->b:J

    const-wide/16 v1, 0x0

    iput-wide v1, v3, Lwi1;->d:J

    iput-wide v10, v3, Lwi1;->e:J

    iput-wide v12, v3, Lwi1;->f:J

    iput-wide v14, v3, Lwi1;->g:J

    iput-wide v4, v3, Lwi1;->c:J

    const-wide/16 v8, 0x0

    move-wide/from16 v16, v4

    invoke-static/range {v6 .. v17}, Lwi1;->a(JJJJJJ)J

    move-result-wide v1

    iput-wide v1, v3, Lwi1;->h:J

    iput-object v3, v0, Lal1;->c:Lwi1;

    return-void
.end method

.method public final b(Llj1;Loj1;)I
    .locals 27

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    :goto_0
    iget-object v3, v0, Lal1;->c:Lwi1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v4, v3, Lwi1;->f:J

    iget-wide v6, v3, Lwi1;->g:J

    iget-wide v8, v3, Lwi1;->h:J

    sub-long/2addr v6, v4

    iget v10, v0, Lal1;->d:I

    int-to-long v10, v10

    cmp-long v6, v6, v10

    const/4 v7, 0x0

    iget-object v10, v0, Lal1;->b:Lzi1;

    if-gtz v6, :cond_0

    iput-object v7, v0, Lal1;->c:Lwi1;

    invoke-interface {v10}, Lzi1;->d()V

    invoke-static {v1, v4, v5, v2}, Lal1;->c(Llj1;JLoj1;)I

    move-result v0

    return v0

    :cond_0
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v4

    sub-long v4, v8, v4

    const-wide/16 v11, 0x0

    cmp-long v6, v4, v11

    if-ltz v6, :cond_5

    const-wide/32 v13, 0x40000

    cmp-long v6, v4, v13

    if-gtz v6, :cond_5

    long-to-int v4, v4

    invoke-interface {v1, v4}, Llj1;->w(I)V

    invoke-interface {v1}, Llj1;->j()V

    iget-wide v4, v3, Lwi1;->b:J

    invoke-interface {v10, v1, v4, v5}, Lzi1;->e(Llj1;J)Lyi1;

    move-result-object v4

    iget v5, v4, Lyi1;->c:I

    move-wide v15, v11

    iget-wide v11, v4, Lyi1;->a:J

    move-wide/from16 v17, v13

    iget-wide v13, v4, Lyi1;->b:J

    const/4 v4, -0x3

    if-eq v5, v4, :cond_4

    const/4 v4, -0x2

    if-eq v5, v4, :cond_3

    const/4 v4, -0x1

    if-eq v5, v4, :cond_2

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v3

    sub-long v3, v13, v3

    cmp-long v5, v3, v15

    if-ltz v5, :cond_1

    cmp-long v5, v3, v17

    if-gtz v5, :cond_1

    long-to-int v3, v3

    invoke-interface {v1, v3}, Llj1;->w(I)V

    :cond_1
    iput-object v7, v0, Lal1;->c:Lwi1;

    invoke-interface {v10}, Lzi1;->d()V

    invoke-static {v1, v13, v14, v2}, Lal1;->c(Llj1;JLoj1;)I

    move-result v0

    return v0

    :cond_2
    iput-wide v11, v3, Lwi1;->e:J

    iput-wide v13, v3, Lwi1;->g:J

    iget-wide v4, v3, Lwi1;->b:J

    iget-wide v6, v3, Lwi1;->d:J

    iget-wide v8, v3, Lwi1;->f:J

    move-wide v15, v4

    iget-wide v4, v3, Lwi1;->c:J

    move-wide/from16 v25, v4

    move-wide/from16 v17, v6

    move-wide/from16 v21, v8

    move-wide/from16 v19, v11

    move-wide/from16 v23, v13

    invoke-static/range {v15 .. v26}, Lwi1;->a(JJJJJJ)J

    move-result-wide v4

    iput-wide v4, v3, Lwi1;->h:J

    goto/16 :goto_0

    :cond_3
    move-wide v4, v11

    move-wide v6, v13

    iput-wide v4, v3, Lwi1;->d:J

    iput-wide v6, v3, Lwi1;->f:J

    iget-wide v8, v3, Lwi1;->b:J

    iget-wide v10, v3, Lwi1;->e:J

    iget-wide v12, v3, Lwi1;->g:J

    iget-wide v14, v3, Lwi1;->c:J

    move-wide/from16 v17, v4

    move-wide/from16 v21, v6

    move-wide/from16 v19, v10

    move-wide/from16 v23, v12

    move-wide/from16 v25, v14

    move-wide v15, v8

    invoke-static/range {v15 .. v26}, Lwi1;->a(JJJJJJ)J

    move-result-wide v4

    iput-wide v4, v3, Lwi1;->h:J

    goto/16 :goto_0

    :cond_4
    iput-object v7, v0, Lal1;->c:Lwi1;

    invoke-interface {v10}, Lzi1;->d()V

    invoke-static {v1, v8, v9, v2}, Lal1;->c(Llj1;JLoj1;)I

    move-result v0

    return v0

    :cond_5
    invoke-static {v1, v8, v9, v2}, Lal1;->c(Llj1;JLoj1;)I

    move-result v0

    return v0
.end method
