.class public final synthetic Lan4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    iput p2, p0, Lan4;->h:I

    iput-object p1, p0, Lan4;->i:Ljava/lang/Object;

    iput-object p3, p0, Lan4;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lvs4;Lg21;I)V
    .locals 0

    .line 10
    iput p3, p0, Lan4;->h:I

    iput-object p2, p0, Lan4;->i:Ljava/lang/Object;

    iput-object p1, p0, Lan4;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lan4;->h:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lqz2;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Lcz4;

    invoke-interface {v0, p0}, Lqz2;->l(Ljava/lang/Object;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lux4;

    :try_start_0
    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Ljava/util/concurrent/Callable;

    invoke-interface {p0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v0, p0}, Lux4;->l(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception p0

    goto :goto_0

    :catch_0
    move-exception p0

    goto :goto_1

    :goto_0
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-direct {v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    invoke-virtual {v0, v1}, Lux4;->m(Ljava/lang/Exception;)V

    goto :goto_2

    :goto_1
    invoke-virtual {v0, p0}, Lux4;->m(Ljava/lang/Exception;)V

    :goto_2
    return-void

    :pswitch_1
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lix4;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Lav3;

    iget-object v1, v0, Lix4;->j:Lpx4;

    invoke-interface {v1}, Lpx4;->e()V

    iget-object v0, v0, Lix4;->i:Llx4;

    iget-object v1, v0, Llx4;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_1
    invoke-virtual {v0}, Llx4;->b()V

    invoke-virtual {p0}, Lav3;->run()V

    monitor-exit v1

    return-void

    :catchall_1
    move-exception p0

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw p0

    :pswitch_2
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Luv4;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/media/AudioRouting;

    invoke-interface {p0}, Landroid/media/AudioRouting;->getRoutedDevice()Landroid/media/AudioDeviceInfo;

    move-result-object p0

    if-eqz p0, :cond_0

    iget-object v1, v0, Luv4;->c:Ljava/lang/Object;

    check-cast v1, Landroid/os/Handler;

    new-instance v2, Lav3;

    const/16 v3, 0xb

    invoke-direct {v2, v0, v3, p0}, Lav3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void

    :pswitch_3
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lzy2;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Lcm4;

    monitor-enter p0

    monitor-exit p0

    sget-object p0, Lvh3;->a:Ljava/lang/String;

    iget-object p0, v0, Lzy2;->j:Ljava/lang/Object;

    check-cast p0, Lsn4;

    iget-object p0, p0, Lsn4;->h:Lhp4;

    iget-object p0, p0, Lhp4;->y:Lus4;

    iget-object v0, p0, Lus4;->d:Lfu1;

    iget-object v0, v0, Lfu1;->l:Ljava/lang/Object;

    check-cast v0, Lwy4;

    invoke-virtual {p0, v0}, Lus4;->w(Lwy4;)Lsr4;

    move-result-object v0

    new-instance v1, Lyd4;

    const/16 v2, 0x14

    invoke-direct {v1, v2}, Lyd4;-><init>(I)V

    const/16 v2, 0x3f5

    invoke-virtual {p0, v0, v2, v1}, Lus4;->s(Lsr4;ILx23;)V

    return-void

    :pswitch_4
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lni;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Lfm3;

    invoke-virtual {p0}, Lfm3;->a()Ld34;

    invoke-interface {v0}, Lni;->a()V

    return-void

    :pswitch_5
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lkt4;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/media/metrics/PlaybackMetrics;

    iget-object v0, v0, Lkt4;->k:Landroid/media/metrics/PlaybackSession;

    invoke-static {v0, p0}, Ljz0;->p(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackMetrics;)V

    return-void

    :pswitch_6
    iget-object v0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast v0, Lkt4;

    iget-object p0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/media/metrics/PlaybackStateEvent;

    iget-object v0, v0, Lkt4;->k:Landroid/media/metrics/PlaybackSession;

    invoke-static {v0, p0}, Lit4;->r(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackStateEvent;)V

    return-void

    :pswitch_7
    iget-object v0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast v0, Ley3;

    iget-object v1, v0, Ley3;->k:Ljava/lang/Object;

    check-cast v1, Lux4;

    :try_start_2
    iget-object v2, v0, Ley3;->j:Ljava/lang/Object;

    check-cast v2, Lw01;

    iget-object p0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast p0, Lg21;

    invoke-virtual {p0}, Lg21;->h()Ljava/lang/Object;

    move-result-object p0

    invoke-interface {v2, p0}, Lw01;->n(Ljava/lang/Object;)Lg21;

    move-result-object p0
    :try_end_2
    .catch Lju0; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/util/concurrent/CancellationException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    if-nez p0, :cond_1

    new-instance p0, Ljava/lang/NullPointerException;

    const-string v0, "Continuation returned null"

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Lux4;->m(Ljava/lang/Exception;)V

    goto :goto_5

    :cond_1
    sget-object v1, Lj21;->b:Lv6;

    invoke-virtual {p0, v1, v0}, Lg21;->d(Ljava/util/concurrent/Executor;Lhj0;)Lux4;

    invoke-virtual {p0, v1, v0}, Lg21;->c(Ljava/util/concurrent/Executor;Ldj0;)Lux4;

    check-cast p0, Lux4;

    new-instance v2, Ley3;

    invoke-direct {v2, v1, v0}, Ley3;-><init>(Ljava/util/concurrent/Executor;Laj0;)V

    iget-object v0, p0, Lux4;->b:Lyy;

    invoke-virtual {v0, v2}, Lyy;->i(Lvs4;)V

    invoke-virtual {p0}, Lux4;->p()V

    goto :goto_5

    :catch_1
    move-exception p0

    goto :goto_3

    :catch_2
    move-exception p0

    goto :goto_4

    :goto_3
    invoke-virtual {v1, p0}, Lux4;->m(Ljava/lang/Exception;)V

    goto :goto_5

    :catch_3
    invoke-virtual {v0}, Ley3;->f()V

    goto :goto_5

    :goto_4
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    instance-of v2, v2, Ljava/lang/Exception;

    if-eqz v2, :cond_2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    check-cast p0, Ljava/lang/Exception;

    invoke-virtual {v0, p0}, Ley3;->C(Ljava/lang/Exception;)V

    goto :goto_5

    :cond_2
    invoke-virtual {v1, p0}, Lux4;->m(Ljava/lang/Exception;)V

    :goto_5
    return-void

    :pswitch_8
    iget-object v0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast v0, Ley3;

    iget-object v1, v0, Ley3;->j:Ljava/lang/Object;

    monitor-enter v1

    :try_start_3
    iget-object v0, v0, Ley3;->k:Ljava/lang/Object;

    check-cast v0, Lhj0;

    iget-object p0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast p0, Lg21;

    invoke-virtual {p0}, Lg21;->h()Ljava/lang/Object;

    move-result-object p0

    invoke-interface {v0, p0}, Lhj0;->j(Ljava/lang/Object;)V

    monitor-exit v1

    return-void

    :catchall_2
    move-exception p0

    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    throw p0

    :pswitch_9
    iget-object v0, p0, Lan4;->j:Ljava/lang/Object;

    check-cast v0, Landroid/os/IBinder;

    iget-object p0, p0, Lan4;->i:Ljava/lang/Object;

    check-cast p0, Lks4;

    monitor-enter p0

    if-nez v0, :cond_3

    :try_start_4
    const-string v0, "Null service connection"

    invoke-virtual {p0, v0}, Lks4;->b(Ljava/lang/String;)V

    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    goto :goto_6

    :catchall_3
    move-exception v0

    goto :goto_7

    :cond_3
    :try_start_5
    new-instance v1, Lry2;

    invoke-direct {v1, v0}, Lry2;-><init>(Landroid/os/IBinder;)V

    iput-object v1, p0, Lks4;->j:Lry2;
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_5 .. :try_end_5} :catch_4
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    const/4 v0, 0x2

    :try_start_6
    iput v0, p0, Lks4;->h:I

    new-instance v0, Lql4;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lql4;-><init>(Lks4;I)V

    iget-object v1, p0, Lks4;->m:Lex4;

    iget-object v1, v1, Lex4;->k:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ScheduledExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    monitor-exit p0

    goto :goto_6

    :catch_4
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lks4;->b(Ljava/lang/String;)V

    monitor-exit p0

    :goto_6
    return-void

    :goto_7
    monitor-exit p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
