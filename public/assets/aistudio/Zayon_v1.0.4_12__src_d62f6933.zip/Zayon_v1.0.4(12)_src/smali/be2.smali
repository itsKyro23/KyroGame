.class public final Lbe2;
.super Lg7;
.source "SourceFile"


# instance fields
.field public final d:Ljava/util/Map;

.field public final e:Landroid/app/Activity;

.field public final f:Ljava/lang/String;

.field public final g:J

.field public final h:J

.field public final i:Ljava/lang/String;

.field public final j:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lsl2;Ljava/util/Map;)V
    .locals 2

    const-string v0, "createCalendarEvent"

    const/4 v1, 0x6

    invoke-direct {p0, p1, v1, v0}, Lg7;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iput-object p2, p0, Lbe2;->d:Ljava/util/Map;

    invoke-interface {p1}, Lsl2;->h()Landroid/app/Activity;

    move-result-object p1

    iput-object p1, p0, Lbe2;->e:Landroid/app/Activity;

    const-string p1, "description"

    invoke-virtual {p0, p1}, Lbe2;->v(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lbe2;->f:Ljava/lang/String;

    const-string p1, "summary"

    invoke-virtual {p0, p1}, Lbe2;->v(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lbe2;->i:Ljava/lang/String;

    const-string p1, "start_ticks"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-wide/16 v0, -0x1

    if-nez p1, :cond_0

    :catch_0
    move-wide p1, v0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iput-wide p1, p0, Lbe2;->g:J

    const-string p1, "end_ticks"

    iget-object p2, p0, Lbe2;->d:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    :try_start_1
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_1
    iput-wide v0, p0, Lbe2;->h:J

    const-string p1, "location"

    invoke-virtual {p0, p1}, Lbe2;->v(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lbe2;->j:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    iget-object p0, p0, Lbe2;->d:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, ""

    return-object p0

    :cond_0
    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
