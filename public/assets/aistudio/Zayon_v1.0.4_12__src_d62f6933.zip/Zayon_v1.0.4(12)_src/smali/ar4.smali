.class public final Lar4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroid/database/Cursor;
