.class public abstract Lb14;
.super Lg04;
.source "SourceFile"


# direct methods
.method public static s(Lna0;)Lb14;
    .locals 1

    instance-of v0, p0, Lb14;

    if-eqz v0, :cond_0

    check-cast p0, Lb14;

    return-object p0

    :cond_0
    new-instance v0, Lc14;

    invoke-direct {v0, p0}, Lc14;-><init>(Lna0;)V

    return-object v0
.end method
