.class public final Lav1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lav4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ldu1;

    invoke-direct {v0}, Ldu1;-><init>()V

    iget-object v0, v0, Ldu1;->a:Ldm0;

    invoke-virtual {v0}, Ldm0;->g()Lav4;

    sget-object v0, Lvh3;->a:Ljava/lang/String;

    const/4 v0, 0x0

    const/16 v1, 0x24

    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lav4;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lav1;->a:Lav4;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    instance-of v0, p1, Lav1;

    if-nez v0, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    check-cast p1, Lav1;

    iget-object p0, p0, Lav1;->a:Lav4;

    iget-object p1, p1, Lav1;->a:Lav4;

    invoke-virtual {p0, p1}, Lav4;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public final hashCode()I
    .locals 0

    iget-object p0, p0, Lav1;->a:Lav4;

    iget-object p0, p0, Lav4;->a:Landroid/util/SparseBooleanArray;

    invoke-virtual {p0}, Landroid/util/SparseBooleanArray;->hashCode()I

    move-result p0

    return p0
.end method
