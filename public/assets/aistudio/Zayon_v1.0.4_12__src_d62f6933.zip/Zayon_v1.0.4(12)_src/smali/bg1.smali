.class public final Lbg1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final j:Lax3;


# instance fields
.field public a:Lzp4;

.field public b:Lqg1;

.field public final c:Landroid/content/Context;

.field public d:Lsf1;

.field public e:Lsf1;

.field public volatile f:Ljava/lang/Thread;

.field public g:Ljl;

.field public h:Lbs2;

.field public i:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lax3;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lbg1;->j:Lax3;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    sget-object v0, Lsf1;->F:Lsf1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput-object v1, p0, Lbg1;->c:Landroid/content/Context;

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    new-instance v1, Lrf1;

    invoke-direct {v1, v0}, Lrf1;-><init>(Lsf1;)V

    invoke-virtual {v1, v0}, Ln52;->a(Lc62;)V

    new-instance v0, Lsf1;

    invoke-direct {v0, v1}, Lsf1;-><init>(Lrf1;)V

    :goto_1
    iput-object v0, p0, Lbg1;->d:Lsf1;

    iput-object v0, p0, Lbg1;->e:Lsf1;

    sget-object v1, Lbs2;->b:Lbs2;

    iput-object v1, p0, Lbg1;->h:Lbs2;

    iget-boolean p0, v0, Lsf1;->A:Z

    if-eqz p0, :cond_2

    if-nez p1, :cond_2

    const-string p0, "Audio channel count constraints cannot be applied without reference to Context. Build the track selector instance with one of the non-deprecated constructors that take a Context argument."

    invoke-static {p0}, Lhd1;->E(Ljava/lang/String;)V

    :cond_2
    return-void
.end method

.method public static a(Leg1;Lsf1;[Lcg1;)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    if-ge v0, v1, :cond_2

    iget-object v1, p0, Leg1;->a:[I

    aget v1, v1, v0

    iget-object v2, p1, Lsf1;->E:Landroid/util/SparseBooleanArray;

    invoke-virtual {v2, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, p1, Lc62;->v:Lsx3;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v2, v1}, Lgx3;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    :cond_0
    const/4 v1, 0x0

    aput-object v1, p2, v0

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public static b([Lcg1;I)Landroid/util/Pair;
    .locals 3

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    if-ge v0, v1, :cond_1

    aget-object v1, p0, v0

    if-eqz v1, :cond_0

    iget-object v2, v1, Lcg1;->a:Lt12;

    iget v2, v2, Lt12;->c:I

    if-ne v2, p1, :cond_0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object p0

    return-object p0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static final c(ILeg1;[[[ILuf1;Ljava/util/Comparator;)Landroid/util/Pair;
    .locals 18

    move-object/from16 v0, p1

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x0

    :goto_0
    const/4 v4, 0x2

    if-ge v3, v4, :cond_7

    iget-object v5, v0, Leg1;->a:[I

    aget v5, v5, v3

    move/from16 v6, p0

    if-ne v6, v5, :cond_6

    iget-object v5, v0, Leg1;->b:[Lb05;

    aget-object v5, v5, v3

    const/4 v7, 0x0

    :goto_1
    iget v8, v5, Lb05;->a:I

    if-ge v7, v8, :cond_6

    invoke-virtual {v5, v7}, Lb05;->a(I)Lt12;

    move-result-object v8

    aget-object v9, p2, v3

    aget-object v9, v9, v7

    move-object/from16 v10, p3

    invoke-interface {v10, v3, v8, v9}, Luf1;->h(ILt12;[I)Lqy3;

    move-result-object v9

    iget v8, v8, Lt12;->a:I

    new-array v11, v8, [Z

    const/4 v12, 0x0

    :goto_2
    if-ge v12, v8, :cond_5

    add-int/lit8 v13, v12, 0x1

    invoke-virtual {v9, v12}, Lqy3;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lzf1;

    invoke-virtual {v14}, Lzf1;->a()I

    move-result v15

    aget-boolean v12, v11, v12

    if-nez v12, :cond_4

    if-nez v15, :cond_0

    goto :goto_5

    :cond_0
    const/4 v12, 0x1

    if-ne v15, v12, :cond_1

    invoke-static {v14}, Lmx3;->j(Ljava/lang/Object;)Lqy3;

    move-result-object v12

    goto :goto_4

    :cond_1
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v15, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v16, v12

    move v12, v13

    :goto_3
    if-ge v12, v8, :cond_3

    invoke-virtual {v9, v12}, Lqy3;->get(I)Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v2, v17

    check-cast v2, Lzf1;

    invoke-virtual {v2}, Lzf1;->a()I

    move-result v0

    if-ne v0, v4, :cond_2

    invoke-virtual {v14, v2}, Lzf1;->b(Lzf1;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {v15, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    aput-boolean v16, v11, v12

    :cond_2
    add-int/lit8 v12, v12, 0x1

    move-object/from16 v0, p1

    goto :goto_3

    :cond_3
    move-object v12, v15

    :goto_4
    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    :goto_5
    move-object/from16 v0, p1

    move v12, v13

    goto :goto_2

    :cond_5
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v0, p1

    goto :goto_1

    :cond_6
    move-object/from16 v10, p3

    add-int/lit8 v3, v3, 0x1

    move-object/from16 v0, p1

    goto/16 :goto_0

    :cond_7
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 v0, 0x0

    return-object v0

    :cond_8
    move-object/from16 v0, p4

    invoke-static {v1, v0}, Ljava/util/Collections;->max(Ljava/util/Collection;Ljava/util/Comparator;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    new-array v1, v1, [I

    const/4 v2, 0x0

    :goto_6
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_9

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lzf1;

    iget v3, v3, Lzf1;->j:I

    aput v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_9
    const/4 v2, 0x0

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lzf1;

    new-instance v2, Lcg1;

    iget-object v3, v0, Lzf1;->i:Lt12;

    invoke-direct {v2, v3, v1}, Lcg1;-><init>(Lt12;[I)V

    iget v0, v0, Lzf1;->h:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    move-result-object v0

    return-object v0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "und"

    invoke-static {p0, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    return-object p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static h(Lfx4;Ljava/lang/String;Z)I
    .locals 2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lfx4;->d:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x4

    return p0

    :cond_0
    invoke-static {p1}, Lbg1;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lfx4;->d:Ljava/lang/String;

    invoke-static {p0}, Lbg1;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_5

    if-nez p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_4

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_2

    goto :goto_0

    :cond_2
    sget-object p2, Lvh3;->a:Ljava/lang/String;

    const-string p2, "-"

    const/4 v1, 0x2

    invoke-virtual {p0, p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    aget-object p0, p0, v0

    invoke-virtual {p1, p2, v1}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p1

    aget-object p1, p1, v0

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    return v1

    :cond_3
    return v0

    :cond_4
    :goto_0
    const/4 p0, 0x3

    return p0

    :cond_5
    :goto_1
    if-eqz p2, :cond_6

    if-nez p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    return v0
.end method

.method public static synthetic i(Lfx4;Lmx3;)I
    .locals 5

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->size()I

    move-result v2

    if-ge v1, v2, :cond_2

    move v2, v0

    :goto_1
    iget-object v3, p0, Lfx4;->c:Lmx3;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v4

    if-ge v2, v4, :cond_1

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Liy4;

    iget-object v3, v3, Liy4;->b:Ljava/lang/String;

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    return v1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const p0, 0x7fffffff

    return p0
.end method

.method public static final j(Lb05;[[ILsf1;)Lcg1;
    .locals 13

    iget-object v0, p2, Lc62;->q:Ld52;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x0

    move v2, v0

    move v4, v2

    move-object v3, v1

    move-object v5, v3

    :goto_0
    iget v6, p0, Lb05;->a:I

    if-ge v2, v6, :cond_3

    invoke-virtual {p0, v2}, Lb05;->a(I)Lt12;

    move-result-object v6

    aget-object v7, p1, v2

    move v8, v0

    :goto_1
    iget v9, v6, Lt12;->a:I

    if-ge v8, v9, :cond_2

    aget v9, v7, v8

    iget-boolean v10, p2, Lsf1;->B:Z

    invoke-static {v9, v10}, Lxx4;->J(IZ)Z

    move-result v9

    if-eqz v9, :cond_1

    iget-object v9, v6, Lt12;->d:[Lfx4;

    aget-object v9, v9, v8

    new-instance v10, Lqf1;

    aget v11, v7, v8

    invoke-direct {v10, v9, v11}, Lqf1;-><init>(Lfx4;I)V

    if-eqz v5, :cond_0

    iget-boolean v9, v10, Lqf1;->i:Z

    iget-boolean v11, v5, Lqf1;->i:Z

    sget-object v12, Ldx3;->a:Lbx3;

    invoke-virtual {v12, v9, v11}, Lbx3;->d(ZZ)Ldx3;

    move-result-object v9

    iget-boolean v11, v10, Lqf1;->h:Z

    iget-boolean v12, v5, Lqf1;->h:Z

    invoke-virtual {v9, v11, v12}, Ldx3;->d(ZZ)Ldx3;

    move-result-object v9

    invoke-virtual {v9}, Ldx3;->e()I

    move-result v9

    if-lez v9, :cond_1

    :cond_0
    move-object v3, v6

    move v4, v8

    move-object v5, v10

    :cond_1
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    if-nez v3, :cond_4

    return-object v1

    :cond_4
    new-instance p0, Lcg1;

    filled-new-array {v4}, [I

    move-result-object p1

    invoke-direct {p0, v3, p1}, Lcg1;-><init>(Lt12;[I)V

    return-object p0
.end method

.method public static k(Leg1;Lc62;)V
    .locals 6

    iget-object p1, p1, Lc62;->u:Lwy3;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/4 v3, 0x2

    if-ge v2, v3, :cond_2

    iget-object v3, p0, Leg1;->b:[Lb05;

    aget-object v3, v3, v2

    move v4, v1

    :goto_1
    iget v5, v3, Lb05;->a:I

    if-ge v4, v5, :cond_1

    invoke-virtual {v3, v4}, Lb05;->a(I)Lt12;

    move-result-object v5

    invoke-virtual {p1, v5}, Lwy3;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_0

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_0
    invoke-static {}, Lnu0;->f()V

    return-void

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    iget-object v2, p0, Leg1;->d:Lb05;

    move v4, v1

    :goto_2
    iget v5, v2, Lb05;->a:I

    if-ge v4, v5, :cond_4

    invoke-virtual {v2, v4}, Lb05;->a(I)Lt12;

    move-result-object v5

    invoke-virtual {p1, v5}, Lwy3;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_3

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_3
    invoke-static {}, Lnu0;->f()V

    return-void

    :cond_4
    :goto_3
    if-ge v1, v3, :cond_6

    iget-object p1, p0, Leg1;->a:[I

    aget p1, p1, v1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_5

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_5
    invoke-static {}, Lnu0;->f()V

    :cond_6
    return-void
.end method

.method public static l(Leg1;Lsf1;[Lcg1;)V
    .locals 3

    iget-object p1, p1, Lsf1;->D:Landroid/util/SparseArray;

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x2

    if-ge v0, v1, :cond_3

    iget-object v1, p0, Leg1;->b:[Lb05;

    aget-object v1, v1, v0

    invoke-virtual {p1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    if-eqz v2, :cond_2

    invoke-interface {v2, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map;

    if-eqz v2, :cond_1

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    invoke-static {}, Lnu0;->f()V

    return-void

    :cond_1
    :goto_1
    const/4 v1, 0x0

    aput-object v1, p2, v0

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_3
    return-void
.end method


# virtual methods
.method public final d(Lc62;)V
    .locals 2

    if-nez p1, :cond_0

    return-void

    :cond_0
    instance-of v0, p1, Lsf1;

    if-eqz v0, :cond_1

    check-cast p1, Lsf1;

    iput-object p1, p0, Lbg1;->e:Lsf1;

    return-void

    :cond_1
    new-instance v0, Lrf1;

    iget-object v1, p0, Lbg1;->e:Lsf1;

    invoke-direct {v0, v1}, Lrf1;-><init>(Lsf1;)V

    invoke-virtual {v0, p1}, Ln52;->a(Lc62;)V

    new-instance p1, Lsf1;

    invoke-direct {p1, v0}, Lsf1;-><init>(Lrf1;)V

    iput-object p1, p0, Lbg1;->e:Lsf1;

    return-void
.end method

.method public final e()V
    .locals 4

    iget-object v0, p0, Lbg1;->f:Ljava/lang/Thread;

    if-eqz v0, :cond_0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    iget-object v1, p0, Lbg1;->f:Ljava/lang/Thread;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "DefaultTrackSelector is accessed on the wrong thread."

    invoke-static {v1, v0}, La60;->E(Ljava/lang/String;Z)V

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x20

    const/4 v2, 0x0

    if-lt v0, v1, :cond_3

    iget-object v0, p0, Lbg1;->g:Ljl;

    if-eqz v0, :cond_3

    iget-object v1, v0, Ljl;->i:Ljava/lang/Object;

    check-cast v1, Landroid/media/Spatializer;

    if-eqz v1, :cond_2

    iget-object v3, v0, Ljl;->k:Ljava/lang/Object;

    check-cast v3, Lvg1;

    if-eqz v3, :cond_2

    iget-object v0, v0, Ljl;->j:Ljava/lang/Object;

    check-cast v0, Landroid/os/Handler;

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {v1, v3}, La2;->g(Landroid/media/Spatializer;Lvg1;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_2
    :goto_0
    iput-object v2, p0, Lbg1;->g:Ljl;

    :cond_3
    iput-object v2, p0, Lbg1;->a:Lzp4;

    iput-object v2, p0, Lbg1;->b:Lqg1;

    return-void
.end method

.method public final f(Lbs2;)V
    .locals 1

    iget-object v0, p0, Lbg1;->h:Lbs2;

    invoke-virtual {v0, p1}, Lbs2;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iput-object p1, p0, Lbg1;->h:Lbs2;

    iget-object p1, p0, Lbg1;->e:Lsf1;

    iget-boolean p1, p1, Lsf1;->A:Z

    if-eqz p1, :cond_1

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x20

    if-lt p1, v0, :cond_1

    iget-object p1, p0, Lbg1;->g:Ljl;

    if-eqz p1, :cond_1

    iget-boolean p1, p1, Ljl;->h:Z

    if-eqz p1, :cond_1

    iget-object p0, p0, Lbg1;->a:Lzp4;

    if-eqz p0, :cond_1

    iget-object p0, p0, Lzp4;->n:Ltf3;

    const/16 p1, 0xa

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Ltf3;->c(ILjava/lang/Object;)Lpf3;

    move-result-object p0

    invoke-virtual {p0}, Lpf3;->a()V

    :cond_1
    :goto_0
    return-void
.end method
