.class public final synthetic Lak2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Lgk2;


# direct methods
.method public synthetic constructor <init>(Lgk2;I)V
    .locals 0

    iput p2, p0, Lak2;->h:I

    iput-object p1, p0, Lak2;->i:Lgk2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lak2;->h:I

    iget-object p0, p0, Lak2;->i:Lgk2;

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lnj2;->i:Lzj2;

    iget-boolean v1, v0, Lzj2;->e:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    iget v1, v0, Lzj2;->f:F

    :goto_0
    iget-boolean v0, v0, Lzj2;->c:Z

    if-eqz v0, :cond_1

    move v2, v1

    :cond_1
    iget-object p0, p0, Lgk2;->p:Lkl2;

    if-eqz p0, :cond_2

    :try_start_0
    iget-object p0, p0, Lkl2;->n:Lqr4;

    if-eqz p0, :cond_3

    iget-object v0, p0, Lqr4;->k:Lfz2;

    invoke-virtual {v0}, Lfz2;->b()V

    iget-object p0, p0, Lqr4;->j:Lhp4;

    invoke-virtual {p0, v2}, Lhp4;->X1(F)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    sget p0, Lj23;->b:I

    const/4 p0, 0x5

    invoke-static {p0}, Lj23;->j(I)Z

    goto :goto_1

    :cond_2
    sget p0, Lj23;->b:I

    const-string p0, "Trying to set volume before player is initialized."

    invoke-static {p0}, Lj23;->g(Ljava/lang/String;)V

    :cond_3
    :goto_1
    return-void

    :pswitch_0
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_4

    invoke-virtual {p0}, Lsj2;->i()V

    :cond_4
    return-void

    :pswitch_1
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_5

    iget-object v0, p0, Lsj2;->l:Lrj2;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lrj2;->j:Z

    sget-object v2, Lzu4;->l:Lrc3;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v3, 0xfa

    invoke-virtual {v2, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    new-instance v0, Loj2;

    invoke-direct {v0, p0, v1}, Loj2;-><init>(Lsj2;I)V

    invoke-virtual {v2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_5
    return-void

    :pswitch_2
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_6

    invoke-virtual {p0}, Lsj2;->g()V

    :cond_6
    return-void

    :pswitch_3
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Lsj2;->f()V

    :cond_7
    return-void

    :pswitch_4
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_8

    invoke-virtual {p0}, Lsj2;->h()V

    :cond_8
    return-void

    :pswitch_5
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Lsj2;->k()V

    :cond_9
    return-void

    :pswitch_6
    iget-object p0, p0, Lgk2;->n:Lsj2;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Lsj2;->e()V

    :cond_a
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
