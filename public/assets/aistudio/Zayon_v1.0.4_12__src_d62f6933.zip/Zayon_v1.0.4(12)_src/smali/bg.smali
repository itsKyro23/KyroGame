.class public final Lbg;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lhg1;


# instance fields
.field public h:I

.field public i:I

.field public j:I

.field public k:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lbg;->j:I

    const/16 v0, 0x64

    new-array v0, v0, [Lgg1;

    iput-object v0, p0, Lbg;->k:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lag;)V
    .locals 1

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 16
    iput v0, p0, Lbg;->j:I

    .line 17
    sget-object v0, Lf60;->a:Ljava/nio/charset/Charset;

    iput-object p1, p0, Lbg;->k:Ljava/lang/Object;

    .line 18
    iput-object p0, p1, Lag;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcg4;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lbg;->j:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lbg;->k:Ljava/lang/Object;

    iput-object p0, p1, Lcg4;->c:Lbg;

    return-void
.end method

.method public static final X(I)V
    .locals 0

    and-int/lit8 p0, p0, 0x3

    if-nez p0, :cond_0

    return-void

    :cond_0
    const-string p0, "Failed to parse the message."

    invoke-static {p0}, Lnu0;->l(Ljava/lang/String;)V

    return-void
.end method

.method public static final Y(I)V
    .locals 0

    and-int/lit8 p0, p0, 0x7

    if-nez p0, :cond_0

    return-void

    :cond_0
    const-string p0, "Failed to parse the message."

    invoke-static {p0}, Lnu0;->l(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public A(I)V
    .locals 0

    iget p0, p0, Lbg;->h:I

    and-int/lit8 p0, p0, 0x7

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0
.end method

.method public B()Z
    .locals 2

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-nez v1, :cond_1

    iget v1, p0, Lbg;->h:I

    iget p0, p0, Lbg;->i:I

    if-ne v1, p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Lag;->x(I)Z

    move-result p0

    return p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return p0
.end method

.method public C(Lug4;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Lch4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lch4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->o()J

    move-result-wide v3

    invoke-virtual {v1, v3, v4}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->o()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->o()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->o()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public D(Lug4;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->p()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->p()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->p()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->p()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public E(Lug4;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Lch4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lch4;

    and-int/lit8 p1, v2, 0x7

    if-eq p1, v4, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->Y(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    add-int/2addr p1, p0

    :cond_0
    invoke-virtual {v0}, Lcg4;->q()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, p1, :cond_0

    goto :goto_1

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->q()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eq v1, v4, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->Y(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_5
    invoke-virtual {v0}, Lcg4;->q()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_5

    goto :goto_1

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->q()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public F(Lug4;)V
    .locals 6

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_5

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eq p1, v4, :cond_3

    if-ne p1, v3, :cond_2

    :cond_0
    invoke-virtual {v0}, Lcg4;->r()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_0

    goto :goto_0

    :cond_2
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_3
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->X(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    add-int v5, p1, p0

    :cond_4
    invoke-virtual {v0}, Lcg4;->r()I

    move-result p0

    invoke-virtual {v1, p0}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v5, :cond_4

    goto :goto_1

    :cond_5
    and-int/lit8 v1, v2, 0x7

    if-eq v1, v4, :cond_8

    if-ne v1, v3, :cond_7

    :cond_6
    invoke-virtual {v0}, Lcg4;->r()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_a

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_6

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    return-void

    :cond_7
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_8
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->X(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_9
    invoke-virtual {v0}, Lcg4;->r()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_9

    :cond_a
    :goto_1
    return-void
.end method

.method public G(Lug4;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lcg4;->s()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->s()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_3

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    :cond_3
    return-void
.end method

.method public H(Lug4;Z)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3

    :cond_0
    if-eqz p2, :cond_1

    invoke-virtual {p0, v2}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->u()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v2}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->t()Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-eqz v1, :cond_2

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v3, p0, Lbg;->h:I

    if-eq v1, v3, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_3
    invoke-static {}, Lnu0;->m()V

    return-void
.end method

.method public I(Lug4;Loh4;Lgg4;)V
    .locals 3

    iget v0, p0, Lbg;->h:I

    and-int/lit8 v1, v0, 0x7

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3

    :cond_0
    invoke-interface {p2}, Loh4;->a()Lng4;

    move-result-object v1

    invoke-virtual {p0, v1, p2, p3}, Lbg;->T(Ljava/lang/Object;Loh4;Lgg4;)V

    invoke-interface {p2, v1}, Loh4;->c(Ljava/lang/Object;)V

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v1, Lcg4;

    invoke-virtual {v1}, Lcg4;->d()Z

    move-result v2

    if-nez v2, :cond_2

    iget v2, p0, Lbg;->j:I

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Lcg4;->i()I

    move-result v1

    if-eq v1, v0, :cond_0

    iput v1, p0, Lbg;->j:I

    :cond_2
    :goto_0
    return-void

    :cond_3
    invoke-static {}, Lnu0;->m()V

    return-void
.end method

.method public J(Lug4;Loh4;Lgg4;)V
    .locals 3

    iget v0, p0, Lbg;->h:I

    and-int/lit8 v1, v0, 0x7

    const/4 v2, 0x3

    if-ne v1, v2, :cond_3

    :cond_0
    invoke-interface {p2}, Loh4;->a()Lng4;

    move-result-object v1

    invoke-virtual {p0, v1, p2, p3}, Lbg;->U(Ljava/lang/Object;Loh4;Lgg4;)V

    invoke-interface {p2, v1}, Loh4;->c(Ljava/lang/Object;)V

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v1, Lcg4;

    invoke-virtual {v1}, Lcg4;->d()Z

    move-result v2

    if-nez v2, :cond_2

    iget v2, p0, Lbg;->j:I

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Lcg4;->i()I

    move-result v1

    if-eq v1, v0, :cond_0

    iput v1, p0, Lbg;->j:I

    :cond_2
    :goto_0
    return-void

    :cond_3
    invoke-static {}, Lnu0;->m()V

    return-void
.end method

.method public K(Lug4;)V
    .locals 2

    iget v0, p0, Lbg;->h:I

    and-int/lit8 v0, v0, 0x7

    const/4 v1, 0x2

    if-ne v0, v1, :cond_2

    :cond_0
    invoke-virtual {p0}, Lbg;->e0()Lyf4;

    move-result-object v0

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-eqz v1, :cond_1

    return-void

    :cond_1
    invoke-virtual {v0}, Lcg4;->i()I

    move-result v0

    iget v1, p0, Lbg;->h:I

    if-eq v0, v1, :cond_0

    iput v0, p0, Lbg;->j:I

    return-void

    :cond_2
    invoke-static {}, Lnu0;->m()V

    return-void
.end method

.method public L(Lug4;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public M(Lug4;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->x()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->x()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->x()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->x()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public N(Lug4;)V
    .locals 6

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_5

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eq p1, v4, :cond_3

    if-ne p1, v3, :cond_2

    :cond_0
    invoke-virtual {v0}, Lcg4;->y()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_0

    goto :goto_0

    :cond_2
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_3
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->X(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    add-int v5, p1, p0

    :cond_4
    invoke-virtual {v0}, Lcg4;->y()I

    move-result p0

    invoke-virtual {v1, p0}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v5, :cond_4

    goto :goto_1

    :cond_5
    and-int/lit8 v1, v2, 0x7

    if-eq v1, v4, :cond_8

    if-ne v1, v3, :cond_7

    :cond_6
    invoke-virtual {v0}, Lcg4;->y()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_a

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_6

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    return-void

    :cond_7
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_8
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->X(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_9
    invoke-virtual {v0}, Lcg4;->y()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_9

    :cond_a
    :goto_1
    return-void
.end method

.method public O(Lug4;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Lch4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lch4;

    and-int/lit8 p1, v2, 0x7

    if-eq p1, v4, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->Y(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    add-int/2addr p1, p0

    :cond_0
    invoke-virtual {v0}, Lcg4;->z()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, p1, :cond_0

    goto :goto_1

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->z()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eq v1, v4, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->Y(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_5
    invoke-virtual {v0}, Lcg4;->z()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_5

    goto :goto_1

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->z()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public P(Lug4;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Log4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Log4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->A()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->A()I

    move-result p1

    invoke-virtual {v1, p1}, Log4;->e(I)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->A()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->A()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public Q(Lug4;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Lch4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lch4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->B()J

    move-result-wide v3

    invoke-virtual {v1, v3, v4}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->B()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->B()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->B()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public R(Leh4;Lwg3;Lgg4;)V
    .locals 11

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lbg;->S(I)V

    iget-object v1, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v1, Lcg4;

    invoke-virtual {v1}, Lcg4;->w()I

    move-result v2

    invoke-virtual {v1, v2}, Lcg4;->a(I)I

    move-result v2

    iget-object v3, p2, Lwg3;->k:Ljava/lang/Object;

    const-string v4, ""

    move-object v5, v3

    :goto_0
    :try_start_0
    invoke-virtual {p0}, Lbg;->a0()I

    move-result v6

    const v7, 0x7fffffff

    if-eq v6, v7, :cond_9

    invoke-virtual {v1}, Lcg4;->d()Z

    move-result v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v7, :cond_0

    goto :goto_5

    :cond_0
    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v9, "Unable to parse map entry."

    if-eq v6, v7, :cond_5

    if-eq v6, v0, :cond_4

    :try_start_1
    invoke-virtual {v1}, Lcg4;->d()Z

    move-result v6

    if-nez v6, :cond_2

    iget v6, p0, Lbg;->h:I

    iget v7, p0, Lbg;->i:I

    if-ne v6, v7, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1, v6}, Lcg4;->k(I)Z

    move-result v6

    goto :goto_2

    :cond_2
    :goto_1
    move v6, v8

    :goto_2
    if-eqz v6, :cond_3

    goto :goto_0

    :cond_3
    new-instance v6, Lyg4;

    invoke-direct {v6, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v6

    :catchall_0
    move-exception p0

    goto :goto_6

    :catch_0
    move-exception v6

    goto :goto_3

    :cond_4
    iget-object v6, p2, Lwg3;->j:Ljava/lang/Object;

    check-cast v6, Lai4;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    invoke-virtual {p0, v6, v7, p3}, Lbg;->V(Lai4;Ljava/lang/Class;Lgg4;)Ljava/lang/Object;

    move-result-object v5

    goto :goto_0

    :cond_5
    iget-object v6, p2, Lwg3;->i:Ljava/lang/Object;

    check-cast v6, Lai4;

    const/4 v7, 0x0

    invoke-virtual {p0, v6, v7, v7}, Lbg;->V(Lai4;Ljava/lang/Class;Lgg4;)Ljava/lang/Object;

    move-result-object v4
    :try_end_1
    .catch Lxg4; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_3
    :try_start_2
    invoke-virtual {v1}, Lcg4;->d()Z

    move-result v7

    if-nez v7, :cond_7

    iget v7, p0, Lbg;->h:I

    iget v10, p0, Lbg;->i:I

    if-ne v7, v10, :cond_6

    goto :goto_4

    :cond_6
    invoke-virtual {v1, v7}, Lcg4;->k(I)Z

    move-result v8

    :cond_7
    :goto_4
    if-eqz v8, :cond_8

    goto :goto_0

    :cond_8
    new-instance p0, Lyg4;

    invoke-direct {p0, v9, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p0

    :cond_9
    :goto_5
    invoke-virtual {p1, v4, v5}, Leh4;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1}, Lcg4;->c()I

    move-result p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-nez p0, :cond_a

    invoke-virtual {v1, v2}, Lcg4;->b(I)V

    return-void

    :cond_a
    :try_start_3
    new-instance p0, Lyg4;

    const-string p1, "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_6
    invoke-virtual {v1, v2}, Lcg4;->b(I)V

    throw p0
.end method

.method public S(I)V
    .locals 0

    iget p0, p0, Lbg;->h:I

    and-int/lit8 p0, p0, 0x7

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lnu0;->m()V

    return-void
.end method

.method public T(Ljava/lang/Object;Loh4;Lgg4;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    invoke-virtual {v0}, Lcg4;->C()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->g()V

    invoke-virtual {v0, v1}, Lcg4;->a(I)I

    move-result v1

    iget v2, v0, Lcg4;->a:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, Lcg4;->a:I

    invoke-interface {p2, p1, p0, p3}, Loh4;->e(Ljava/lang/Object;Lbg;Lgg4;)V

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, Lcg4;->j(I)V

    iget p0, v0, Lcg4;->a:I

    add-int/lit8 p0, p0, -0x1

    iput p0, v0, Lcg4;->a:I

    invoke-virtual {v0}, Lcg4;->c()I

    move-result p0

    if-nez p0, :cond_0

    invoke-virtual {v0, v1}, Lcg4;->b(I)V

    return-void

    :cond_0
    const-string p0, "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length."

    invoke-static {p0}, Lnu0;->l(Ljava/lang/String;)V

    return-void
.end method

.method public U(Ljava/lang/Object;Loh4;Lgg4;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    invoke-virtual {v0}, Lcg4;->g()V

    iget v1, p0, Lbg;->i:I

    iget v2, p0, Lbg;->h:I

    ushr-int/lit8 v2, v2, 0x3

    shl-int/lit8 v2, v2, 0x3

    or-int/lit8 v2, v2, 0x4

    iput v2, p0, Lbg;->i:I

    iget v2, v0, Lcg4;->b:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, Lcg4;->b:I

    :try_start_0
    invoke-interface {p2, p1, p0, p3}, Loh4;->e(Ljava/lang/Object;Lbg;Lgg4;)V

    iget p1, p0, Lbg;->h:I

    iget p2, p0, Lbg;->i:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ne p1, p2, :cond_0

    iget p1, v0, Lcg4;->b:I

    add-int/lit8 p1, p1, -0x1

    iput p1, v0, Lcg4;->b:I

    iput v1, p0, Lbg;->i:I

    return-void

    :cond_0
    :try_start_1
    new-instance p1, Lyg4;

    const-string p2, "Failed to parse the message."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    iget p2, v0, Lcg4;->b:I

    add-int/lit8 p2, p2, -0x1

    iput p2, v0, Lcg4;->b:I

    iput v1, p0, Lbg;->i:I

    throw p1
.end method

.method public V(Lai4;Ljava/lang/Class;Lgg4;)Ljava/lang/Object;
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    sget-object v1, Lai4;->j:Lai4;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    const-string p0, "unsupported field type."

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_1
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->B()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_2
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->A()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_3
    invoke-virtual {p0, v3}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->z()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_4
    invoke-virtual {p0, v2}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->y()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_5
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->x()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_6
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_7
    invoke-virtual {p0}, Lbg;->e0()Lyf4;

    move-result-object p0

    return-object p0

    :pswitch_8
    invoke-virtual {p0, v1}, Lbg;->S(I)V

    sget-object p1, Ljh4;->b:Ljh4;

    invoke-virtual {p1, p2}, Ljh4;->a(Ljava/lang/Class;)Loh4;

    move-result-object p1

    invoke-interface {p1}, Loh4;->a()Lng4;

    move-result-object p2

    invoke-virtual {p0, p2, p1, p3}, Lbg;->T(Ljava/lang/Object;Loh4;Lgg4;)V

    invoke-interface {p1, p2}, Loh4;->c(Ljava/lang/Object;)V

    return-object p2

    :pswitch_9
    invoke-virtual {p0, v1}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->u()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->s()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_b
    invoke-virtual {p0, v2}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->r()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_c
    invoke-virtual {p0, v3}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->q()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_d
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->p()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_e
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->n()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_f
    invoke-virtual {p0, v4}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->o()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_10
    invoke-virtual {p0, v2}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->m()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    return-object p0

    :pswitch_11
    invoke-virtual {p0, v3}, Lbg;->S(I)V

    invoke-virtual {v0}, Lcg4;->l()D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public W(I)V
    .locals 0

    iget-object p0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast p0, Lcg4;

    invoke-virtual {p0}, Lcg4;->e()I

    move-result p0

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    const-string p0, "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length."

    invoke-static {p0}, Lnu0;->l(Ljava/lang/String;)V

    return-void
.end method

.method public Z()Z
    .locals 2

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, [B

    iget v1, p0, Lbg;->i:I

    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    iget v1, p0, Lbg;->j:I

    shr-int/2addr v0, v1

    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lbg;->c0(I)V

    and-int/lit8 p0, v0, 0x1

    if-eq v1, p0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    return v1
.end method

.method public declared-synchronized a()Lgg1;
    .locals 4

    monitor-enter p0

    :try_start_0
    iget v0, p0, Lbg;->i:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lbg;->i:I

    iget v1, p0, Lbg;->j:I

    if-lez v1, :cond_1

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, [Lgg1;

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lbg;->j:I

    aget-object v2, v0, v1

    const/4 v3, 0x0

    if-eqz v2, :cond_0

    aput-object v3, v0, v1

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    throw v3

    :cond_1
    new-instance v2, Lgg1;

    const/high16 v1, 0x10000

    new-array v1, v1, [B

    invoke-direct {v2, v1}, Lgg1;-><init>([B)V

    iget-object v1, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v1, [Lgg1;

    array-length v3, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-gt v0, v3, :cond_2

    :goto_0
    monitor-exit p0

    return-object v2

    :cond_2
    add-int/2addr v3, v3

    :try_start_1
    invoke-static {v1, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lgg1;

    iput-object v0, p0, Lbg;->k:Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-object v2

    :goto_1
    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public a0()I
    .locals 2

    iget v0, p0, Lbg;->j:I

    if-eqz v0, :cond_0

    iput v0, p0, Lbg;->h:I

    const/4 v1, 0x0

    iput v1, p0, Lbg;->j:I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v0

    iput v0, p0, Lbg;->h:I

    :goto_0
    if-eqz v0, :cond_2

    iget p0, p0, Lbg;->i:I

    if-ne v0, p0, :cond_1

    goto :goto_1

    :cond_1
    ushr-int/lit8 p0, v0, 0x3

    return p0

    :cond_2
    :goto_1
    const p0, 0x7fffffff

    return p0
.end method

.method public b()I
    .locals 2

    iget v0, p0, Lbg;->j:I

    if-eqz v0, :cond_0

    iput v0, p0, Lbg;->h:I

    const/4 v1, 0x0

    iput v1, p0, Lbg;->j:I

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    invoke-virtual {v0}, Lag;->u()I

    move-result v0

    iput v0, p0, Lbg;->h:I

    :goto_0
    if-eqz v0, :cond_2

    iget p0, p0, Lbg;->i:I

    if-ne v0, p0, :cond_1

    goto :goto_1

    :cond_1
    ushr-int/lit8 p0, v0, 0x3

    return p0

    :cond_2
    :goto_1
    const p0, 0x7fffffff

    return p0
.end method

.method public b0(I)I
    .locals 6

    iget v0, p0, Lbg;->i:I

    iget v1, p0, Lbg;->j:I

    rsub-int/lit8 v1, v1, 0x8

    add-int/lit8 v2, v0, 0x1

    iget-object v3, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v3, [B

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    aget-byte v0, v3, v0

    const/16 v4, 0xff

    and-int/2addr v0, v4

    iget v5, p0, Lbg;->j:I

    shr-int/2addr v0, v5

    rsub-int/lit8 v5, v1, 0x8

    shr-int v5, v4, v5

    and-int/2addr v0, v5

    :goto_0
    if-ge v1, p1, :cond_0

    add-int/lit8 v5, v2, 0x1

    aget-byte v2, v3, v2

    and-int/2addr v2, v4

    shl-int/2addr v2, v1

    or-int/2addr v0, v2

    add-int/lit8 v1, v1, 0x8

    move v2, v5

    goto :goto_0

    :cond_0
    rsub-int/lit8 v1, p1, 0x20

    const/4 v2, -0x1

    ushr-int v1, v2, v1

    and-int/2addr v0, v1

    invoke-virtual {p0, p1}, Lbg;->c0(I)V

    return v0
.end method

.method public c(Ljava/lang/Object;Lpv0;Lut;)V
    .locals 2

    iget v0, p0, Lbg;->i:I

    iget v1, p0, Lbg;->h:I

    ushr-int/lit8 v1, v1, 0x3

    shl-int/lit8 v1, v1, 0x3

    or-int/lit8 v1, v1, 0x4

    iput v1, p0, Lbg;->i:I

    :try_start_0
    invoke-interface {p2, p1, p0, p3}, Lpv0;->h(Ljava/lang/Object;Lbg;Lut;)V

    iget p1, p0, Lbg;->h:I

    iget p2, p0, Lbg;->i:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ne p1, p2, :cond_0

    iput v0, p0, Lbg;->i:I

    return-void

    :cond_0
    :try_start_1
    new-instance p1, Lo60;

    const-string p2, "Failed to parse the message."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    iput v0, p0, Lbg;->i:I

    throw p1
.end method

.method public c0(I)V
    .locals 3

    iget v0, p0, Lbg;->i:I

    div-int/lit8 v1, p1, 0x8

    add-int/2addr v0, v1

    iput v0, p0, Lbg;->i:I

    mul-int/lit8 v1, v1, 0x8

    iget v2, p0, Lbg;->j:I

    sub-int/2addr p1, v1

    add-int/2addr p1, v2

    iput p1, p0, Lbg;->j:I

    const/4 v1, 0x7

    if-le p1, v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lbg;->i:I

    add-int/lit8 p1, p1, -0x8

    iput p1, p0, Lbg;->j:I

    :cond_0
    const/4 v1, 0x0

    if-ltz v0, :cond_2

    iget p0, p0, Lbg;->h:I

    const/4 v2, 0x1

    if-lt v0, p0, :cond_1

    if-ne v0, p0, :cond_2

    if-nez p1, :cond_2

    :cond_1
    move v1, v2

    :cond_2
    invoke-static {v1}, La60;->D(Z)V

    return-void
.end method

.method public d(Ljava/lang/Object;Lpv0;Lut;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    iget v2, v0, Lag;->a:I

    const/16 v3, 0x64

    if-ge v2, v3, :cond_0

    invoke-virtual {v0, v1}, Lag;->e(I)I

    move-result v1

    iget v2, v0, Lag;->a:I

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, Lag;->a:I

    invoke-interface {p2, p1, p0, p3}, Lpv0;->h(Ljava/lang/Object;Lbg;Lut;)V

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, Lag;->a(I)V

    iget p0, v0, Lag;->a:I

    add-int/lit8 p0, p0, -0x1

    iput p0, v0, Lag;->a:I

    invoke-virtual {v0, v1}, Lag;->d(I)V

    return-void

    :cond_0
    new-instance p0, Lo60;

    const-string p1, "Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public declared-synchronized d0(I)V
    .locals 1

    monitor-enter p0

    :try_start_0
    iget v0, p0, Lbg;->h:I

    iput p1, p0, Lbg;->h:I

    if-ge p1, v0, :cond_0

    invoke-virtual {p0}, Lbg;->k()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    goto :goto_0

    :cond_0
    monitor-exit p0

    return-void

    :goto_0
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public e(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->f()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->f()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public e0()Lyf4;
    .locals 1

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lbg;->S(I)V

    iget-object p0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast p0, Lcg4;

    invoke-virtual {p0}, Lcg4;->v()Lwf4;

    move-result-object p0

    return-object p0
.end method

.method public f()Lsd;
    .locals 1

    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lbg;->A(I)V

    iget-object p0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast p0, Lag;

    invoke-virtual {p0}, Lag;->g()Lsd;

    move-result-object p0

    return-object p0
.end method

.method public f0(Lug4;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x1

    if-eq v1, v2, :cond_2

    const/4 p0, 0x2

    if-ne v1, p0, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->Y(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_0
    invoke-virtual {v0}, Lcg4;->l()D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_0

    goto :goto_0

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->l()D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_3

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    :cond_3
    :goto_0
    return-void
.end method

.method public g(Le60;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-ne v1, v2, :cond_2

    :cond_0
    invoke-virtual {p0}, Lbg;->f()Lsd;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_1

    return-void

    :cond_1
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0
.end method

.method public g0(Lug4;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-eq v1, v2, :cond_2

    const/4 v2, 0x5

    if-ne v1, v2, :cond_1

    :cond_0
    invoke-virtual {v0}, Lcg4;->m()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_4

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->w()I

    move-result p0

    invoke-static {p0}, Lbg;->X(I)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    add-int/2addr v1, p0

    :cond_3
    invoke-virtual {v0}, Lcg4;->m()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p0

    if-lt p0, v1, :cond_3

    :cond_4
    return-void
.end method

.method public h(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3

    const/4 p0, 0x2

    if-ne v1, p0, :cond_2

    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x7

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_0
    invoke-virtual {v0}, Lag;->h()D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_0

    goto :goto_0

    :cond_1
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->h()D

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_4

    :goto_0
    return-void

    :cond_4
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_3

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public h0(Lug4;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lcg4;

    instance-of v1, p1, Lch4;

    iget v2, p0, Lbg;->h:I

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    move-object v1, p1

    check-cast v1, Lch4;

    and-int/lit8 p1, v2, 0x7

    if-eqz p1, :cond_2

    if-ne p1, v3, :cond_1

    invoke-virtual {v0}, Lcg4;->w()I

    move-result p1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, p1

    :cond_0
    invoke-virtual {v0}, Lcg4;->n()J

    move-result-wide v3

    invoke-virtual {v1, v3, v4}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->e()I

    move-result p1

    if-lt p1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_1
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lcg4;->n()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Lch4;->d(J)V

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result p1

    if-eqz p1, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lcg4;->i()I

    move-result p1

    iget v2, p0, Lbg;->h:I

    if-eq p1, v2, :cond_2

    goto :goto_0

    :cond_4
    and-int/lit8 v1, v2, 0x7

    if-eqz v1, :cond_7

    if-ne v1, v3, :cond_6

    invoke-virtual {v0}, Lcg4;->w()I

    move-result v1

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v2

    add-int/2addr v2, v1

    :cond_5
    invoke-virtual {v0}, Lcg4;->n()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->e()I

    move-result v1

    if-lt v1, v2, :cond_5

    invoke-virtual {p0, v2}, Lbg;->W(I)V

    return-void

    :cond_6
    invoke-static {}, Lnu0;->m()V

    return-void

    :cond_7
    invoke-virtual {v0}, Lcg4;->n()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lcg4;->d()Z

    move-result v1

    if-nez v1, :cond_8

    invoke-virtual {v0}, Lcg4;->i()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_7

    move p1, v1

    :goto_0
    iput p1, p0, Lbg;->j:I

    :cond_8
    :goto_1
    return-void
.end method

.method public i(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->i()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->i()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public j(Lfa1;Ljava/lang/Class;Lut;)Ljava/lang/Object;
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    const-string p0, "unsupported field type."

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_1
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->r()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_2
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->q()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_3
    invoke-virtual {p0, v3}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->p()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_4
    invoke-virtual {p0, v2}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->o()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_5
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->i()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_6
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_7
    invoke-virtual {p0}, Lbg;->f()Lsd;

    move-result-object p0

    return-object p0

    :pswitch_8
    invoke-virtual {p0, v1}, Lbg;->A(I)V

    sget-object p1, Ljp0;->c:Ljp0;

    invoke-virtual {p1, p2}, Ljp0;->a(Ljava/lang/Class;)Lpv0;

    move-result-object p1

    invoke-interface {p1}, Lpv0;->i()Lb20;

    move-result-object p2

    invoke-virtual {p0, p2, p1, p3}, Lbg;->d(Ljava/lang/Object;Lpv0;Lut;)V

    invoke-interface {p1, p2}, Lpv0;->c(Ljava/lang/Object;)V

    return-object p2

    :pswitch_9
    invoke-virtual {p0, v1}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->t()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->f()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :pswitch_b
    invoke-virtual {p0, v2}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->j()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_c
    invoke-virtual {p0, v3}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->k()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_d
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->m()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_e
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->w()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_f
    invoke-virtual {p0, v4}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->n()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0

    :pswitch_10
    invoke-virtual {p0, v2}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->l()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    return-object p0

    :pswitch_11
    invoke-virtual {p0, v3}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->h()D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public declared-synchronized k()V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget v0, p0, Lbg;->h:I

    sget-object v1, Lvh3;->a:Ljava/lang/String;

    const v1, 0xffff

    add-int/2addr v0, v1

    const/high16 v1, 0x10000

    div-int/2addr v0, v1

    iget v1, p0, Lbg;->i:I

    sub-int/2addr v0, v1

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget v1, p0, Lbg;->j:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-lt v0, v1, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    iget-object v2, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v2, [Lgg1;

    const/4 v3, 0x0

    invoke-static {v2, v0, v1, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    iput v0, p0, Lbg;->j:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public l(Le60;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-eq v1, v2, :cond_3

    const/4 v2, 0x5

    if-ne v1, v2, :cond_2

    :cond_0
    invoke-virtual {v0}, Lag;->j()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x3

    if-nez v1, :cond_5

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_4
    invoke-virtual {v0}, Lag;->j()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_4

    :goto_0
    return-void

    :cond_5
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public declared-synchronized m(Lgg1;)V
    .locals 3

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, [Lgg1;

    iget v1, p0, Lbg;->j:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lbg;->j:I

    aput-object p1, v0, v1

    iget p1, p0, Lbg;->i:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Lbg;->i:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public declared-synchronized n(Lnn1;)V
    .locals 3

    monitor-enter p0

    :cond_0
    :goto_0
    if-eqz p1, :cond_2

    :try_start_0
    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, [Lgg1;

    iget v1, p0, Lbg;->j:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lbg;->j:I

    iget-object v2, p1, Lnn1;->j:Ljava/lang/Object;

    check-cast v2, Lgg1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    aput-object v2, v0, v1

    iget v0, p0, Lbg;->i:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lbg;->i:I

    iget-object p1, p1, Lnn1;->k:Ljava/lang/Object;

    check-cast p1, Lnn1;

    if-eqz p1, :cond_1

    iget-object v0, p1, Lnn1;->j:Ljava/lang/Object;

    check-cast v0, Lgg1;

    if-nez v0, :cond_0

    :cond_1
    const/4 p1, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1

    :cond_2
    monitor-exit p0

    return-void
.end method

.method public o(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3

    const/4 p0, 0x2

    if-ne v1, p0, :cond_2

    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x7

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_0
    invoke-virtual {v0}, Lag;->k()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_0

    goto :goto_0

    :cond_1
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->k()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_4

    :goto_0
    return-void

    :cond_4
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_3

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public p(Le60;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-eq v1, v2, :cond_3

    const/4 v2, 0x5

    if-ne v1, v2, :cond_2

    :cond_0
    invoke-virtual {v0}, Lag;->l()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x3

    if-nez v1, :cond_5

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_4
    invoke-virtual {v0}, Lag;->l()F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_4

    :goto_0
    return-void

    :cond_5
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public q(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->m()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->m()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public r(Le60;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->n()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->n()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public s(Le60;)V
    .locals 3

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-eq v1, v2, :cond_3

    const/4 v2, 0x5

    if-ne v1, v2, :cond_2

    :cond_0
    invoke-virtual {v0}, Lag;->o()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x3

    if-nez v1, :cond_5

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_4
    invoke-virtual {v0}, Lag;->o()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_4

    :goto_0
    return-void

    :cond_5
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public t(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x1

    if-eq v1, v2, :cond_3

    const/4 p0, 0x2

    if-ne v1, p0, :cond_2

    invoke-virtual {v0}, Lag;->v()I

    move-result p0

    and-int/lit8 v1, p0, 0x7

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    add-int/2addr v1, p0

    :cond_0
    invoke-virtual {v0}, Lag;->p()J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, p0}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result p0

    if-lt p0, v1, :cond_0

    goto :goto_0

    :cond_1
    new-instance p0, Lo60;

    const-string p1, "Failed to parse the message."

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_3
    invoke-virtual {v0}, Lag;->p()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_4

    :goto_0
    return-void

    :cond_4
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_3

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public u(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->q()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->q()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public v(Le60;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->r()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->r()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public w(Le60;Z)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    const/4 v2, 0x2

    if-ne v1, v2, :cond_3

    :cond_0
    if-eqz p2, :cond_1

    invoke-virtual {p0, v2}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->t()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v2}, Lbg;->A(I)V

    invoke-virtual {v0}, Lag;->s()Ljava/lang/String;

    move-result-object v1

    :goto_0
    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_2

    return-void

    :cond_2
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v3, p0, Lbg;->h:I

    if-eq v1, v3, :cond_0

    iput v1, p0, Lbg;->j:I

    return-void

    :cond_3
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0
.end method

.method public x(Le60;)V
    .locals 4

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public y(Le60;)V
    .locals 5

    iget-object v0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast v0, Lag;

    iget v1, p0, Lbg;->h:I

    and-int/lit8 v1, v1, 0x7

    if-eqz v1, :cond_2

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-virtual {v0}, Lag;->v()I

    move-result v1

    invoke-virtual {v0}, Lag;->b()I

    move-result v2

    add-int/2addr v2, v1

    :cond_0
    invoke-virtual {v0}, Lag;->w()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v3, p1

    check-cast v3, Lkp0;

    invoke-virtual {v3, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->b()I

    move-result v1

    if-lt v1, v2, :cond_0

    invoke-virtual {p0, v2}, Lbg;->z(I)V

    return-void

    :cond_1
    invoke-static {}, Lo60;->b()Ln60;

    move-result-object p0

    throw p0

    :cond_2
    invoke-virtual {v0}, Lag;->w()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    move-object v2, p1

    check-cast v2, Lkp0;

    invoke-virtual {v2, v1}, Lkp0;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lag;->c()Z

    move-result v1

    if-eqz v1, :cond_3

    return-void

    :cond_3
    invoke-virtual {v0}, Lag;->u()I

    move-result v1

    iget v2, p0, Lbg;->h:I

    if-eq v1, v2, :cond_2

    iput v1, p0, Lbg;->j:I

    return-void
.end method

.method public z(I)V
    .locals 0

    iget-object p0, p0, Lbg;->k:Ljava/lang/Object;

    check-cast p0, Lag;

    invoke-virtual {p0}, Lag;->b()I

    move-result p0

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lo60;->e()Lo60;

    move-result-object p0

    throw p0
.end method
