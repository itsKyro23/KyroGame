.class public interface abstract Laa2;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract F()V
.end method

.method public abstract e1(Lwg2;)V
.end method

.method public abstract q()V
.end method
