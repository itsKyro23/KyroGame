.class public interface abstract Las;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Lfv2;)V
.end method
