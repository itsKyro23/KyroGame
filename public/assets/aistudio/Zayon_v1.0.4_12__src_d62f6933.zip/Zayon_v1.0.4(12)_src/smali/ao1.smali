.class public final Lao1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lko1;

.field public final b:Lno1;

.field public final c:Llk1;

.field public final d:Lmk1;

.field public final e:Z

.field public final f:Z

.field public g:I

.field public h:Lfx4;


# direct methods
.method public constructor <init>(Lko1;Lno1;Llk1;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lao1;->a:Lko1;

    iput-object p2, p0, Lao1;->b:Lno1;

    iput-object p3, p0, Lao1;->c:Llk1;

    iget p2, p1, Lko1;->b:I

    iget-object p1, p1, Lko1;->g:Lfx4;

    const/4 p3, 0x2

    if-ne p2, p3, :cond_0

    const/4 p2, 0x1

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    iput-boolean p2, p0, Lao1;->e:Z

    iget-object p2, p1, Lfx4;->o:Ljava/lang/String;

    const-string p3, "application/x-itut-t35"

    invoke-static {p2, p3}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    iput-boolean p2, p0, Lao1;->f:Z

    iget-object p1, p1, Lfx4;->o:Ljava/lang/String;

    const-string p2, "audio/true-hd"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    new-instance p1, Lmk1;

    invoke-direct {p1}, Lmk1;-><init>()V

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    iput-object p1, p0, Lao1;->d:Lmk1;

    return-void
.end method
