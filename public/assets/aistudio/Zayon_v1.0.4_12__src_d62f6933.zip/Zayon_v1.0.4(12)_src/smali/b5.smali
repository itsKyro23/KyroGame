.class public final synthetic Lb5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:I

.field public final synthetic j:Ljava/lang/Object;

.field public final synthetic k:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;I)V
    .locals 0

    iput p4, p0, Lb5;->h:I

    iput-object p1, p0, Lb5;->j:Ljava/lang/Object;

    iput p2, p0, Lb5;->i:I

    iput-object p3, p0, Lb5;->k:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/io/Serializable;II)V
    .locals 0

    .line 12
    iput p4, p0, Lb5;->h:I

    iput-object p1, p0, Lb5;->j:Ljava/lang/Object;

    iput-object p2, p0, Lb5;->k:Ljava/lang/Object;

    iput p3, p0, Lb5;->i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 26

    move-object/from16 v0, p0

    iget v1, v0, Lb5;->h:I

    const v2, 0x7f0f017a

    const/4 v3, 0x4

    const-string v4, "\u2013"

    const/16 v5, 0x9

    const/4 v6, 0x0

    const v11, 0x7f0f01d4

    const/4 v12, -0x5

    const v13, 0x7f0700f8

    const/4 v14, -0x4

    const/4 v15, -0x3

    const/4 v7, -0x2

    const v9, 0x7f070086

    const/16 v18, 0x2

    const/4 v8, 0x0

    const/4 v10, 0x1

    packed-switch v1, :pswitch_data_0

    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Lf41;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, [I

    aget v0, v0, v8

    iget v3, v1, Lf41;->h:I

    if-eq v2, v3, :cond_0

    goto :goto_1

    :cond_0
    iput-object v6, v1, Lf41;->g:Lqb1;

    iput-object v6, v1, Lf41;->z:Ljava/lang/String;

    if-eq v0, v10, :cond_2

    const/4 v3, 0x3

    if-ne v0, v3, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, v1, Lf41;->l:Landroid/os/Handler;

    new-instance v3, Ln00;

    invoke-direct {v3, v1, v2, v5}, Ln00;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    :cond_2
    :goto_0
    iput-boolean v10, v1, Lf41;->k:Z

    :goto_1
    return-void

    :pswitch_0
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Lky0;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, [I

    aget v0, v0, v8

    iget-object v3, v1, Lky0;->n:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    if-eq v2, v3, :cond_3

    goto :goto_2

    :cond_3
    iput-object v6, v1, Lky0;->m:Lqb1;

    iput-object v6, v1, Lky0;->r:Ljava/lang/String;

    if-ne v0, v10, :cond_4

    iput-boolean v10, v1, Lky0;->q:Z

    :cond_4
    iget-object v0, v1, Lky0;->g:Landroid/os/Handler;

    new-instance v3, Lgy0;

    invoke-direct {v3, v1, v2, v10}, Lgy0;-><init>(Lky0;II)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_2
    return-void

    :pswitch_1
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Lto0;

    iget-object v2, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget v0, v0, Lb5;->i:I

    sget-object v3, Lto0;->T0:Ljava/lang/String;

    iput-boolean v8, v1, Lto0;->q0:Z

    iget-object v3, v1, Lrx;->L:Landroid/view/View;

    if-nez v3, :cond_5

    goto :goto_4

    :cond_5
    iget-object v3, v1, Lto0;->j0:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v1, Lto0;->i0:Landroid/widget/TextView;

    if-gez v0, :cond_6

    goto :goto_3

    :cond_6
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    :goto_3
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_4
    return-void

    :pswitch_2
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Ldg0;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, Lqb1;

    iget v3, v1, Ldg0;->s:I

    if-ne v2, v3, :cond_7

    iput-object v0, v1, Ldg0;->q:Lqb1;

    goto :goto_5

    :cond_7
    iget-object v1, v1, Ldg0;->n:Landroid/os/Handler;

    if-eqz v1, :cond_8

    new-instance v2, Lwf0;

    invoke-direct {v2, v0, v10}, Lwf0;-><init>(Lqb1;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_5

    :cond_8
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lwf0;

    invoke-direct {v2, v0, v10}, Lwf0;-><init>(Lqb1;I)V

    const-string v0, "zayon-monitor-close"

    invoke-direct {v1, v2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    :goto_5
    return-void

    :pswitch_3
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Landroid/app/Activity;

    iget v4, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    sput-boolean v8, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v5

    if-nez v5, :cond_12

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v5

    if-eqz v5, :cond_9

    goto/16 :goto_6

    :cond_9
    if-ne v4, v10, :cond_b

    new-instance v2, Landroid/content/Intent;

    const-class v3, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    invoke-direct {v2, v1, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    if-eqz v0, :cond_a

    const-string v3, "com.zayon.optimize.GAME_ID"

    invoke-virtual {v2, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_a
    invoke-virtual {v1, v2}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    goto/16 :goto_6

    :cond_b
    if-nez v4, :cond_c

    invoke-static {v8}, Lcom/zayon/optimize/core/ZyCore;->featureInfo(I)[I

    move-result-object v2

    aget v4, v2, v10

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v20

    aget v4, v2, v8

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v21

    aget v2, v2, v18

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v22

    const v2, 0x7f0f01cf

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v23

    const v2, 0x7f0f01d0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v24

    new-instance v2, Lb10;

    invoke-direct {v2, v3, v1, v0}, Lb10;-><init>(ILandroid/app/Activity;Ljava/lang/String;)V

    move-object/from16 v19, v1

    move-object/from16 v25, v2

    invoke-static/range {v19 .. v25}, Ldc0;->v(Landroid/app/Activity;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_6

    :cond_c
    if-ne v4, v7, :cond_d

    const v0, 0x7f0f01e1

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    goto :goto_6

    :cond_d
    if-ne v4, v15, :cond_e

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    goto :goto_6

    :cond_e
    if-ne v4, v14, :cond_f

    const v0, 0x7f0f01e3

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    goto :goto_6

    :cond_f
    if-ne v4, v12, :cond_10

    invoke-virtual {v1, v11}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    goto :goto_6

    :cond_10
    const/4 v0, -0x6

    if-ne v4, v0, :cond_11

    const v0, 0x7f0f01ba

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v2, 0x7f0700ac

    invoke-static {v2, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    goto :goto_6

    :cond_11
    const v0, 0x7f0f01e2

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v2, 0x7f0700f6

    invoke-static {v2, v1, v0}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->D(ILandroid/app/Activity;Ljava/lang/String;)V

    :cond_12
    :goto_6
    return-void

    :pswitch_4
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iget v3, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    sget-boolean v4, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    iput-boolean v8, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->v0:Z

    iget-boolean v4, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->u0:Z

    if-nez v4, :cond_1b

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v4

    if-eqz v4, :cond_13

    goto/16 :goto_8

    :cond_13
    if-ne v3, v10, :cond_14

    invoke-virtual {v1, v0, v10}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->G(Ljava/lang/String;Z)V

    goto/16 :goto_8

    :cond_14
    if-nez v3, :cond_15

    invoke-static/range {v18 .. v18}, Lcom/zayon/optimize/core/ZyCore;->featureInfo(I)[I

    move-result-object v0

    aget v2, v0, v10

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v20

    aget v2, v0, v8

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v21

    aget v0, v0, v18

    invoke-static {v8, v0}, Ljava/lang/Math;->max(II)I

    move-result v22

    const v0, 0x7f0f01ff

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v23

    const v0, 0x7f0f0200

    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v24

    new-instance v0, Ly00;

    invoke-direct {v0, v1, v5}, Ly00;-><init>(Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;I)V

    move-object/from16 v25, v0

    move-object/from16 v19, v1

    invoke-static/range {v19 .. v25}, Ldc0;->v(Landroid/app/Activity;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_8

    :cond_15
    const v4, 0x7f050071

    invoke-virtual {v1, v4}, Landroid/content/Context;->getColor(I)I

    move-result v4

    if-ne v3, v7, :cond_16

    const v2, 0x7f0f01ef

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v9, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    goto :goto_7

    :cond_16
    if-ne v3, v15, :cond_17

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v9, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    goto :goto_7

    :cond_17
    if-ne v3, v14, :cond_18

    const v2, 0x7f0f01fd

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const v3, 0x7f0f01d6

    invoke-virtual {v1, v3, v2}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v13, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    goto :goto_7

    :cond_18
    if-ne v3, v12, :cond_19

    invoke-virtual {v1, v11}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v9, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    goto :goto_7

    :cond_19
    const/4 v2, -0x6

    if-ne v3, v2, :cond_1a

    const v2, 0x7f0f01ba

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f0700ac

    invoke-virtual {v1, v3, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    goto :goto_7

    :cond_1a
    const v2, 0x7f0f0202

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f0700f6

    invoke-virtual {v1, v3, v4, v2}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I(IILjava/lang/String;)V

    :goto_7
    iput-boolean v10, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->v0:Z

    iget-object v2, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->F:Landroid/os/Handler;

    new-instance v3, Ll10;

    invoke-direct {v3, v1, v0, v10}, Ll10;-><init>(Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;Ljava/lang/String;I)V

    const-wide/16 v0, 0x640

    invoke-virtual {v2, v3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1b
    :goto_8
    return-void

    :pswitch_5
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iget-object v2, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v2, [F

    iget v0, v0, Lb5;->i:I

    sget-boolean v3, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    iget-boolean v3, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->u0:Z

    if-eqz v3, :cond_1c

    goto :goto_a

    :cond_1c
    iget-object v3, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->n0:Landroid/widget/TextView;

    if-nez v2, :cond_1d

    goto :goto_9

    :cond_1d
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    aget v2, v2, v8

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v5, "%.2f GHz"

    invoke-static {v4, v5, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    :goto_9
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->q0:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "%"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_a
    return-void

    :pswitch_6
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Law;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, Lov;

    iget-boolean v3, v1, Law;->d0:Z

    if-nez v3, :cond_1f

    iget v3, v1, Law;->q0:I

    if-ne v2, v3, :cond_1f

    iget-object v2, v1, Law;->r0:Lov;

    if-eqz v2, :cond_1e

    goto :goto_b

    :cond_1e
    iput-object v0, v1, Law;->r0:Lov;

    invoke-virtual {v1, v0}, Law;->g(Lov;)V

    :cond_1f
    :goto_b
    return-void

    :pswitch_7
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Law;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    iget-object v3, v1, Law;->b:Landroid/content/Context;

    iget-object v4, v1, Law;->c:Lu20;

    iput-boolean v8, v1, Law;->e0:Z

    iget-boolean v5, v1, Law;->d0:Z

    if-eqz v5, :cond_20

    goto/16 :goto_c

    :cond_20
    if-ne v2, v10, :cond_21

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    goto/16 :goto_c

    :cond_21
    if-nez v2, :cond_23

    invoke-static {v10}, Lcom/zayon/optimize/core/ZyCore;->featureInfo(I)[I

    move-result-object v2

    aget v3, v2, v10

    invoke-static {v8, v3}, Ljava/lang/Math;->max(II)I

    move-result v12

    aget v3, v2, v8

    invoke-static {v8, v3}, Ljava/lang/Math;->max(II)I

    move-result v13

    aget v2, v2, v18

    invoke-static {v8, v2}, Ljava/lang/Math;->max(II)I

    move-result v14

    new-instance v2, Ltv;

    invoke-direct {v2, v1, v0, v10}, Ltv;-><init>(Law;Ljava/lang/Runnable;I)V

    iget-object v0, v4, Lu20;->i:Ljava/lang/Object;

    check-cast v0, Lp00;

    invoke-virtual {v0}, Lrx;->h()Lk6;

    move-result-object v1

    if-nez v1, :cond_22

    goto :goto_c

    :cond_22
    invoke-virtual {v0}, Lrx;->h()Lk6;

    move-result-object v11

    const v1, 0x7f0f00a0

    invoke-virtual {v0, v1}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v15

    const v1, 0x7f0f00a1

    invoke-virtual {v0, v1}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v17, v2

    invoke-static/range {v11 .. v17}, Ldc0;->v(Landroid/app/Activity;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_c

    :cond_23
    if-ne v2, v7, :cond_24

    const v0, 0x7f0f0096

    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v9, v0}, Lu20;->u(ILjava/lang/String;)V

    goto :goto_c

    :cond_24
    if-ne v2, v15, :cond_25

    const v0, 0x7f0f0075

    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v9, v0}, Lu20;->u(ILjava/lang/String;)V

    goto :goto_c

    :cond_25
    if-ne v2, v14, :cond_26

    const v0, 0x7f0f00a6

    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v13, v0}, Lu20;->u(ILjava/lang/String;)V

    goto :goto_c

    :cond_26
    if-ne v2, v12, :cond_27

    invoke-virtual {v3, v11}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v9, v0}, Lu20;->u(ILjava/lang/String;)V

    goto :goto_c

    :cond_27
    const/4 v0, -0x6

    if-ne v2, v0, :cond_28

    const v0, 0x7f0f01ba

    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v2, 0x7f0700ac

    invoke-virtual {v4, v2, v0}, Lu20;->u(ILjava/lang/String;)V

    goto :goto_c

    :cond_28
    const v0, 0x7f0f00a5

    invoke-virtual {v3, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v2, 0x7f0700f6

    invoke-virtual {v4, v2, v0}, Lu20;->u(ILjava/lang/String;)V

    :goto_c
    return-void

    :pswitch_8
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Law;

    iget-object v2, v0, Lb5;->k:Ljava/lang/Object;

    check-cast v2, Ljava/util/HashSet;

    iget v0, v0, Lb5;->i:I

    :try_start_0
    iget-object v4, v1, Law;->a:Landroid/content/Context;

    invoke-static {v4, v2}, Ljg4;->f(Landroid/content/Context;Ljava/util/HashSet;)Lov;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_d

    :catchall_0
    new-instance v2, Lov;

    invoke-direct {v2}, Lov;-><init>()V

    :goto_d
    iget-object v4, v1, Law;->e:Landroid/os/Handler;

    new-instance v5, Lb5;

    invoke-direct {v5, v1, v0, v2, v3}, Lb5;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_9
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Ldq;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    iget-object v1, v1, Ldq;->b:Luo0;

    invoke-interface {v1, v2, v0}, Luo0;->m(ILjava/lang/Object;)V

    return-void

    :pswitch_a
    iget-object v1, v0, Lb5;->j:Ljava/lang/Object;

    check-cast v1, Le5;

    iget v2, v0, Lb5;->i:I

    iget-object v0, v0, Lb5;->k:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ld5;

    :try_start_1
    iget-object v0, v1, Le5;->a:Landroid/content/Context;

    invoke-static {v0}, Ly4;->g(Landroid/content/Context;)Ly4;

    move-result-object v0

    move/from16 v4, v18

    invoke-virtual {v1, v0, v4}, Le5;->h(Ly4;I)V

    const-string v5, "127.0.0.1"

    invoke-virtual {v0, v5}, Lio/github/muntashirakon/adb/AbsAdbConnectionManager;->setHostAddress(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Lio/github/muntashirakon/adb/AbsAdbConnectionManager;->connect(I)Z

    move-result v8

    if-eqz v8, :cond_29

    iput v4, v1, Le5;->e:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_e

    :catchall_1
    move-exception v0

    goto :goto_f

    :cond_29
    :goto_e
    iget-object v0, v1, Le5;->a:Landroid/content/Context;

    if-eqz v8, :cond_2a

    :try_start_2
    invoke-static {v0}, Lck2;->p(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    const v2, 0x7f0f0329

    invoke-virtual {v0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_10

    :cond_2a
    invoke-static {v0}, Lck2;->p(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const v4, 0x7f0f0328

    invoke-virtual {v0, v4, v2}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_10

    :goto_f
    invoke-virtual {v1, v0}, Le5;->k(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    :goto_10
    invoke-virtual {v1, v8, v0, v3}, Le5;->e(ZLjava/lang/String;Ld5;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
