.class public interface abstract Lb00;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lr;

.field public static final b:Lr;

.field public static final c:Lr;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    new-instance v0, Lr;

    const-string v1, "1.2.156.10197.1"

    invoke-direct {v0, v1}, Lr;-><init>(Ljava/lang/String;)V

    const-string v1, "101.1"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "101.2"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "101.3"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "101.4"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "102.3"

    const-string v2, "102.4"

    const-string v3, "102.1"

    const-string v4, "102.2"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "103.1"

    const-string v2, "103.2"

    const-string v3, "102.5"

    const-string v4, "102.6"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "103.5"

    const-string v2, "103.6"

    const-string v3, "103.3"

    const-string v4, "103.4"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "104.3"

    const-string v2, "104.4"

    const-string v3, "104.1"

    const-string v4, "104.2"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "104.7"

    const-string v2, "104.8"

    const-string v3, "104.5"

    const-string v4, "104.6"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "104.11"

    const-string v2, "104.12"

    const-string v3, "104.9"

    const-string v4, "104.10"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "301"

    const-string v2, "301.1"

    const-string v3, "104.100"

    const-string v4, "201"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "301.2"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "301.3"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    move-result-object v1

    const-string v2, "301.101"

    invoke-virtual {v0, v2}, Lr;->s(Ljava/lang/String;)Lr;

    new-instance v2, Lr;

    const-string v3, "1.2.156.11235.1.1.1"

    invoke-direct {v2, v3}, Lr;-><init>(Ljava/lang/String;)V

    new-instance v2, Lr;

    const-string v3, "1.2.156.11235.1.1.2.1"

    invoke-direct {v2, v3}, Lr;-><init>(Ljava/lang/String;)V

    const-string v2, "1"

    invoke-virtual {v1, v2}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v2, "2"

    invoke-virtual {v1, v2}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v3, "2.3"

    const-string v4, "2.4"

    const-string v5, "2.1"

    const-string v6, "2.2"

    invoke-static {v1, v5, v6, v3, v4}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "2.7"

    const-string v4, "2.8"

    const-string v5, "2.5"

    const-string v6, "2.6"

    invoke-static {v1, v5, v6, v3, v4}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v3, "2.9"

    invoke-virtual {v1, v3}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v3, "2.10"

    invoke-virtual {v1, v3}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v3, "2.11"

    invoke-virtual {v1, v3}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "302.2"

    const-string v3, "302.3"

    const-string v4, "302"

    const-string v5, "302.1"

    invoke-static {v0, v4, v5, v1, v3}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "401"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    move-result-object v1

    sput-object v1, Lb00;->a:Lr;

    invoke-virtual {v1, v2}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "501"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    move-result-object v1

    sput-object v1, Lb00;->b:Lr;

    const-string v1, "502"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "503"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    move-result-object v1

    sput-object v1, Lb00;->c:Lr;

    const-string v1, "506"

    const-string v2, "507"

    const-string v3, "504"

    const-string v4, "505"

    invoke-static {v0, v3, v4, v1, v2}, Loj;->s(Lr;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "520"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "521"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    const-string v1, "522"

    invoke-virtual {v0, v1}, Lr;->s(Ljava/lang/String;)Lr;

    return-void
.end method
