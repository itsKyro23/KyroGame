.class public final Lbc4;
.super Lng4;
.source "SourceFile"


# static fields
.field public static final synthetic zza:I

.field private static final zzd:Lbc4;


# instance fields
.field private zzb:I

.field private zzc:Lyf4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lbc4;

    invoke-direct {v0}, Lbc4;-><init>()V

    sput-object v0, Lbc4;->zzd:Lbc4;

    const-class v1, Lbc4;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Lyf4;->i:Lwf4;

    iput-object v0, p0, Lbc4;->zzc:Lyf4;

    return-void
.end method

.method public static A(Lyf4;Lgg4;)Lbc4;
    .locals 1

    sget-object v0, Lbc4;->zzd:Lbc4;

    invoke-static {v0, p0, p1}, Lng4;->l(Lng4;Lyf4;Lgg4;)Lng4;

    move-result-object p0

    check-cast p0, Lbc4;

    return-object p0
.end method

.method public static B()Lac4;
    .locals 1

    sget-object v0, Lbc4;->zzd:Lbc4;

    invoke-virtual {v0}, Lng4;->o()Lkg4;

    move-result-object v0

    check-cast v0, Lac4;

    return-object v0
.end method


# virtual methods
.method public final synthetic C(Lyf4;)V
    .locals 0

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, Lbc4;->zzc:Lyf4;

    return-void
.end method

.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lac4;

    sget-object p1, Lbc4;->zzd:Lbc4;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lbc4;

    invoke-direct {p0}, Lbc4;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zzb"

    const-string p1, "zzc"

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lbc4;->zzd:Lbc4;

    new-instance p2, Llh4;

    const-string v0, "\u0000\u0002\u0000\u0000\u0001\u0003\u0002\u0000\u0000\u0000\u0001\u000b\u0003\n"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method

.method public final y()I
    .locals 0

    iget p0, p0, Lbc4;->zzb:I

    return p0
.end method

.method public final z()Lyf4;
    .locals 0

    iget-object p0, p0, Lbc4;->zzc:Lyf4;

    return-object p0
.end method
