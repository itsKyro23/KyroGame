.class public final La92;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lp82;


# instance fields
.field public final synthetic h:Loo4;


# direct methods
.method public constructor <init>(Loo4;)V
    .locals 0

    iput-object p1, p0, La92;->h:Loo4;

    const-string p1, "com.google.android.gms.ads.internal.formats.client.IOnCustomTemplateAdLoadedListener"

    invoke-direct {p0, p1}, Lf12;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    const/4 v0, 0x1

    if-ne p3, v0, :cond_2

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_0

    const/4 p3, 0x0

    goto :goto_0

    :cond_0
    const-string v1, "com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd"

    invoke-interface {p3, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v1

    instance-of v2, v1, Lh82;

    if-eqz v2, :cond_1

    move-object p3, v1

    check-cast p3, Lh82;

    goto :goto_0

    :cond_1
    new-instance v1, Lg82;

    invoke-direct {v1, p3}, Lg82;-><init>(Landroid/os/IBinder;)V

    move-object p3, v1

    :goto_0
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p0, p3}, La92;->W2(Lh82;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v0

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method public final W2(Lh82;)V
    .locals 2

    iget-object p0, p0, La92;->h:Loo4;

    iget-object v0, p0, Loo4;->i:Ljava/lang/Object;

    check-cast v0, Lm23;

    monitor-enter p0

    :try_start_0
    iget-object v1, p0, Loo4;->k:Ljava/lang/Object;

    check-cast v1, Lu20;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v1, :cond_0

    :goto_0
    monitor-exit p0

    goto :goto_1

    :cond_0
    :try_start_1
    new-instance v1, Lu20;

    invoke-direct {v1, p1}, Lu20;-><init>(Lh82;)V

    iput-object v1, p0, Loo4;->k:Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_1
    iget-object p0, v0, Lm23;->i:Lbe0;

    check-cast p0, Loo4;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p1, "#008 Must be called on the main UI thread."

    invoke-static {p1}, Lck2;->d(Ljava/lang/String;)V

    :try_start_2
    iget-object p1, v1, Lu20;->i:Ljava/lang/Object;

    check-cast p1, Lh82;

    invoke-interface {p1}, Lh82;->g()Ljava/lang/String;

    move-result-object p1
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :catch_0
    invoke-static {}, Lj23;->e()V

    const/4 p1, 0x0

    :goto_2
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "Adapter called onAdLoaded with template id "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lj23;->c(Ljava/lang/String;)V

    iput-object v1, p0, Loo4;->k:Ljava/lang/Object;

    :try_start_3
    iget-object p0, p0, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Llc2;

    invoke-interface {p0}, Llc2;->h()V
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_3

    :catch_1
    move-exception p0

    const-string p1, "#007 Could not call remote method."

    invoke-static {p1, p0}, Lj23;->i(Ljava/lang/String;Ljava/lang/Exception;)V

    :goto_3
    return-void

    :catchall_0
    move-exception p1

    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p1
.end method
