.class public interface abstract Laj0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract f()V
.end method
