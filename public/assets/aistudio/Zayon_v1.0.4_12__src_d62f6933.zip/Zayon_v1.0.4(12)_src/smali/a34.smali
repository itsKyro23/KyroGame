.class public abstract La34;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lq64;

.field public static final b:Lx54;

.field public static final c:Lz24;

.field public static final d:Ly24;

.field public static final e:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget-object v0, Lil2;->A:Lil2;

    new-instance v1, Lq64;

    const-class v2, Lx24;

    const-class v3, Lb24;

    invoke-direct {v1, v2, v3, v0}, Lq64;-><init>(Ljava/lang/Class;Ljava/lang/Class;Ls64;)V

    sput-object v1, La34;->a:Lq64;

    sget v0, Lf84;->zza:I

    const-class v0, Lf84;

    invoke-static {v0}, Lng4;->q(Ljava/lang/Class;)Llg4;

    new-instance v0, Lx54;

    const/4 v1, 0x3

    const-string v2, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    invoke-direct {v0, v1, v3, v2}, Lx54;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v0, La34;->b:Lx54;

    sget-object v0, Lz24;->a:Lz24;

    sput-object v0, La34;->c:Lz24;

    sget-object v0, Ly24;->b:Ly24;

    sput-object v0, La34;->d:Ly24;

    const/4 v0, 0x2

    sput v0, La34;->e:I

    return-void
.end method
