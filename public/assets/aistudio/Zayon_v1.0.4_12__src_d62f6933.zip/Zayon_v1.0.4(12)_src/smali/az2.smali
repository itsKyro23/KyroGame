.class public final Laz2;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lh13;

.field public final b:Ls03;

.field public final c:Liq2;

.field public final d:Lqx2;


# direct methods
.method public constructor <init>(Lh13;Ls03;Liq2;Lqx2;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laz2;->a:Lh13;

    iput-object p2, p0, Laz2;->b:Ls03;

    iput-object p3, p0, Laz2;->c:Liq2;

    iput-object p4, p0, Laz2;->d:Lqx2;

    return-void
.end method


# virtual methods
.method public final a()Landroid/view/View;
    .locals 6

    invoke-static {}, Lxt4;->a()Lxt4;

    move-result-object v0

    const/4 v1, 0x0

    iget-object v2, p0, Laz2;->a:Lh13;

    invoke-virtual {v2, v0, v1, v1}, Lh13;->a(Lxt4;Lbg3;Ldg3;)Lsl2;

    move-result-object v0

    invoke-interface {v0}, Lsl2;->j0()Landroid/view/View;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    new-instance v1, Lyy2;

    const/4 v2, 0x4

    invoke-direct {v1, p0, v2}, Lyy2;-><init>(Laz2;I)V

    const-string v2, "/sendMessageToSdk"

    invoke-interface {v0, v2, v1}, Lsl2;->c1(Ljava/lang/String;Ln92;)V

    new-instance v1, Lyy2;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lyy2;-><init>(Laz2;I)V

    const-string v2, "/adMuted"

    invoke-interface {v0, v2, v1}, Lsl2;->c1(Ljava/lang/String;Ln92;)V

    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v2, Lyy2;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v3}, Lyy2;-><init>(Laz2;I)V

    new-instance v3, Lpx2;

    iget-object v4, p0, Laz2;->b:Ls03;

    const-string v5, "/loadHtml"

    invoke-direct {v3, v4, v1, v5, v2}, Lpx2;-><init>(Ls03;Ljava/lang/ref/WeakReference;Ljava/lang/String;Ln92;)V

    invoke-virtual {v4, v5, v3}, Ls03;->b(Ljava/lang/String;Ln92;)V

    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v2, Lyy2;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lyy2;-><init>(Laz2;I)V

    new-instance v3, Lpx2;

    const-string v5, "/showOverlay"

    invoke-direct {v3, v4, v1, v5, v2}, Lpx2;-><init>(Ls03;Ljava/lang/ref/WeakReference;Ljava/lang/String;Ln92;)V

    invoke-virtual {v4, v5, v3}, Ls03;->b(Ljava/lang/String;Ln92;)V

    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v2, Lyy2;

    const/4 v3, 0x3

    invoke-direct {v2, p0, v3}, Lyy2;-><init>(Laz2;I)V

    new-instance p0, Lpx2;

    const-string v3, "/hideOverlay"

    invoke-direct {p0, v4, v1, v3, v2}, Lpx2;-><init>(Ls03;Ljava/lang/ref/WeakReference;Ljava/lang/String;Ln92;)V

    invoke-virtual {v4, v3, p0}, Ls03;->b(Ljava/lang/String;Ln92;)V

    invoke-interface {v0}, Lsl2;->j0()Landroid/view/View;

    move-result-object p0

    return-object p0
.end method
