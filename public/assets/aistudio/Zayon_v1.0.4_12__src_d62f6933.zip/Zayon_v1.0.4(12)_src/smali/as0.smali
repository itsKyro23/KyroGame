.class public interface abstract Las0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract accept(Ljava/lang/Object;Ljava/lang/Object;)V
.end method
