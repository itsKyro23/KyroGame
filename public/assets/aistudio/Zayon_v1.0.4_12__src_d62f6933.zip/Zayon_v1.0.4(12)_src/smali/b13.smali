.class public final Lb13;
.super Lgc1;
.source "SourceFile"


# instance fields
.field public final i:Ljava/lang/Object;

.field public j:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 1

    const/4 v0, 0x3

    invoke-direct {p0, v0}, Lgc1;-><init>(I)V

    iput-object p1, p0, Lb13;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .locals 0

    iget-boolean p0, p0, Lb13;->j:Z

    if-nez p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final next()Ljava/lang/Object;
    .locals 1

    iget-boolean v0, p0, Lb13;->j:Z

    if-nez v0, :cond_0

    const/4 v0, 0x1

    iput-boolean v0, p0, Lb13;->j:Z

    iget-object p0, p0, Lb13;->i:Ljava/lang/Object;

    return-object p0

    :cond_0
    invoke-static {}, Ls40;->b()V

    const/4 p0, 0x0

    return-object p0
.end method
