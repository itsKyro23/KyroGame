.class public final Lad3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltd3;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Boolean;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Boolean;I)V
    .locals 0

    iput p2, p0, Lad3;->a:I

    iput-object p1, p0, Lad3;->b:Ljava/lang/Boolean;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final bridge synthetic l(Ljava/lang/Object;)V
    .locals 1

    iget v0, p0, Lad3;->a:I

    iget-object p0, p0, Lad3;->b:Ljava/lang/Boolean;

    packed-switch v0, :pswitch_data_0

    check-cast p1, Landroid/os/Bundle;

    const-string v0, "lft"

    if-nez p0, :cond_0

    const/4 p0, -0x1

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 p0, 0x1

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :goto_0
    return-void

    :pswitch_0
    check-cast p1, Landroid/os/Bundle;

    if-eqz p0, :cond_2

    const-string v0, "hw_accel"

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
