.class public final Lbp4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lmq4;


# instance fields
.field public final a:Ljava/lang/Object;

.field public b:Ly02;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lsy4;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbp4;->a:Ljava/lang/Object;

    iget-object p1, p2, Lsy4;->o:Lqy4;

    iput-object p1, p0, Lbp4;->b:Ly02;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Lbp4;->a:Ljava/lang/Object;

    return-object p0
.end method

.method public final d()Ly02;
    .locals 0

    iget-object p0, p0, Lbp4;->b:Ly02;

    return-object p0
.end method
