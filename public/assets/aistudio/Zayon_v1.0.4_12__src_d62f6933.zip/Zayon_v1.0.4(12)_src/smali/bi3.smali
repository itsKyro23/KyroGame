.class public interface abstract Lbi3;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract A(Ljava/lang/String;)V
.end method

.method public abstract D(Ljava/lang/String;Lyh3;)V
.end method

.method public abstract l(Ljava/lang/String;Lyh3;)V
.end method

.method public abstract s(Lyh3;Ljava/lang/String;Ljava/lang/Throwable;)V
.end method
