.class public final Laf0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Loz;

.field public final b:Lug;

.field public final c:Lzz0;

.field public final d:Lsj;


# direct methods
.method public constructor <init>(Loz;Lug;Lzz0;Lsj;)V
    .locals 0

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laf0;->a:Loz;

    iput-object p2, p0, Laf0;->b:Lug;

    iput-object p3, p0, Laf0;->c:Lzz0;

    iput-object p4, p0, Laf0;->d:Lsj;

    return-void
.end method
