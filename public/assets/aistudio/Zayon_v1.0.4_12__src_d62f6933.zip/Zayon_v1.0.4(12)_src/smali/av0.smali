.class public abstract Lav0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lyu0;)V
.end method
