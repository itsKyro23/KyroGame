.class public interface abstract Lbs1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Llj1;J)Z
.end method

.method public abstract b(IJ)V
.end method

.method public abstract d(J)V
.end method
