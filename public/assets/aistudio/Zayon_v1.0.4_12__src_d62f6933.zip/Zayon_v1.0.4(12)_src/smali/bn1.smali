.class public final Lbn1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lon1;


# static fields
.field public static final d:[J

.field public static final e:[B

.field public static final f:[B


# instance fields
.field public a:I

.field public b:I

.field public c:Ljava/lang/Object;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    new-array v0, v0, [J

    fill-array-data v0, :array_0

    sput-object v0, Lbn1;->d:[J

    const/16 v0, 0x2f

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    sput-object v0, Lbn1;->e:[B

    const/16 v0, 0x2c

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    sput-object v0, Lbn1;->f:[B

    return-void

    :array_0
    .array-data 8
        0x80
        0x40
        0x20
        0x10
        0x8
        0x4
        0x2
        0x1
    .end array-data

    :array_1
    .array-data 1
        0x4ft
        0x67t
        0x67t
        0x53t
        0x0t
        0x2t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x1ct
        -0x2bt
        -0x3bt
        -0x9t
        0x1t
        0x13t
        0x4ft
        0x70t
        0x75t
        0x73t
        0x48t
        0x65t
        0x61t
        0x64t
        0x1t
        0x2t
        0x38t
        0x1t
        -0x80t
        -0x45t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data

    :array_2
    .array-data 1
        0x4ft
        0x67t
        0x67t
        0x53t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x1t
        0x0t
        0x0t
        0x0t
        0xbt
        -0x67t
        0x57t
        0x53t
        0x1t
        0x10t
        0x4ft
        0x70t
        0x75t
        0x73t
        0x54t
        0x61t
        0x67t
        0x73t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x8

    new-array v0, v0, [B

    iput-object v0, p0, Lbn1;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;I)V
    .locals 0

    .line 10
    iput p1, p0, Lbn1;->a:I

    iput p3, p0, Lbn1;->b:I

    iput-object p2, p0, Lbn1;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final g(Ljava/nio/ByteBuffer;JIIZ)V
    .locals 2

    const/16 v0, 0x4f

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/16 v0, 0x67

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/16 v0, 0x53

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    if-eq v1, p5, :cond_0

    move p5, v0

    goto :goto_0

    :cond_0
    const/4 p5, 0x2

    :goto_0
    invoke-virtual {p0, p5}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    invoke-virtual {p0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    invoke-virtual {p0, p3}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    int-to-long p1, p4

    invoke-static {p1, p2}, Lgd;->m(J)B

    move-result p1

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    return-void
.end method

.method public static h(IZ[B)J
    .locals 7

    const/4 v0, 0x0

    aget-byte v0, p2, v0

    int-to-long v0, v0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    if-eqz p1, :cond_0

    add-int/lit8 p1, p0, -0x1

    sget-object v4, Lbn1;->d:[J

    aget-wide v5, v4, p1

    not-long v4, v5

    and-long/2addr v0, v4

    :cond_0
    const/4 p1, 0x1

    :goto_0
    if-ge p1, p0, :cond_1

    const/16 v4, 0x8

    shl-long/2addr v0, v4

    aget-byte v4, p2, p1

    int-to-long v4, v4

    and-long/2addr v4, v2

    or-long/2addr v0, v4

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    return-wide v0
.end method


# virtual methods
.method public a()I
    .locals 0

    iget p0, p0, Lbn1;->b:I

    return p0
.end method

.method public b(Ljava/util/ArrayList;Ljava/util/ArrayList;)Ljava/lang/String;
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iget v2, v0, Lbn1;->a:I

    new-instance v3, Lmg;

    const/16 v4, 0x14

    invoke-direct {v3, v4}, Lmg;-><init>(I)V

    invoke-static {v1, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    const/4 v5, 0x0

    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    const-string v7, ""

    if-ge v5, v6, :cond_11

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lb22;

    iget v6, v6, Lb22;->e:I

    move-object/from16 v8, p1

    invoke-virtual {v8, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    sget-object v9, Ljava/text/Normalizer$Form;->NFKC:Ljava/text/Normalizer$Form;

    invoke-static {v6, v9}, Ljava/text/Normalizer;->normalize(Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;

    move-result-object v6

    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v6, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    const-string v9, "\n"

    invoke-virtual {v6, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    array-length v9, v6

    if-nez v9, :cond_0

    goto/16 :goto_e

    :cond_0
    const/4 v9, 0x0

    :goto_1
    array-length v10, v6

    if-ge v9, v10, :cond_10

    aget-object v10, v6, v9

    const-string v11, "\'"

    invoke-virtual {v10, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_9

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x1

    const/4 v14, 0x0

    :goto_2
    add-int/lit8 v15, v13, 0x2

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    if-gt v15, v4, :cond_6

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v4

    const/16 v16, 0x1

    const/16 v12, 0x27

    if-ne v4, v12, :cond_5

    add-int/lit8 v4, v13, -0x1

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v4

    const/16 v12, 0x20

    if-eq v4, v12, :cond_4

    add-int/lit8 v4, v13, 0x1

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v14

    const/16 v12, 0x73

    if-eq v14, v12, :cond_2

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v4

    const/16 v12, 0x53

    if-ne v4, v12, :cond_1

    goto :goto_3

    :cond_1
    const/16 v12, 0x20

    goto :goto_5

    :cond_2
    :goto_3
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    if-eq v15, v4, :cond_3

    invoke-virtual {v11, v15}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v4

    const/16 v12, 0x20

    if-ne v4, v12, :cond_4

    goto :goto_4

    :cond_3
    const/16 v12, 0x20

    :goto_4
    invoke-virtual {v11, v13, v12}, Ljava/lang/StringBuilder;->insert(IC)Ljava/lang/StringBuilder;

    move v13, v15

    goto :goto_6

    :cond_4
    :goto_5
    invoke-virtual {v11, v13, v12}, Ljava/lang/StringBuilder;->setCharAt(IC)V

    :goto_6
    move/from16 v14, v16

    :cond_5
    add-int/lit8 v13, v13, 0x1

    goto :goto_2

    :cond_6
    const/16 v16, 0x1

    if-eqz v14, :cond_7

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_7

    :cond_7
    const/4 v4, 0x0

    :goto_7
    if-nez v4, :cond_8

    goto :goto_8

    :cond_8
    move-object v10, v4

    :goto_8
    move/from16 v4, v16

    goto :goto_9

    :cond_9
    const/16 v16, 0x1

    goto :goto_8

    :goto_9
    invoke-static {v10, v4}, Lfv2;->q(Ljava/lang/String;Z)[Ljava/lang/String;

    move-result-object v4

    array-length v10, v4

    iget v11, v0, Lbn1;->b:I

    if-ge v10, v11, :cond_a

    goto :goto_d

    :cond_a
    const/4 v10, 0x0

    :goto_a
    array-length v12, v4

    if-ge v10, v12, :cond_e

    move-object v13, v7

    const/4 v12, 0x0

    :goto_b
    if-ge v12, v11, :cond_d

    add-int v14, v10, v12

    array-length v15, v4

    if-lt v14, v15, :cond_b

    goto :goto_c

    :cond_b
    if-lez v12, :cond_c

    const-string v15, " "

    invoke-virtual {v13, v15}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    :cond_c
    aget-object v14, v4, v14

    invoke-static {v14}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    add-int/lit8 v12, v12, 0x1

    goto :goto_b

    :cond_d
    invoke-virtual {v3, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    move-result v12

    if-ge v12, v2, :cond_11

    add-int/lit8 v10, v10, 0x1

    goto :goto_a

    :cond_e
    :goto_c
    invoke-virtual {v3}, Ljava/util/HashSet;->size()I

    move-result v4

    if-lt v4, v2, :cond_f

    goto :goto_f

    :cond_f
    :goto_d
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_1

    :cond_10
    :goto_e
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0

    :cond_11
    :goto_f
    new-instance v1, Ljava/io/ByteArrayOutputStream;

    const/16 v2, 0x1000

    invoke-direct {v1, v2}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    new-instance v2, Landroid/util/Base64OutputStream;

    const/16 v4, 0xa

    invoke-direct {v2, v1, v4}, Landroid/util/Base64OutputStream;-><init>(Ljava/io/OutputStream;I)V

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_10
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_12

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    :try_start_0
    iget-object v5, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v5, Lg22;

    invoke-virtual {v5, v4}, Lg22;->v(Ljava/lang/String;)[B

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/io/OutputStream;->write([B)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_10

    :catch_0
    sget v0, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :cond_12
    :try_start_1
    invoke-virtual {v2}, Landroid/util/Base64OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_11

    :catch_1
    sget v0, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :goto_11
    :try_start_2
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toString()Ljava/lang/String;

    move-result-object v7
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_12

    :catchall_0
    move-exception v0

    throw v0

    :catch_2
    sget v0, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :goto_12
    return-object v7
.end method

.method public c(Lyl4;Ljava/util/List;)V
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v1, Lyl4;->d:Ljava/nio/ByteBuffer;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/nio/Buffer;->limit()I

    move-result v2

    iget-object v3, v1, Lyl4;->d:Ljava/nio/ByteBuffer;

    invoke-virtual {v3}, Ljava/nio/Buffer;->position()I

    move-result v3

    sub-int/2addr v2, v3

    if-nez v2, :cond_0

    return-void

    :cond_0
    iget v2, v0, Lbn1;->a:I

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-ne v2, v4, :cond_2

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->size()I

    move-result v2

    if-eq v2, v5, :cond_1

    invoke-interface/range {p2 .. p2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x3

    if-ne v2, v7, :cond_2

    :cond_1
    move-object/from16 v2, p2

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, [B

    :cond_2
    iget-object v2, v1, Lyl4;->d:Ljava/nio/ByteBuffer;

    invoke-virtual {v2}, Ljava/nio/Buffer;->position()I

    move-result v7

    invoke-virtual {v2}, Ljava/nio/Buffer;->limit()I

    move-result v8

    sub-int v9, v8, v7

    iget v10, v0, Lbn1;->a:I

    add-int/lit16 v11, v9, 0xff

    const/16 v12, 0xff

    div-int/2addr v11, v12

    add-int/lit8 v13, v11, 0x1b

    add-int/2addr v13, v9

    if-ne v10, v4, :cond_4

    if-eqz v3, :cond_3

    array-length v10, v3

    add-int/lit8 v10, v10, 0x1c

    goto :goto_0

    :cond_3
    const/16 v10, 0x2f

    :goto_0
    add-int/lit8 v14, v10, 0x2c

    add-int/2addr v13, v14

    goto :goto_1

    :cond_4
    move v10, v6

    :goto_1
    iget-object v14, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v14, Ljava/nio/ByteBuffer;

    invoke-virtual {v14}, Ljava/nio/Buffer;->capacity()I

    move-result v14

    if-ge v14, v13, :cond_5

    invoke-static {v13}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v13

    sget-object v14, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v13, v14}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v13

    iput-object v13, v0, Lbn1;->c:Ljava/lang/Object;

    goto :goto_2

    :cond_5
    iget-object v13, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v13, Ljava/nio/ByteBuffer;

    invoke-virtual {v13}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    :goto_2
    iget-object v13, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v13, Ljava/nio/ByteBuffer;

    iget v14, v0, Lbn1;->a:I

    const/16 v15, 0x16

    if-ne v14, v4, :cond_7

    if-eqz v3, :cond_6

    const/16 v18, 0x1

    const/16 v19, 0x1

    move v14, v15

    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    move/from16 v21, v14

    move-object v14, v13

    move/from16 v13, v21

    invoke-static/range {v14 .. v19}, Lbn1;->g(Ljava/nio/ByteBuffer;JIIZ)V

    array-length v15, v3

    int-to-long v4, v15

    invoke-static {v4, v5}, Lgd;->m(J)B

    move-result v4

    invoke-virtual {v14, v4}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    invoke-virtual {v14, v3}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v3

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v4

    add-int/lit8 v15, v15, 0x1c

    invoke-static {v4, v15, v6, v3}, Lvh3;->h(III[B)I

    move-result v3

    invoke-virtual {v14, v13, v3}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    invoke-virtual {v14, v15}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    goto :goto_3

    :cond_6
    move-object v14, v13

    move v13, v15

    sget-object v3, Lbn1;->e:[B

    invoke-virtual {v14, v3}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    :goto_3
    sget-object v3, Lbn1;->f:[B

    invoke-virtual {v14, v3}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    goto :goto_4

    :cond_7
    move-object v14, v13

    move v13, v15

    :goto_4
    invoke-virtual {v2, v6}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v3

    invoke-virtual {v2}, Ljava/nio/Buffer;->limit()I

    move-result v4

    const/4 v5, 0x1

    if-le v4, v5, :cond_8

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v4

    goto :goto_5

    :cond_8
    move v4, v6

    :goto_5
    invoke-static {v3, v4}, Lfv2;->v(BB)J

    move-result-wide v3

    const-wide/32 v15, 0xbb80

    mul-long/2addr v3, v15

    const-wide/32 v15, 0xf4240

    div-long/2addr v3, v15

    long-to-int v3, v3

    iget v4, v0, Lbn1;->b:I

    add-int/2addr v4, v3

    iput v4, v0, Lbn1;->b:I

    iget v3, v0, Lbn1;->a:I

    int-to-long v4, v4

    const/16 v18, 0x0

    move/from16 v16, v3

    move/from16 v17, v11

    move v3, v13

    move-object v13, v14

    move-wide v14, v4

    invoke-static/range {v13 .. v18}, Lbn1;->g(Ljava/nio/ByteBuffer;JIIZ)V

    move-object v14, v13

    move v4, v6

    :goto_6
    if-ge v4, v11, :cond_a

    if-lt v9, v12, :cond_9

    const/4 v5, -0x1

    invoke-virtual {v14, v5}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    add-int/lit16 v9, v9, -0xff

    goto :goto_7

    :cond_9
    int-to-byte v5, v9

    invoke-virtual {v14, v5}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    move v9, v6

    :goto_7
    add-int/lit8 v4, v4, 0x1

    goto :goto_6

    :cond_a
    :goto_8
    if-ge v7, v8, :cond_b

    invoke-virtual {v2, v7}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v4

    invoke-virtual {v14, v4}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    add-int/lit8 v7, v7, 0x1

    goto :goto_8

    :cond_b
    invoke-virtual {v2}, Ljava/nio/Buffer;->limit()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    iget v2, v0, Lbn1;->a:I

    const/4 v4, 0x2

    if-ne v2, v4, :cond_c

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v3

    add-int/2addr v3, v10

    add-int/lit8 v3, v3, 0x2c

    invoke-virtual {v14}, Ljava/nio/Buffer;->limit()I

    move-result v4

    invoke-virtual {v14}, Ljava/nio/Buffer;->position()I

    move-result v5

    sub-int/2addr v4, v5

    invoke-static {v3, v4, v6, v2}, Lvh3;->h(III[B)I

    move-result v2

    add-int/lit8 v10, v10, 0x42

    invoke-virtual {v14, v10, v2}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    goto :goto_9

    :cond_c
    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v2

    invoke-virtual {v14}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v4

    invoke-virtual {v14}, Ljava/nio/Buffer;->limit()I

    move-result v5

    invoke-virtual {v14}, Ljava/nio/Buffer;->position()I

    move-result v7

    sub-int/2addr v5, v7

    invoke-static {v4, v5, v6, v2}, Lvh3;->h(III[B)I

    move-result v2

    invoke-virtual {v14, v3, v2}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    :goto_9
    iget v2, v0, Lbn1;->a:I

    const/16 v20, 0x1

    add-int/lit8 v2, v2, 0x1

    iput v2, v0, Lbn1;->a:I

    iput-object v14, v0, Lbn1;->c:Ljava/lang/Object;

    invoke-virtual {v1}, Lyl4;->a()V

    iget-object v2, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v2, Ljava/nio/ByteBuffer;

    invoke-virtual {v2}, Ljava/nio/Buffer;->remaining()I

    move-result v2

    invoke-virtual {v1, v2}, Lyl4;->d(I)V

    iget-object v2, v1, Lyl4;->d:Ljava/nio/ByteBuffer;

    iget-object v0, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    invoke-virtual {v1}, Lyl4;->f()V

    return-void
.end method

.method public d()I
    .locals 0

    iget p0, p0, Lbn1;->a:I

    return p0
.end method

.method public e(Llj1;ZZI)J
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lbn1;->c:Ljava/lang/Object;

    check-cast v2, [B

    iget v3, v0, Lbn1;->a:I

    const/4 v4, -0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v3, :cond_4

    move/from16 v3, p2

    invoke-interface {v1, v2, v6, v5, v3}, Llj1;->x([BIIZ)Z

    move-result v3

    if-nez v3, :cond_0

    const-wide/16 v0, -0x1

    return-wide v0

    :cond_0
    aget-byte v3, v2, v6

    and-int/lit16 v3, v3, 0xff

    move v7, v6

    :goto_0
    const/16 v8, 0x8

    const-wide/16 v9, 0x0

    if-ge v7, v8, :cond_2

    add-int/lit8 v8, v7, 0x1

    sget-object v11, Lbn1;->d:[J

    aget-wide v12, v11, v7

    int-to-long v14, v3

    and-long v11, v12, v14

    cmp-long v7, v11, v9

    if-eqz v7, :cond_1

    goto :goto_1

    :cond_1
    move v7, v8

    goto :goto_0

    :cond_2
    move v8, v4

    :goto_1
    iput v8, v0, Lbn1;->b:I

    if-eq v8, v4, :cond_3

    iput v5, v0, Lbn1;->a:I

    goto :goto_2

    :cond_3
    const-string v0, "No valid varint length mask found"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)V

    return-wide v9

    :cond_4
    :goto_2
    iget v3, v0, Lbn1;->b:I

    move/from16 v7, p4

    if-le v3, v7, :cond_5

    iput v6, v0, Lbn1;->a:I

    const-wide/16 v0, -0x2

    return-wide v0

    :cond_5
    if-eq v3, v5, :cond_6

    add-int/2addr v3, v4

    invoke-interface {v1, v5, v3, v2}, Llj1;->B(II[B)V

    :cond_6
    iput v6, v0, Lbn1;->a:I

    iget v0, v0, Lbn1;->b:I

    move/from16 v1, p3

    invoke-static {v0, v1, v2}, Lbn1;->h(IZ[B)J

    move-result-wide v0

    return-wide v0
.end method

.method public f()I
    .locals 2

    iget v0, p0, Lbn1;->a:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_0

    iget-object p0, p0, Lbn1;->c:Ljava/lang/Object;

    check-cast p0, Lzb3;

    invoke-virtual {p0}, Lzb3;->h()I

    move-result p0

    return p0

    :cond_0
    return v0
.end method
