.class public final Lad0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final h:[I

.field public static final i:[I

.field public static final j:[I


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ll00;

.field public final c:Landroid/widget/LinearLayout;

.field public final d:Landroid/view/View;

.field public final e:Landroid/view/LayoutInflater;

.field public final f:F

.field public final g:Ljava/text/SimpleDateFormat;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const v0, 0x7f07009e

    const v1, 0x7f070098

    const v2, 0x7f0700da

    const v3, 0x7f0700e4

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lad0;->h:[I

    const v0, 0x7f0f00c2

    const v1, 0x7f0f00bb

    const v2, 0x7f0f00c8

    const v3, 0x7f0f00cb

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lad0;->i:[I

    const v0, 0x7f0901a3

    const v1, 0x7f09019f

    const v2, 0x7f0901a4

    const v3, 0x7f0901a6

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lad0;->j:[I

    return-void
.end method

.method public constructor <init>(Landroid/view/View;Ll00;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/text/SimpleDateFormat;

    new-instance v1, Ljava/util/Locale;

    const-string v2, "id"

    const-string v3, "ID"

    invoke-direct {v1, v2, v3}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "d MMM yyyy"

    invoke-direct {v0, v2, v1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lad0;->g:Ljava/text/SimpleDateFormat;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lad0;->a:Landroid/content/Context;

    iput-object p2, p0, Lad0;->b:Ll00;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    iput v1, p0, Lad0;->f:F

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Lad0;->e:Landroid/view/LayoutInflater;

    const v0, 0x7f0900f1

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Lad0;->c:Landroid/widget/LinearLayout;

    const v0, 0x7f0900ee

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lad0;->d:Landroid/view/View;

    const v0, 0x7f0900ef

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/zayon/optimize/ui/ZyBox;->setBorderDashed(Z)V

    const v0, 0x7f0900f2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lk1;

    const/4 v3, 0x6

    invoke-direct {v2, v3}, Lk1;-><init>(I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v2, Lyc0;

    const/4 v4, 0x0

    invoke-direct {v2, p0, p2, v4}, Lyc0;-><init>(Lad0;Ll00;I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f0900f0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Lk1;

    invoke-direct {v0, v3}, Lk1;-><init>(I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v0, Lyc0;

    invoke-direct {v0, p0, p2, v1}, Lyc0;-><init>(Lad0;Ll00;I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Lad0;->a()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, Lad0;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v2, v0, Lad0;->a:Landroid/content/Context;

    invoke-static {v2}, Lcd0;->e(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-string v5, "zayon_map_profiles"

    const/4 v6, 0x0

    invoke-virtual {v4, v5, v6}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    const-string v5, "active"

    const/4 v7, 0x0

    invoke-interface {v4, v5, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v5

    move v7, v6

    :goto_0
    if-ge v7, v5, :cond_f

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    add-int/lit8 v7, v7, 0x1

    check-cast v9, Lbd0;

    iget-object v10, v9, Lbd0;->a:Ljava/lang/String;

    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    iget-object v11, v0, Lad0;->e:Landroid/view/LayoutInflater;

    const v12, 0x7f0c0043

    invoke-virtual {v11, v12, v1, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v11

    check-cast v11, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v13

    if-nez v13, :cond_0

    const/16 v13, 0xe

    goto :goto_1

    :cond_0
    const/16 v13, 0xa

    :goto_1
    int-to-float v13, v13

    iget v14, v0, Lad0;->f:F

    mul-float/2addr v13, v14

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    iput v13, v12, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v11, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v10, :cond_1

    const v12, 0x7f050073

    goto :goto_2

    :cond_1
    const v12, 0x7f05025e

    :goto_2
    invoke-virtual {v2, v12}, Landroid/content/Context;->getColor(I)I

    move-result v12

    invoke-virtual {v11, v12}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    const v12, 0x7f050084

    if-eqz v10, :cond_2

    move v13, v12

    goto :goto_3

    :cond_2
    const v13, 0x7f050263

    :goto_3
    invoke-virtual {v2, v13}, Landroid/content/Context;->getColor(I)I

    move-result v13

    invoke-virtual {v11, v13}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    const v13, 0x7f0901a1

    invoke-virtual {v11, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Lcom/zayon/optimize/ui/ZyBox;

    if-eqz v10, :cond_3

    const v15, 0x7f050078

    goto :goto_4

    :cond_3
    const v15, 0x7f050261

    :goto_4
    invoke-virtual {v2, v15}, Landroid/content/Context;->getColor(I)I

    move-result v15

    invoke-virtual {v13, v15}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    if-eqz v10, :cond_4

    move v15, v12

    goto :goto_5

    :cond_4
    const v15, 0x7f050264

    :goto_5
    invoke-virtual {v2, v15}, Landroid/content/Context;->getColor(I)I

    move-result v15

    invoke-virtual {v13, v15}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    const v13, 0x7f0901a0

    invoke-virtual {v11, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/ImageView;

    const v16, 0x7f050071

    if-eqz v10, :cond_5

    move/from16 v6, v16

    goto :goto_6

    :cond_5
    const v6, 0x7f050230

    :goto_6
    invoke-virtual {v2, v6}, Landroid/content/Context;->getColor(I)I

    move-result v6

    invoke-virtual {v13, v6}, Landroid/widget/ImageView;->setColorFilter(I)V

    const v6, 0x7f0901a2

    invoke-virtual {v11, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    iget-object v13, v9, Lbd0;->c:Ljava/lang/String;

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v6, 0x7f09019e

    invoke-virtual {v11, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    new-instance v13, Ljava/util/Date;

    iget-wide v14, v9, Lbd0;->b:J

    invoke-direct {v13, v14, v15}, Ljava/util/Date;-><init>(J)V

    iget-object v14, v0, Lad0;->g:Ljava/text/SimpleDateFormat;

    invoke-virtual {v14, v13}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v13

    filled-new-array {v13}, [Ljava/lang/Object;

    move-result-object v13

    const v14, 0x7f0f00c7

    invoke-virtual {v2, v14, v13}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v6, 0x7f0901a5

    invoke-virtual {v11, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    invoke-virtual {v9, v2}, Lbd0;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v6, 0x7f0901a7

    invoke-virtual {v11, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Lcom/zayon/optimize/ui/ZyBox;

    const v13, 0x7f0901a8

    invoke-virtual {v6, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/ImageView;

    const v14, 0x7f0901a9

    invoke-virtual {v6, v14}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    const v15, 0x7f05008a

    if-eqz v10, :cond_6

    move v8, v15

    goto :goto_7

    :cond_6
    const v8, 0x7f050078

    :goto_7
    invoke-virtual {v2, v8}, Landroid/content/Context;->getColor(I)I

    move-result v8

    invoke-virtual {v6, v8}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    if-eqz v10, :cond_7

    move v12, v15

    :cond_7
    invoke-virtual {v2, v12}, Landroid/content/Context;->getColor(I)I

    move-result v8

    invoke-virtual {v6, v8}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    if-eqz v10, :cond_8

    const/4 v8, 0x0

    goto :goto_8

    :cond_8
    const/16 v8, 0x8

    :goto_8
    invoke-virtual {v13, v8}, Landroid/widget/ImageView;->setVisibility(I)V

    const v8, 0x7f070090

    invoke-virtual {v13, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    const v8, 0x7f050161

    invoke-virtual {v2, v8}, Landroid/content/Context;->getColor(I)I

    move-result v12

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setColorFilter(I)V

    if-eqz v10, :cond_9

    const v12, 0x7f0f00b8

    goto :goto_9

    :cond_9
    const v12, 0x7f0f00cf

    :goto_9
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setText(I)V

    if-eqz v10, :cond_a

    const v12, 0x3df5c28f    # 0.12f

    goto :goto_a

    :cond_a
    const/4 v12, 0x0

    :goto_a
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setLetterSpacing(F)V

    if-eqz v10, :cond_b

    goto :goto_b

    :cond_b
    move/from16 v8, v16

    :goto_b
    invoke-virtual {v2, v8}, Landroid/content/Context;->getColor(I)I

    move-result v8

    invoke-virtual {v14, v8}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v8, 0x6

    if-nez v10, :cond_c

    new-instance v10, Lk1;

    invoke-direct {v10, v8}, Lk1;-><init>(I)V

    invoke-virtual {v6, v10}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v10, Le1;

    const/4 v12, 0x7

    invoke-direct {v10, v0, v12, v9}, Le1;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v6, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_c
    const/4 v6, 0x0

    :goto_c
    const/4 v10, 0x4

    if-ge v6, v10, :cond_e

    sget-object v10, Lad0;->j:[I

    aget v10, v10, v6

    invoke-virtual {v11, v10}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Lcom/zayon/optimize/ui/ZyBox;

    const/4 v12, 0x3

    if-ne v6, v12, :cond_d

    const v12, 0x7f05019a

    goto :goto_d

    :cond_d
    const v12, 0x7f050230

    :goto_d
    invoke-virtual {v2, v12}, Landroid/content/Context;->getColor(I)I

    move-result v12

    const v13, 0x7f09019c

    invoke-virtual {v10, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/ImageView;

    sget-object v14, Lad0;->h:[I

    aget v14, v14, v6

    invoke-virtual {v13, v14}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setColorFilter(I)V

    const v13, 0x7f09019d

    invoke-virtual {v10, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/TextView;

    sget-object v14, Lad0;->i:[I

    aget v14, v14, v6

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(I)V

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v12, Lk1;

    invoke-direct {v12, v8}, Lk1;-><init>(I)V

    invoke-virtual {v10, v12}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v12, Lo20;

    const/4 v13, 0x1

    invoke-direct {v12, v0, v6, v9, v13}, Lo20;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v10, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_c

    :cond_e
    invoke-virtual {v1, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_f
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_10

    const/4 v6, 0x0

    goto :goto_e

    :cond_10
    const/16 v6, 0x8

    :goto_e
    iget-object v0, v0, Lad0;->d:Landroid/view/View;

    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
