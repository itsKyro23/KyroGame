.class public final enum Lah4;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum i:Lah4;

.field public static final enum j:Lah4;

.field public static final enum k:Lah4;

.field public static final enum l:Lah4;

.field public static final enum m:Lah4;

.field public static final enum n:Lah4;

.field public static final enum o:Lah4;

.field public static final enum p:Lah4;

.field public static final enum q:Lah4;

.field public static final enum r:Lah4;

.field public static final synthetic s:[Lah4;


# instance fields
.field public final h:Ljava/lang/Class;


# direct methods
.method static constructor <clinit>()V
    .locals 13

    new-instance v0, Lah4;

    const-string v1, "VOID"

    const/4 v2, 0x0

    const-class v3, Ljava/lang/Void;

    invoke-direct {v0, v2, v3, v1}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v0, Lah4;->i:Lah4;

    new-instance v1, Lah4;

    const-string v2, "INT"

    const/4 v3, 0x1

    const-class v4, Ljava/lang/Integer;

    invoke-direct {v1, v3, v4, v2}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v1, Lah4;->j:Lah4;

    new-instance v2, Lah4;

    const-string v3, "LONG"

    const/4 v5, 0x2

    const-class v6, Ljava/lang/Long;

    invoke-direct {v2, v5, v6, v3}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v2, Lah4;->k:Lah4;

    new-instance v3, Lah4;

    const-string v5, "FLOAT"

    const/4 v6, 0x3

    const-class v7, Ljava/lang/Float;

    invoke-direct {v3, v6, v7, v5}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v3, Lah4;->l:Lah4;

    move-object v5, v4

    new-instance v4, Lah4;

    const-string v6, "DOUBLE"

    const/4 v7, 0x4

    const-class v8, Ljava/lang/Double;

    invoke-direct {v4, v7, v8, v6}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v4, Lah4;->m:Lah4;

    move-object v6, v5

    new-instance v5, Lah4;

    const-string v7, "BOOLEAN"

    const/4 v8, 0x5

    const-class v9, Ljava/lang/Boolean;

    invoke-direct {v5, v8, v9, v7}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v5, Lah4;->n:Lah4;

    move-object v7, v6

    new-instance v6, Lah4;

    const-string v8, "STRING"

    const/4 v9, 0x6

    const-class v10, Ljava/lang/String;

    invoke-direct {v6, v9, v10, v8}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v6, Lah4;->o:Lah4;

    move-object v8, v7

    new-instance v7, Lah4;

    sget-object v9, Lyf4;->i:Lwf4;

    const-string v9, "BYTE_STRING"

    const/4 v10, 0x7

    const-class v11, Lyf4;

    invoke-direct {v7, v10, v11, v9}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v7, Lah4;->p:Lah4;

    move-object v9, v8

    new-instance v8, Lah4;

    const-string v10, "ENUM"

    const/16 v11, 0x8

    invoke-direct {v8, v11, v9, v10}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v8, Lah4;->q:Lah4;

    new-instance v9, Lah4;

    const-string v10, "MESSAGE"

    const/16 v11, 0x9

    const-class v12, Ljava/lang/Object;

    invoke-direct {v9, v11, v12, v10}, Lah4;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v9, Lah4;->r:Lah4;

    filled-new-array/range {v0 .. v9}, [Lah4;

    move-result-object v0

    sput-object v0, Lah4;->s:[Lah4;

    return-void
.end method

.method public constructor <init>(ILjava/lang/Class;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0, p3, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p2, p0, Lah4;->h:Ljava/lang/Class;

    return-void
.end method

.method public static values()[Lah4;
    .locals 1

    sget-object v0, Lah4;->s:[Lah4;

    invoke-virtual {v0}, [Lah4;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lah4;

    return-object v0
.end method
