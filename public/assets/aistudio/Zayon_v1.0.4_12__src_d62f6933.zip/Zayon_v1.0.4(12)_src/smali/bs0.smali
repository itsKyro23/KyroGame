.class public final Lbs0;
.super Ljava/lang/Exception;
.source "SourceFile"
