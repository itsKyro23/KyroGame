.class public abstract Lb44;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ll64;

.field public static final b:Lj64;

.field public static final c:Lu54;

.field public static final d:Ls54;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget-object v0, La44;->j:La44;

    new-instance v1, Ll64;

    const-class v2, Lz34;

    invoke-direct {v1, v2, v0}, Ll64;-><init>(Ljava/lang/Class;Lm64;)V

    sput-object v1, Lb44;->a:Ll64;

    sget-object v0, La44;->i:La44;

    new-instance v1, Lj64;

    const-string v2, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-direct {v1, v2, v0}, Lj64;-><init>(Ljava/lang/String;Lk64;)V

    sput-object v1, Lb44;->b:Lj64;

    sget-object v0, Lu34;->j:Lu34;

    new-instance v1, Lu54;

    const-class v3, Ly34;

    invoke-direct {v1, v3, v0}, Lu54;-><init>(Ljava/lang/Class;Lv54;)V

    sput-object v1, Lb44;->c:Lu54;

    sget-object v0, Lw34;->j:Lw34;

    new-instance v1, Ls54;

    invoke-direct {v1, v2, v0}, Ls54;-><init>(Ljava/lang/String;Lt54;)V

    sput-object v1, Lb44;->d:Ls54;

    return-void
.end method

.method public static a(Lm24;)Lm24;
    .locals 2

    sget-object v0, Lm24;->i:Lm24;

    if-eq p0, v0, :cond_1

    sget-object v0, Lm24;->j:Lm24;

    if-ne p0, v0, :cond_0

    sget-object p0, Lm24;->f:Lm24;

    return-object p0

    :cond_0
    new-instance v0, Ljava/security/GeneralSecurityException;

    iget-object p0, p0, Lm24;->b:Ljava/lang/String;

    const-string v1, "Unable to serialize variant: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    sget-object p0, Lm24;->d:Lm24;

    return-object p0
.end method
