.class public interface abstract La0;
.super Ljava/lang/Object;


# virtual methods
.method public abstract d()Ljava/lang/String;
.end method
