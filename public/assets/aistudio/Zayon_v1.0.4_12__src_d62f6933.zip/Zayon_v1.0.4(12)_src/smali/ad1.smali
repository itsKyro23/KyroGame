.class public abstract Lad1;
.super Lkc1;
.source "SourceFile"

# interfaces
.implements Lcd1;


# static fields
.field public static final synthetic i:I
