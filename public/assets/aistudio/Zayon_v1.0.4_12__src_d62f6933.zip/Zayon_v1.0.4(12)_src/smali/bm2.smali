.class public final Lbm2;
.super Ljava/lang/Exception;
.source "SourceFile"
