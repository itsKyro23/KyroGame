.class public interface abstract Lbk1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()J
.end method

.method public abstract b(J)Lak1;
.end method

.method public abstract d()Z
.end method

.method public n()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method
