.class public final Lbd2;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lqc2;


# instance fields
.field public final h:Lve1;


# direct methods
.method public constructor <init>(Lve1;)V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.mediation.client.IUnifiedNativeAdMapper"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lbd2;->h:Lve1;

    return-void
.end method


# virtual methods
.method public final A2()Landroid/os/Bundle;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->l:Landroid/os/Bundle;

    return-object p0
.end method

.method public final F0()V
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final L()F
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return p0
.end method

.method public final M()Z
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-boolean p0, p0, Lve1;->m:Z

    return p0
.end method

.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2

    packed-switch p3, :pswitch_data_0

    const/4 p0, 0x0

    return p0

    :pswitch_0
    invoke-interface {p0}, Lqc2;->s1()V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_0

    :pswitch_1
    invoke-interface {p0}, Lqc2;->R()F

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeFloat(F)V

    goto/16 :goto_0

    :pswitch_2
    invoke-interface {p0}, Lqc2;->L()F

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeFloat(F)V

    goto/16 :goto_0

    :pswitch_3
    invoke-interface {p0}, Lqc2;->v()F

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeFloat(F)V

    goto/16 :goto_0

    :pswitch_4
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lqc2;->h1(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_0

    :pswitch_5
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object v0

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object v1

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3, v0, v1}, Lqc2;->u1(Ll50;Ll50;Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_0

    :pswitch_6
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lqc2;->g0(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_0

    :pswitch_7
    invoke-interface {p0}, Lqc2;->F0()V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_0

    :pswitch_8
    invoke-interface {p0}, Lqc2;->m2()Z

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    sget-object p1, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeInt(I)V

    goto/16 :goto_0

    :pswitch_9
    invoke-interface {p0}, Lqc2;->M()Z

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    sget-object p1, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeInt(I)V

    goto/16 :goto_0

    :pswitch_a
    invoke-interface {p0}, Lqc2;->A2()Landroid/os/Bundle;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->d(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    goto/16 :goto_0

    :pswitch_b
    invoke-interface {p0}, Lqc2;->x()Ll50;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto/16 :goto_0

    :pswitch_c
    invoke-interface {p0}, Lqc2;->m()Ll50;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto/16 :goto_0

    :pswitch_d
    invoke-interface {p0}, Lqc2;->p()Ll50;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto/16 :goto_0

    :pswitch_e
    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    sget-object p0, Lg12;->a:Ljava/lang/ClassLoader;

    const/4 p0, 0x0

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    goto/16 :goto_0

    :pswitch_f
    invoke-interface {p0}, Lqc2;->o()Lo23;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto :goto_0

    :pswitch_10
    invoke-interface {p0}, Lqc2;->n()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_11
    invoke-interface {p0}, Lqc2;->j()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_12
    invoke-interface {p0}, Lqc2;->i()D

    move-result-wide p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0, p1}, Landroid/os/Parcel;->writeDouble(D)V

    goto :goto_0

    :pswitch_13
    invoke-interface {p0}, Lqc2;->h()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_14
    invoke-interface {p0}, Lqc2;->l()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_15
    invoke-interface {p0}, Lqc2;->g()Ly72;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto :goto_0

    :pswitch_16
    invoke-interface {p0}, Lqc2;->e()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_0

    :pswitch_17
    invoke-interface {p0}, Lqc2;->c()Ljava/util/List;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeList(Ljava/util/List;)V

    goto :goto_0

    :pswitch_18
    invoke-interface {p0}, Lqc2;->b()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    :goto_0
    const/4 p0, 0x1

    return p0

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final R()F
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return p0
.end method

.method public final b()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->a:Ljava/lang/String;

    return-object p0
.end method

.method public final c()Ljava/util/List;
    .locals 12

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->b:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-nez p0, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    check-cast v3, Lz72;

    new-instance v4, Lm72;

    iget-object v5, v3, Lz72;->b:Landroid/graphics/drawable/Drawable;

    iget-object v6, v3, Lz72;->c:Landroid/net/Uri;

    iget-wide v7, v3, Lz72;->d:D

    iget v9, v3, Lz72;->e:I

    iget v10, v3, Lz72;->f:I

    const/4 v11, 0x0

    invoke-direct/range {v4 .. v11}, Lm72;-><init>(Landroid/graphics/drawable/Drawable;Landroid/net/Uri;DIILjava/util/HashMap;)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    :goto_1
    return-object v0
.end method

.method public final e()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->c:Ljava/lang/String;

    return-object p0
.end method

.method public final g()Ly72;
    .locals 8

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->d:Lz72;

    if-eqz p0, :cond_0

    new-instance v0, Lm72;

    iget-object v1, p0, Lz72;->b:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, Lz72;->c:Landroid/net/Uri;

    iget-wide v3, p0, Lz72;->d:D

    iget v5, p0, Lz72;->e:I

    iget v6, p0, Lz72;->f:I

    const/4 v7, 0x0

    invoke-direct/range {v0 .. v7}, Lm72;-><init>(Landroid/graphics/drawable/Drawable;Landroid/net/Uri;DIILjava/util/HashMap;)V

    return-object v0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final g0(Ll50;)V
    .locals 0

    invoke-static {p1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final h()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->f:Ljava/lang/String;

    return-object p0
.end method

.method public final h1(Ll50;)V
    .locals 0

    invoke-static {p1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final i()D
    .locals 2

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->g:Ljava/lang/Double;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    return-wide v0

    :cond_0
    const-wide/high16 v0, -0x4010000000000000L    # -1.0

    return-wide v0
.end method

.method public final j()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->h:Ljava/lang/String;

    return-object p0
.end method

.method public final l()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->e:Ljava/lang/String;

    return-object p0
.end method

.method public final m()Ll50;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method public final m2()Z
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-boolean p0, p0, Lve1;->n:Z

    return p0
.end method

.method public final n()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->i:Ljava/lang/String;

    return-object p0
.end method

.method public final o()Lo23;
    .locals 1

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->j:La71;

    if-eqz p0, :cond_0

    iget-object v0, p0, La71;->a:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object p0, p0, La71;->b:Lo23;

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final p()Ll50;
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0
.end method

.method public final s()Lr72;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public final s1()V
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final u1(Ll50;Ll50;Ll50;)V
    .locals 0

    invoke-static {p2}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/HashMap;

    invoke-static {p3}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/HashMap;

    invoke-static {p1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/View;

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p0, Lcf2;->a:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lnu0;->f()V

    return-void
.end method

.method public final v()F
    .locals 0

    iget-object p0, p0, Lbd2;->h:Lve1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return p0
.end method

.method public final x()Ll50;
    .locals 1

    iget-object p0, p0, Lbd2;->h:Lve1;

    iget-object p0, p0, Lve1;->k:Ljava/lang/Object;

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v0, Lui0;

    invoke-direct {v0, p0}, Lui0;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method
