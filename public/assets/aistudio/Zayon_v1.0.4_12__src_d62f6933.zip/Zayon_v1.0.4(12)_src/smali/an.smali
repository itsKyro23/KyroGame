.class public interface abstract Lan;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Loz;Llj;)Ljava/lang/Object;
.end method

.method public abstract getData()Lbw;
.end method
