.class public Laq0;
.super Lrx;
.source "SourceFile"


# static fields
.field public static final h1:[I

.field public static final i1:[I

.field public static final j1:[I


# instance fields
.field public A0:Landroid/view/View;

.field public B0:Lcom/zayon/optimize/ui/ZyBox;

.field public C0:Lcom/zayon/optimize/ui/ZyBox;

.field public D0:Lu1;

.field public E0:Landroid/widget/TextView;

.field public F0:Landroid/widget/TextView;

.field public G0:Landroid/widget/TextView;

.field public H0:Landroid/widget/TextView;

.field public I0:Landroid/widget/TextView;

.field public J0:Lcom/zayon/optimize/ui/ZyBox;

.field public K0:Lcom/zayon/optimize/ui/ZyBox;

.field public L0:Lcom/zayon/optimize/ui/ZyBox;

.field public M0:Lcom/zayon/optimize/ui/ZyBox;

.field public N0:Landroid/widget/TextView;

.field public O0:Landroid/widget/TextView;

.field public P0:Landroid/view/View;

.field public final Q0:Landroid/os/Handler;

.field public R0:Z

.field public S0:I

.field public T0:Z

.field public U0:Ll41;

.field public V0:Ll41;

.field public W0:Ll41;

.field public X0:Ll41;

.field public final Y0:[Loo4;

.field public final Z0:Lag0;

.field public final a1:Lzp0;

.field public b1:Z

.field public c0:F

.field public final c1:Lwp0;

.field public d0:C

.field public d1:Landroid/widget/LinearLayout;

.field public e0:C

.field public e1:Lcom/zayon/optimize/ui/ZyTextView;

.field public f0:Ljava/lang/String;

.field public f1:Lcom/zayon/optimize/ui/ZyBox;

.field public g0:Landroid/view/View;

.field public final g1:Lzp0;

.field public h0:Landroid/view/View;

.field public i0:Landroid/view/View;

.field public j0:Landroid/view/View;

.field public k0:Landroid/view/View;

.field public l0:Landroid/view/View;

.field public m0:Landroid/view/View;

.field public n0:Landroid/widget/TextView;

.field public o0:Landroid/widget/TextView;

.field public p0:Landroid/widget/TextView;

.field public q0:Landroid/widget/TextView;

.field public r0:Landroid/widget/TextView;

.field public s0:Landroid/view/View;

.field public t0:Landroid/view/View;

.field public u0:Landroid/view/View;

.field public v0:Landroid/widget/TextView;

.field public w0:Landroid/widget/TextView;

.field public x0:Landroid/animation/ObjectAnimator;

.field public y0:Z

.field public z0:Landroid/view/View;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const v0, 0x7f0f012e

    const v1, 0x7f0f012f

    const v2, 0x7f0f012d

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Laq0;->h1:[I

    const v0, 0x7f0f0100

    const v1, 0x7f0f0101

    const v2, 0x7f0f00fe

    const v3, 0x7f0f00ff

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Laq0;->i1:[I

    const v0, 0x7f0f011f

    const v1, 0x7f0f0120

    const v2, 0x7f0f011d

    const v3, 0x7f0f011e

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Laq0;->j1:[I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const v0, 0x7f0c0026

    invoke-direct {p0, v0}, Lrx;-><init>(I)V

    const/16 v0, 0x63

    iput-char v0, p0, Laq0;->d0:C

    const/16 v0, 0x6b

    iput-char v0, p0, Laq0;->e0:C

    const-string v0, "tcp"

    iput-object v0, p0, Laq0;->f0:Ljava/lang/String;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Laq0;->Q0:Landroid/os/Handler;

    const/16 v0, 0x15b3

    iput v0, p0, Laq0;->S0:I

    const/4 v0, 0x3

    new-array v0, v0, [Loo4;

    iput-object v0, p0, Laq0;->Y0:[Loo4;

    new-instance v0, Lag0;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p0}, Lag0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Laq0;->Z0:Lag0;

    new-instance v0, Lzp0;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lzp0;-><init>(Laq0;I)V

    iput-object v0, p0, Laq0;->a1:Lzp0;

    new-instance v0, Lwp0;

    invoke-direct {v0, p0}, Lwp0;-><init>(Laq0;)V

    iput-object v0, p0, Laq0;->c1:Lwp0;

    new-instance v0, Lzp0;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lzp0;-><init>(Laq0;I)V

    iput-object v0, p0, Laq0;->g1:Lzp0;

    return-void
.end method


# virtual methods
.method public final A()V
    .locals 4

    const/4 v0, 0x1

    iput-boolean v0, p0, Lrx;->J:Z

    iget-object v1, p0, Laq0;->D0:Lu1;

    iget-object v2, p0, Laq0;->Z0:Lag0;

    invoke-virtual {v1, v2}, Lu1;->b(Lag0;)V

    iget-object v1, p0, Laq0;->D0:Lu1;

    iget-object v2, v1, Lu1;->h:Ltj0;

    iget-object v3, p0, Laq0;->c1:Lwp0;

    iput-object v3, v2, Ltj0;->f:Lwp0;

    iget v2, v1, Lu1;->i:I

    const/4 v3, 0x4

    if-eq v2, v3, :cond_2

    const/4 v3, 0x2

    if-eq v2, v3, :cond_2

    iget-boolean v2, v1, Lu1;->j:Z

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Lau0;->g()Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 v3, 0x3

    :cond_1
    iput v3, v1, Lu1;->i:I

    :cond_2
    :goto_0
    invoke-virtual {p0}, Laq0;->Q()V

    invoke-virtual {p0}, Laq0;->M()V

    iput-boolean v0, p0, Laq0;->R0:Z

    invoke-virtual {p0}, Laq0;->b0()V

    invoke-virtual {p0}, Laq0;->a0()V

    return-void
.end method

.method public final E(Landroid/view/View;)V
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0}, Lrx;->I()Landroid/content/Context;

    move-result-object v6

    invoke-virtual {v0}, Lrx;->m()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    iput v2, v0, Laq0;->c0:F

    new-instance v2, Luv0;

    invoke-direct {v2, v6}, Luv0;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f0901bf

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    new-instance v4, Lk00;

    const/4 v7, 0x5

    invoke-direct {v4, v3, v7}, Lk00;-><init>(II)V

    sget-object v3, Ls71;->a:Ljava/util/WeakHashMap;

    invoke-static {v2, v4}, Lk71;->c(Landroid/view/View;Lwi0;)V

    invoke-virtual {v2}, Landroid/view/View;->requestApplyInsets()V

    invoke-static {v6}, Lu1;->e(Landroid/content/Context;)Lu1;

    move-result-object v2

    iput-object v2, v0, Laq0;->D0:Lu1;

    const v2, 0x7f0901e4

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->n0:Landroid/widget/TextView;

    const v2, 0x7f0901ec

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->s0:Landroid/view/View;

    const v2, 0x7f0901c0

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lup0;

    const/16 v4, 0xd

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901ed

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lup0;

    const/4 v8, 0x0

    invoke-direct {v3, v0, v8}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901c1

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->t0:Landroid/view/View;

    const v2, 0x7f0901c2

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->u0:Landroid/view/View;

    const v2, 0x7f0901c3

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->v0:Landroid/widget/TextView;

    const v2, 0x7f0901c4

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->w0:Landroid/widget/TextView;

    const v2, 0x7f0901de

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->o0:Landroid/widget/TextView;

    const v2, 0x7f0901e3

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->p0:Landroid/widget/TextView;

    const v2, 0x7f0901dd

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->q0:Landroid/widget/TextView;

    const v2, 0x7f0901e2

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->r0:Landroid/widget/TextView;

    const v2, 0x7f0901db

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->z0:Landroid/view/View;

    const v2, 0x7f0901e0

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->A0:Landroid/view/View;

    const v2, 0x7f0901dc

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->B0:Lcom/zayon/optimize/ui/ZyBox;

    const v2, 0x7f0901e1

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->C0:Lcom/zayon/optimize/ui/ZyBox;

    iget-object v2, v0, Laq0;->B0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/4 v9, 0x1

    invoke-direct {v3, v0, v9}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->C0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/4 v10, 0x2

    invoke-direct {v3, v0, v10}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901e8

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->E0:Landroid/widget/TextView;

    const v2, 0x7f0901eb

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->F0:Landroid/widget/TextView;

    const v2, 0x7f0901e9

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->J0:Lcom/zayon/optimize/ui/ZyBox;

    const v2, 0x7f0901ea

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->G0:Landroid/widget/TextView;

    const v2, 0x7f0901ef

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->H0:Landroid/widget/TextView;

    const v2, 0x7f0901f0

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->K0:Lcom/zayon/optimize/ui/ZyBox;

    const v2, 0x7f0901f1

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->L0:Lcom/zayon/optimize/ui/ZyBox;

    const v2, 0x7f0901f2

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->I0:Landroid/widget/TextView;

    iget-object v2, v0, Laq0;->F0:Landroid/widget/TextView;

    new-instance v3, Lup0;

    const/4 v11, 0x3

    invoke-direct {v3, v0, v11}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->J0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/4 v4, 0x4

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->K0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    invoke-direct {v3, v0, v7}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->L0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/4 v4, 0x6

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901cd

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object v2, v0, Laq0;->M0:Lcom/zayon/optimize/ui/ZyBox;

    const v2, 0x7f0901ce

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->N0:Landroid/widget/TextView;

    const v2, 0x7f0901d2

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iput-object v2, v0, Laq0;->O0:Landroid/widget/TextView;

    const v2, 0x7f0901d1

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->P0:Landroid/view/View;

    iget-object v2, v0, Laq0;->M0:Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/4 v4, 0x7

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->M0:Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget-object v3, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    const/16 v4, 0x10

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v3, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x0

    invoke-static {v6, v3, v9, v3}, Lcom/zayon/optimize/ui/ZyBox;->c(Landroid/content/Context;FZF)Lcom/zayon/optimize/ui/ZyBox;

    move-result-object v3

    iput-object v3, v0, Laq0;->f1:Lcom/zayon/optimize/ui/ZyBox;

    iget-object v5, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    iget v13, v0, Laq0;->c0:F

    const/high16 v14, 0x40e00000    # 7.0f

    mul-float/2addr v13, v14

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    iget v15, v0, Laq0;->c0:F

    mul-float/2addr v15, v14

    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    move-result v14

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v3, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v3, v6}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    const/high16 v12, 0x41400000    # 12.0f

    invoke-virtual {v3, v10, v12}, Lt8;->setTextSize(IF)V

    const v13, 0x7f080003

    invoke-static {v6, v13}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iput-object v3, v0, Laq0;->e1:Lcom/zayon/optimize/ui/ZyTextView;

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v5, v8, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v16, 0x41000000    # 8.0f

    move/from16 v17, v9

    iget v9, v0, Laq0;->c0:F

    mul-float v9, v9, v16

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-virtual {v5, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    iget-object v9, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    invoke-virtual {v9, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    invoke-direct {v3, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v16, 0x41600000    # 14.0f

    iget v5, v0, Laq0;->c0:F

    mul-float v5, v5, v16

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iput v5, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v5, v0, Laq0;->d1:Landroid/widget/LinearLayout;

    iget-object v9, v0, Laq0;->M0:Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v2, v9}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v9

    invoke-virtual {v2, v5, v9, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    const v2, 0x7f0901be

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    new-instance v3, Lup0;

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901bd

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->g0:Landroid/view/View;

    const v2, 0x7f0901c5

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->h0:Landroid/view/View;

    const v2, 0x7f0901e6

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->i0:Landroid/view/View;

    const v2, 0x7f0901ee

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->j0:Landroid/view/View;

    const v2, 0x7f0901ca

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->k0:Landroid/view/View;

    const v2, 0x7f0901cb

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->l0:Landroid/view/View;

    const v2, 0x7f0901cf

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, v0, Laq0;->m0:Landroid/view/View;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const v2, 0x7f0901c6

    const v3, 0x7f0901c7

    invoke-virtual/range {v0 .. v5}, Laq0;->R(Landroid/view/View;IIII)Ll41;

    move-result-object v2

    iput-object v2, v0, Laq0;->U0:Ll41;

    const v2, 0x7f0901c8

    const v3, 0x7f0901c9

    invoke-virtual/range {v0 .. v5}, Laq0;->R(Landroid/view/View;IIII)Ll41;

    move-result-object v2

    iput-object v2, v0, Laq0;->V0:Ll41;

    const v4, 0x7f0901d6

    const v5, 0x7f0901d4

    const v2, 0x7f0901d3

    const v3, 0x7f0901d5

    invoke-virtual/range {v0 .. v5}, Laq0;->R(Landroid/view/View;IIII)Ll41;

    move-result-object v2

    iput-object v2, v0, Laq0;->W0:Ll41;

    const v4, 0x7f0901da

    const v5, 0x7f0901d8

    const v2, 0x7f0901d7

    const v3, 0x7f0901d9

    invoke-virtual/range {v0 .. v5}, Laq0;->R(Landroid/view/View;IIII)Ll41;

    move-result-object v2

    iput-object v2, v0, Laq0;->X0:Ll41;

    iget-object v2, v0, Laq0;->U0:Ll41;

    iget-object v2, v2, Ll41;->i:Ljava/lang/Object;

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/16 v4, 0x9

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->V0:Ll41;

    iget-object v2, v2, Ll41;->i:Ljava/lang/Object;

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/16 v4, 0xa

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->W0:Ll41;

    iget-object v2, v2, Ll41;->i:Ljava/lang/Object;

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/16 v4, 0xb

    invoke-direct {v3, v0, v4}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v0, Laq0;->X0:Ll41;

    iget-object v2, v2, Ll41;->i:Ljava/lang/Object;

    check-cast v2, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v3, Lup0;

    const/16 v5, 0xc

    invoke-direct {v3, v0, v5}, Lup0;-><init>(Laq0;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0901e5

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    const-string v3, "tcp"

    const-string v5, "TCP/IP"

    filled-new-array {v3, v5}, [Ljava/lang/String;

    move-result-object v3

    const-string v5, "wifi"

    const-string v9, "Wireless"

    filled-new-array {v5, v9}, [Ljava/lang/String;

    move-result-object v5

    const-string v9, "otg"

    const-string v4, "OTG"

    filled-new-array {v9, v4}, [Ljava/lang/String;

    move-result-object v4

    filled-new-array {v3, v5, v4}, [[Ljava/lang/String;

    move-result-object v3

    move v4, v8

    :goto_0
    iget-object v5, v0, Laq0;->Y0:[Loo4;

    if-ge v4, v11, :cond_1

    new-instance v9, Loo4;

    invoke-direct {v9, v7}, Loo4;-><init>(I)V

    aget-object v18, v3, v4

    aget-object v7, v18, v8

    iput-object v7, v9, Loo4;->i:Ljava/lang/Object;

    invoke-static {v6, v12, v8, v15}, Lcom/zayon/optimize/ui/ZyBox;->c(Landroid/content/Context;FZF)Lcom/zayon/optimize/ui/ZyBox;

    move-result-object v7

    iput-object v7, v9, Loo4;->j:Ljava/lang/Object;

    new-instance v7, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v7, v6}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    aget-object v18, v3, v4

    aget-object v11, v18, v17

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v11, 0x41500000    # 13.0f

    invoke-virtual {v7, v10, v11}, Lt8;->setTextSize(IF)V

    invoke-static {v6, v13}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v11

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    move/from16 v11, v17

    invoke-virtual {v7, v11}, Landroid/widget/TextView;->setMaxLines(I)V

    iput-object v7, v9, Loo4;->k:Ljava/lang/Object;

    iget-object v10, v9, Loo4;->j:Ljava/lang/Object;

    check-cast v10, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v11, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v12, 0x11

    invoke-direct {v11, v14, v14, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v10, v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    invoke-direct {v7, v8, v10, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v4, :cond_0

    const/high16 v11, 0x40c00000    # 6.0f

    iget v12, v0, Laq0;->c0:F

    mul-float/2addr v12, v11

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    :cond_0
    iget-object v11, v9, Loo4;->j:Ljava/lang/Object;

    check-cast v11, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v2, v11, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v7, v9, Loo4;->i:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    iget-object v11, v9, Loo4;->j:Ljava/lang/Object;

    check-cast v11, Lcom/zayon/optimize/ui/ZyBox;

    new-instance v12, Le1;

    const/16 v10, 0xb

    invoke-direct {v12, v0, v10, v7}, Le1;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    aput-object v9, v5, v4

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/high16 v12, 0x41400000    # 12.0f

    const/16 v17, 0x1

    goto :goto_0

    :cond_1
    const v2, 0x7f0901f3

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    sget-object v3, Laq0;->h1:[I

    invoke-virtual {v0, v2, v3}, Laq0;->Y(Landroid/widget/LinearLayout;[I)V

    const v2, 0x7f0901cc

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    sget-object v3, Laq0;->i1:[I

    invoke-virtual {v0, v2, v3}, Laq0;->Y(Landroid/widget/LinearLayout;[I)V

    const v2, 0x7f0901d0

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    sget-object v2, Laq0;->j1:[I

    invoke-virtual {v0, v1, v2}, Laq0;->Y(Landroid/widget/LinearLayout;[I)V

    iget-object v1, v0, Laq0;->U0:Ll41;

    iget-char v2, v0, Laq0;->d0:C

    const/16 v3, 0x63

    if-ne v2, v3, :cond_2

    const/4 v2, 0x1

    goto :goto_1

    :cond_2
    move v2, v8

    :goto_1
    invoke-virtual {v0, v1, v2, v8}, Laq0;->N(Ll41;ZZ)V

    iget-object v1, v0, Laq0;->V0:Ll41;

    iget-char v2, v0, Laq0;->d0:C

    const/16 v3, 0x6d

    if-ne v2, v3, :cond_3

    const/4 v2, 0x1

    goto :goto_2

    :cond_3
    move v2, v8

    :goto_2
    invoke-virtual {v0, v1, v2, v8}, Laq0;->N(Ll41;ZZ)V

    iget-object v1, v0, Laq0;->W0:Ll41;

    iget-char v2, v0, Laq0;->e0:C

    const/16 v3, 0x6b

    if-ne v2, v3, :cond_4

    const/4 v2, 0x1

    goto :goto_3

    :cond_4
    move v2, v8

    :goto_3
    invoke-virtual {v0, v1, v2, v8}, Laq0;->N(Ll41;ZZ)V

    iget-object v1, v0, Laq0;->X0:Ll41;

    iget-char v2, v0, Laq0;->e0:C

    const/16 v3, 0x74

    if-ne v2, v3, :cond_5

    const/4 v9, 0x1

    goto :goto_4

    :cond_5
    move v9, v8

    :goto_4
    invoke-virtual {v0, v1, v9, v8}, Laq0;->N(Ll41;ZZ)V

    array-length v1, v5

    move v2, v8

    :goto_5
    if-ge v2, v1, :cond_6

    aget-object v3, v5, v2

    iget-object v4, v3, Loo4;->i:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    iget-object v6, v0, Laq0;->f0:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    invoke-virtual {v0, v3, v4, v8}, Laq0;->P(Loo4;ZZ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :cond_6
    invoke-virtual {v0}, Laq0;->c0()V

    invoke-virtual {v0}, Laq0;->M()V

    invoke-virtual {v0}, Laq0;->Q()V

    return-void
.end method

.method public final M()V
    .locals 13

    iget-object v0, p0, Laq0;->D0:Lu1;

    invoke-virtual {v0}, Lu1;->j()I

    move-result v0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    move v4, v2

    goto :goto_0

    :cond_0
    move v4, v3

    :goto_0
    iget-object v5, p0, Laq0;->z0:Landroid/view/View;

    if-eqz v4, :cond_1

    move v6, v3

    goto :goto_1

    :cond_1
    move v6, v1

    :goto_1
    invoke-virtual {v5, v6}, Landroid/view/View;->setVisibility(I)V

    iget-object v5, p0, Laq0;->o0:Landroid/widget/TextView;

    const v6, 0x7f0f00fb

    const v7, 0x7f0f0127

    const/4 v8, 0x2

    const v9, 0x7f0f00f1

    if-eqz v4, :cond_2

    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setText(I)V

    goto :goto_2

    :cond_2
    if-ne v0, v8, :cond_3

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    goto :goto_2

    :cond_3
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(I)V

    :goto_2
    const/4 v5, 0x3

    if-ne v0, v5, :cond_4

    move v10, v2

    goto :goto_3

    :cond_4
    move v10, v3

    :goto_3
    iget-object v11, p0, Laq0;->q0:Landroid/widget/TextView;

    const v12, 0x7f0f00ef

    if-eqz v4, :cond_5

    move v7, v9

    goto :goto_4

    :cond_5
    if-ne v0, v8, :cond_6

    goto :goto_4

    :cond_6
    move v7, v12

    :goto_4
    invoke-virtual {v11, v7}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->B0:Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v10}, Landroid/view/View;->setClickable(Z)V

    const v4, 0x3ecccccd    # 0.4f

    const/high16 v7, 0x3f800000    # 1.0f

    if-eqz v10, :cond_7

    move v10, v7

    goto :goto_5

    :cond_7
    move v10, v4

    :goto_5
    invoke-virtual {v0, v10}, Landroid/view/View;->setAlpha(F)V

    iget-object v0, p0, Laq0;->D0:Lu1;

    invoke-virtual {v0}, Lu1;->n()I

    move-result v0

    if-ne v0, v1, :cond_8

    move v10, v2

    goto :goto_6

    :cond_8
    move v10, v3

    :goto_6
    iget-object v11, p0, Laq0;->A0:Landroid/view/View;

    if-eqz v10, :cond_9

    move v1, v3

    :cond_9
    invoke-virtual {v11, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-static {v0}, Loj;->x(I)I

    move-result v0

    if-eqz v0, :cond_c

    if-eq v0, v2, :cond_b

    if-eq v0, v5, :cond_a

    move v9, v12

    goto :goto_7

    :cond_a
    move v6, v9

    goto :goto_7

    :cond_b
    const v6, 0x7f0f0109

    const v9, 0x7f0f010c

    goto :goto_7

    :cond_c
    const v6, 0x7f0f0108

    const v9, 0x7f0f00fc

    :goto_7
    iget-object v0, p0, Laq0;->p0:Landroid/widget/TextView;

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->r0:Landroid/widget/TextView;

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->C0:Lcom/zayon/optimize/ui/ZyBox;

    xor-int/lit8 v1, v10, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    if-nez v10, :cond_d

    move v4, v7

    :cond_d
    invoke-virtual {v0, v4}, Landroid/view/View;->setAlpha(F)V

    iget-object v0, p0, Laq0;->D0:Lu1;

    invoke-virtual {v0}, Lu1;->d()Z

    move-result v0

    iget-object v1, p0, Laq0;->n0:Landroid/widget/TextView;

    if-eqz v0, :cond_e

    const v4, 0x7f0f00f6

    goto :goto_8

    :cond_e
    const v4, 0x7f0f0102

    :goto_8
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(I)V

    iget-object v1, p0, Laq0;->s0:Landroid/view/View;

    const/16 v4, 0x8

    if-eqz v0, :cond_f

    move v6, v4

    goto :goto_9

    :cond_f
    move v6, v3

    :goto_9
    invoke-virtual {v1, v6}, Landroid/view/View;->setVisibility(I)V

    iget-object v1, p0, Laq0;->t0:Landroid/view/View;

    if-eqz v0, :cond_10

    move v4, v3

    :cond_10
    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Laq0;->a0()V

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    invoke-virtual {v0}, Le5;->d()Z

    move-result v1

    if-eqz v1, :cond_11

    iget v0, v0, Le5;->e:I

    goto :goto_a

    :cond_11
    move v0, v2

    :goto_a
    if-ne v0, v8, :cond_12

    move v1, v2

    goto :goto_b

    :cond_12
    move v1, v3

    :goto_b
    if-ne v0, v5, :cond_13

    goto :goto_c

    :cond_13
    move v2, v3

    :goto_c
    iget-object v0, p0, Laq0;->E0:Landroid/widget/TextView;

    if-eqz v1, :cond_14

    const v3, 0x7f0f0124

    goto :goto_d

    :cond_14
    const v3, 0x7f0f0123

    :goto_d
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->E0:Landroid/widget/TextView;

    const v3, 0x7f050230

    const v4, 0x7f050071

    if-eqz v1, :cond_15

    move v5, v4

    goto :goto_e

    :cond_15
    move v5, v3

    :goto_e
    invoke-virtual {p0, v5}, Laq0;->S(I)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Laq0;->H0:Landroid/widget/TextView;

    if-eqz v2, :cond_16

    const v5, 0x7f0f00f4

    goto :goto_f

    :cond_16
    const v5, 0x7f0f012b

    :goto_f
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->H0:Landroid/widget/TextView;

    if-eqz v2, :cond_17

    move v3, v4

    :cond_17
    invoke-virtual {p0, v3}, Laq0;->S(I)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    iget-boolean v0, v0, Le5;->d:Z

    iget-boolean v3, p0, Laq0;->b1:Z

    const v4, 0x7f0f00f5

    const v5, 0x7f0f00f3

    if-nez v3, :cond_1a

    iget-object v3, p0, Laq0;->G0:Landroid/widget/TextView;

    if-eqz v1, :cond_18

    move v1, v5

    goto :goto_10

    :cond_18
    if-eqz v0, :cond_19

    move v1, v4

    goto :goto_10

    :cond_19
    const v1, 0x7f0f00f2

    :goto_10
    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(I)V

    :cond_1a
    iget-object v1, p0, Laq0;->I0:Landroid/widget/TextView;

    if-eqz v2, :cond_1b

    move v4, v5

    goto :goto_11

    :cond_1b
    if-eqz v0, :cond_1c

    goto :goto_11

    :cond_1c
    const v4, 0x7f0f011c

    :goto_11
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(I)V

    invoke-virtual {p0}, Laq0;->O()V

    return-void
.end method

.method public final N(Ll41;ZZ)V
    .locals 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    if-eqz p2, :cond_0

    const v2, 0x7f050078

    goto :goto_0

    :cond_0
    const v2, 0x7f05025e

    :goto_0
    invoke-virtual {v0, v2}, Laq0;->S(I)I

    move-result v3

    if-eqz p2, :cond_1

    const v2, 0x7f050086

    goto :goto_1

    :cond_1
    const v2, 0x7f050263

    :goto_1
    invoke-virtual {v0, v2}, Laq0;->S(I)I

    move-result v5

    const v2, 0x7f050071

    if-eqz p2, :cond_2

    move v4, v2

    goto :goto_2

    :cond_2
    const v4, 0x7f050230

    :goto_2
    invoke-virtual {v0, v4}, Laq0;->S(I)I

    move-result v9

    if-eqz p2, :cond_3

    :goto_3
    invoke-virtual {v0, v2}, Laq0;->S(I)I

    move-result v0

    move v11, v0

    goto :goto_4

    :cond_3
    const v2, 0x7f050072

    goto :goto_3

    :goto_4
    if-eqz p2, :cond_4

    const/high16 v0, 0x3f800000    # 1.0f

    :goto_5
    move v7, v0

    goto :goto_6

    :cond_4
    const/4 v0, 0x0

    goto :goto_5

    :goto_6
    if-nez p3, :cond_6

    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v3}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v5}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v7}, Lcom/zayon/optimize/ui/ZyBox;->setShadowMix(F)V

    iget-object v0, v1, Ll41;->j:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {v0, v9}, Landroid/widget/ImageView;->setColorFilter(I)V

    iget-object v0, v1, Ll41;->k:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    if-eqz v0, :cond_5

    invoke-virtual {v0, v9}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    iget-object v0, v1, Ll41;->l:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v11}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    :cond_5
    iget-object v0, v1, Ll41;->j:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    return-void

    :cond_6
    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getBg()I

    move-result v2

    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getBorderColor()I

    move-result v4

    iget-object v0, v1, Ll41;->j:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Ljava/lang/Integer;

    if-eqz v0, :cond_7

    iget-object v0, v1, Ll41;->j:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    move v8, v0

    goto :goto_7

    :cond_7
    move v8, v9

    :goto_7
    iget-object v0, v1, Ll41;->l:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getBg()I

    move-result v0

    move v10, v0

    goto :goto_8

    :cond_8
    move v10, v11

    :goto_8
    iget-object v0, v1, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getShadowMix()F

    move-result v6

    iget-object v0, v1, Ll41;->j:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ImageView;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v0, v12}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    sget-object v19, Lsr;->h:Landroid/view/animation/PathInterpolator;

    new-instance v0, Lrn0;

    const/4 v12, 0x1

    invoke-direct/range {v0 .. v12}, Lrn0;-><init>(Ljava/lang/Object;IIIIFFIIIII)V

    const/4 v13, 0x0

    const/high16 v14, 0x3f800000    # 1.0f

    const-wide/16 v15, 0xfa

    const-wide/16 v17, 0x0

    move-object/from16 v20, v0

    invoke-static/range {v13 .. v20}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    return-void
.end method

.method public final O()V
    .locals 5

    iget-object v0, p0, Laq0;->N0:Landroid/widget/TextView;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->h:Ltj0;

    iget v0, v0, Ltj0;->d:I

    invoke-static {v0}, Loj;->x(I)I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_4

    const/4 v1, 0x2

    if-eq v0, v1, :cond_3

    const/4 v1, 0x3

    if-eq v0, v1, :cond_2

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1

    const v0, 0x7f0f0118

    invoke-virtual {p0, v0}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const v0, 0x7f0f0121

    invoke-virtual {p0, v0}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_2
    const v0, 0x7f0f00f0

    invoke-virtual {p0, v0}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_3
    const v0, 0x7f0f00ef

    invoke-virtual {p0, v0}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_4
    const v0, 0x7f0f0119

    invoke-virtual {p0, v0}, Lrx;->n(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    iget-object v1, p0, Laq0;->N0:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->h:Ltj0;

    iget-object v0, v0, Ltj0;->h:Ljava/lang/String;

    iget-object v1, p0, Laq0;->d1:Landroid/widget/LinearLayout;

    const/4 v2, 0x0

    const/16 v3, 0x8

    if-nez v0, :cond_5

    move v4, v3

    goto :goto_1

    :cond_5
    move v4, v2

    :goto_1
    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    if-eqz v0, :cond_7

    iget-object v1, p0, Laq0;->D0:Lu1;

    iget-object v1, v1, Lu1;->h:Ltj0;

    iget-boolean v1, v1, Ltj0;->i:Z

    if-eqz v1, :cond_6

    const v1, 0x7f05018f

    goto :goto_2

    :cond_6
    const v1, 0x7f050071

    :goto_2
    invoke-virtual {p0, v1}, Laq0;->S(I)I

    move-result v1

    iget-object v4, p0, Laq0;->e1:Lcom/zayon/optimize/ui/ZyTextView;

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Laq0;->e1:Lcom/zayon/optimize/ui/ZyTextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Laq0;->f1:Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v1}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    :cond_7
    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    invoke-virtual {v0}, Le5;->d()Z

    move-result v0

    iget-object v1, p0, Laq0;->O0:Landroid/widget/TextView;

    if-eqz v0, :cond_8

    const v4, 0x7f0f00f3

    goto :goto_3

    :cond_8
    const v4, 0x7f0f012a

    :goto_3
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(I)V

    iget-object p0, p0, Laq0;->P0:Landroid/view/View;

    if-eqz v0, :cond_9

    move v2, v3

    :cond_9
    invoke-virtual {p0, v2}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public final P(Loo4;ZZ)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    const v3, 0x7f05007a

    invoke-virtual {v0, v3}, Laq0;->S(I)I

    move-result v3

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    if-eqz p2, :cond_1

    const v2, 0x7f050084

    invoke-virtual {v0, v2}, Laq0;->S(I)I

    move-result v2

    :cond_1
    move v5, v2

    if-eqz p2, :cond_2

    const v2, 0x7f050071

    goto :goto_1

    :cond_2
    const v2, 0x7f050233

    :goto_1
    invoke-virtual {v0, v2}, Laq0;->S(I)I

    move-result v7

    iget-object v0, v1, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    if-nez p3, :cond_3

    invoke-virtual {v0, v3}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    iget-object v0, v1, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0, v5}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    iget-object v0, v1, Loo4;->k:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    :cond_3
    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getBg()I

    move-result v2

    iget-object v0, v1, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v0}, Lcom/zayon/optimize/ui/ZyBox;->getBorderColor()I

    move-result v4

    iget-object v0, v1, Loo4;->k:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v6

    sget-object v14, Lsr;->h:Landroid/view/animation/PathInterpolator;

    new-instance v15, Lxp0;

    move-object v0, v15

    invoke-direct/range {v0 .. v7}, Lxp0;-><init>(Loo4;IIIIII)V

    const/4 v8, 0x0

    const/high16 v9, 0x3f800000    # 1.0f

    const-wide/16 v10, 0xc8

    const-wide/16 v12, 0x0

    invoke-static/range {v8 .. v15}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    return-void
.end method

.method public final Q()V
    .locals 4

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    new-instance v1, Lwp0;

    invoke-direct {v1, p0}, Lwp0;-><init>(Laq0;)V

    iget-boolean p0, v0, Le5;->d:Z

    if-nez p0, :cond_1

    iget-object p0, v0, Le5;->a:Landroid/content/Context;

    invoke-static {p0}, Le5;->l(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/Thread;

    new-instance v2, La5;

    const/4 v3, 0x1

    invoke-direct {v2, v0, v1, v3}, La5;-><init>(Le5;Lwp0;I)V

    const-string v0, "zayon-adb-auto"

    invoke-direct {p0, v2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Thread;->start()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final R(Landroid/view/View;IIII)Ll41;
    .locals 3

    new-instance v0, Ll41;

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ll41;-><init>(IZ)V

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object p2, v0, Ll41;->i:Ljava/lang/Object;

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    iput-object p2, v0, Ll41;->j:Ljava/lang/Object;

    if-eqz p4, :cond_0

    invoke-virtual {p1, p4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/zayon/optimize/ui/ZyBox;

    iput-object p2, v0, Ll41;->k:Ljava/lang/Object;

    invoke-virtual {p1, p5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/zayon/optimize/ui/ZyBox;

    iput-object p1, v0, Ll41;->l:Ljava/lang/Object;

    :cond_0
    iget-object p1, v0, Ll41;->i:Ljava/lang/Object;

    check-cast p1, Lcom/zayon/optimize/ui/ZyBox;

    new-instance p2, Lsb1;

    const p3, 0x7f050076

    invoke-virtual {p0, p3}, Laq0;->S(I)I

    move-result p3

    const/high16 p4, 0x40400000    # 3.0f

    iget p5, p0, Laq0;->c0:F

    mul-float/2addr p5, p4

    const/4 p4, 0x0

    invoke-direct {p2, p4, p4, p5, p3}, Lsb1;-><init>(FFFI)V

    new-instance p3, Lsb1;

    const p5, 0x7f050079

    invoke-virtual {p0, p5}, Laq0;->S(I)I

    move-result p5

    iget p0, p0, Laq0;->c0:F

    const/high16 v1, 0x41000000    # 8.0f

    mul-float/2addr v1, p0

    const/high16 v2, 0x41c00000    # 24.0f

    mul-float/2addr p0, v2

    invoke-direct {p3, v1, p0, p4, p5}, Lsb1;-><init>(FFFI)V

    filled-new-array {p2, p3}, [Lsb1;

    move-result-object p0

    invoke-virtual {p1, p0}, Lcom/zayon/optimize/ui/ZyBox;->setShadowsB([Lsb1;)V

    return-object v0
.end method

.method public final S(I)I
    .locals 0

    invoke-virtual {p0}, Lrx;->I()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    return p0
.end method

.method public final T(Z)V
    .locals 3

    iget-boolean v0, p0, Laq0;->b1:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    invoke-virtual {v0}, Le5;->d()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    iget v0, v0, Le5;->e:I

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    iget-boolean v0, v0, Le5;->d:Z

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    iput-boolean v2, p0, Laq0;->b1:Z

    iget-object v0, p0, Laq0;->G0:Landroid/widget/TextView;

    const v1, 0x7f0f00f5

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v0, v0, Lu1;->g:Le5;

    iget v1, p0, Laq0;->S0:I

    new-instance v2, Lvp0;

    invoke-direct {v2, p0, p1}, Lvp0;-><init>(Laq0;Z)V

    invoke-virtual {v0, v1, v2}, Le5;->c(ILd5;)V

    :cond_2
    :goto_1
    return-void
.end method

.method public final U()Z
    .locals 2

    iget-boolean v0, p0, Laq0;->R0:Z

    if-eqz v0, :cond_0

    iget-char v0, p0, Laq0;->d0:C

    const/16 v1, 0x6d

    if-ne v0, v1, :cond_0

    const-string v0, "otg"

    iget-object v1, p0, Laq0;->f0:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-char p0, p0, Laq0;->e0:C

    const/16 v0, 0x74

    if-ne p0, v0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final V(C)V
    .locals 4

    iget-char v0, p0, Laq0;->d0:C

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-char p1, p0, Laq0;->d0:C

    iget-object v0, p0, Laq0;->U0:Ll41;

    const/16 v1, 0x63

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne p1, v1, :cond_1

    move v1, v3

    goto :goto_0

    :cond_1
    move v1, v2

    :goto_0
    invoke-virtual {p0, v0, v1, v3}, Laq0;->N(Ll41;ZZ)V

    iget-object v0, p0, Laq0;->V0:Ll41;

    const/16 v1, 0x6d

    if-ne p1, v1, :cond_2

    move v2, v3

    :cond_2
    invoke-virtual {p0, v0, v2, v3}, Laq0;->N(Ll41;ZZ)V

    invoke-virtual {p0}, Laq0;->c0()V

    return-void
.end method

.method public final W(C)V
    .locals 4

    iget-char v0, p0, Laq0;->e0:C

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-char p1, p0, Laq0;->e0:C

    iget-object v0, p0, Laq0;->W0:Ll41;

    const/16 v1, 0x6b

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne p1, v1, :cond_1

    move v1, v3

    goto :goto_0

    :cond_1
    move v1, v2

    :goto_0
    invoke-virtual {p0, v0, v1, v3}, Laq0;->N(Ll41;ZZ)V

    iget-object v0, p0, Laq0;->X0:Ll41;

    const/16 v1, 0x74

    if-ne p1, v1, :cond_2

    move v2, v3

    :cond_2
    invoke-virtual {p0, v0, v2, v3}, Laq0;->N(Ll41;ZZ)V

    invoke-virtual {p0}, Laq0;->c0()V

    return-void
.end method

.method public final X(Landroid/content/Intent;)Z
    .locals 2

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    const/high16 v1, 0x10000000

    invoke-virtual {p1, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :try_start_0
    invoke-virtual {p0, p1}, Lrx;->L(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p0, 0x1

    return p0

    :catch_0
    return v0
.end method

.method public final Y(Landroid/widget/LinearLayout;[I)V
    .locals 7

    invoke-virtual {p0}, Lrx;->I()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    array-length v3, p2

    if-ge v2, v3, :cond_1

    const v3, 0x7f0c0046

    invoke-virtual {v0, v3, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v3

    const v4, 0x7f090286

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    add-int/lit8 v5, v2, 0x1

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v4, 0x7f090287

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    aget v6, p2, v2

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(I)V

    if-lez v2, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x41400000    # 12.0f

    iget v6, p0, Laq0;->c0:F

    mul-float/2addr v6, v4

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_0
    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move v2, v5

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final Z(Ljava/lang/String;)V
    .locals 1

    invoke-virtual {p0}, Lrx;->j()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lrx;->j()Landroid/content/Context;

    move-result-object p0

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_0
    return-void
.end method

.method public final a0()V
    .locals 5

    iget-object v0, p0, Laq0;->t0:Landroid/view/View;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Laq0;->Q0:Landroid/os/Handler;

    iget-object v1, p0, Laq0;->a1:Lzp0;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v0, p0, Laq0;->R0:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Laq0;->y0:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Laq0;->t0:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1

    move v0, v3

    goto :goto_0

    :cond_1
    move v0, v2

    :goto_0
    if-eqz v0, :cond_2

    invoke-virtual {v1}, Lzp0;->run()V

    :cond_2
    iget-object v1, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    if-eqz v1, :cond_3

    move v2, v3

    :cond_3
    if-ne v0, v2, :cond_4

    :goto_1
    return-void

    :cond_4
    if-eqz v0, :cond_5

    iget-object v0, p0, Laq0;->u0:Landroid/view/View;

    sget-object v1, Landroid/view/View;->ALPHA:Landroid/util/Property;

    const/4 v2, 0x2

    new-array v3, v2, [F

    fill-array-data v3, :array_0

    invoke-static {v0, v1, v3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    iput-object v0, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    const-wide/16 v3, 0x384

    invoke-virtual {v0, v3, v4}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    iget-object v0, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    iget-object v0, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->setRepeatMode(I)V

    iget-object p0, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    invoke-virtual {p0}, Landroid/animation/ObjectAnimator;->start()V

    return-void

    :cond_5
    invoke-virtual {v1}, Landroid/animation/Animator;->cancel()V

    const/4 v0, 0x0

    iput-object v0, p0, Laq0;->x0:Landroid/animation/ObjectAnimator;

    iget-object p0, p0, Laq0;->u0:Landroid/view/View;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    return-void

    :array_0
    .array-data 4
        0x3f800000    # 1.0f
        0x3e800000    # 0.25f
    .end array-data
.end method

.method public final b0()V
    .locals 2

    iget-object v0, p0, Laq0;->Q0:Landroid/os/Handler;

    iget-object v1, p0, Laq0;->g1:Lzp0;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Laq0;->U()Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method

.method public final c0()V
    .locals 5

    iget-object v0, p0, Laq0;->g0:Landroid/view/View;

    iget-char v1, p0, Laq0;->d0:C

    const/16 v2, 0x63

    const/16 v3, 0x8

    const/4 v4, 0x0

    if-ne v1, v2, :cond_0

    move v1, v4

    goto :goto_0

    :cond_0
    move v1, v3

    :goto_0
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->h0:Landroid/view/View;

    iget-char v1, p0, Laq0;->d0:C

    const/16 v2, 0x6d

    if-ne v1, v2, :cond_1

    move v1, v4

    goto :goto_1

    :cond_1
    move v1, v3

    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->i0:Landroid/view/View;

    const-string v1, "tcp"

    iget-object v2, p0, Laq0;->f0:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    move v1, v4

    goto :goto_2

    :cond_2
    move v1, v3

    :goto_2
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->j0:Landroid/view/View;

    const-string v1, "wifi"

    iget-object v2, p0, Laq0;->f0:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v4

    goto :goto_3

    :cond_3
    move v1, v3

    :goto_3
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->k0:Landroid/view/View;

    const-string v1, "otg"

    iget-object v2, p0, Laq0;->f0:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    move v1, v4

    goto :goto_4

    :cond_4
    move v1, v3

    :goto_4
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->l0:Landroid/view/View;

    iget-char v1, p0, Laq0;->e0:C

    const/16 v2, 0x6b

    if-ne v1, v2, :cond_5

    move v1, v4

    goto :goto_5

    :cond_5
    move v1, v3

    :goto_5
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Laq0;->m0:Landroid/view/View;

    iget-char v1, p0, Laq0;->e0:C

    const/16 v2, 0x74

    if-ne v1, v2, :cond_6

    move v3, v4

    :cond_6
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Laq0;->b0()V

    return-void
.end method

.method public final z()V
    .locals 3

    const/4 v0, 0x0

    iput-boolean v0, p0, Laq0;->R0:Z

    invoke-virtual {p0}, Laq0;->b0()V

    invoke-virtual {p0}, Laq0;->a0()V

    iget-object v0, p0, Laq0;->D0:Lu1;

    iget-object v1, v0, Lu1;->h:Ltj0;

    const/4 v2, 0x0

    iput-object v2, v1, Ltj0;->f:Lwp0;

    iget-object v1, p0, Laq0;->Z0:Lag0;

    iget-object v0, v0, Lu1;->c:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Lrx;->J:Z

    return-void
.end method
