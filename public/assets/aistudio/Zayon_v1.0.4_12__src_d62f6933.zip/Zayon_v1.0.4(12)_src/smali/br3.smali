.class public final Lbr3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lwq3;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Loy1;


# direct methods
.method public synthetic constructor <init>(Loy1;I)V
    .locals 0

    iput p2, p0, Lbr3;->h:I

    iput-object p1, p0, Lbr3;->i:Loy1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a([B[B)V
    .locals 91

    move-object/from16 v0, p0

    iget-object v0, v0, Lbr3;->i:Loy1;

    iget v1, v0, Loy1;->R0:I

    iget v2, v0, Loy1;->S0:I

    xor-int/2addr v2, v1

    iget v3, v0, Loy1;->J0:I

    xor-int/2addr v2, v3

    iget v3, v0, Loy1;->i0:I

    not-int v2, v2

    and-int/2addr v2, v3

    iget v4, v0, Loy1;->K:I

    iget v5, v0, Loy1;->S:I

    not-int v6, v5

    and-int/2addr v6, v4

    iget v7, v0, Loy1;->o0:I

    xor-int v8, v7, v6

    iget v9, v0, Loy1;->i2:I

    xor-int v10, v9, v4

    and-int v11, v4, v9

    iget v12, v0, Loy1;->a0:I

    not-int v13, v12

    and-int v14, v4, v13

    iget v15, v0, Loy1;->w0:I

    not-int v15, v15

    and-int/2addr v15, v4

    move/from16 p0, v2

    iget v2, v0, Loy1;->C:I

    xor-int v16, v2, v15

    or-int v16, v16, v12

    move/from16 p1, v3

    iget v3, v0, Loy1;->z1:I

    and-int/2addr v3, v4

    move/from16 p2, v3

    iget v3, v0, Loy1;->e2:I

    xor-int v17, v3, p2

    move/from16 v18, v3

    iget v3, v0, Loy1;->F0:I

    xor-int v3, p2, v3

    move/from16 p2, v3

    not-int v3, v2

    move/from16 v19, v2

    iget v2, v0, Loy1;->z0:I

    and-int v20, v4, v2

    xor-int v7, v7, v20

    and-int v20, v4, v3

    move/from16 v21, v2

    xor-int v2, v19, v20

    and-int v22, v12, v2

    and-int v22, v22, p1

    not-int v2, v2

    and-int/2addr v2, v12

    and-int v23, v4, v19

    xor-int v23, v21, v23

    move/from16 v24, v2

    iget v2, v0, Loy1;->S1:I

    and-int/2addr v2, v4

    xor-int v2, v18, v2

    move/from16 v18, v2

    iget v2, v0, Loy1;->m:I

    move/from16 v25, v3

    not-int v3, v2

    move/from16 v26, v2

    iget v2, v0, Loy1;->j2:I

    and-int v18, v18, v3

    xor-int v18, v2, v18

    and-int v27, p2, v25

    move/from16 p2, v3

    iget v3, v0, Loy1;->g0:I

    xor-int v18, v18, v27

    or-int v27, v18, v3

    and-int v18, v3, v18

    move/from16 v28, v3

    iget v3, v0, Loy1;->O1:I

    move/from16 v29, v4

    not-int v4, v3

    and-int v4, v29, v4

    move/from16 v30, v3

    iget v3, v0, Loy1;->u:I

    xor-int v31, v3, v4

    or-int v31, v26, v31

    xor-int v21, v21, v29

    and-int v21, v21, v13

    move/from16 v32, v3

    xor-int v3, v23, v21

    and-int v21, v3, p1

    move/from16 v23, v4

    iget v4, v0, Loy1;->g:I

    xor-int/2addr v14, v8

    xor-int v14, v14, v21

    not-int v14, v14

    and-int/2addr v14, v4

    not-int v3, v3

    and-int v3, p1, v3

    move/from16 v21, v3

    iget v3, v0, Loy1;->e:I

    xor-int v33, v3, v23

    not-int v9, v9

    and-int v9, v29, v9

    move/from16 v34, v3

    iget v3, v0, Loy1;->Y0:I

    xor-int/2addr v9, v3

    and-int/2addr v7, v13

    xor-int/2addr v7, v9

    xor-int v7, v7, p0

    and-int/2addr v7, v4

    xor-int v9, v10, v24

    xor-int v9, v9, v22

    xor-int/2addr v7, v9

    iget v9, v0, Loy1;->d:I

    xor-int/2addr v7, v9

    iput v7, v0, Loy1;->d:I

    not-int v1, v1

    and-int v1, v29, v1

    xor-int/2addr v1, v5

    iget v9, v0, Loy1;->Q0:I

    xor-int/2addr v1, v9

    and-int v1, p1, v1

    xor-int v6, v19, v6

    iget v9, v0, Loy1;->f2:I

    and-int v22, v29, v9

    xor-int v9, v9, v22

    or-int v24, v26, v9

    xor-int v20, v5, v20

    move/from16 p0, v1

    or-int v1, v12, v20

    not-int v1, v1

    and-int v1, p1, v1

    move/from16 v20, v1

    iget v1, v0, Loy1;->v0:I

    and-int/2addr v6, v13

    xor-int/2addr v6, v10

    xor-int v10, v17, v24

    xor-int v11, v11, v16

    xor-int v6, v6, p0

    xor-int/2addr v15, v1

    move/from16 v16, v3

    iget v3, v0, Loy1;->N0:I

    xor-int/2addr v3, v15

    and-int v3, v3, p1

    xor-int/2addr v3, v11

    not-int v3, v3

    and-int/2addr v3, v4

    iget v11, v0, Loy1;->r:I

    xor-int/2addr v3, v6

    xor-int/2addr v3, v11

    iput v3, v0, Loy1;->r:I

    iget v6, v0, Loy1;->b:I

    not-int v11, v6

    and-int v15, v3, v11

    xor-int v17, v6, v15

    move/from16 p0, v3

    iget v3, v0, Loy1;->w1:I

    xor-int v3, v3, v23

    xor-int v3, v3, v31

    or-int v23, v26, v22

    xor-int v23, v33, v23

    not-int v2, v2

    and-int v2, v29, v2

    xor-int v2, v30, v2

    move/from16 p1, v2

    iget v2, v0, Loy1;->F1:I

    xor-int v2, p1, v2

    and-int v2, v2, v25

    xor-int/2addr v2, v3

    or-int v3, v2, v28

    and-int v2, v28, v2

    xor-int v16, v16, v29

    xor-int v16, v16, v12

    xor-int v16, v16, v21

    xor-int v14, v16, v14

    move/from16 p1, v2

    iget v2, v0, Loy1;->x:I

    xor-int/2addr v2, v14

    iput v2, v0, Loy1;->x:I

    xor-int v14, v34, v22

    not-int v14, v14

    and-int v14, v26, v14

    xor-int/2addr v9, v14

    or-int v9, v19, v9

    xor-int v9, v23, v9

    xor-int v14, v9, v18

    move/from16 v16, v2

    iget v2, v0, Loy1;->J:I

    xor-int/2addr v2, v14

    iput v2, v0, Loy1;->J:I

    xor-int v9, v9, v27

    iget v14, v0, Loy1;->X:I

    xor-int/2addr v9, v14

    iput v9, v0, Loy1;->X:I

    xor-int v14, v32, v22

    and-int v14, v14, p2

    xor-int v14, v22, v14

    or-int v14, v19, v14

    move/from16 p2, v3

    iget v3, v0, Loy1;->b0:I

    xor-int/2addr v10, v14

    xor-int v14, v10, p2

    xor-int/2addr v3, v14

    iput v3, v0, Loy1;->b0:I

    iget v14, v0, Loy1;->l0:I

    xor-int v10, v10, p1

    xor-int/2addr v10, v14

    iput v10, v0, Loy1;->l0:I

    and-int v14, v29, v1

    xor-int/2addr v14, v1

    and-int/2addr v13, v14

    xor-int v13, v13, v20

    not-int v13, v13

    and-int/2addr v13, v4

    not-int v14, v1

    and-int v14, v29, v14

    xor-int/2addr v1, v14

    and-int/2addr v1, v12

    xor-int/2addr v1, v8

    iget v8, v0, Loy1;->y0:I

    xor-int/2addr v1, v8

    iget v8, v0, Loy1;->f:I

    xor-int/2addr v1, v13

    xor-int/2addr v1, v8

    iput v1, v0, Loy1;->f:I

    iget v8, v0, Loy1;->r0:I

    iget v12, v0, Loy1;->P:I

    not-int v13, v12

    and-int/2addr v8, v13

    iget v13, v0, Loy1;->b1:I

    xor-int/2addr v8, v13

    iget v13, v0, Loy1;->a:I

    xor-int/2addr v8, v13

    iget v13, v0, Loy1;->U:I

    not-int v14, v8

    and-int v18, v13, v14

    xor-int v19, v13, v18

    move/from16 p1, v1

    iget v1, v0, Loy1;->c2:I

    and-int v20, v1, v14

    move/from16 v21, v1

    iget v1, v0, Loy1;->L0:I

    xor-int v20, v1, v20

    move/from16 v22, v1

    iget v1, v0, Loy1;->E:I

    or-int v23, v1, v20

    move/from16 v24, v4

    iget v4, v0, Loy1;->A1:I

    or-int/2addr v4, v8

    move/from16 p2, v4

    iget v4, v0, Loy1;->C1:I

    move/from16 v25, v4

    xor-int v4, v25, p2

    not-int v4, v4

    and-int/2addr v4, v1

    move/from16 p2, v4

    iget v4, v0, Loy1;->T1:I

    and-int v27, v4, v14

    xor-int v27, v13, v27

    or-int v27, v27, v1

    or-int v30, v8, v4

    move/from16 v31, v4

    iget v4, v0, Loy1;->c0:I

    xor-int v33, v4, v30

    or-int v35, v8, v22

    xor-int v36, v13, v35

    or-int v36, v1, v36

    or-int v21, v8, v21

    move/from16 v37, v4

    iget v4, v0, Loy1;->n1:I

    move/from16 v38, v4

    xor-int v4, v38, v21

    not-int v4, v4

    and-int/2addr v4, v1

    xor-int v39, v31, v35

    move/from16 v40, v4

    not-int v4, v1

    xor-int v18, v31, v18

    move/from16 v41, v1

    or-int v1, v8, v37

    move/from16 v42, v4

    xor-int v4, v37, v1

    not-int v4, v4

    and-int v4, v41, v4

    xor-int v4, v19, v4

    move/from16 v43, v4

    iget v4, v0, Loy1;->M:I

    and-int v43, v4, v43

    xor-int v44, v31, v8

    xor-int v27, v44, v27

    and-int v27, v4, v27

    move/from16 v45, v4

    iget v4, v0, Loy1;->k0:I

    xor-int v23, v44, v23

    move/from16 v46, v5

    xor-int v5, v23, v27

    not-int v5, v5

    and-int/2addr v5, v4

    move/from16 v23, v5

    iget v5, v0, Loy1;->G0:I

    and-int/2addr v5, v14

    xor-int v5, v22, v5

    move/from16 v22, v6

    not-int v6, v5

    and-int v6, v41, v6

    xor-int v6, v18, v6

    not-int v6, v6

    and-int v6, v45, v6

    or-int v27, v30, v41

    xor-int v19, v19, v27

    and-int v19, v45, v19

    xor-int v27, v13, v21

    and-int v27, v41, v27

    move/from16 v30, v5

    xor-int v5, v44, v27

    not-int v5, v5

    and-int v5, v45, v5

    move/from16 v27, v5

    iget v5, v0, Loy1;->l:I

    xor-int v20, v20, v40

    xor-int v20, v20, v27

    xor-int v20, v20, v23

    xor-int v5, v20, v5

    iput v5, v0, Loy1;->l:I

    and-int v20, v21, v42

    xor-int v20, v33, v20

    and-int v20, v45, v20

    or-int v21, v8, v13

    xor-int v23, v37, v21

    move/from16 v27, v6

    iget v6, v0, Loy1;->t0:I

    and-int v40, v6, v8

    move/from16 v47, v8

    iget v8, v0, Loy1;->q0:I

    xor-int v8, v8, v40

    move/from16 v40, v8

    iget v8, v0, Loy1;->G:I

    move/from16 v48, v11

    not-int v11, v8

    and-int v49, v41, v21

    xor-int v36, v21, v36

    move/from16 v50, v8

    xor-int v8, v36, v43

    not-int v8, v8

    and-int/2addr v8, v4

    move/from16 v36, v8

    iget v8, v0, Loy1;->j:I

    xor-int v43, v44, v49

    xor-int v20, v43, v20

    xor-int v20, v20, v36

    xor-int v8, v20, v8

    iput v8, v0, Loy1;->j:I

    move/from16 v20, v8

    iget v8, v0, Loy1;->d1:I

    and-int v8, v8, v47

    move/from16 v36, v8

    iget v8, v0, Loy1;->m0:I

    xor-int v8, v8, v36

    or-int v8, v50, v8

    move/from16 v43, v8

    iget v8, v0, Loy1;->Y1:I

    and-int v8, v47, v8

    move/from16 v44, v8

    iget v8, v0, Loy1;->u0:I

    xor-int v8, v8, v44

    and-int v40, v40, v11

    xor-int v8, v8, v40

    not-int v8, v8

    and-int/2addr v8, v4

    move/from16 v40, v8

    iget v8, v0, Loy1;->q:I

    and-int v8, v8, v47

    move/from16 v44, v8

    iget v8, v0, Loy1;->e1:I

    xor-int v44, v8, v44

    or-int v49, v50, v44

    move/from16 v51, v8

    xor-int v8, v44, v49

    not-int v8, v8

    and-int/2addr v8, v4

    move/from16 v44, v8

    iget v8, v0, Loy1;->s0:I

    and-int v39, v39, v42

    xor-int v23, v23, v39

    xor-int v23, v23, v27

    and-int/2addr v8, v14

    xor-int/2addr v8, v6

    and-int v27, v38, v14

    and-int v27, v41, v27

    xor-int v27, v30, v27

    move/from16 v30, v8

    iget v8, v0, Loy1;->U0:I

    and-int v8, v8, v47

    move/from16 v38, v8

    iget v8, v0, Loy1;->f1:I

    xor-int v38, v8, v38

    not-int v6, v6

    and-int v6, v47, v6

    move/from16 v39, v6

    iget v6, v0, Loy1;->g1:I

    xor-int v6, v6, v39

    or-int v6, v50, v6

    xor-int v35, v25, v35

    move/from16 v39, v6

    iget v6, v0, Loy1;->p1:I

    xor-int v6, v35, v6

    and-int v6, v45, v6

    move/from16 v35, v6

    iget v6, v0, Loy1;->k1:I

    move/from16 v49, v11

    not-int v11, v6

    and-int v11, v47, v11

    move/from16 v52, v6

    iget v6, v0, Loy1;->i1:I

    xor-int/2addr v6, v11

    or-int v6, v50, v6

    and-int v11, v25, v14

    xor-int v11, v31, v11

    and-int v11, v11, v42

    xor-int v11, v18, v11

    xor-int v11, v11, v19

    not-int v11, v11

    and-int/2addr v11, v4

    iget v14, v0, Loy1;->h0:I

    xor-int v11, v23, v11

    xor-int/2addr v11, v14

    iput v11, v0, Loy1;->h0:I

    or-int v14, v2, v11

    move/from16 v18, v6

    not-int v6, v2

    move/from16 v19, v2

    not-int v2, v11

    and-int v2, v19, v2

    move/from16 v23, v2

    and-int v2, v11, v19

    move/from16 v25, v6

    not-int v6, v2

    and-int v31, v19, v6

    move/from16 v42, v2

    xor-int v2, v11, v19

    xor-int v36, v51, v36

    and-int v36, v36, v49

    move/from16 v49, v6

    not-int v6, v4

    move/from16 v51, v4

    iget v4, v0, Loy1;->j1:I

    xor-int v4, v4, v47

    xor-int v4, v4, v18

    xor-int v4, v4, v44

    xor-int/2addr v4, v12

    iput v4, v0, Loy1;->u0:I

    move/from16 v18, v6

    iget v6, v0, Loy1;->y1:I

    and-int v6, v6, v47

    or-int v6, v50, v6

    move/from16 v44, v6

    iget v6, v0, Loy1;->V0:I

    and-int v6, v6, v47

    move/from16 v50, v6

    iget v6, v0, Loy1;->X0:I

    xor-int v6, v6, v50

    xor-int v6, v6, v43

    and-int v6, v51, v6

    move/from16 v43, v6

    iget v6, v0, Loy1;->n:I

    xor-int v38, v38, v39

    xor-int v38, v38, v43

    xor-int v6, v38, v6

    iput v6, v0, Loy1;->n:I

    move/from16 v38, v11

    not-int v11, v6

    and-int v11, p1, v11

    iput v11, v0, Loy1;->e2:I

    or-int v11, v6, p1

    iput v11, v0, Loy1;->t0:I

    iput v11, v0, Loy1;->V0:I

    xor-int v6, p1, v6

    iput v6, v0, Loy1;->X0:I

    not-int v6, v8

    and-int v6, v47, v6

    xor-int v6, v52, v6

    iget v8, v0, Loy1;->F:I

    xor-int v11, v30, v36

    xor-int v6, v6, v44

    and-int v11, v11, v18

    xor-int/2addr v11, v6

    xor-int/2addr v8, v11

    iput v8, v0, Loy1;->F:I

    or-int v11, v10, v8

    iput v11, v0, Loy1;->d1:I

    xor-int v6, v6, v40

    iget v11, v0, Loy1;->B:I

    xor-int/2addr v6, v11

    iput v6, v0, Loy1;->B:I

    not-int v11, v6

    and-int v18, v19, v11

    or-int v30, v6, v19

    or-int v36, v6, v31

    xor-int v39, v19, v36

    not-int v1, v1

    and-int v1, v41, v1

    xor-int v1, v21, v1

    not-int v1, v1

    and-int v1, v45, v1

    xor-int v1, v27, v1

    not-int v1, v1

    and-int v1, v51, v1

    move/from16 v21, v1

    iget v1, v0, Loy1;->j0:I

    xor-int v27, v33, p2

    xor-int v27, v27, v35

    xor-int v21, v27, v21

    xor-int v1, v21, v1

    iput v1, v0, Loy1;->j0:I

    move/from16 p2, v6

    iget v6, v0, Loy1;->Z0:I

    or-int/2addr v6, v12

    move/from16 v21, v6

    iget v6, v0, Loy1;->E1:I

    xor-int v6, v6, v21

    move/from16 v21, v6

    iget v6, v0, Loy1;->o:I

    xor-int v6, v21, v6

    move/from16 v21, v11

    iget v11, v0, Loy1;->P0:I

    or-int/2addr v11, v6

    move/from16 v27, v11

    iget v11, v0, Loy1;->t1:I

    xor-int v11, v11, v27

    move/from16 v27, v11

    iget v11, v0, Loy1;->Z:I

    xor-int v11, v27, v11

    iput v11, v0, Loy1;->Z:I

    and-int v27, v11, v49

    move/from16 v33, v11

    iget v11, v0, Loy1;->s1:I

    or-int/2addr v11, v6

    move/from16 v35, v11

    iget v11, v0, Loy1;->d2:I

    xor-int v11, v11, v35

    move/from16 v35, v11

    iget v11, v0, Loy1;->d0:I

    xor-int v11, v35, v11

    iput v11, v0, Loy1;->d0:I

    move/from16 v35, v11

    iget v11, v0, Loy1;->H0:I

    or-int/2addr v11, v6

    move/from16 v40, v11

    iget v11, v0, Loy1;->q1:I

    xor-int v11, v11, v40

    move/from16 v40, v11

    iget v11, v0, Loy1;->H:I

    xor-int v11, v40, v11

    iput v11, v0, Loy1;->H:I

    xor-int v40, v11, v22

    and-int v43, v11, v4

    and-int v44, v11, v48

    and-int v48, p0, v44

    move/from16 v49, v12

    or-int v12, v22, v44

    xor-int/2addr v15, v12

    or-int v50, v11, v22

    move/from16 v51, v13

    not-int v13, v11

    and-int v52, p0, v13

    move/from16 v53, v11

    not-int v11, v4

    and-int v54, v53, v11

    xor-int v54, v4, v54

    and-int v13, v22, v13

    move/from16 v55, v4

    not-int v4, v13

    and-int v4, v22, v4

    not-int v4, v4

    and-int v4, p0, v4

    xor-int v56, v22, v4

    xor-int v57, v13, p0

    and-int v58, p0, v13

    and-int v22, v53, v22

    and-int v59, p0, v22

    xor-int v60, v22, p0

    and-int v61, p0, v53

    xor-int v62, v55, v43

    move/from16 p0, v4

    not-int v4, v9

    move/from16 v63, v4

    iget v4, v0, Loy1;->X1:I

    move/from16 v64, v4

    not-int v4, v6

    and-int v4, v64, v4

    move/from16 v64, v4

    iget v4, v0, Loy1;->M1:I

    xor-int v4, v4, v64

    move/from16 v64, v4

    iget v4, v0, Loy1;->D:I

    xor-int v4, v64, v4

    iput v4, v0, Loy1;->D:I

    move/from16 v64, v6

    not-int v6, v4

    and-int v65, v3, v6

    move/from16 v66, v4

    iget v4, v0, Loy1;->c1:I

    or-int v4, v49, v4

    move/from16 v49, v4

    iget v4, v0, Loy1;->a1:I

    xor-int v4, v4, v49

    move/from16 v49, v4

    iget v4, v0, Loy1;->s:I

    xor-int v4, v49, v4

    move/from16 v49, v4

    iget v4, v0, Loy1;->I:I

    move/from16 v67, v6

    not-int v6, v4

    move/from16 v68, v4

    iget v4, v0, Loy1;->e0:I

    and-int v69, v49, v6

    xor-int v70, v4, v69

    move/from16 v71, v6

    iget v6, v0, Loy1;->M0:I

    move/from16 v72, v9

    and-int v9, v49, v6

    move/from16 v73, v11

    iget v11, v0, Loy1;->c:I

    not-int v9, v9

    and-int/2addr v9, v11

    xor-int/2addr v9, v6

    move/from16 v74, v9

    iget v9, v0, Loy1;->k:I

    or-int v74, v9, v74

    move/from16 v75, v11

    iget v11, v0, Loy1;->Z1:I

    and-int v11, v49, v11

    move/from16 v76, v11

    iget v11, v0, Loy1;->O0:I

    move/from16 v77, v13

    xor-int v13, v11, v76

    not-int v13, v13

    and-int v13, v75, v13

    move/from16 v76, v13

    not-int v13, v11

    move/from16 v78, v11

    iget v11, v0, Loy1;->K0:I

    and-int v13, v49, v13

    xor-int/2addr v11, v13

    not-int v11, v11

    and-int v11, v75, v11

    and-int v79, v49, v78

    xor-int v79, v78, v79

    move/from16 v80, v11

    iget v11, v0, Loy1;->x1:I

    xor-int v81, v44, v48

    xor-int v48, v50, v48

    xor-int v50, v12, v52

    xor-int v58, v40, v58

    xor-int v82, v40, v59

    xor-int v22, v22, v52

    xor-int v52, v53, v61

    xor-int v11, v79, v11

    move/from16 v83, v11

    not-int v11, v9

    and-int v79, v75, v79

    xor-int v79, v49, v79

    move/from16 v84, v9

    iget v9, v0, Loy1;->n0:I

    move/from16 v85, v11

    not-int v11, v9

    and-int v11, v49, v11

    move/from16 v86, v9

    iget v9, v0, Loy1;->x0:I

    xor-int v87, v9, v11

    move/from16 v88, v9

    iget v9, v0, Loy1;->I0:I

    xor-int v80, v87, v80

    xor-int v9, v80, v9

    move/from16 v80, v9

    iget v9, v0, Loy1;->A:I

    move/from16 v87, v11

    not-int v11, v9

    move/from16 v89, v9

    not-int v9, v4

    and-int v9, v49, v9

    xor-int v90, v78, v9

    and-int v90, v75, v90

    or-int v84, v84, v90

    move/from16 v90, v4

    xor-int v4, v86, v87

    not-int v4, v4

    and-int v4, v75, v4

    and-int v83, v83, v85

    xor-int v4, v4, v83

    or-int v4, v89, v4

    xor-int v83, v6, v49

    xor-int v76, v83, v76

    move/from16 v83, v4

    iget v4, v0, Loy1;->T0:I

    xor-int v4, v76, v4

    move/from16 v76, v4

    iget v4, v0, Loy1;->T:I

    and-int v80, v80, v11

    xor-int v76, v76, v80

    xor-int v4, v76, v4

    iput v4, v0, Loy1;->T:I

    move/from16 v76, v9

    and-int v9, v4, v67

    iput v9, v0, Loy1;->I0:I

    iget v9, v0, Loy1;->l1:I

    xor-int v9, v76, v9

    and-int v9, v9, v85

    xor-int/2addr v9, v13

    or-int v9, v89, v9

    and-int v76, v49, v88

    xor-int v76, v88, v76

    move/from16 v80, v9

    iget v9, v0, Loy1;->p0:I

    xor-int v9, v76, v9

    xor-int v13, v78, v13

    and-int v13, v75, v13

    xor-int v13, v70, v13

    and-int v70, v49, v68

    xor-int v70, v78, v70

    or-int v76, v75, v70

    move/from16 v78, v9

    iget v9, v0, Loy1;->z:I

    and-int v76, v76, v85

    xor-int v13, v13, v76

    xor-int v13, v13, v83

    xor-int/2addr v9, v13

    iput v9, v0, Loy1;->z:I

    or-int v13, v9, v57

    move/from16 v76, v11

    not-int v11, v9

    and-int v50, v50, v11

    xor-int v17, v17, v50

    or-int v50, v9, v81

    xor-int v50, v57, v50

    and-int v22, v22, v11

    xor-int v22, v40, v22

    and-int v22, v20, v22

    or-int v40, v9, v48

    xor-int v40, v82, v40

    xor-int v22, v40, v22

    or-int v22, v10, v22

    and-int v40, v52, v11

    xor-int v40, v53, v40

    and-int v40, v20, v40

    xor-int v40, v59, v40

    or-int v40, v10, v40

    and-int v48, v57, v11

    xor-int v48, v60, v48

    and-int v48, v20, v48

    and-int v52, v57, v9

    xor-int v52, v44, v52

    and-int v52, v20, v52

    or-int v57, v9, v56

    xor-int v57, v15, v57

    move/from16 v59, v9

    not-int v9, v12

    and-int v9, v59, v9

    not-int v9, v9

    and-int v9, v20, v9

    move/from16 v60, v9

    iget v9, v0, Loy1;->O:I

    xor-int v17, v17, v60

    xor-int v17, v17, v40

    xor-int v9, v17, v9

    iput v9, v0, Loy1;->O:I

    and-int v17, v14, v25

    and-int v40, v14, v21

    and-int v60, v2, v21

    or-int v81, p2, v17

    or-int v82, p2, v42

    and-int v83, v38, v21

    xor-int v77, v77, p0

    or-int v86, p2, v38

    xor-int v40, v2, v40

    xor-int v60, v2, v60

    xor-int v87, v17, v18

    xor-int v81, v38, v81

    move/from16 v88, v11

    xor-int v11, v38, v30

    xor-int v14, v14, v82

    xor-int v30, v2, v18

    move/from16 p0, v12

    xor-int v12, v38, v18

    move/from16 v18, v13

    xor-int v13, v2, v83

    and-int v83, p0, v88

    move/from16 p0, v14

    xor-int v14, v44, v83

    not-int v14, v14

    and-int v14, v20, v14

    xor-int v14, v50, v14

    xor-int v22, v14, v22

    move/from16 v44, v14

    xor-int v14, v22, v41

    iput v14, v0, Loy1;->E:I

    and-int v22, v78, v85

    xor-int v22, v79, v22

    xor-int v18, v58, v18

    and-int v22, v22, v76

    xor-int v18, v18, v48

    and-int v41, v61, v88

    xor-int v15, v15, v41

    and-int v15, v20, v15

    xor-int v15, v57, v15

    and-int/2addr v15, v10

    xor-int v15, v44, v15

    xor-int v15, v15, v89

    iput v15, v0, Loy1;->v0:I

    and-int v20, v77, v88

    xor-int v20, v56, v20

    xor-int v20, v20, v52

    not-int v10, v10

    and-int v20, v20, v10

    xor-int v18, v18, v20

    move/from16 v20, v10

    xor-int v10, v18, v26

    iput v10, v0, Loy1;->m:I

    not-int v6, v6

    and-int v6, v49, v6

    not-int v6, v6

    and-int v6, v75, v6

    iget v10, v0, Loy1;->V1:I

    xor-int/2addr v6, v10

    xor-int v6, v6, v84

    iget v10, v0, Loy1;->N:I

    xor-int v6, v6, v22

    xor-int/2addr v6, v10

    iput v6, v0, Loy1;->N:I

    and-int v10, v6, v8

    iput v10, v0, Loy1;->p0:I

    and-int v18, v6, v16

    move/from16 v22, v10

    xor-int v10, v6, v1

    iput v10, v0, Loy1;->M0:I

    or-int v10, v1, v6

    move/from16 v26, v10

    not-int v10, v6

    and-int/2addr v10, v1

    and-int v41, v16, v10

    move/from16 v44, v6

    not-int v6, v10

    and-int/2addr v6, v1

    move/from16 v48, v6

    not-int v6, v1

    and-int v6, v44, v6

    iput v6, v0, Loy1;->c2:I

    or-int v50, v1, v6

    and-int v52, v16, v50

    move/from16 v56, v1

    not-int v1, v8

    and-int v1, v44, v1

    and-int v20, v1, v20

    xor-int v20, v22, v20

    move/from16 v22, v6

    or-int v6, v35, v20

    iput v6, v0, Loy1;->m0:I

    iput v1, v0, Loy1;->Q0:I

    and-int v1, v44, v56

    iput v1, v0, Loy1;->t1:I

    xor-int v6, v68, v69

    and-int v6, v75, v6

    xor-int v6, v70, v6

    xor-int v6, v6, v74

    xor-int v6, v6, v80

    move/from16 v20, v1

    iget v1, v0, Loy1;->R:I

    xor-int/2addr v1, v6

    iput v1, v0, Loy1;->R:I

    not-int v6, v2

    and-int/2addr v6, v1

    xor-int v6, v60, v6

    and-int v6, v33, v6

    and-int v35, v1, v60

    move/from16 v57, v2

    xor-int v2, v36, v35

    not-int v2, v2

    and-int v2, v33, v2

    and-int v35, v1, p0

    xor-int v17, v17, v35

    xor-int v6, v17, v6

    not-int v6, v6

    and-int v6, p1, v6

    and-int v17, v1, v38

    xor-int v17, v39, v17

    and-int v17, v33, v17

    move/from16 p0, v2

    not-int v2, v12

    and-int/2addr v2, v1

    xor-int v2, v81, v2

    not-int v2, v2

    and-int v2, v33, v2

    move/from16 v35, v2

    not-int v2, v1

    and-int v36, v40, v2

    xor-int v36, v12, v36

    xor-int v35, v36, v35

    xor-int v6, v35, v6

    xor-int v6, v6, v24

    iput v6, v0, Loy1;->g:I

    or-int v24, v30, v1

    xor-int v12, v12, v24

    and-int v12, v33, v12

    not-int v11, v11

    move/from16 v30, v1

    not-int v1, v13

    and-int v1, v30, v1

    xor-int v1, v19, v1

    not-int v1, v1

    and-int v1, v33, v1

    and-int v11, v30, v11

    xor-int/2addr v1, v11

    not-int v1, v1

    and-int v1, p1, v1

    and-int v2, v86, v2

    xor-int/2addr v2, v13

    xor-int/2addr v2, v12

    xor-int/2addr v1, v2

    xor-int v1, v1, v32

    iput v1, v0, Loy1;->u:I

    and-int v1, v42, v21

    or-int v2, v30, v87

    xor-int v11, v31, p2

    xor-int v12, v42, v82

    and-int v13, v23, v21

    xor-int v1, v42, v1

    move/from16 v23, v2

    xor-int v2, v12, v24

    not-int v2, v2

    and-int v2, v33, v2

    xor-int v2, v23, v2

    and-int v2, p1, v2

    not-int v1, v1

    and-int v1, v30, v1

    xor-int/2addr v1, v11

    xor-int v1, v1, v17

    xor-int/2addr v1, v2

    xor-int v1, v1, v51

    iput v1, v0, Loy1;->U:I

    and-int v2, v1, v14

    not-int v12, v12

    and-int v12, v30, v12

    xor-int v12, v57, v12

    xor-int v12, v12, v27

    and-int v13, v30, v13

    xor-int/2addr v11, v13

    xor-int v11, v11, p0

    and-int v11, p1, v11

    xor-int/2addr v11, v12

    xor-int v11, v11, v90

    iput v11, v0, Loy1;->e0:I

    and-int v12, v11, v15

    iput v12, v0, Loy1;->G0:I

    or-int v13, v9, v11

    iput v13, v0, Loy1;->f2:I

    move/from16 p0, v2

    not-int v2, v11

    and-int/2addr v13, v2

    iput v13, v0, Loy1;->C1:I

    xor-int v13, v11, v15

    iput v13, v0, Loy1;->U0:I

    not-int v13, v9

    and-int/2addr v13, v11

    iput v13, v0, Loy1;->e1:I

    and-int v13, v11, v9

    iput v13, v0, Loy1;->i1:I

    not-int v13, v13

    and-int/2addr v13, v11

    iput v13, v0, Loy1;->g1:I

    xor-int/2addr v9, v11

    iput v9, v0, Loy1;->b1:I

    or-int v13, v15, v11

    iput v13, v0, Loy1;->l1:I

    not-int v13, v15

    and-int/2addr v13, v11

    iput v13, v0, Loy1;->A1:I

    or-int/2addr v13, v15

    iput v13, v0, Loy1;->Y1:I

    and-int/2addr v2, v15

    iput v2, v0, Loy1;->y1:I

    not-int v2, v2

    and-int/2addr v2, v15

    iput v2, v0, Loy1;->T1:I

    iget v2, v0, Loy1;->D1:I

    iget v13, v0, Loy1;->Q:I

    xor-int/2addr v2, v13

    iput v2, v0, Loy1;->Q:I

    not-int v13, v2

    and-int v17, v34, v13

    move/from16 p1, v2

    iget v2, v0, Loy1;->Y:I

    xor-int v23, v2, v17

    and-int v23, v28, v23

    and-int v24, v2, v13

    move/from16 v27, v2

    xor-int v2, v34, v24

    iput v2, v0, Loy1;->o1:I

    iget v2, v0, Loy1;->B0:I

    and-int v24, v2, v13

    and-int v30, v24, v71

    move/from16 v31, v2

    iget v2, v0, Loy1;->L1:I

    and-int/2addr v2, v13

    xor-int v2, v31, v2

    move/from16 v32, v2

    iget v2, v0, Loy1;->R1:I

    xor-int v24, v2, v24

    xor-int v23, v24, v23

    or-int v23, v23, v68

    move/from16 v24, v2

    iget v2, v0, Loy1;->G1:I

    and-int v33, v2, v13

    move/from16 v35, v2

    iget v2, v0, Loy1;->H1:I

    xor-int v36, v2, v33

    move/from16 v38, v2

    xor-int v2, v24, p1

    xor-int v39, v2, v28

    and-int v40, v28, v2

    not-int v2, v2

    and-int v2, v28, v2

    move/from16 v42, v2

    iget v2, v0, Loy1;->U1:I

    or-int v2, p1, v2

    not-int v2, v2

    and-int v2, v28, v2

    move/from16 v51, v2

    iget v2, v0, Loy1;->J1:I

    or-int v57, p1, v2

    move/from16 v58, v2

    xor-int v2, v34, v57

    not-int v2, v2

    and-int v2, v28, v2

    and-int v57, v28, v33

    move/from16 v60, v2

    xor-int v2, v35, v17

    move/from16 v17, v8

    not-int v8, v2

    and-int v8, v28, v8

    xor-int v8, v33, v8

    and-int v8, v8, v71

    xor-int v33, v36, v51

    xor-int v8, v33, v8

    and-int v8, v8, v76

    xor-int v2, v2, v40

    xor-int v2, v2, v23

    or-int v2, v89, v2

    or-int v23, p1, v38

    xor-int v23, v34, v23

    xor-int v23, v23, v42

    and-int v23, v23, v71

    xor-int v23, v24, v23

    move/from16 v24, v2

    or-int v2, v89, v23

    iput v2, v0, Loy1;->L0:I

    and-int v2, v62, v63

    or-int v23, p1, v34

    xor-int v33, v31, v23

    and-int v33, v28, v33

    xor-int v33, v27, v33

    move/from16 v34, v2

    or-int v2, v68, v33

    iput v2, v0, Loy1;->s1:I

    xor-int v2, v58, v23

    and-int v2, v28, v2

    xor-int v2, v27, v2

    and-int v2, v2, v71

    xor-int v2, v39, v2

    xor-int/2addr v2, v8

    iget v8, v0, Loy1;->f0:I

    xor-int/2addr v2, v8

    iput v2, v0, Loy1;->f0:I

    xor-int v8, v2, p2

    or-int v33, v7, v8

    move/from16 v35, v8

    xor-int v8, v35, v33

    move/from16 v33, v9

    not-int v9, v8

    and-int v9, v19, v9

    and-int v8, v8, v19

    and-int v36, v2, v21

    move/from16 v39, v8

    not-int v8, v7

    and-int v40, v2, v8

    and-int v42, v40, v19

    move/from16 v51, v7

    iget v7, v0, Loy1;->t:I

    xor-int v42, v36, v42

    and-int v42, v7, v42

    or-int v58, v55, v2

    move/from16 v61, v7

    not-int v7, v2

    move/from16 v62, v2

    and-int v2, v58, v7

    move/from16 v68, v7

    not-int v7, v2

    and-int v7, v53, v7

    xor-int v7, v55, v7

    move/from16 v69, v2

    xor-int v2, v69, v43

    and-int v70, v72, v2

    move/from16 v74, v7

    not-int v7, v2

    and-int v7, v72, v7

    xor-int v7, v74, v7

    and-int v7, v7, v88

    or-int v2, v2, v72

    xor-int v76, v62, v43

    and-int v77, v72, v76

    or-int v76, v72, v76

    and-int v78, v55, v68

    and-int v79, v53, v78

    xor-int v80, v58, v79

    xor-int v34, v80, v34

    or-int v34, v59, v34

    or-int v80, v59, v79

    xor-int v78, v78, v53

    xor-int v78, v78, v72

    move/from16 v81, v2

    xor-int v2, v55, v62

    and-int v82, v53, v2

    xor-int v69, v69, v82

    or-int v69, v69, v72

    xor-int v69, v53, v69

    or-int v59, v59, v69

    xor-int v69, v79, v81

    move/from16 v81, v7

    xor-int v7, v69, v59

    not-int v7, v7

    and-int v7, v51, v7

    move/from16 v59, v7

    not-int v7, v2

    and-int v7, v53, v7

    xor-int v7, v58, v7

    xor-int v7, v7, v76

    and-int v58, v7, v88

    xor-int v7, v7, v58

    not-int v7, v7

    and-int v7, v51, v7

    xor-int v58, v74, v77

    xor-int v58, v58, v80

    xor-int v7, v58, v7

    xor-int v7, v7, v64

    iput v7, v0, Loy1;->o:I

    xor-int v58, v2, v43

    or-int v58, v58, v72

    and-int v64, v62, v73

    move/from16 v69, v2

    xor-int v2, v64, v43

    and-int v43, v2, v63

    xor-int v54, v54, v43

    and-int v54, v54, v88

    xor-int v63, v2, v70

    xor-int v63, v63, v81

    xor-int v59, v63, v59

    move/from16 v63, v8

    xor-int v8, v59, v49

    iput v8, v0, Loy1;->s:I

    move/from16 v49, v9

    not-int v9, v8

    and-int/2addr v9, v12

    iput v9, v0, Loy1;->M1:I

    and-int v9, v8, v15

    iput v9, v0, Loy1;->x1:I

    and-int/2addr v8, v11

    iput v8, v0, Loy1;->n1:I

    not-int v8, v2

    and-int v8, v72, v8

    xor-int/2addr v2, v8

    and-int v2, v2, v88

    or-int v8, v51, v62

    and-int v9, v62, p2

    or-int v12, v51, v9

    xor-int v15, v9, v12

    and-int v15, v19, v15

    move/from16 v59, v2

    not-int v2, v9

    and-int v2, p2, v2

    or-int v2, v51, v2

    move/from16 v64, v2

    xor-int v2, v36, v64

    not-int v2, v2

    and-int v2, v19, v2

    move/from16 v36, v2

    xor-int v2, v62, v64

    not-int v2, v2

    and-int v2, v19, v2

    or-int v70, v72, v62

    xor-int v70, v79, v70

    and-int v70, v70, v88

    xor-int v69, v69, v79

    xor-int v43, v69, v43

    move/from16 v69, v2

    xor-int v2, v43, v70

    not-int v2, v2

    and-int v2, v51, v2

    xor-int v43, v74, v58

    xor-int v34, v43, v34

    xor-int v2, v34, v2

    xor-int v2, v2, v29

    iput v2, v0, Loy1;->K:I

    and-int v2, v9, v63

    and-int v9, v53, v62

    xor-int v9, v62, v9

    or-int v9, v72, v9

    move/from16 v29, v2

    or-int v2, p2, v62

    and-int v21, v2, v21

    xor-int v12, v21, v12

    xor-int v34, v12, v36

    and-int v34, v61, v34

    xor-int v36, v12, v49

    xor-int v21, v21, v51

    xor-int v43, v21, v69

    xor-int v42, v43, v42

    move/from16 v43, v8

    not-int v8, v5

    or-int v49, v51, v2

    xor-int v49, v2, v49

    xor-int v15, v49, v15

    or-int/2addr v15, v5

    move/from16 v49, v5

    xor-int v5, v2, v43

    not-int v5, v5

    and-int v5, v19, v5

    xor-int v5, v51, v5

    not-int v5, v5

    and-int v5, v61, v5

    xor-int v43, v2, v29

    and-int v58, v43, v25

    xor-int v12, v12, v58

    xor-int v12, v12, v34

    xor-int/2addr v12, v15

    xor-int v12, v12, v46

    iput v12, v0, Loy1;->S:I

    or-int v12, v19, v43

    and-int v12, v61, v12

    and-int v15, v2, v63

    or-int v15, v19, v15

    xor-int v15, v35, v15

    xor-int v34, v2, v64

    and-int v43, v34, v25

    move/from16 v46, v5

    xor-int v5, v21, v43

    not-int v5, v5

    and-int v5, v61, v5

    and-int v21, v34, v19

    xor-int v21, v35, v21

    xor-int v21, v21, v46

    and-int v34, v42, v8

    xor-int v21, v21, v34

    move/from16 v34, v5

    xor-int v5, v21, p1

    iput v5, v0, Loy1;->Z0:I

    not-int v5, v2

    and-int v5, v19, v5

    xor-int v5, v40, v5

    and-int v5, v61, v5

    xor-int v2, v2, v51

    or-int v2, v19, v2

    xor-int v2, v51, v2

    not-int v2, v2

    and-int v2, v61, v2

    and-int v19, p2, v68

    xor-int v21, v19, v29

    xor-int v21, v21, v39

    move/from16 p2, v2

    iget v2, v0, Loy1;->y:I

    xor-int v12, v36, v12

    xor-int v21, v21, p2

    and-int v8, v21, v8

    xor-int/2addr v8, v12

    xor-int/2addr v2, v8

    iput v2, v0, Loy1;->y:I

    and-int v2, v19, v63

    and-int v2, v2, v25

    xor-int v2, v40, v2

    xor-int/2addr v2, v5

    or-int v2, v49, v2

    xor-int v5, v15, v34

    xor-int/2addr v2, v5

    xor-int v2, v2, v45

    iput v2, v0, Loy1;->M:I

    not-int v5, v2

    and-int v8, v1, v5

    and-int v12, v14, v2

    xor-int v15, v12, p0

    and-int v19, v1, v12

    move/from16 p2, v2

    and-int v2, v14, v5

    move/from16 v21, v5

    xor-int v5, v2, v8

    iput v5, v0, Loy1;->O0:I

    and-int v25, v1, v2

    move/from16 v29, v5

    not-int v5, v2

    and-int/2addr v5, v14

    iput v5, v0, Loy1;->K0:I

    move/from16 v34, v2

    not-int v2, v5

    and-int/2addr v2, v1

    xor-int v5, v5, v19

    iput v5, v0, Loy1;->S1:I

    move/from16 v19, v2

    not-int v2, v7

    and-int v2, p2, v2

    iput v2, v0, Loy1;->c1:I

    and-int v2, v6, p2

    iput v2, v0, Loy1;->G1:I

    not-int v2, v2

    and-int/2addr v2, v6

    iput v2, v0, Loy1;->a1:I

    or-int v2, p2, v14

    move/from16 v35, v2

    not-int v2, v6

    move/from16 v36, v2

    and-int v2, p2, v36

    iput v2, v0, Loy1;->x0:I

    xor-int v2, v78, v59

    move/from16 v39, v2

    xor-int v2, p2, v6

    iput v2, v0, Loy1;->U1:I

    xor-int/2addr v2, v7

    iput v2, v0, Loy1;->F0:I

    not-int v2, v14

    and-int v7, p2, v2

    move/from16 v40, v2

    not-int v2, v7

    and-int/2addr v2, v1

    or-int v42, v7, v14

    xor-int v43, v42, p0

    and-int v45, v1, v7

    move/from16 v46, v2

    xor-int v2, v35, v46

    iput v2, v0, Loy1;->R0:I

    xor-int v12, v12, v45

    iput v12, v0, Loy1;->p1:I

    move/from16 v35, v2

    or-int v2, p2, v6

    iput v2, v0, Loy1;->z0:I

    and-int v2, v2, v36

    iput v2, v0, Loy1;->Y0:I

    and-int v2, v6, v21

    iput v2, v0, Loy1;->j2:I

    and-int v2, v1, p2

    xor-int v2, v42, v2

    iput v2, v0, Loy1;->O1:I

    xor-int v6, p2, v14

    xor-int v14, v6, v46

    iput v14, v0, Loy1;->H0:I

    move/from16 v21, v2

    xor-int v2, v6, v19

    iput v2, v0, Loy1;->y0:I

    xor-int v2, v6, p0

    move/from16 p0, v2

    xor-int v2, v6, v45

    iput v2, v0, Loy1;->w1:I

    and-int v2, v1, v6

    iput v2, v0, Loy1;->b2:I

    move/from16 v19, v2

    not-int v2, v6

    and-int/2addr v2, v1

    iput v2, v0, Loy1;->w0:I

    xor-int v6, v6, v19

    iput v6, v0, Loy1;->J0:I

    and-int v36, v62, v55

    and-int v36, v53, v36

    xor-int v36, v62, v36

    xor-int v9, v36, v9

    xor-int v9, v9, v54

    not-int v9, v9

    and-int v9, v51, v9

    xor-int v9, v39, v9

    xor-int v9, v9, v47

    iput v9, v0, Loy1;->a:I

    and-int v13, v38, v13

    xor-int v13, v13, v57

    xor-int v13, v13, v30

    or-int v13, v89, v13

    iput v13, v0, Loy1;->s0:I

    xor-int v13, v27, v23

    xor-int v13, v13, v60

    xor-int v23, v31, p1

    and-int v23, v28, v23

    xor-int v23, v32, v23

    and-int v23, v23, v71

    xor-int v13, v13, v23

    xor-int v13, v13, v24

    move/from16 p1, v2

    iget v2, v0, Loy1;->h:I

    xor-int/2addr v2, v13

    iput v2, v0, Loy1;->h:I

    or-int v13, v2, v26

    xor-int v23, v26, v13

    xor-int v18, v23, v18

    and-int v18, v17, v18

    or-int v23, v66, v2

    move/from16 v24, v5

    and-int v5, v4, v2

    move/from16 v26, v6

    not-int v6, v5

    and-int v27, v3, v6

    or-int v27, v56, v27

    and-int/2addr v6, v2

    or-int v6, v66, v6

    move/from16 v28, v5

    or-int v5, v3, v6

    iput v5, v0, Loy1;->r0:I

    xor-int v5, v6, v65

    or-int v5, v56, v5

    xor-int v6, v28, v23

    move/from16 v23, v5

    xor-int v5, v6, v3

    iput v5, v0, Loy1;->L1:I

    and-int v5, v28, v67

    move/from16 v30, v5

    not-int v5, v3

    move/from16 v31, v3

    iget v3, v0, Loy1;->L:I

    xor-int v32, v28, v30

    and-int v32, v32, v5

    xor-int v23, v32, v23

    and-int v3, v3, v23

    or-int v23, v66, v28

    move/from16 v28, v3

    not-int v3, v2

    and-int v32, v10, v3

    xor-int v32, v56, v32

    or-int v36, v2, v48

    and-int v38, v17, v36

    move/from16 v39, v2

    iget v2, v0, Loy1;->p:I

    xor-int v38, v36, v38

    move/from16 v42, v3

    or-int v3, v2, v38

    iput v3, v0, Loy1;->n0:I

    iput v13, v0, Loy1;->V1:I

    and-int v3, v39, v67

    or-int v13, v31, v39

    iput v13, v0, Loy1;->m1:I

    xor-int v13, p2, v25

    move/from16 p2, v3

    or-int v3, v39, v56

    move/from16 v38, v5

    not-int v5, v3

    and-int v5, v16, v5

    iput v5, v0, Loy1;->z1:I

    xor-int v3, v56, v3

    and-int v3, v3, v16

    iput v3, v0, Loy1;->i2:I

    or-int v3, v39, v44

    xor-int v44, v44, v3

    move/from16 v45, v3

    xor-int v3, v44, v41

    not-int v3, v3

    and-int v3, v17, v3

    iput v3, v0, Loy1;->F1:I

    not-int v3, v4

    and-int v3, v39, v3

    xor-int v41, v3, p2

    move/from16 p2, v3

    and-int v3, v41, v38

    iput v3, v0, Loy1;->A0:I

    or-int v3, v31, v41

    xor-int/2addr v3, v6

    iput v3, v0, Loy1;->d2:I

    xor-int v3, v10, v36

    xor-int v6, v3, v52

    not-int v3, v3

    and-int v3, v16, v3

    xor-int v3, v32, v3

    iput v3, v0, Loy1;->q0:I

    xor-int v3, v10, v45

    not-int v3, v3

    and-int v3, v16, v3

    and-int v32, v50, v42

    xor-int v22, v22, v32

    move/from16 v32, v3

    and-int v3, v22, v16

    iput v3, v0, Loy1;->P0:I

    or-int v3, v4, v39

    iput v3, v0, Loy1;->D1:I

    and-int v4, v3, v42

    or-int v4, v66, v4

    xor-int v22, p2, v4

    move/from16 v36, v3

    or-int v3, v56, v22

    iput v3, v0, Loy1;->v1:I

    xor-int v3, v36, v4

    or-int v3, v31, v3

    and-int v4, v36, v38

    iput v4, v0, Loy1;->r1:I

    and-int v4, v36, v67

    xor-int v4, p2, v4

    iput v4, v0, Loy1;->h1:I

    xor-int v4, v36, v23

    xor-int v4, v4, v31

    xor-int v4, v4, v27

    xor-int v4, v4, v28

    xor-int v4, v4, v75

    iput v4, v0, Loy1;->c:I

    not-int v4, v4

    and-int/2addr v11, v4

    iput v11, v0, Loy1;->X1:I

    and-int v4, v33, v4

    iput v4, v0, Loy1;->B1:I

    xor-int v4, v36, v30

    or-int v11, v31, v4

    iput v11, v0, Loy1;->A:I

    xor-int/2addr v3, v4

    iput v3, v0, Loy1;->K1:I

    and-int v3, v20, v42

    xor-int v3, v56, v3

    iput v3, v0, Loy1;->q1:I

    or-int v4, v16, v3

    xor-int/2addr v4, v3

    not-int v4, v4

    and-int v4, v17, v4

    and-int v3, v17, v3

    xor-int/2addr v3, v5

    or-int/2addr v3, v2

    iput v3, v0, Loy1;->W0:I

    xor-int v3, v10, v39

    iput v3, v0, Loy1;->S0:I

    xor-int v3, v3, v32

    xor-int v3, v3, v18

    not-int v2, v2

    xor-int/2addr v4, v6

    and-int/2addr v2, v3

    xor-int/2addr v2, v4

    xor-int v2, v2, v37

    iput v2, v0, Loy1;->c0:I

    xor-int v3, v19, v2

    iput v3, v0, Loy1;->P:I

    and-int v4, v15, v2

    xor-int v5, v13, v4

    or-int/2addr v5, v9

    and-int v6, v2, v40

    xor-int v6, p1, v6

    iput v6, v0, Loy1;->o0:I

    not-int v6, v2

    and-int v10, v43, v6

    xor-int v10, v29, v10

    not-int v11, v9

    and-int/2addr v6, v7

    xor-int v6, v26, v6

    and-int v7, v10, v11

    xor-int/2addr v6, v7

    iput v6, v0, Loy1;->E1:I

    xor-int v6, v34, v25

    and-int v7, v12, v2

    xor-int v7, v21, v7

    and-int/2addr v7, v11

    xor-int/2addr v3, v7

    iput v3, v0, Loy1;->T0:I

    and-int v3, v6, v2

    xor-int v3, v24, v3

    or-int/2addr v3, v9

    iput v3, v0, Loy1;->N0:I

    or-int v3, v2, p0

    xor-int/2addr v3, v14

    iput v3, v0, Loy1;->k1:I

    xor-int/2addr v3, v5

    iput v3, v0, Loy1;->Q1:I

    and-int v3, v2, v43

    xor-int/2addr v3, v8

    or-int/2addr v3, v9

    not-int v5, v1

    and-int/2addr v2, v5

    xor-int/2addr v1, v2

    iput v1, v0, Loy1;->Z1:I

    xor-int/2addr v1, v3

    iput v1, v0, Loy1;->f1:I

    xor-int v1, v35, v4

    iput v1, v0, Loy1;->j1:I

    return-void
.end method


# virtual methods
.method public final b([B[B)V
    .locals 106

    move-object/from16 v0, p0

    iget v1, v0, Lbr3;->h:I

    packed-switch v1, :pswitch_data_0

    iget-object v0, v0, Lbr3;->i:Loy1;

    iget v1, v0, Loy1;->k1:I

    iget v2, v0, Loy1;->n2:I

    and-int v3, v1, v2

    iget v4, v0, Loy1;->u2:I

    xor-int/2addr v3, v4

    iget v5, v0, Loy1;->F2:I

    xor-int/2addr v5, v2

    iget v6, v0, Loy1;->B1:I

    iget v7, v0, Loy1;->F0:I

    not-int v7, v7

    and-int/2addr v7, v6

    iget v8, v0, Loy1;->H0:I

    xor-int/2addr v7, v8

    not-int v8, v6

    iget v9, v0, Loy1;->s:I

    and-int v10, v9, v8

    iget v11, v0, Loy1;->u:I

    and-int v12, v11, v10

    iget v13, v0, Loy1;->U0:I

    and-int/2addr v13, v6

    iget v14, v0, Loy1;->Z1:I

    xor-int/2addr v13, v14

    iget v14, v0, Loy1;->a0:I

    not-int v13, v13

    and-int/2addr v13, v14

    and-int/2addr v8, v11

    iget v15, v0, Loy1;->G0:I

    not-int v15, v15

    and-int/2addr v15, v6

    move/from16 p0, v2

    iget v2, v0, Loy1;->k2:I

    xor-int/2addr v2, v15

    xor-int/2addr v2, v13

    iget v13, v0, Loy1;->r:I

    xor-int/2addr v2, v13

    iput v2, v0, Loy1;->r:I

    iget v13, v0, Loy1;->p2:I

    not-int v15, v2

    move/from16 p1, v2

    and-int v2, v13, v15

    iput v2, v0, Loy1;->U0:I

    not-int v2, v2

    and-int/2addr v2, v13

    iput v2, v0, Loy1;->G0:I

    xor-int v2, p1, v13

    iput v2, v0, Loy1;->k2:I

    not-int v2, v13

    and-int v2, p1, v2

    iput v2, v0, Loy1;->l1:I

    or-int/2addr v2, v13

    iput v2, v0, Loy1;->n:I

    iget v2, v0, Loy1;->D:I

    xor-int/2addr v2, v8

    iget v13, v0, Loy1;->e:I

    move/from16 p2, v2

    not-int v2, v13

    move/from16 v16, v2

    iget v2, v0, Loy1;->A1:I

    and-int v17, p2, v16

    xor-int v2, v2, v17

    move/from16 p2, v3

    iget v3, v0, Loy1;->m:I

    not-int v2, v2

    and-int/2addr v2, v3

    move/from16 v17, v2

    not-int v2, v9

    and-int/2addr v2, v6

    and-int v18, v11, v2

    xor-int v18, v9, v18

    and-int v19, v11, v6

    xor-int v19, v9, v19

    or-int v19, v19, v13

    move/from16 v20, v2

    iget v2, v0, Loy1;->S0:I

    move/from16 v21, v2

    xor-int v2, v21, v19

    not-int v2, v2

    and-int/2addr v2, v3

    move/from16 v19, v2

    iget v2, v0, Loy1;->Y1:I

    not-int v2, v2

    and-int/2addr v2, v6

    move/from16 v22, v2

    iget v2, v0, Loy1;->j0:I

    xor-int v2, v2, v22

    not-int v2, v2

    and-int/2addr v2, v14

    xor-int/2addr v2, v7

    iget v7, v0, Loy1;->f:I

    xor-int/2addr v2, v7

    iput v2, v0, Loy1;->f:I

    iget v7, v0, Loy1;->v:I

    xor-int v22, v2, v7

    move/from16 v23, v3

    iget v3, v0, Loy1;->I1:I

    and-int v22, v3, v22

    and-int v24, v3, v2

    move/from16 v25, v3

    and-int v3, v6, v9

    or-int v26, v13, v3

    xor-int v26, v12, v26

    and-int v26, v23, v26

    not-int v3, v3

    and-int v27, v11, v3

    and-int v27, v27, v16

    xor-int v21, v21, v27

    and-int/2addr v3, v6

    move/from16 v27, v4

    not-int v4, v3

    and-int/2addr v4, v11

    xor-int/2addr v10, v4

    xor-int v11, v20, v12

    and-int v12, v11, v16

    xor-int/2addr v10, v12

    xor-int v10, v10, v19

    iget v12, v0, Loy1;->K1:I

    move/from16 v16, v3

    not-int v3, v10

    and-int/2addr v3, v12

    move/from16 v19, v3

    not-int v3, v12

    not-int v4, v4

    and-int/2addr v4, v13

    xor-int v4, v18, v4

    xor-int v4, v4, v17

    or-int v17, v4, v12

    and-int/2addr v4, v12

    xor-int v8, v16, v8

    or-int v16, v13, v8

    move/from16 v20, v3

    iget v3, v0, Loy1;->f2:I

    xor-int v16, v18, v16

    xor-int v16, v16, v26

    xor-int v18, v16, v19

    xor-int v3, v18, v3

    iput v3, v0, Loy1;->f2:I

    move/from16 v18, v4

    iget v4, v0, Loy1;->j1:I

    and-int v10, v10, v20

    xor-int v10, v16, v10

    xor-int/2addr v10, v4

    iput v10, v0, Loy1;->z0:I

    not-int v8, v8

    and-int/2addr v8, v13

    xor-int/2addr v8, v11

    and-int v8, v23, v8

    xor-int v8, v21, v8

    iget v11, v0, Loy1;->X:I

    xor-int v16, v8, v17

    move/from16 v17, v4

    xor-int v4, v16, v11

    iput v4, v0, Loy1;->S0:I

    move/from16 v16, v5

    iget v5, v0, Loy1;->q1:I

    move/from16 v19, v6

    not-int v6, v5

    move/from16 v20, v5

    iget v5, v0, Loy1;->x0:I

    and-int/2addr v6, v4

    xor-int/2addr v6, v5

    move/from16 v21, v5

    iget v5, v0, Loy1;->t0:I

    move/from16 v23, v5

    not-int v5, v4

    and-int v26, v23, v5

    move/from16 v28, v4

    iget v4, v0, Loy1;->d2:I

    xor-int v4, v4, v26

    move/from16 v26, v4

    iget v4, v0, Loy1;->P:I

    move/from16 v29, v5

    not-int v5, v4

    or-int v30, v28, p0

    xor-int v23, v23, v30

    or-int v23, v4, v23

    move/from16 v30, v4

    iget v4, v0, Loy1;->a1:I

    and-int v31, v4, v28

    xor-int v31, v16, v31

    move/from16 v32, v4

    iget v4, v0, Loy1;->W:I

    or-int v4, v28, v4

    move/from16 v33, v4

    iget v4, v0, Loy1;->h:I

    xor-int v4, v4, v33

    move/from16 v33, v4

    iget v4, v0, Loy1;->m0:I

    and-int v33, v33, v5

    xor-int v4, v4, v33

    move/from16 v33, v5

    iget v5, v0, Loy1;->M0:I

    and-int v5, v5, v29

    xor-int v5, v16, v5

    move/from16 v34, v5

    iget v5, v0, Loy1;->o0:I

    or-int v5, v28, v5

    xor-int v5, v27, v5

    move/from16 v27, v5

    iget v5, v0, Loy1;->W1:I

    not-int v5, v5

    and-int v5, v28, v5

    xor-int v5, p0, v5

    move/from16 p0, v5

    iget v5, v0, Loy1;->m1:I

    xor-int v5, p0, v5

    and-int v20, v20, v29

    move/from16 p0, v5

    iget v5, v0, Loy1;->E2:I

    xor-int v5, v5, v20

    or-int v5, v30, v5

    move/from16 v20, v5

    iget v5, v0, Loy1;->A2:I

    or-int v5, v28, v5

    xor-int v5, v32, v5

    move/from16 v32, v5

    iget v5, v0, Loy1;->v1:I

    and-int v5, v5, v29

    xor-int v5, v21, v5

    or-int v5, v30, v5

    move/from16 v21, v5

    iget v5, v0, Loy1;->x1:I

    or-int v5, v28, v5

    xor-int v5, p2, v5

    or-int v16, v28, v16

    move/from16 p2, v5

    iget v5, v0, Loy1;->e2:I

    xor-int v5, v5, v16

    or-int v5, v30, v5

    move/from16 v16, v5

    iget v5, v0, Loy1;->J:I

    xor-int v8, v8, v18

    xor-int/2addr v5, v8

    iput v5, v0, Loy1;->J:I

    iget v8, v0, Loy1;->B:I

    move/from16 v18, v6

    and-int v6, v8, v5

    or-int v28, v1, v6

    move/from16 v29, v9

    not-int v9, v6

    and-int/2addr v9, v8

    xor-int v30, v5, v8

    or-int v35, v30, v1

    or-int v36, v5, v8

    move/from16 v37, v9

    not-int v9, v8

    move/from16 v38, v8

    xor-int v8, v36, v28

    iput v8, v0, Loy1;->x1:I

    iput v6, v0, Loy1;->a1:I

    not-int v8, v5

    and-int v8, v38, v8

    move/from16 v28, v5

    iget v5, v0, Loy1;->y1:I

    or-int/2addr v11, v5

    xor-int/2addr v5, v11

    iget v11, v0, Loy1;->f0:I

    and-int/2addr v11, v5

    move/from16 v39, v5

    iget v5, v0, Loy1;->d1:I

    xor-int/2addr v5, v11

    iget v11, v0, Loy1;->p0:I

    xor-int/2addr v5, v11

    iget v11, v0, Loy1;->D0:I

    xor-int v11, v39, v11

    move/from16 v39, v5

    iget v5, v0, Loy1;->u0:I

    and-int/2addr v5, v11

    iget v11, v0, Loy1;->n1:I

    xor-int/2addr v5, v11

    iget v11, v0, Loy1;->H:I

    not-int v5, v5

    and-int/2addr v5, v11

    move/from16 v40, v5

    iget v5, v0, Loy1;->o:I

    xor-int v39, v39, v40

    xor-int v5, v39, v5

    move/from16 v39, v6

    iget v6, v0, Loy1;->i0:I

    or-int v40, v5, v6

    move/from16 v41, v8

    iget v8, v0, Loy1;->w:I

    and-int v42, v8, v5

    or-int v43, v40, v8

    move/from16 v44, v8

    iget v8, v0, Loy1;->X0:I

    move/from16 v45, v8

    iget v8, v0, Loy1;->z:I

    not-int v8, v8

    and-int v45, v45, v8

    move/from16 v46, v8

    iget v8, v0, Loy1;->g0:I

    xor-int v8, v8, v45

    and-int v8, v17, v8

    move/from16 v45, v8

    iget v8, v0, Loy1;->R1:I

    xor-int v8, v8, v45

    move/from16 v45, v8

    iget v8, v0, Loy1;->I0:I

    xor-int v8, v45, v8

    iput v8, v0, Loy1;->I0:I

    move/from16 v45, v9

    iget v9, v0, Loy1;->W0:I

    move/from16 v47, v9

    not-int v9, v8

    and-int v48, v47, v9

    move/from16 v49, v8

    iget v8, v0, Loy1;->b:I

    xor-int v48, v8, v48

    move/from16 v50, v8

    iget v8, v0, Loy1;->s0:I

    and-int v51, v8, v48

    move/from16 v52, v9

    iget v9, v0, Loy1;->y:I

    move/from16 v53, v9

    xor-int v9, v48, v51

    not-int v9, v9

    and-int v9, v53, v9

    or-int v51, v8, v48

    move/from16 v54, v9

    or-int v9, v49, v47

    move/from16 v47, v11

    iget v11, v0, Loy1;->L0:I

    xor-int v55, v11, v9

    or-int v55, v55, v8

    move/from16 v56, v11

    iget v11, v0, Loy1;->G:I

    xor-int v55, v11, v55

    and-int v55, v53, v55

    or-int v57, v49, v11

    xor-int v57, v50, v57

    and-int v58, v8, v57

    or-int v57, v57, v8

    and-int v59, v11, v52

    move/from16 v60, v11

    not-int v11, v8

    move/from16 v61, v8

    iget v8, v0, Loy1;->N0:I

    xor-int v62, v8, v9

    xor-int v57, v62, v57

    and-int v62, v53, v57

    move/from16 v63, v8

    iget v8, v0, Loy1;->y2:I

    xor-int v57, v57, v62

    or-int v57, v8, v57

    and-int v62, v63, v52

    xor-int v62, v50, v62

    and-int v63, v59, v11

    xor-int v62, v62, v63

    and-int v62, v53, v62

    move/from16 v63, v11

    not-int v11, v9

    and-int v11, v61, v11

    and-int v64, v61, v9

    move/from16 v65, v9

    iget v9, v0, Loy1;->e1:I

    and-int v9, v9, v52

    move/from16 v66, v11

    not-int v11, v9

    and-int v11, v53, v11

    and-int v65, v65, v63

    xor-int v65, v9, v65

    xor-int v55, v65, v55

    or-int v55, v55, v8

    move/from16 v65, v9

    iget v9, v0, Loy1;->C1:I

    xor-int v9, v65, v9

    not-int v9, v9

    and-int v9, v53, v9

    xor-int v65, v60, v59

    xor-int v65, v65, v51

    and-int v65, v53, v65

    xor-int v59, v50, v59

    move/from16 v67, v9

    iget v9, v0, Loy1;->Q:I

    or-int v9, v49, v9

    xor-int v68, v50, v9

    move/from16 v69, v9

    not-int v9, v8

    and-int v52, v50, v52

    xor-int v52, v60, v52

    xor-int v52, v52, v61

    xor-int v69, v60, v69

    xor-int v64, v69, v64

    and-int v53, v53, v64

    move/from16 v64, v8

    iget v8, v0, Loy1;->t:I

    and-int v70, v36, v45

    xor-int v48, v48, v66

    xor-int v48, v48, v53

    xor-int v48, v48, v55

    xor-int v8, v48, v8

    iput v8, v0, Loy1;->t:I

    and-int v45, v28, v45

    move/from16 v48, v9

    not-int v9, v8

    and-int v53, v39, v9

    xor-int v55, v39, v53

    move/from16 v66, v8

    not-int v8, v1

    or-int v71, v66, v70

    xor-int v72, v45, v71

    and-int v55, v55, v8

    move/from16 v73, v1

    xor-int v1, v72, v55

    iput v1, v0, Loy1;->d1:I

    xor-int v1, v68, v51

    xor-int v1, v1, v67

    and-int v1, v1, v48

    and-int v48, v59, v63

    xor-int v51, v28, v71

    and-int v30, v30, v9

    xor-int v30, v38, v30

    or-int v55, v66, v39

    xor-int v55, v45, v55

    or-int v55, v73, v55

    xor-int v37, v37, v53

    or-int v37, v73, v37

    move/from16 v53, v1

    xor-int v1, v30, v37

    iput v1, v0, Loy1;->f0:I

    and-int v1, v45, v9

    xor-int v37, v28, v1

    and-int v37, v37, v8

    move/from16 v45, v1

    xor-int v1, v30, v37

    iput v1, v0, Loy1;->e2:I

    and-int v1, v28, v9

    xor-int v9, v28, v1

    iput v9, v0, Loy1;->o1:I

    or-int v9, v66, v28

    xor-int v30, v36, v9

    and-int v37, v73, v30

    move/from16 v59, v1

    xor-int v1, v36, v37

    iput v1, v0, Loy1;->d2:I

    or-int v1, v66, v36

    xor-int v1, v36, v1

    and-int/2addr v1, v8

    iput v1, v0, Loy1;->z2:I

    xor-int v1, v41, v45

    or-int v36, v73, v1

    move/from16 v37, v1

    xor-int v1, v30, v36

    iput v1, v0, Loy1;->o0:I

    and-int v1, v37, v8

    xor-int v1, v51, v1

    iput v1, v0, Loy1;->n2:I

    xor-int v1, v39, v66

    not-int v1, v1

    and-int v1, v73, v1

    xor-int v1, v39, v1

    iput v1, v0, Loy1;->W0:I

    or-int v1, v66, v38

    xor-int v1, v28, v1

    xor-int v8, v1, v73

    iput v8, v0, Loy1;->X0:I

    and-int v1, v73, v1

    iput v1, v0, Loy1;->Z1:I

    xor-int v1, v70, v9

    xor-int v1, v1, v35

    iput v1, v0, Loy1;->M0:I

    xor-int v1, v59, v55

    iput v1, v0, Loy1;->N0:I

    xor-int v1, v38, v59

    xor-int v1, v1, v73

    iput v1, v0, Loy1;->x0:I

    xor-int v1, v69, v58

    xor-int/2addr v1, v11

    xor-int v1, v1, v57

    iget v8, v0, Loy1;->p:I

    xor-int/2addr v1, v8

    iput v1, v0, Loy1;->p:I

    iget v8, v0, Loy1;->N:I

    xor-int v9, v8, v1

    iput v9, v0, Loy1;->h:I

    not-int v11, v8

    and-int v30, v1, v8

    move/from16 v35, v1

    iget v1, v0, Loy1;->x:I

    move/from16 v36, v8

    not-int v8, v1

    xor-int v37, v69, v48

    xor-int v37, v37, v62

    move/from16 v45, v1

    iget v1, v0, Loy1;->L:I

    xor-int v37, v37, v53

    xor-int v1, v37, v1

    iput v1, v0, Loy1;->L:I

    xor-int v37, v1, v2

    move/from16 v48, v8

    and-int v8, v1, v2

    move/from16 v51, v9

    not-int v9, v8

    and-int/2addr v9, v2

    or-int v53, v7, v9

    xor-int v53, v37, v53

    xor-int v24, v53, v24

    move/from16 v53, v8

    not-int v8, v7

    or-int v55, v7, v53

    xor-int v55, v2, v55

    move/from16 v57, v7

    not-int v7, v1

    and-int v58, v2, v7

    and-int v58, v58, v8

    move/from16 v59, v1

    xor-int v1, v58, v22

    move/from16 v62, v7

    xor-int v7, v37, v58

    not-int v7, v7

    and-int v7, v25, v7

    xor-int v37, v59, v58

    and-int v37, v25, v37

    or-int v58, v57, v59

    xor-int v58, v53, v58

    and-int v58, v25, v58

    move/from16 v63, v7

    xor-int v7, v57, v58

    or-int v66, v2, v59

    move/from16 v67, v8

    not-int v8, v2

    and-int v68, v66, v8

    or-int v57, v57, v68

    xor-int v57, v66, v57

    move/from16 v66, v2

    xor-int v2, v57, v22

    and-int v22, v59, v8

    and-int v22, v22, v67

    move/from16 v57, v8

    xor-int v8, v9, v22

    not-int v8, v8

    and-int v8, v25, v8

    or-int v22, v49, v56

    xor-int v22, v50, v22

    move/from16 v25, v8

    iget v8, v0, Loy1;->O1:I

    xor-int v49, v52, v54

    xor-int v8, v22, v8

    xor-int v8, v8, v65

    or-int v8, v8, v64

    move/from16 v22, v8

    iget v8, v0, Loy1;->h2:I

    xor-int v22, v49, v22

    xor-int v8, v22, v8

    iput v8, v0, Loy1;->h2:I

    move/from16 v22, v9

    and-int v9, v8, p1

    iput v9, v0, Loy1;->g0:I

    and-int v9, v8, v15

    iput v9, v0, Loy1;->R1:I

    iget v9, v0, Loy1;->R:I

    and-int v9, v9, v46

    iget v15, v0, Loy1;->G2:I

    xor-int/2addr v9, v15

    or-int v9, v9, v17

    iget v15, v0, Loy1;->h1:I

    xor-int/2addr v9, v15

    iget v15, v0, Loy1;->E:I

    xor-int/2addr v9, v15

    iput v9, v0, Loy1;->E:I

    iget v15, v0, Loy1;->k0:I

    or-int v17, v15, v9

    move/from16 v46, v11

    not-int v11, v15

    move/from16 v49, v11

    iget v11, v0, Loy1;->M:I

    and-int v50, v9, v49

    move/from16 v52, v12

    xor-int v12, v11, v50

    move/from16 v54, v13

    iget v13, v0, Loy1;->c0:I

    not-int v12, v12

    and-int/2addr v12, v13

    or-int v56, v5, v9

    and-int v65, v6, v9

    move/from16 p1, v12

    not-int v12, v5

    xor-int v68, v6, v9

    xor-int v69, v68, v40

    and-int v69, v44, v69

    or-int v70, v5, v68

    or-int v71, v9, v11

    or-int v72, v15, v71

    move/from16 v73, v5

    and-int v5, v13, v50

    iput v5, v0, Loy1;->T1:I

    not-int v5, v9

    and-int v74, v11, v5

    move/from16 v75, v5

    and-int v5, v74, v49

    iput v5, v0, Loy1;->s2:I

    and-int v5, v13, v74

    xor-int v74, v74, v50

    move/from16 v76, v5

    and-int v5, v13, v74

    iput v5, v0, Loy1;->A2:I

    move/from16 v74, v5

    xor-int v5, v9, v11

    iput v5, v0, Loy1;->i1:I

    move/from16 v77, v5

    or-int v5, v15, v77

    iput v5, v0, Loy1;->o2:I

    move/from16 v78, v5

    iget v5, v0, Loy1;->U:I

    and-int v79, v77, v49

    xor-int v79, v77, v79

    move/from16 v80, v9

    or-int v9, v5, v79

    iput v9, v0, Loy1;->a2:I

    not-int v9, v13

    and-int v9, v78, v9

    xor-int/2addr v9, v15

    iput v9, v0, Loy1;->e0:I

    not-int v9, v5

    xor-int v15, v77, v15

    move/from16 v79, v5

    not-int v5, v15

    and-int/2addr v5, v13

    xor-int v5, v71, v5

    or-int v5, v79, v5

    move/from16 v81, v5

    iget v5, v0, Loy1;->B0:I

    xor-int/2addr v5, v15

    xor-int v15, v11, v78

    move/from16 v82, v5

    iget v5, v0, Loy1;->C:I

    xor-int v5, v80, v5

    or-int v83, v80, v6

    xor-int v84, v83, v73

    or-int v85, v73, v83

    move/from16 v86, v5

    not-int v5, v6

    and-int v5, v80, v5

    move/from16 v87, v6

    xor-int v6, v5, v70

    not-int v6, v6

    and-int v6, v44, v6

    and-int v70, v5, v12

    xor-int v70, v5, v70

    xor-int v42, v70, v42

    xor-int v70, v5, v40

    and-int v70, v44, v70

    move/from16 v88, v6

    not-int v6, v5

    and-int v6, v80, v6

    move/from16 v89, v5

    not-int v5, v6

    and-int v5, v44, v5

    and-int v90, v44, v6

    and-int v65, v65, v12

    xor-int v65, v65, v90

    or-int v90, v11, v65

    move/from16 v91, v5

    not-int v5, v11

    and-int v65, v65, v5

    xor-int v43, v43, v65

    move/from16 v65, v5

    iget v5, v0, Loy1;->g:I

    and-int v92, v59, v67

    and-int v53, v53, v67

    xor-int v22, v22, v92

    xor-int v53, v59, v53

    and-int v31, v31, v33

    and-int v26, v26, v33

    xor-int v25, v55, v25

    move/from16 v33, v5

    xor-int v5, v53, v58

    xor-int v37, v55, v37

    xor-int v22, v22, v63

    xor-int v16, p2, v16

    xor-int v21, v34, v21

    xor-int v20, v32, v20

    move/from16 p2, v6

    xor-int v6, v27, v31

    xor-int v18, v18, v26

    and-int v26, v33, v43

    xor-int v27, p2, v73

    and-int v31, v44, v27

    or-int v32, v73, v89

    xor-int v32, v68, v32

    xor-int v31, v32, v31

    and-int v31, v31, v65

    move/from16 v32, v9

    xor-int v9, v42, v31

    not-int v9, v9

    and-int v9, v33, v9

    move/from16 p2, v9

    and-int v9, v87, v75

    move/from16 v31, v11

    not-int v11, v9

    and-int v11, v44, v11

    and-int/2addr v12, v9

    xor-int v34, v68, v12

    xor-int v42, v34, v69

    xor-int v42, v42, v90

    xor-int v26, v42, v26

    move/from16 v42, v9

    xor-int v9, v26, v47

    iput v9, v0, Loy1;->H:I

    xor-int v26, v27, v70

    xor-int v27, v84, v91

    move/from16 v43, v9

    iget v9, v0, Loy1;->c1:I

    and-int v20, v43, v20

    xor-int v18, v18, v20

    xor-int v9, v18, v9

    iput v9, v0, Loy1;->c1:I

    not-int v6, v6

    iget v9, v0, Loy1;->a:I

    and-int v6, v43, v6

    xor-int v6, v21, v6

    xor-int/2addr v6, v9

    iput v6, v0, Loy1;->t0:I

    and-int v18, v43, v23

    xor-int v16, v16, v18

    move/from16 v18, v9

    xor-int v9, v16, v19

    iput v9, v0, Loy1;->B1:I

    not-int v4, v4

    and-int v4, v43, v4

    xor-int v4, p0, v4

    xor-int v4, v4, v73

    iput v4, v0, Loy1;->W:I

    xor-int v16, v87, v12

    xor-int v11, v16, v11

    and-int v11, v11, v65

    xor-int v16, v42, v40

    or-int v19, v73, v42

    xor-int v19, v19, v91

    xor-int v12, v83, v12

    move/from16 p0, v4

    iget v4, v0, Loy1;->V:I

    xor-int/2addr v4, v12

    or-int v4, v31, v4

    xor-int v4, v56, v4

    not-int v4, v4

    and-int v4, v33, v4

    iget v12, v0, Loy1;->g2:I

    xor-int v11, v27, v11

    xor-int/2addr v4, v11

    xor-int/2addr v4, v12

    iput v4, v0, Loy1;->g2:I

    not-int v1, v1

    and-int/2addr v1, v4

    xor-int v1, v25, v1

    iput v1, v0, Loy1;->F0:I

    not-int v11, v3

    and-int/2addr v11, v4

    or-int v12, v3, v11

    not-int v2, v2

    and-int/2addr v2, v4

    xor-int v2, v22, v2

    iput v2, v0, Loy1;->Y1:I

    and-int v20, v4, v3

    move/from16 v21, v1

    or-int v1, v4, v3

    move/from16 v22, v2

    not-int v2, v1

    and-int v2, v59, v2

    move/from16 v23, v1

    not-int v1, v4

    and-int/2addr v1, v3

    move/from16 v25, v2

    not-int v2, v1

    and-int v27, v3, v2

    or-int v40, v59, v27

    and-int v2, v59, v2

    xor-int v43, v4, v3

    not-int v5, v5

    and-int/2addr v5, v4

    xor-int v5, v37, v5

    iput v5, v0, Loy1;->m0:I

    not-int v7, v7

    and-int/2addr v7, v4

    xor-int v7, v24, v7

    iput v7, v0, Loy1;->A1:I

    or-int v24, v44, v42

    or-int v37, v80, v42

    xor-int v42, v37, v56

    xor-int v42, v42, v88

    or-int v42, v31, v42

    move/from16 v47, v1

    iget v1, v0, Loy1;->d0:I

    xor-int v26, v26, v42

    xor-int v26, v26, p2

    xor-int v1, v26, v1

    iput v1, v0, Loy1;->d0:I

    move/from16 p2, v2

    iget v2, v0, Loy1;->F:I

    move/from16 v26, v3

    not-int v3, v2

    and-int/2addr v3, v1

    move/from16 v42, v2

    xor-int v2, v3, v36

    move/from16 v53, v3

    iget v3, v0, Loy1;->x2:I

    not-int v2, v2

    and-int/2addr v2, v3

    and-int v55, v53, v46

    move/from16 v56, v2

    xor-int v2, v42, v55

    not-int v2, v2

    and-int/2addr v2, v3

    or-int/2addr v2, v8

    or-int v55, v36, v53

    or-int v58, v3, v55

    move/from16 v63, v2

    iget v2, v0, Loy1;->J2:I

    xor-int v2, v53, v2

    move/from16 v67, v2

    not-int v2, v3

    or-int v53, v42, v53

    and-int v68, v3, v53

    move/from16 v69, v2

    iget v2, v0, Loy1;->C2:I

    xor-int v2, v2, v68

    and-int v53, v53, v46

    or-int v68, v1, v42

    or-int v70, v36, v68

    move/from16 v73, v2

    not-int v2, v8

    move/from16 v75, v2

    iget v2, v0, Loy1;->q0:I

    xor-int v83, v89, v85

    and-int v83, v83, v65

    xor-int v2, v68, v2

    and-int/2addr v2, v3

    xor-int v84, v55, v2

    or-int v84, v8, v84

    xor-int v85, v68, v36

    and-int v85, v85, v3

    move/from16 v88, v2

    not-int v2, v1

    and-int v2, v42, v2

    or-int v89, v36, v2

    and-int v90, v2, v46

    xor-int v91, v1, v90

    move/from16 v92, v1

    iget v1, v0, Loy1;->l2:I

    xor-int v1, v91, v1

    move/from16 v93, v1

    iget v1, v0, Loy1;->p1:I

    xor-int v1, v90, v1

    move/from16 v94, v1

    not-int v1, v10

    xor-int v53, v2, v53

    xor-int v55, v68, v55

    and-int v67, v67, v69

    xor-int v67, v55, v67

    and-int v67, v67, v75

    xor-int v53, v53, v88

    xor-int v53, v53, v67

    or-int v53, v10, v53

    xor-int v67, v2, v36

    and-int v67, v3, v67

    xor-int v2, v2, v89

    xor-int v68, v2, v85

    and-int v68, v68, v75

    xor-int v67, v2, v67

    xor-int v67, v67, v68

    or-int v67, v10, v67

    and-int v2, v2, v69

    xor-int v2, v55, v2

    or-int/2addr v2, v8

    xor-int v68, v92, v42

    or-int v68, v36, v68

    xor-int v68, v42, v68

    move/from16 v69, v1

    or-int v1, v36, v92

    not-int v1, v1

    and-int/2addr v1, v3

    xor-int v1, v91, v1

    or-int/2addr v1, v8

    and-int v8, v92, v42

    move/from16 v85, v1

    xor-int v1, v8, v89

    not-int v1, v1

    and-int/2addr v1, v3

    xor-int v1, v70, v1

    and-int v1, v1, v75

    xor-int v1, v93, v1

    xor-int v1, v1, v53

    xor-int v1, v1, v52

    iput v1, v0, Loy1;->K1:I

    iget v1, v0, Loy1;->I2:I

    xor-int/2addr v1, v8

    move/from16 v52, v2

    not-int v2, v1

    and-int/2addr v2, v3

    xor-int v2, v55, v2

    xor-int v2, v2, v85

    xor-int v2, v2, v67

    xor-int v2, v2, v87

    iput v2, v0, Loy1;->i0:I

    move/from16 v53, v1

    not-int v1, v9

    and-int v55, v2, v1

    xor-int v67, v9, v55

    xor-int v8, v8, v90

    xor-int v56, v8, v56

    and-int v56, v56, v75

    xor-int v56, v73, v56

    or-int v10, v10, v56

    move/from16 v56, v1

    iget v1, v0, Loy1;->i:I

    xor-int v53, v53, v58

    xor-int v53, v53, v63

    xor-int v24, v34, v24

    xor-int v15, v15, p1

    and-int v15, v15, v32

    xor-int v34, v82, v81

    and-int v58, v71, v49

    and-int v30, v30, v48

    xor-int v10, v53, v10

    xor-int/2addr v1, v10

    iput v1, v0, Loy1;->i:I

    not-int v10, v6

    move/from16 p1, v2

    or-int v2, v6, v1

    move/from16 v53, v3

    and-int v3, v1, v6

    move/from16 v63, v4

    not-int v4, v3

    and-int/2addr v4, v6

    xor-int v70, v1, v6

    move/from16 v73, v3

    not-int v3, v1

    and-int/2addr v3, v6

    not-int v8, v8

    and-int v8, v53, v8

    move/from16 v53, v1

    iget v1, v0, Loy1;->P1:I

    xor-int v8, v68, v8

    xor-int v8, v8, v52

    xor-int v52, v94, v84

    and-int v52, v52, v69

    xor-int v8, v8, v52

    xor-int/2addr v1, v8

    iput v1, v0, Loy1;->P1:I

    and-int v1, v44, v37

    xor-int v1, v16, v1

    and-int v1, v1, v65

    xor-int v1, v19, v1

    not-int v1, v1

    and-int v1, v33, v1

    iget v8, v0, Loy1;->Z:I

    xor-int v16, v24, v83

    xor-int v1, v16, v1

    xor-int/2addr v1, v8

    iput v1, v0, Loy1;->Z:I

    not-int v8, v1

    move/from16 v16, v1

    and-int v1, v28, v8

    iput v1, v0, Loy1;->z1:I

    or-int v1, v16, v28

    and-int v1, v1, v57

    iput v1, v0, Loy1;->Q:I

    and-int v1, v80, v65

    move/from16 v19, v1

    xor-int v1, v19, v58

    and-int v24, v13, v1

    not-int v1, v1

    and-int/2addr v1, v13

    xor-int v37, v19, v72

    xor-int v1, v37, v1

    xor-int/2addr v1, v15

    and-int v1, v18, v1

    iget v15, v0, Loy1;->R0:I

    xor-int v1, v34, v1

    xor-int/2addr v1, v15

    iput v1, v0, Loy1;->R0:I

    not-int v15, v1

    and-int v34, v63, v15

    move/from16 v52, v1

    xor-int v1, v26, v34

    move/from16 v58, v3

    not-int v3, v1

    and-int v3, v59, v3

    and-int v65, v59, v1

    xor-int v1, v1, v40

    move/from16 v40, v1

    and-int v1, v43, v15

    move/from16 v68, v3

    not-int v3, v1

    and-int v3, v59, v3

    or-int v69, v52, v26

    xor-int v69, v23, v69

    xor-int v25, v69, v25

    move/from16 v72, v1

    iget v1, v0, Loy1;->H1:I

    and-int v25, v1, v25

    and-int v75, v35, v15

    xor-int v81, v52, v75

    xor-int v81, v81, v45

    and-int v82, v20, v15

    xor-int v83, v11, v82

    move/from16 v84, v1

    or-int v1, v36, v52

    move/from16 v85, v3

    not-int v3, v1

    and-int v3, v35, v3

    xor-int v87, v1, v35

    xor-int v30, v87, v30

    and-int v30, v84, v30

    move/from16 v88, v1

    xor-int v1, v43, v52

    move/from16 v89, v3

    not-int v3, v1

    and-int v3, v59, v3

    xor-int v3, v83, v3

    and-int v3, v84, v3

    or-int v83, v52, v27

    xor-int v90, v12, v34

    and-int v90, v59, v90

    move/from16 v91, v1

    and-int v1, v36, v15

    and-int v92, v1, v45

    and-int v93, v35, v1

    move/from16 v94, v3

    not-int v3, v1

    and-int v3, v35, v3

    and-int v95, v1, v48

    xor-int v95, v51, v95

    move/from16 v96, v1

    or-int v1, v52, v96

    and-int v97, v45, v1

    move/from16 v98, v3

    not-int v3, v1

    and-int v3, v45, v3

    and-int v1, v35, v1

    xor-int v1, v36, v1

    and-int v99, v84, v1

    move/from16 v100, v1

    xor-int v1, v95, v99

    not-int v1, v1

    and-int v1, v42, v1

    xor-int v89, v88, v89

    move/from16 v95, v1

    xor-int v1, v89, v3

    not-int v1, v1

    and-int v1, v84, v1

    xor-int v1, v81, v1

    and-int v1, v1, v42

    and-int v81, v36, v52

    and-int v81, v35, v81

    xor-int v88, v88, v81

    xor-int v3, v88, v3

    not-int v3, v3

    and-int v3, v84, v3

    xor-int v81, v52, v81

    xor-int v81, v81, v97

    and-int v81, v84, v81

    xor-int v87, v87, v92

    move/from16 v88, v1

    xor-int v1, v87, v81

    iput v1, v0, Loy1;->c:I

    and-int v10, v53, v10

    and-int v81, v35, v46

    xor-int v26, v26, v72

    move/from16 v72, v1

    and-int v1, v59, v26

    not-int v1, v1

    and-int v1, v84, v1

    move/from16 v26, v1

    xor-int v1, v96, v75

    iput v1, v0, Loy1;->h1:I

    xor-int v68, v52, v68

    xor-int v75, v52, v98

    or-int v87, v52, v63

    xor-int v12, v12, v87

    move/from16 v87, v1

    not-int v1, v12

    and-int v1, v59, v1

    xor-int v1, v83, v1

    not-int v1, v1

    and-int v1, v84, v1

    move/from16 v83, v1

    iget v1, v0, Loy1;->T:I

    move/from16 v89, v3

    not-int v3, v1

    xor-int v12, v12, p2

    xor-int v12, v12, v25

    or-int/2addr v12, v1

    and-int v25, v47, v15

    xor-int v92, v11, v25

    xor-int v36, v36, v52

    xor-int v36, v36, v45

    xor-int v81, v52, v81

    and-int v81, v45, v81

    xor-int v75, v75, v81

    move/from16 v81, v1

    xor-int v1, v75, v89

    not-int v1, v1

    and-int v1, v42, v1

    or-int v43, v52, v43

    xor-int v20, v20, v43

    move/from16 p2, v1

    xor-int v1, v20, v90

    not-int v1, v1

    and-int v1, v84, v1

    or-int v1, v81, v1

    or-int v20, v52, v11

    xor-int v20, v47, v20

    xor-int v20, v20, v65

    xor-int v20, v20, v94

    move/from16 v43, v1

    iget v1, v0, Loy1;->q:I

    xor-int v47, v68, v83

    and-int v47, v47, v3

    xor-int v20, v20, v47

    xor-int v1, v20, v1

    iput v1, v0, Loy1;->q:I

    xor-int v20, v2, v1

    or-int v47, v1, v53

    xor-int v47, v2, v47

    or-int v65, v1, v6

    move/from16 v68, v3

    not-int v3, v1

    and-int v75, v53, v3

    and-int v81, v6, v3

    move/from16 v83, v1

    xor-int v1, v70, v81

    or-int v89, v83, v2

    xor-int v89, v53, v89

    xor-int v90, v73, v65

    xor-int v94, v70, v75

    xor-int v97, v70, v83

    or-int v98, v83, v70

    and-int v3, v70, v3

    xor-int v53, v53, v3

    xor-int v4, v4, v81

    xor-int v3, v70, v3

    xor-int v70, v73, v81

    xor-int v6, v6, v83

    xor-int v34, v63, v34

    move/from16 v81, v3

    and-int v3, v34, v62

    not-int v3, v3

    and-int v3, v84, v3

    and-int v34, v35, v52

    xor-int v34, v52, v34

    move/from16 v62, v3

    and-int v3, v34, v48

    not-int v3, v3

    and-int v3, v84, v3

    move/from16 v34, v3

    xor-int v3, v27, v82

    not-int v3, v3

    and-int v3, v59, v3

    xor-int v3, v92, v3

    xor-int v3, v3, v62

    xor-int v3, v3, v43

    xor-int v3, v3, v64

    iput v3, v0, Loy1;->y2:I

    and-int v3, v52, v46

    and-int v27, v35, v3

    move/from16 v35, v5

    xor-int v5, v96, v27

    iput v5, v0, Loy1;->G1:I

    and-int v27, v3, v45

    move/from16 v43, v5

    xor-int v5, v100, v27

    not-int v5, v5

    and-int v5, v84, v5

    xor-int v5, v36, v5

    xor-int v5, v5, v95

    xor-int v5, v5, v29

    iput v5, v0, Loy1;->s:I

    move/from16 v29, v6

    and-int v6, v5, v9

    xor-int v36, v6, p1

    and-int v46, p1, v6

    xor-int v62, v5, v9

    xor-int v64, v62, p1

    move/from16 v82, v7

    not-int v7, v5

    and-int v83, p1, v7

    and-int/2addr v7, v9

    and-int v92, p1, v7

    move/from16 v95, v5

    xor-int v5, v7, v92

    iput v5, v0, Loy1;->N1:I

    xor-int v5, v10, v98

    move/from16 v92, v8

    xor-int v8, v10, v65

    move/from16 v65, v9

    not-int v9, v7

    and-int v9, p1, v9

    xor-int v96, v7, v55

    move/from16 v98, v9

    and-int v9, v95, v56

    or-int v56, v65, v9

    and-int v99, p1, v56

    xor-int v100, v65, v99

    move/from16 v101, v10

    not-int v10, v9

    and-int v10, p1, v10

    xor-int v55, v9, v55

    and-int v102, p1, v95

    iput v7, v0, Loy1;->b0:I

    xor-int v85, v91, v85

    move/from16 v91, v7

    or-int v7, v95, v65

    iput v7, v0, Loy1;->V0:I

    move/from16 v103, v9

    not-int v9, v7

    and-int v9, p1, v9

    move/from16 v104, v7

    not-int v7, v6

    and-int v7, v65, v7

    not-int v3, v3

    and-int v3, v52, v3

    move/from16 v105, v6

    xor-int v6, v3, v93

    not-int v6, v6

    and-int v6, v45, v6

    xor-int v6, v51, v6

    iput v6, v0, Loy1;->q1:I

    xor-int v6, v6, v30

    iput v6, v0, Loy1;->u2:I

    xor-int v6, v6, p2

    xor-int/2addr v6, v13

    iput v6, v0, Loy1;->b2:I

    not-int v3, v3

    and-int v3, v45, v3

    xor-int v3, v87, v3

    and-int v3, v84, v3

    xor-int v6, v43, v27

    iput v6, v0, Loy1;->p1:I

    xor-int/2addr v3, v6

    not-int v3, v3

    and-int v3, v42, v3

    xor-int v3, v72, v3

    iget v6, v0, Loy1;->Y:I

    xor-int/2addr v3, v6

    iput v3, v0, Loy1;->Y:I

    and-int v3, v52, v48

    xor-int v3, v51, v3

    iput v3, v0, Loy1;->K:I

    xor-int v3, v3, v34

    xor-int v3, v3, v88

    xor-int v3, v3, v60

    iput v3, v0, Loy1;->G:I

    and-int v6, v70, v3

    xor-int v6, v47, v6

    iput v6, v0, Loy1;->w1:I

    and-int v6, v3, v81

    xor-int v6, v29, v6

    iput v6, v0, Loy1;->v2:I

    and-int v6, v3, v2

    xor-int v6, v97, v6

    iput v6, v0, Loy1;->A:I

    not-int v5, v5

    and-int/2addr v5, v3

    xor-int v5, v94, v5

    iput v5, v0, Loy1;->v1:I

    not-int v4, v4

    and-int/2addr v4, v3

    xor-int v4, v53, v4

    iput v4, v0, Loy1;->E0:I

    and-int v4, v101, v3

    xor-int v4, v90, v4

    iput v4, v0, Loy1;->L0:I

    not-int v4, v1

    and-int/2addr v4, v3

    xor-int v4, v58, v4

    iput v4, v0, Loy1;->k:I

    not-int v2, v2

    and-int/2addr v2, v3

    xor-int v2, v89, v2

    iput v2, v0, Loy1;->X:I

    and-int v2, v3, v1

    xor-int v2, v47, v2

    iput v2, v0, Loy1;->D0:I

    and-int v2, v3, v58

    xor-int v2, v47, v2

    iput v2, v0, Loy1;->u0:I

    and-int v2, v75, v3

    iput v2, v0, Loy1;->B2:I

    or-int v2, v3, v20

    iput v2, v0, Loy1;->V:I

    not-int v2, v8

    and-int/2addr v2, v3

    xor-int v2, v73, v2

    iput v2, v0, Loy1;->H0:I

    not-int v2, v3

    and-int/2addr v2, v1

    xor-int/2addr v1, v2

    iput v1, v0, Loy1;->V1:I

    xor-int v1, v78, v76

    xor-int v2, v85, v26

    and-int v1, v1, v32

    xor-int v3, v71, v50

    xor-int v4, v63, v25

    xor-int v5, v4, v59

    and-int v5, v84, v5

    xor-int/2addr v4, v5

    and-int v4, v4, v68

    xor-int/2addr v2, v4

    xor-int v2, v2, v44

    iput v2, v0, Loy1;->w:I

    not-int v4, v2

    and-int v5, p0, v4

    iput v5, v0, Loy1;->y1:I

    xor-int v5, p0, v2

    iput v5, v0, Loy1;->R:I

    and-int v5, v11, v15

    xor-int v5, v23, v5

    not-int v5, v5

    and-int v5, v59, v5

    xor-int v5, v69, v5

    not-int v5, v5

    and-int v5, v84, v5

    xor-int v5, v40, v5

    xor-int/2addr v5, v12

    xor-int v5, v5, v54

    iput v5, v0, Loy1;->e:I

    not-int v6, v5

    and-int v8, v104, v6

    iput v8, v0, Loy1;->z:I

    or-int/2addr v7, v5

    xor-int v7, v95, v7

    iput v7, v0, Loy1;->y0:I

    and-int v7, v95, v6

    xor-int v7, v62, v7

    iput v7, v0, Loy1;->C1:I

    and-int v7, v62, v6

    xor-int v7, v95, v7

    iput v7, v0, Loy1;->I:I

    and-int v7, v65, v6

    xor-int v7, v62, v7

    iput v7, v0, Loy1;->q0:I

    or-int v7, v5, v105

    xor-int v7, v105, v7

    iput v7, v0, Loy1;->p0:I

    or-int v7, v5, v65

    xor-int v7, v95, v7

    iput v7, v0, Loy1;->o:I

    and-int v7, v91, v6

    xor-int v7, v62, v7

    iput v7, v0, Loy1;->F2:I

    or-int v7, v5, v62

    iput v7, v0, Loy1;->O1:I

    or-int v5, v5, v104

    xor-int v5, v62, v5

    iput v5, v0, Loy1;->l2:I

    and-int v5, v105, v6

    xor-int v5, v103, v5

    iput v5, v0, Loy1;->J0:I

    xor-int v5, v37, v74

    or-int v5, v79, v5

    xor-int v6, v19, v50

    and-int/2addr v6, v13

    xor-int v6, v86, v6

    or-int v6, v79, v6

    and-int v7, v19, v49

    xor-int v7, v80, v7

    xor-int v7, v7, v24

    xor-int/2addr v6, v7

    and-int v6, v18, v6

    iput v6, v0, Loy1;->G2:I

    and-int v6, v80, v31

    iput v6, v0, Loy1;->n1:I

    and-int v7, v6, v49

    xor-int v7, v77, v7

    and-int/2addr v7, v13

    xor-int v7, v78, v7

    xor-int/2addr v5, v7

    not-int v5, v5

    and-int v5, v18, v5

    xor-int v6, v6, v17

    not-int v6, v6

    and-int/2addr v6, v13

    iget v7, v0, Loy1;->r2:I

    xor-int/2addr v3, v6

    xor-int/2addr v1, v3

    xor-int/2addr v1, v5

    xor-int/2addr v1, v7

    iput v1, v0, Loy1;->r2:I

    xor-int v3, v1, v39

    and-int v3, v3, v92

    or-int v5, v16, v1

    not-int v6, v1

    and-int v7, v28, v6

    and-int v8, v38, v7

    and-int v11, v28, v1

    not-int v12, v11

    and-int v13, v38, v12

    and-int v15, v13, v92

    and-int v17, v38, v11

    and-int/2addr v12, v1

    move/from16 p2, v1

    not-int v1, v12

    and-int v1, v38, v1

    xor-int/2addr v12, v13

    or-int v12, v16, v12

    xor-int v11, v11, v38

    xor-int/2addr v15, v11

    or-int v15, v66, v15

    iput v15, v0, Loy1;->r1:I

    xor-int v15, v104, v98

    xor-int v10, v104, v10

    xor-int v18, v62, v83

    xor-int v13, v28, v13

    or-int v13, v16, v13

    or-int v19, v28, p2

    move/from16 v20, v1

    and-int v1, v19, v6

    move/from16 v23, v2

    not-int v2, v1

    and-int v2, v38, v2

    move/from16 v24, v1

    or-int v1, v16, v24

    iput v1, v0, Loy1;->f1:I

    xor-int v1, v24, v8

    xor-int/2addr v1, v5

    iput v1, v0, Loy1;->H2:I

    and-int v1, v38, v19

    xor-int v1, p2, v1

    not-int v1, v1

    and-int v1, v16, v1

    xor-int v5, v19, v39

    iput v5, v0, Loy1;->h0:I

    xor-int/2addr v2, v7

    xor-int v7, v11, v13

    xor-int v8, v105, v99

    xor-int v11, v56, v83

    xor-int v13, v103, v83

    xor-int v24, v91, v46

    xor-int v25, v91, v98

    xor-int/2addr v5, v12

    and-int v5, v5, v57

    xor-int/2addr v5, v7

    iput v5, v0, Loy1;->C:I

    and-int v5, v38, v6

    iput v5, v0, Loy1;->e1:I

    and-int v5, v22, v6

    xor-int v5, v35, v5

    xor-int v5, v5, v61

    iput v5, v0, Loy1;->s0:I

    and-int v5, v21, p2

    xor-int v5, v82, v5

    xor-int/2addr v5, v14

    iput v5, v0, Loy1;->a0:I

    or-int v6, v11, v5

    xor-int v6, v55, v6

    iput v6, v0, Loy1;->Q1:I

    not-int v6, v5

    and-int v7, v18, v6

    xor-int v7, v96, v7

    iput v7, v0, Loy1;->m1:I

    and-int v7, v5, v36

    iput v7, v0, Loy1;->I2:I

    or-int v7, v36, v5

    xor-int/2addr v7, v15

    iput v7, v0, Loy1;->U1:I

    and-int v7, p1, v6

    xor-int/2addr v7, v11

    iput v7, v0, Loy1;->K0:I

    xor-int v7, v24, v5

    iput v7, v0, Loy1;->q2:I

    and-int v7, v5, v8

    iput v7, v0, Loy1;->c2:I

    and-int v7, v13, v6

    xor-int/2addr v7, v10

    iput v7, v0, Loy1;->E1:I

    and-int v7, v5, v25

    xor-int v7, v64, v7

    iput v7, v0, Loy1;->O:I

    or-int v7, v67, v5

    xor-int/2addr v7, v9

    iput v7, v0, Loy1;->C2:I

    or-int v5, v100, v5

    xor-int v5, v25, v5

    iput v5, v0, Loy1;->t2:I

    and-int v5, v65, v6

    xor-int v5, v64, v5

    iput v5, v0, Loy1;->A0:I

    and-int v5, v102, v6

    xor-int v5, v62, v5

    iput v5, v0, Loy1;->Y0:I

    xor-int v5, p2, v41

    iput v5, v0, Loy1;->W1:I

    and-int v5, v38, p2

    iput v5, v0, Loy1;->X1:I

    xor-int v5, v28, p2

    iput v5, v0, Loy1;->D:I

    and-int v6, v5, v16

    xor-int/2addr v6, v2

    and-int v6, v6, v57

    not-int v7, v5

    and-int v7, v38, v7

    xor-int/2addr v7, v5

    or-int v7, v16, v7

    xor-int v8, v19, v7

    or-int v8, v66, v8

    xor-int v7, v17, v7

    or-int v7, v66, v7

    iget v9, v0, Loy1;->S1:I

    xor-int/2addr v2, v7

    or-int/2addr v2, v9

    iput v2, v0, Loy1;->B0:I

    xor-int v2, v5, v20

    xor-int/2addr v2, v3

    xor-int/2addr v2, v6

    or-int/2addr v2, v9

    xor-int v3, v5, v38

    iput v3, v0, Loy1;->E2:I

    xor-int/2addr v1, v3

    xor-int/2addr v1, v8

    xor-int/2addr v1, v2

    xor-int v1, v1, v33

    iput v1, v0, Loy1;->g:I

    and-int v2, v1, v4

    iput v2, v0, Loy1;->T0:I

    not-int v3, v1

    and-int v3, p0, v3

    not-int v3, v3

    and-int v3, p0, v3

    iput v3, v0, Loy1;->j0:I

    xor-int v4, v3, v23

    iput v4, v0, Loy1;->j1:I

    or-int v3, v23, v3

    iput v3, v0, Loy1;->g1:I

    and-int v3, v1, p0

    iput v3, v0, Loy1;->J2:I

    xor-int/2addr v2, v3

    iput v2, v0, Loy1;->M1:I

    or-int v2, v23, v1

    xor-int/2addr v1, v2

    iput v1, v0, Loy1;->C0:I

    xor-int v1, p0, v2

    iput v1, v0, Loy1;->u1:I

    xor-int v1, v3, v2

    iput v1, v0, Loy1;->F1:I

    return-void

    :pswitch_0
    invoke-direct/range {p0 .. p2}, Lbr3;->a([B[B)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
