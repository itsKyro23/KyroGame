.class public final synthetic La31;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Le31;

.field public final synthetic j:I


# direct methods
.method public synthetic constructor <init>(Le31;II)V
    .locals 0

    iput p3, p0, La31;->h:I

    iput-object p1, p0, La31;->i:Le31;

    iput p2, p0, La31;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget p1, p0, La31;->h:I

    iget v0, p0, La31;->j:I

    iget-object p0, p0, La31;->i:Le31;

    packed-switch p1, :pswitch_data_0

    invoke-virtual {p0, v0}, Le31;->g(I)V

    return-void

    :pswitch_0
    invoke-virtual {p0}, Le31;->d()Z

    move-result p1

    if-eqz p1, :cond_5

    iget-boolean p1, p0, Le31;->d0:Z

    if-eqz p1, :cond_0

    goto :goto_1

    :cond_0
    iget p1, p0, Le31;->a0:I

    if-ne v0, p1, :cond_1

    goto :goto_1

    :cond_1
    iput v0, p0, Le31;->a0:I

    sget-object p1, Le31;->p0:[[I

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ge v0, v1, :cond_4

    aget-object p1, p1, v0

    const/4 v0, 0x0

    aget v1, p1, v0

    iput v1, p0, Le31;->b0:I

    aget v1, p1, v2

    if-ne v1, v2, :cond_2

    move v1, v2

    goto :goto_0

    :cond_2
    move v1, v0

    :goto_0
    iput-boolean v1, p0, Le31;->Y:Z

    const/4 v1, 0x2

    aget p1, p1, v1

    if-ne p1, v2, :cond_3

    move v0, v2

    :cond_3
    iput-boolean v0, p0, Le31;->Z:Z

    :cond_4
    invoke-virtual {p0, v2}, Le31;->i(Z)V

    :cond_5
    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
