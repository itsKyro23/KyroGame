.class Landroidx/lifecycle/LiveData$LifecycleBoundObserver;
.super Lua0;
.source "SourceFile"

# interfaces
.implements Lh90;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lua0;",
        "Lh90;"
    }
.end annotation


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public final c()V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public final d()Z
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
