.class public final Landroidx/lifecycle/LegacySavedStateHandleController$tryToAddRecreator$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    sget-object p0, Ld90;->ON_START:Ld90;

    if-eq p2, p0, :cond_0

    return-void

    :cond_0
    const/4 p0, 0x0

    throw p0
.end method
