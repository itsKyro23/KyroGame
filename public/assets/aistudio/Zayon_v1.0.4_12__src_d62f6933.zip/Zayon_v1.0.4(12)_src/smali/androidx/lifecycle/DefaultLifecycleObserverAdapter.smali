.class public final Landroidx/lifecycle/DefaultLifecycleObserverAdapter;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public final h:Luo;

.field public final i:Lh90;


# direct methods
.method public constructor <init>(Luo;Lh90;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->h:Luo;

    iput-object p2, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->i:Lh90;

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 2

    sget-object v0, Lvo;->a:[I

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    const/4 v1, 0x7

    if-eq v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "ON_ANY must not been send by anybody"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void

    :cond_1
    iget-object v0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->h:Luo;

    invoke-interface {v0}, Luo;->onResume()V

    :goto_0
    iget-object p0, p0, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;->i:Lh90;

    if-eqz p0, :cond_2

    invoke-interface {p0, p1, p2}, Lh90;->b(Lk90;Ld90;)V

    :cond_2
    return-void
.end method
