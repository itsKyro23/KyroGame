.class public Landroidx/lifecycle/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final k:Ljava/lang/Object;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Lbv0;

.field public c:I

.field public d:Z

.field public volatile e:Ljava/lang/Object;

.field public volatile f:Ljava/lang/Object;

.field public g:I

.field public h:Z

.field public i:Z

.field public final j:Ls1;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Landroidx/lifecycle/b;->k:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/b;->a:Ljava/lang/Object;

    new-instance v0, Lbv0;

    invoke-direct {v0}, Lbv0;-><init>()V

    iput-object v0, p0, Landroidx/lifecycle/b;->b:Lbv0;

    const/4 v0, 0x0

    iput v0, p0, Landroidx/lifecycle/b;->c:I

    sget-object v0, Landroidx/lifecycle/b;->k:Ljava/lang/Object;

    iput-object v0, p0, Landroidx/lifecycle/b;->f:Ljava/lang/Object;

    new-instance v1, Ls1;

    const/16 v2, 0xd

    invoke-direct {v1, v2, p0}, Ls1;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Landroidx/lifecycle/b;->j:Ls1;

    iput-object v0, p0, Landroidx/lifecycle/b;->e:Ljava/lang/Object;

    const/4 v0, -0x1

    iput v0, p0, Landroidx/lifecycle/b;->g:I

    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .locals 2

    invoke-static {}, Li9;->H()Li9;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    if-ne v0, v1, :cond_0

    return-void

    :cond_0
    const-string v0, "Cannot invoke "

    const-string v1, " on a background thread"

    invoke-static {v0, p0, v1}, Loj;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final b(Lua0;)V
    .locals 2

    iget-boolean v0, p1, Lua0;->i:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lua0;->d()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 p0, 0x0

    invoke-virtual {p1, p0}, Lua0;->a(Z)V

    return-void

    :cond_1
    iget v0, p1, Lua0;->j:I

    iget v1, p0, Landroidx/lifecycle/b;->g:I

    if-lt v0, v1, :cond_2

    goto :goto_0

    :cond_2
    iput v1, p1, Lua0;->j:I

    iget-object p1, p1, Lua0;->h:Lxy1;

    iget-object p0, p0, Landroidx/lifecycle/b;->e:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lk90;

    iget-object p1, p1, Lxy1;->i:Ljava/lang/Object;

    check-cast p1, Lpq;

    if-eqz p0, :cond_5

    iget-boolean p0, p1, Lpq;->h0:Z

    if-eqz p0, :cond_5

    invoke-virtual {p1}, Lrx;->J()Landroid/view/View;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-nez v0, :cond_4

    iget-object v0, p1, Lpq;->l0:Landroid/app/Dialog;

    if-eqz v0, :cond_5

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p1, Lpq;->l0:Landroid/app/Dialog;

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_3
    iget-object p1, p1, Lpq;->l0:Landroid/app/Dialog;

    invoke-virtual {p1, p0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    return-void

    :cond_4
    const-string p0, "DialogFragment can not be attached to a container view"

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    :cond_5
    :goto_0
    return-void
.end method

.method public final c(Lua0;)V
    .locals 4

    iget-boolean v0, p0, Landroidx/lifecycle/b;->h:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iput-boolean v1, p0, Landroidx/lifecycle/b;->i:Z

    return-void

    :cond_0
    iput-boolean v1, p0, Landroidx/lifecycle/b;->h:Z

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/lifecycle/b;->i:Z

    if-eqz p1, :cond_2

    invoke-virtual {p0, p1}, Landroidx/lifecycle/b;->b(Lua0;)V

    const/4 p1, 0x0

    goto :goto_0

    :cond_2
    iget-object v1, p0, Landroidx/lifecycle/b;->b:Lbv0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lzu0;

    invoke-direct {v2, v1}, Lzu0;-><init>(Lbv0;)V

    iget-object v1, v1, Lbv0;->j:Ljava/util/WeakHashMap;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v2, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    invoke-virtual {v2}, Lzu0;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {v2}, Lzu0;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lua0;

    invoke-virtual {p0, v1}, Landroidx/lifecycle/b;->b(Lua0;)V

    iget-boolean v1, p0, Landroidx/lifecycle/b;->i:Z

    if-eqz v1, :cond_3

    :cond_4
    :goto_0
    iget-boolean v1, p0, Landroidx/lifecycle/b;->i:Z

    if-nez v1, :cond_1

    iput-boolean v0, p0, Landroidx/lifecycle/b;->h:Z

    return-void
.end method

.method public final d(Lxy1;)V
    .locals 3

    const-string v0, "observeForever"

    invoke-static {v0}, Landroidx/lifecycle/b;->a(Ljava/lang/String;)V

    new-instance v0, Lta0;

    invoke-direct {v0, p0, p1}, Lua0;-><init>(Landroidx/lifecycle/b;Lxy1;)V

    iget-object p0, p0, Landroidx/lifecycle/b;->b:Lbv0;

    invoke-virtual {p0, p1}, Lbv0;->b(Ljava/lang/Object;)Lyu0;

    move-result-object v1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    iget-object p0, v1, Lyu0;->i:Ljava/lang/Object;

    goto :goto_1

    :cond_0
    new-instance v1, Lyu0;

    invoke-direct {v1, p1, v0}, Lyu0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iget p1, p0, Lbv0;->k:I

    add-int/2addr p1, v2

    iput p1, p0, Lbv0;->k:I

    iget-object p1, p0, Lbv0;->i:Lyu0;

    if-nez p1, :cond_1

    iput-object v1, p0, Lbv0;->h:Lyu0;

    iput-object v1, p0, Lbv0;->i:Lyu0;

    goto :goto_0

    :cond_1
    iput-object v1, p1, Lyu0;->j:Lyu0;

    iput-object p1, v1, Lyu0;->k:Lyu0;

    iput-object v1, p0, Lbv0;->i:Lyu0;

    :goto_0
    const/4 p0, 0x0

    :goto_1
    check-cast p0, Lua0;

    instance-of p1, p0, Landroidx/lifecycle/LiveData$LifecycleBoundObserver;

    if-nez p1, :cond_3

    if-eqz p0, :cond_2

    return-void

    :cond_2
    invoke-virtual {v0, v2}, Lua0;->a(Z)V

    return-void

    :cond_3
    const-string p0, "Cannot add the same observer with different lifecycles"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method

.method public final e(Ljava/lang/Object;)V
    .locals 1

    const-string v0, "setValue"

    invoke-static {v0}, Landroidx/lifecycle/b;->a(Ljava/lang/String;)V

    iget v0, p0, Landroidx/lifecycle/b;->g:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/lifecycle/b;->g:I

    iput-object p1, p0, Landroidx/lifecycle/b;->e:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroidx/lifecycle/b;->c(Lua0;)V

    return-void
.end method
