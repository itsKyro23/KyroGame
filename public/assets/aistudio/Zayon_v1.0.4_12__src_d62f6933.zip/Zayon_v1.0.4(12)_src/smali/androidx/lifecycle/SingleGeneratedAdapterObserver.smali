.class public final Landroidx/lifecycle/SingleGeneratedAdapterObserver;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
