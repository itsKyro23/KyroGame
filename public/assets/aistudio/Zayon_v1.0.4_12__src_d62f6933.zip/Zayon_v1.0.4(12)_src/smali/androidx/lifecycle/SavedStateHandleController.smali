.class public final Landroidx/lifecycle/SavedStateHandleController;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public h:Z


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 1

    sget-object v0, Ld90;->ON_DESTROY:Ld90;

    if-ne p2, v0, :cond_0

    const/4 p2, 0x0

    iput-boolean p2, p0, Landroidx/lifecycle/SavedStateHandleController;->h:Z

    invoke-interface {p1}, Lk90;->e()Landroidx/lifecycle/a;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroidx/lifecycle/a;->f(Lj90;)V

    :cond_0
    return-void
.end method
