.class public final Landroidx/lifecycle/LifecycleCoroutineScopeImpl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;
.implements Lak;


# virtual methods
.method public final a()Lsj;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public final b(Lk90;Ld90;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
