.class Landroidx/activity/ComponentActivity$5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public final synthetic h:Landroidx/activity/a;


# direct methods
.method public constructor <init>(Landroidx/activity/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/ComponentActivity$5;->h:Landroidx/activity/a;

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    iget-object p1, p0, Landroidx/activity/ComponentActivity$5;->h:Landroidx/activity/a;

    iget-object p2, p1, Landroidx/activity/a;->m:Ly71;

    if-nez p2, :cond_1

    invoke-virtual {p1}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lih;

    if-eqz p2, :cond_0

    iget-object p2, p2, Lih;->a:Ly71;

    iput-object p2, p1, Landroidx/activity/a;->m:Ly71;

    :cond_0
    iget-object p2, p1, Landroidx/activity/a;->m:Ly71;

    if-nez p2, :cond_1

    new-instance p2, Ly71;

    invoke-direct {p2}, Ly71;-><init>()V

    iput-object p2, p1, Landroidx/activity/a;->m:Ly71;

    :cond_1
    iget-object p1, p1, Landroidx/activity/a;->k:Landroidx/lifecycle/a;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/a;->f(Lj90;)V

    return-void
.end method
