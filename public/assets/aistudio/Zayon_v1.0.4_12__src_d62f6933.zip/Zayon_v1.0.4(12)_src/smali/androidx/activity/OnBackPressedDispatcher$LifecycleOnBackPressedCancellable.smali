.class final Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;
.implements Lee;


# instance fields
.field public final h:Landroidx/lifecycle/a;

.field public final i:Lzx;

.field public j:Lzi0;

.field public final synthetic k:Landroidx/activity/b;


# direct methods
.method public constructor <init>(Landroidx/activity/b;Landroidx/lifecycle/a;Lzx;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->k:Landroidx/activity/b;

    iput-object p2, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->h:Landroidx/lifecycle/a;

    iput-object p3, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->i:Lzx;

    invoke-virtual {p2, p0}, Landroidx/lifecycle/a;->a(Lj90;)V

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 3

    sget-object p1, Ld90;->ON_START:Ld90;

    if-ne p2, p1, :cond_1

    iget-object p1, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->k:Landroidx/activity/b;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p2, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->i:Lzx;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Landroidx/activity/b;->b:Lj9;

    invoke-virtual {v0, p2}, Lj9;->addLast(Ljava/lang/Object;)V

    new-instance v0, Lzi0;

    invoke-direct {v0, p1, p2}, Lzi0;-><init>(Landroidx/activity/b;Lzx;)V

    iget-object v1, p2, Lzx;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x21

    if-lt v1, v2, :cond_0

    invoke-virtual {p1}, Landroidx/activity/b;->c()V

    iget-object p1, p1, Landroidx/activity/b;->c:Lxi0;

    iput-object p1, p2, Lzx;->c:Lxi0;

    :cond_0
    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->j:Lzi0;

    return-void

    :cond_1
    sget-object p1, Ld90;->ON_STOP:Ld90;

    if-ne p2, p1, :cond_2

    iget-object p0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->j:Lzi0;

    if-eqz p0, :cond_3

    invoke-virtual {p0}, Lzi0;->cancel()V

    return-void

    :cond_2
    sget-object p1, Ld90;->ON_DESTROY:Ld90;

    if-ne p2, p1, :cond_3

    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->cancel()V

    :cond_3
    return-void
.end method

.method public final cancel()V
    .locals 1

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->h:Landroidx/lifecycle/a;

    invoke-virtual {v0, p0}, Landroidx/lifecycle/a;->f(Lj90;)V

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->i:Lzx;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lzx;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->j:Lzi0;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lzi0;->cancel()V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;->j:Lzi0;

    return-void
.end method
