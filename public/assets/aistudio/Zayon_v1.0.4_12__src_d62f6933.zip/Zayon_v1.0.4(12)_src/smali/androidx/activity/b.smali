.class public final Landroidx/activity/b;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Lj9;

.field public final c:Lxi0;

.field public final d:Landroid/window/OnBackInvokedCallback;

.field public e:Landroid/window/OnBackInvokedDispatcher;

.field public f:Z


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/b;->a:Ljava/lang/Runnable;

    new-instance p1, Lj9;

    invoke-direct {p1}, Lj9;-><init>()V

    iput-object p1, p0, Landroidx/activity/b;->b:Lj9;

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p1, v0, :cond_0

    new-instance p1, Lxi0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lxi0;-><init>(Landroidx/activity/b;I)V

    iput-object p1, p0, Landroidx/activity/b;->c:Lxi0;

    new-instance p1, Lxi0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v0}, Lxi0;-><init>(Landroidx/activity/b;I)V

    sget-object v0, Lyi0;->a:Lyi0;

    invoke-virtual {v0, p1}, Lyi0;->a(Lzy;)Landroid/window/OnBackInvokedCallback;

    move-result-object p1

    iput-object p1, p0, Landroidx/activity/b;->d:Landroid/window/OnBackInvokedCallback;

    :cond_0
    return-void
.end method


# virtual methods
.method public final a(Lk90;Lzx;)V
    .locals 2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Lk90;->e()Landroidx/lifecycle/a;

    move-result-object p1

    iget-object v0, p1, Landroidx/lifecycle/a;->b:Le90;

    sget-object v1, Le90;->h:Le90;

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;

    invoke-direct {v0, p0, p1, p2}, Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;-><init>(Landroidx/activity/b;Landroidx/lifecycle/a;Lzx;)V

    iget-object p1, p2, Lzx;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {p1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p1, v0, :cond_1

    invoke-virtual {p0}, Landroidx/activity/b;->c()V

    iget-object p0, p0, Landroidx/activity/b;->c:Lxi0;

    iput-object p0, p2, Lzx;->c:Lxi0;

    :cond_1
    :goto_0
    return-void
.end method

.method public final b()V
    .locals 5

    iget-object v0, p0, Landroidx/activity/b;->b:Lj9;

    iget v1, v0, Lj9;->j:I

    invoke-virtual {v0, v1}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lzx;

    iget-boolean v2, v2, Lzx;->a:Z

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    check-cast v1, Lzx;

    if-eqz v1, :cond_c

    iget p0, v1, Lzx;->d:I

    const/4 v0, 0x1

    packed-switch p0, :pswitch_data_0

    iget-object p0, v1, Lzx;->e:Ljava/lang/Object;

    check-cast p0, Lcom/zayon/optimize/MainActivity;

    iget-object v2, p0, Lcom/zayon/optimize/MainActivity;->F:Lmm0;

    if-eqz v2, :cond_2

    iget-boolean v2, v2, Lmm0;->z:Z

    if-eqz v2, :cond_2

    goto/16 :goto_1

    :cond_2
    iget-object v2, p0, Lcom/zayon/optimize/MainActivity;->G:Lcx0;

    if-eqz v2, :cond_4

    iget-boolean v3, v2, Lcx0;->L:Z

    if-eqz v3, :cond_4

    iget-object p0, v2, Lcx0;->K:Landroid/view/View;

    iget-object v0, v2, Lcx0;->l:Landroid/view/View;

    if-eq p0, v0, :cond_3

    invoke-virtual {v2, v0}, Lcx0;->j(Landroid/view/View;)V

    goto :goto_1

    :cond_3
    invoke-virtual {v2}, Lcx0;->f()V

    goto :goto_1

    :cond_4
    iget-object v2, p0, Lcom/zayon/optimize/MainActivity;->T:Lsf0;

    if-eqz v2, :cond_5

    iget-boolean v3, v2, Lsf0;->M:Z

    if-eqz v3, :cond_5

    invoke-virtual {v2}, Lsf0;->b()V

    goto :goto_1

    :cond_5
    iget-object v2, p0, Lcom/zayon/optimize/MainActivity;->S:Lm70;

    if-eqz v2, :cond_6

    iget v3, v2, Lm70;->l:I

    if-ne v3, v0, :cond_6

    invoke-virtual {v2}, Lm70;->d()V

    goto :goto_1

    :cond_6
    if-eqz v2, :cond_7

    iget v2, v2, Lm70;->l:I

    const/4 v3, 0x2

    if-ne v2, v3, :cond_7

    goto :goto_1

    :cond_7
    iget-boolean v2, p0, Lcom/zayon/optimize/MainActivity;->I:Z

    const/4 v3, 0x0

    if-eqz v2, :cond_9

    if-nez v2, :cond_8

    goto :goto_1

    :cond_8
    invoke-virtual {p0, v3}, Lcom/zayon/optimize/MainActivity;->J(Z)V

    goto :goto_1

    :cond_9
    iget-object v2, p0, Lcom/zayon/optimize/MainActivity;->Z:Ljava/lang/String;

    const-string v4, "home"

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    invoke-virtual {p0, v4}, Lcom/zayon/optimize/MainActivity;->A(Ljava/lang/String;)V

    goto :goto_1

    :cond_a
    invoke-virtual {v1, v3}, Lzx;->a(Z)V

    iget-object p0, p0, Landroidx/activity/a;->n:Landroidx/activity/b;

    invoke-virtual {p0}, Landroidx/activity/b;->b()V

    invoke-virtual {v1, v0}, Lzx;->a(Z)V

    goto :goto_1

    :pswitch_0
    iget-object p0, v1, Lzx;->e:Ljava/lang/Object;

    check-cast p0, Lhy;

    invoke-virtual {p0, v0}, Lhy;->x(Z)Z

    iget-object v0, p0, Lhy;->h:Lzx;

    iget-boolean v0, v0, Lzx;->a:Z

    if-eqz v0, :cond_b

    invoke-virtual {p0}, Lhy;->N()Z

    goto :goto_1

    :cond_b
    iget-object p0, p0, Lhy;->g:Landroidx/activity/b;

    invoke-virtual {p0}, Landroidx/activity/b;->b()V

    :goto_1
    return-void

    :cond_c
    iget-object p0, p0, Landroidx/activity/b;->a:Ljava/lang/Runnable;

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final c()V
    .locals 7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object v2, p0, Landroidx/activity/b;->b:Lj9;

    if-eqz v2, :cond_1

    invoke-virtual {v2}, Lj9;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    :cond_0
    move v2, v1

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, Ljava/util/AbstractList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lzx;

    iget-boolean v3, v3, Lzx;->a:Z

    if-eqz v3, :cond_2

    move v2, v0

    :goto_0
    iget-object v3, p0, Landroidx/activity/b;->e:Landroid/window/OnBackInvokedDispatcher;

    iget-object v4, p0, Landroidx/activity/b;->d:Landroid/window/OnBackInvokedCallback;

    if-eqz v3, :cond_4

    if-eqz v4, :cond_4

    sget-object v5, Lyi0;->a:Lyi0;

    if-eqz v2, :cond_3

    iget-boolean v6, p0, Landroidx/activity/b;->f:Z

    if-nez v6, :cond_3

    invoke-virtual {v5, v3, v1, v4}, Lyi0;->b(Ljava/lang/Object;ILjava/lang/Object;)V

    iput-boolean v0, p0, Landroidx/activity/b;->f:Z

    return-void

    :cond_3
    if-nez v2, :cond_4

    iget-boolean v0, p0, Landroidx/activity/b;->f:Z

    if-eqz v0, :cond_4

    invoke-virtual {v5, v3, v4}, Lyi0;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-boolean v1, p0, Landroidx/activity/b;->f:Z

    :cond_4
    return-void
.end method
