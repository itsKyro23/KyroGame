.class Landroidx/activity/result/ActivityResultRegistry$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:Lq3;

.field public final synthetic j:Lbo;

.field public final synthetic k:Landroidx/activity/result/a;


# direct methods
.method public constructor <init>(Landroidx/activity/result/a;Ljava/lang/String;Lq3;Lbo;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/result/ActivityResultRegistry$1;->k:Landroidx/activity/result/a;

    iput-object p2, p0, Landroidx/activity/result/ActivityResultRegistry$1;->h:Ljava/lang/String;

    iput-object p3, p0, Landroidx/activity/result/ActivityResultRegistry$1;->i:Lq3;

    iput-object p4, p0, Landroidx/activity/result/ActivityResultRegistry$1;->j:Lbo;

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 4

    sget-object p1, Ld90;->ON_START:Ld90;

    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    iget-object v0, p0, Landroidx/activity/result/ActivityResultRegistry$1;->h:Ljava/lang/String;

    iget-object v1, p0, Landroidx/activity/result/ActivityResultRegistry$1;->k:Landroidx/activity/result/a;

    if-eqz p1, :cond_1

    iget-object p1, v1, Landroidx/activity/result/a;->f:Ljava/util/HashMap;

    iget-object p2, v1, Landroidx/activity/result/a;->h:Landroid/os/Bundle;

    iget-object v1, v1, Landroidx/activity/result/a;->g:Ljava/util/HashMap;

    new-instance v2, Lv3;

    iget-object v3, p0, Landroidx/activity/result/ActivityResultRegistry$1;->i:Lq3;

    iget-object p0, p0, Landroidx/activity/result/ActivityResultRegistry$1;->j:Lbo;

    invoke-direct {v2, v3, p0}, Lv3;-><init>(Lq3;Lbo;)V

    invoke-virtual {p1, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v1, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v3, p1}, Lq3;->A(Ljava/lang/Object;)V

    :cond_0
    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Lp3;

    if-eqz p1, :cond_3

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    iget p2, p1, Lp3;->h:I

    iget-object p1, p1, Lp3;->i:Landroid/content/Intent;

    invoke-virtual {p0, p1, p2}, Lbo;->i(Landroid/content/Intent;I)Ljava/lang/Object;

    move-result-object p0

    invoke-interface {v3, p0}, Lq3;->A(Ljava/lang/Object;)V

    return-void

    :cond_1
    sget-object p0, Ld90;->ON_STOP:Ld90;

    invoke-virtual {p0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    iget-object p0, v1, Landroidx/activity/result/a;->f:Ljava/util/HashMap;

    invoke-virtual {p0, v0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_2
    sget-object p0, Ld90;->ON_DESTROY:Ld90;

    invoke-virtual {p0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-virtual {v1, v0}, Landroidx/activity/result/a;->f(Ljava/lang/String;)V

    :cond_3
    return-void
.end method
