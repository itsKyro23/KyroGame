.class Landroidx/activity/ComponentActivity$4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public final synthetic h:Landroidx/activity/a;


# direct methods
.method public constructor <init>(Landroidx/activity/a;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/activity/ComponentActivity$4;->h:Landroidx/activity/a;

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    sget-object p1, Ld90;->ON_DESTROY:Ld90;

    if-ne p2, p1, :cond_0

    iget-object p1, p0, Landroidx/activity/ComponentActivity$4;->h:Landroidx/activity/a;

    iget-object p1, p1, Landroidx/activity/a;->i:Lgj;

    const/4 p2, 0x0

    iput-object p2, p1, Lgj;->h:Ljava/lang/Object;

    iget-object p1, p0, Landroidx/activity/ComponentActivity$4;->h:Landroidx/activity/a;

    invoke-virtual {p1}, Landroid/app/Activity;->isChangingConfigurations()Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p0, p0, Landroidx/activity/ComponentActivity$4;->h:Landroidx/activity/a;

    invoke-virtual {p0}, Landroidx/activity/a;->d()Ly71;

    move-result-object p0

    invoke-virtual {p0}, Ly71;->a()V

    :cond_0
    return-void
.end method
