.class public Landroidx/work/impl/diagnostics/DiagnosticsReceiver;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "DiagnosticsRcvr"

    invoke-static {v0}, Llb0;->f(Ljava/lang/String;)Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    if-nez p2, :cond_0

    return-void

    :cond_0
    invoke-static {}, Llb0;->c()Llb0;

    move-result-object p0

    const/4 p2, 0x0

    new-array v0, p2, [Ljava/lang/Throwable;

    invoke-virtual {p0, v0}, Llb0;->a([Ljava/lang/Throwable;)V

    :try_start_0
    invoke-static {p1}, Lta1;->b(Landroid/content/Context;)Lta1;

    move-result-object p0

    const-class p1, Landroidx/work/impl/workers/DiagnosticsWorker;

    new-instance v0, Loo4;

    invoke-direct {v0, p1}, Loo4;-><init>(Ljava/lang/Class;)V

    invoke-virtual {v0}, Loo4;->f()Lkj0;

    move-result-object p1

    invoke-virtual {p0, p1}, Lta1;->a(Lkj0;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p0

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object p1

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Throwable;

    aput-object p0, v0, p2

    invoke-virtual {p1, v0}, Llb0;->b([Ljava/lang/Throwable;)V

    return-void
.end method
