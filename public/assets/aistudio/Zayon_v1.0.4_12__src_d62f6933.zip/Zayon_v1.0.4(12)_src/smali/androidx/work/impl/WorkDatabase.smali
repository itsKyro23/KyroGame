.class public abstract Landroidx/work/impl/WorkDatabase;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public volatile a:Lty;

.field public b:Ljava/util/concurrent/Executor;

.field public c:Lg11;

.field public final d:Lt60;

.field public e:Z

.field public f:Z

.field public g:Ljava/util/List;

.field public final h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

.field public final i:Ljava/lang/ThreadLocal;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    iput-object v0, p0, Landroidx/work/impl/WorkDatabase;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    iput-object v0, p0, Landroidx/work/impl/WorkDatabase;->i:Ljava/lang/ThreadLocal;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->d()Lt60;

    move-result-object v0

    iput-object v0, p0, Landroidx/work/impl/WorkDatabase;->d:Lt60;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 1

    iget-boolean p0, p0, Landroidx/work/impl/WorkDatabase;->e:Z

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p0

    invoke-virtual {p0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object p0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    if-eq p0, v0, :cond_1

    :goto_0
    return-void

    :cond_1
    const-string p0, "Cannot access database on the main thread since it may potentially lock the UI for a long period of time."

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final b()V
    .locals 1

    iget-object v0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {v0}, Lg11;->c()Lty;

    move-result-object v0

    iget-object v0, v0, Lty;->i:Ljava/lang/Object;

    check-cast v0, Landroid/database/sqlite/SQLiteDatabase;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object p0, p0, Landroidx/work/impl/WorkDatabase;->i:Ljava/lang/ThreadLocal;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "Cannot access database on a different coroutine context inherited from a suspending transaction."

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final c()V
    .locals 1

    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->a()V

    iget-object v0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {v0}, Lg11;->c()Lty;

    move-result-object v0

    iget-object p0, p0, Landroidx/work/impl/WorkDatabase;->d:Lt60;

    invoke-virtual {p0, v0}, Lt60;->c(Lty;)V

    invoke-virtual {v0}, Lty;->a()V

    return-void
.end method

.method public abstract d()Lt60;
.end method

.method public abstract e(Lzn;)Lg11;
.end method

.method public abstract f()Lsf2;
.end method

.method public final g()V
    .locals 3

    iget-object v0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {v0}, Lg11;->c()Lty;

    move-result-object v0

    invoke-virtual {v0}, Lty;->h()V

    iget-object v0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {v0}, Lg11;->c()Lty;

    move-result-object v0

    iget-object v0, v0, Lty;->i:Ljava/lang/Object;

    check-cast v0, Landroid/database/sqlite/SQLiteDatabase;

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteDatabase;->inTransaction()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Landroidx/work/impl/WorkDatabase;->d:Lt60;

    iget-object v0, p0, Lt60;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lt60;->c:Landroidx/work/impl/WorkDatabase_Impl;

    iget-object v0, v0, Landroidx/work/impl/WorkDatabase;->b:Ljava/util/concurrent/Executor;

    iget-object p0, p0, Lt60;->i:Ls1;

    invoke-interface {v0, p0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method public abstract h()Llx2;
.end method

.method public final i(Lh11;)Landroid/database/Cursor;
    .locals 0

    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->a()V

    invoke-virtual {p0}, Landroidx/work/impl/WorkDatabase;->b()V

    iget-object p0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {p0}, Lg11;->c()Lty;

    move-result-object p0

    invoke-virtual {p0, p1}, Lty;->j(Lh11;)Landroid/database/Cursor;

    move-result-object p0

    return-object p0
.end method

.method public final j()V
    .locals 0

    iget-object p0, p0, Landroidx/work/impl/WorkDatabase;->c:Lg11;

    invoke-interface {p0}, Lg11;->c()Lty;

    move-result-object p0

    invoke-virtual {p0}, Lty;->l()V

    return-void
.end method

.method public abstract k()Loo4;
.end method

.method public abstract l()Lxt3;
.end method

.method public abstract m()La90;
.end method

.method public abstract n()Lsj1;
.end method

.method public abstract o()Lsf2;
.end method
