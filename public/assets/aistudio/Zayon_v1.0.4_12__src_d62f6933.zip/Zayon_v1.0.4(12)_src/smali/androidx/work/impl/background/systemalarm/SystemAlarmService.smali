.class public Landroidx/work/impl/background/systemalarm/SystemAlarmService;
.super Lm90;
.source "SourceFile"


# instance fields
.field public i:Lo11;

.field public j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "SystemAlarmService"

    invoke-static {v0}, Llb0;->f(Ljava/lang/String;)Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lm90;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->j:Z

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [Ljava/lang/Throwable;

    invoke-virtual {v0, v2}, Llb0;->a([Ljava/lang/Throwable;)V

    sget-object v0, Ln81;->a:Ljava/util/WeakHashMap;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sget-object v2, Ln81;->a:Ljava/util/WeakHashMap;

    monitor-enter v2

    :try_start_0
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/os/PowerManager$WakeLock;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v4

    if-eqz v4, :cond_0

    const-string v4, "WakeLock held for %s"

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object v3

    sget-object v4, Ln81;->a:Ljava/util/WeakHashMap;

    new-array v4, v1, [Ljava/lang/Throwable;

    invoke-virtual {v3, v4}, Llb0;->g([Ljava/lang/Throwable;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public final onCreate()V
    .locals 3

    invoke-super {p0}, Lm90;->onCreate()V

    new-instance v0, Lo11;

    invoke-direct {v0, p0}, Lo11;-><init>(Landroidx/work/impl/background/systemalarm/SystemAlarmService;)V

    iput-object v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->i:Lo11;

    iget-object v1, v0, Lo11;->q:Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Throwable;

    invoke-virtual {v0, v1}, Llb0;->b([Ljava/lang/Throwable;)V

    goto :goto_0

    :cond_0
    iput-object p0, v0, Lo11;->q:Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    :goto_0
    iput-boolean v2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->j:Z

    return-void
.end method

.method public final onDestroy()V
    .locals 1

    invoke-super {p0}, Lm90;->onDestroy()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->j:Z

    iget-object p0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->i:Lo11;

    invoke-virtual {p0}, Lo11;->d()V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    invoke-super {p0, p1, p2, p3}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    iget-boolean p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->j:Z

    if-eqz p2, :cond_1

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object p2

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/Throwable;

    invoke-virtual {p2, v1}, Llb0;->e([Ljava/lang/Throwable;)V

    iget-object p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->i:Lo11;

    invoke-virtual {p2}, Lo11;->d()V

    new-instance p2, Lo11;

    invoke-direct {p2, p0}, Lo11;-><init>(Landroidx/work/impl/background/systemalarm/SystemAlarmService;)V

    iput-object p2, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->i:Lo11;

    iget-object v1, p2, Lo11;->q:Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    if-eqz v1, :cond_0

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object p2

    new-array v1, v0, [Ljava/lang/Throwable;

    invoke-virtual {p2, v1}, Llb0;->b([Ljava/lang/Throwable;)V

    goto :goto_0

    :cond_0
    iput-object p0, p2, Lo11;->q:Landroidx/work/impl/background/systemalarm/SystemAlarmService;

    :goto_0
    iput-boolean v0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->j:Z

    :cond_1
    if-eqz p1, :cond_2

    iget-object p0, p0, Landroidx/work/impl/background/systemalarm/SystemAlarmService;->i:Lo11;

    invoke-virtual {p0, p1, p3}, Lo11;->b(Landroid/content/Intent;I)V

    :cond_2
    const/4 p0, 0x3

    return p0
.end method
