.class public final Landroidx/work/WorkerParameters;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/util/UUID;

.field public b:Lsm;

.field public c:Ljava/util/HashSet;

.field public d:Lwg3;

.field public e:I

.field public f:Ljava/util/concurrent/ExecutorService;

.field public g:Lxh2;

.field public h:Lgb1;

.field public i:Lxa1;

.field public j:Lsa1;
