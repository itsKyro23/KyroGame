.class public final Landroidx/work/WorkManagerInitializer;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lv50;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lv50;"
    }
.end annotation


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "WrkMgrInitializer"

    invoke-static {v0}, Llb0;->f(Ljava/lang/String;)Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .locals 0

    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    return-object p0
.end method

.method public final b(Landroid/content/Context;)Ljava/lang/Object;
    .locals 1

    invoke-static {}, Llb0;->c()Llb0;

    move-result-object p0

    const/4 v0, 0x0

    new-array v0, v0, [Ljava/lang/Throwable;

    invoke-virtual {p0, v0}, Llb0;->a([Ljava/lang/Throwable;)V

    new-instance p0, Lq24;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lvh;

    invoke-direct {v0, p0}, Lvh;-><init>(Lq24;)V

    invoke-static {p1, v0}, Lta1;->c(Landroid/content/Context;Lvh;)V

    invoke-static {p1}, Lta1;->b(Landroid/content/Context;)Lta1;

    move-result-object p0

    return-object p0
.end method
