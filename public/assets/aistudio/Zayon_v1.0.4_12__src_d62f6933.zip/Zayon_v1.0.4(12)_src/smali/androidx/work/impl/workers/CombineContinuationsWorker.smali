.class public Landroidx/work/impl/workers/CombineContinuationsWorker;
.super Landroidx/work/Worker;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Landroidx/work/Worker;-><init>(Landroid/content/Context;Landroidx/work/WorkerParameters;)V

    return-void
.end method


# virtual methods
.method public final doWork()Lra0;
    .locals 1

    invoke-virtual {p0}, Landroidx/work/ListenableWorker;->getInputData()Lsm;

    move-result-object p0

    new-instance v0, Lqa0;

    invoke-direct {v0, p0}, Lqa0;-><init>(Lsm;)V

    return-object v0
.end method
