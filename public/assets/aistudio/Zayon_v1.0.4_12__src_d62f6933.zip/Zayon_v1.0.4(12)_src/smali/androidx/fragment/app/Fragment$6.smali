.class Landroidx/fragment/app/Fragment$6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# instance fields
.field public final synthetic h:Lrx;


# direct methods
.method public constructor <init>(Lrx;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/fragment/app/Fragment$6;->h:Lrx;

    return-void
.end method


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    sget-object p1, Ld90;->ON_STOP:Ld90;

    if-ne p2, p1, :cond_0

    iget-object p0, p0, Landroidx/fragment/app/Fragment$6;->h:Lrx;

    iget-object p0, p0, Lrx;->L:Landroid/view/View;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->cancelPendingInputEvents()V

    :cond_0
    return-void
.end method
