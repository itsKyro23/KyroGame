.class Landroidx/fragment/app/FragmentManager$6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lh90;


# virtual methods
.method public final b(Lk90;Ld90;)V
    .locals 0

    sget-object p0, Ld90;->ON_START:Ld90;

    const/4 p1, 0x0

    if-eq p2, p0, :cond_1

    sget-object p0, Ld90;->ON_DESTROY:Ld90;

    if-eq p2, p0, :cond_0

    return-void

    :cond_0
    throw p1

    :cond_1
    throw p1
.end method
