.class public final Landroidx/fragment/app/a;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Llx2;

.field public final b:Ll41;

.field public final c:Lrx;

.field public d:Z

.field public e:I


# direct methods
.method public constructor <init>(Llx2;Ll41;Ljava/lang/ClassLoader;Lcy;Lmy;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/fragment/app/a;->d:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/fragment/app/a;->e:I

    iput-object p1, p0, Landroidx/fragment/app/a;->a:Llx2;

    iput-object p2, p0, Landroidx/fragment/app/a;->b:Ll41;

    iget-object p1, p5, Lmy;->h:Ljava/lang/String;

    invoke-virtual {p4, p1}, Lcy;->a(Ljava/lang/String;)Lrx;

    move-result-object p1

    iget-object p2, p5, Lmy;->q:Landroid/os/Bundle;

    if-eqz p2, :cond_0

    invoke-virtual {p2, p3}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    :cond_0
    iget-object p3, p1, Lrx;->y:Lhy;

    if-eqz p3, :cond_2

    invoke-virtual {p3}, Lhy;->K()Z

    move-result p3

    if-nez p3, :cond_1

    goto :goto_0

    :cond_1
    const-string p0, "Fragment already added and state has been saved"

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_2
    :goto_0
    iput-object p2, p1, Lrx;->m:Landroid/os/Bundle;

    iget-object p2, p5, Lmy;->i:Ljava/lang/String;

    iput-object p2, p1, Lrx;->l:Ljava/lang/String;

    iget-boolean p2, p5, Lmy;->j:Z

    iput-boolean p2, p1, Lrx;->t:Z

    const/4 p2, 0x1

    iput-boolean p2, p1, Lrx;->v:Z

    iget p2, p5, Lmy;->k:I

    iput p2, p1, Lrx;->C:I

    iget p2, p5, Lmy;->l:I

    iput p2, p1, Lrx;->D:I

    iget-object p2, p5, Lmy;->m:Ljava/lang/String;

    iput-object p2, p1, Lrx;->E:Ljava/lang/String;

    iget-boolean p2, p5, Lmy;->n:Z

    iput-boolean p2, p1, Lrx;->H:Z

    iget-boolean p2, p5, Lmy;->o:Z

    iput-boolean p2, p1, Lrx;->s:Z

    iget-boolean p2, p5, Lmy;->p:Z

    iput-boolean p2, p1, Lrx;->G:Z

    iget-boolean p2, p5, Lmy;->r:Z

    iput-boolean p2, p1, Lrx;->F:Z

    invoke-static {}, Le90;->values()[Le90;

    move-result-object p2

    iget p3, p5, Lmy;->s:I

    aget-object p2, p2, p3

    iput-object p2, p1, Lrx;->S:Le90;

    iget-object p2, p5, Lmy;->t:Landroid/os/Bundle;

    if-eqz p2, :cond_3

    iput-object p2, p1, Lrx;->i:Landroid/os/Bundle;

    goto :goto_1

    :cond_3
    new-instance p2, Landroid/os/Bundle;

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    iput-object p2, p1, Lrx;->i:Landroid/os/Bundle;

    :goto_1
    iput-object p1, p0, Landroidx/fragment/app/a;->c:Lrx;

    const/4 p0, 0x2

    invoke-static {p0}, Lhy;->F(I)Z

    move-result p0

    if-eqz p0, :cond_4

    invoke-static {p1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_4
    return-void
.end method

.method public constructor <init>(Llx2;Ll41;Lrx;)V
    .locals 1

    .line 122
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 123
    iput-boolean v0, p0, Landroidx/fragment/app/a;->d:Z

    const/4 v0, -0x1

    .line 124
    iput v0, p0, Landroidx/fragment/app/a;->e:I

    .line 125
    iput-object p1, p0, Landroidx/fragment/app/a;->a:Llx2;

    .line 126
    iput-object p2, p0, Landroidx/fragment/app/a;->b:Ll41;

    .line 127
    iput-object p3, p0, Landroidx/fragment/app/a;->c:Lrx;

    return-void
.end method

.method public constructor <init>(Llx2;Ll41;Lrx;Lmy;)V
    .locals 2

    .line 128
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 129
    iput-boolean v0, p0, Landroidx/fragment/app/a;->d:Z

    const/4 v1, -0x1

    .line 130
    iput v1, p0, Landroidx/fragment/app/a;->e:I

    .line 131
    iput-object p1, p0, Landroidx/fragment/app/a;->a:Llx2;

    .line 132
    iput-object p2, p0, Landroidx/fragment/app/a;->b:Ll41;

    .line 133
    iput-object p3, p0, Landroidx/fragment/app/a;->c:Lrx;

    const/4 p0, 0x0

    .line 134
    iput-object p0, p3, Lrx;->j:Landroid/util/SparseArray;

    .line 135
    iput-object p0, p3, Lrx;->k:Landroid/os/Bundle;

    .line 136
    iput v0, p3, Lrx;->x:I

    .line 137
    iput-boolean v0, p3, Lrx;->u:Z

    .line 138
    iput-boolean v0, p3, Lrx;->r:Z

    .line 139
    iget-object p1, p3, Lrx;->n:Lrx;

    if-eqz p1, :cond_0

    iget-object p1, p1, Lrx;->l:Ljava/lang/String;

    goto :goto_0

    :cond_0
    move-object p1, p0

    :goto_0
    iput-object p1, p3, Lrx;->o:Ljava/lang/String;

    .line 140
    iput-object p0, p3, Lrx;->n:Lrx;

    .line 141
    iget-object p0, p4, Lmy;->t:Landroid/os/Bundle;

    if-eqz p0, :cond_1

    .line 142
    iput-object p0, p3, Lrx;->i:Landroid/os/Bundle;

    return-void

    .line 143
    :cond_1
    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    iput-object p0, p3, Lrx;->i:Landroid/os/Bundle;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 7

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v1

    iget-object v2, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v1, :cond_0

    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v1, v2, Lrx;->A:Lhy;

    invoke-virtual {v1}, Lhy;->M()V

    iput v0, v2, Lrx;->h:I

    const/4 v1, 0x0

    iput-boolean v1, v2, Lrx;->J:Z

    invoke-virtual {v2}, Lrx;->r()V

    iget-boolean v3, v2, Lrx;->J:Z

    const-string v4, "Fragment "

    if-eqz v3, :cond_6

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, Lrx;->toString()Ljava/lang/String;

    :cond_1
    iget-object v0, v2, Lrx;->L:Landroid/view/View;

    const/4 v3, 0x0

    if-eqz v0, :cond_5

    iget-object v5, v2, Lrx;->i:Landroid/os/Bundle;

    iget-object v6, v2, Lrx;->j:Landroid/util/SparseArray;

    if-eqz v6, :cond_2

    invoke-virtual {v0, v6}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    iput-object v3, v2, Lrx;->j:Landroid/util/SparseArray;

    :cond_2
    iget-object v0, v2, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_3

    iget-object v0, v2, Lrx;->U:Lry;

    iget-object v6, v2, Lrx;->k:Landroid/os/Bundle;

    iget-object v0, v0, Lry;->k:Lyy;

    invoke-virtual {v0, v6}, Lyy;->d(Landroid/os/Bundle;)V

    iput-object v3, v2, Lrx;->k:Landroid/os/Bundle;

    :cond_3
    iput-boolean v1, v2, Lrx;->J:Z

    invoke-virtual {v2, v5}, Lrx;->F(Landroid/os/Bundle;)V

    iget-boolean v0, v2, Lrx;->J:Z

    if-eqz v0, :cond_4

    iget-object v0, v2, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_5

    iget-object v0, v2, Lrx;->U:Lry;

    sget-object v4, Ld90;->ON_CREATE:Ld90;

    invoke-virtual {v0, v4}, Lry;->a(Ld90;)V

    goto :goto_0

    :cond_4
    new-instance p0, Lx01;

    const-string v0, " did not call through to super.onViewStateRestored()"

    invoke-static {v4, v2, v0}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_5
    :goto_0
    iput-object v3, v2, Lrx;->i:Landroid/os/Bundle;

    iget-object v0, v2, Lrx;->A:Lhy;

    iput-boolean v1, v0, Lhy;->E:Z

    iput-boolean v1, v0, Lhy;->F:Z

    iget-object v2, v0, Lhy;->L:Ljy;

    iput-boolean v1, v2, Ljy;->h:Z

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Lhy;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v1}, Llx2;->g(Z)V

    return-void

    :cond_6
    new-instance p0, Lx01;

    const-string v0, " did not call through to super.onActivityCreated()"

    invoke-static {v4, v2, v0}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final b()V
    .locals 7

    iget-object v0, p0, Landroidx/fragment/app/a;->b:Ll41;

    iget-object v0, v0, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    iget-object p0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-object v1, p0, Lrx;->K:Landroid/view/ViewGroup;

    const/4 v2, -0x1

    if-nez v1, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v3

    add-int/lit8 v4, v3, -0x1

    :goto_0
    if-ltz v4, :cond_2

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lrx;

    iget-object v6, v5, Lrx;->K:Landroid/view/ViewGroup;

    if-ne v6, v1, :cond_1

    iget-object v5, v5, Lrx;->L:Landroid/view/View;

    if-eqz v5, :cond_1

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    add-int/lit8 v2, v0, 0x1

    goto :goto_2

    :cond_1
    add-int/lit8 v4, v4, -0x1

    goto :goto_0

    :cond_2
    :goto_1
    add-int/lit8 v3, v3, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_4

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lrx;

    iget-object v5, v4, Lrx;->K:Landroid/view/ViewGroup;

    if-ne v5, v1, :cond_3

    iget-object v4, v4, Lrx;->L:Landroid/view/View;

    if-eqz v4, :cond_3

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v2

    goto :goto_2

    :cond_3
    goto :goto_1

    :cond_4
    :goto_2
    iget-object v0, p0, Lrx;->K:Landroid/view/ViewGroup;

    iget-object p0, p0, Lrx;->L:Landroid/view/View;

    invoke-virtual {v0, p0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    return-void
.end method

.method public final c()V
    .locals 7

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->n:Lrx;

    const/4 v2, 0x0

    const-string v3, " that does not belong to this FragmentManager!"

    const-string v4, " declared target fragment "

    iget-object v5, p0, Landroidx/fragment/app/a;->b:Ll41;

    const-string v6, "Fragment "

    if-eqz v0, :cond_2

    iget-object v0, v0, Lrx;->l:Ljava/lang/String;

    iget-object v5, v5, Ll41;->j:Ljava/lang/Object;

    check-cast v5, Ljava/util/HashMap;

    invoke-virtual {v5, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/fragment/app/a;

    if-eqz v0, :cond_1

    iget-object v3, v1, Lrx;->n:Lrx;

    iget-object v3, v3, Lrx;->l:Ljava/lang/String;

    iput-object v3, v1, Lrx;->o:Ljava/lang/String;

    iput-object v2, v1, Lrx;->n:Lrx;

    move-object v2, v0

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v1, v1, Lrx;->n:Lrx;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    iget-object v0, v1, Lrx;->o:Ljava/lang/String;

    if-eqz v0, :cond_4

    iget-object v2, v5, Ll41;->j:Ljava/lang/Object;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Landroidx/fragment/app/a;

    if-eqz v2, :cond_3

    goto :goto_0

    :cond_3
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v1, Lrx;->o:Ljava/lang/String;

    invoke-static {p0, v0, v3}, Loj;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void

    :cond_4
    :goto_0
    if-eqz v2, :cond_5

    invoke-virtual {v2}, Landroidx/fragment/app/a;->k()V

    :cond_5
    iget-object v0, v1, Lrx;->y:Lhy;

    iget-object v2, v0, Lhy;->t:Ltx;

    iput-object v2, v1, Lrx;->z:Ltx;

    iget-object v0, v0, Lhy;->v:Lrx;

    iput-object v0, v1, Lrx;->B:Lrx;

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Llx2;->o(Z)V

    iget-object v2, v1, Lrx;->Z:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v4, v0

    :goto_1
    if-ge v4, v3, :cond_6

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Lqx;

    invoke-virtual {v5}, Lqx;->a()V

    goto :goto_1

    :cond_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iget-object v2, v1, Lrx;->A:Lhy;

    iget-object v3, v1, Lrx;->z:Ltx;

    invoke-virtual {v1}, Lrx;->f()La60;

    move-result-object v4

    invoke-virtual {v2, v3, v4, v1}, Lhy;->b(Ltx;La60;Lrx;)V

    iput v0, v1, Lrx;->h:I

    iput-boolean v0, v1, Lrx;->J:Z

    iget-object v2, v1, Lrx;->z:Ltx;

    iget-object v2, v2, Ltx;->x:Lk6;

    invoke-virtual {v1, v2}, Lrx;->t(Lk6;)V

    iget-boolean v2, v1, Lrx;->J:Z

    if-eqz v2, :cond_8

    iget-object v2, v1, Lrx;->y:Lhy;

    iget-object v2, v2, Lhy;->m:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lky;

    invoke-interface {v3}, Lky;->c()V

    goto :goto_2

    :cond_7
    iget-object v1, v1, Lrx;->A:Lhy;

    iput-boolean v0, v1, Lhy;->E:Z

    iput-boolean v0, v1, Lhy;->F:Z

    iget-object v2, v1, Lhy;->L:Ljy;

    iput-boolean v0, v2, Ljy;->h:Z

    invoke-virtual {v1, v0}, Lhy;->t(I)V

    invoke-virtual {p0, v0}, Llx2;->h(Z)V

    return-void

    :cond_8
    new-instance p0, Lx01;

    const-string v0, " did not call through to super.onAttach()"

    invoke-static {v6, v1, v0}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final d()I
    .locals 13

    iget-object v0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-object v1, v0, Lrx;->y:Lhy;

    if-nez v1, :cond_0

    iget p0, v0, Lrx;->h:I

    return p0

    :cond_0
    iget v1, p0, Landroidx/fragment/app/a;->e:I

    iget-object v2, v0, Lrx;->S:Le90;

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v5, -0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eq v2, v9, :cond_3

    if-eq v2, v8, :cond_2

    if-eq v2, v6, :cond_1

    if-eq v2, v7, :cond_4

    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_0

    :cond_1
    invoke-static {v1, v4}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_0

    :cond_2
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_0

    :cond_3
    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_4
    :goto_0
    iget-boolean v2, v0, Lrx;->t:Z

    if-eqz v2, :cond_7

    iget-boolean v2, v0, Lrx;->u:Z

    iget p0, p0, Landroidx/fragment/app/a;->e:I

    if-eqz v2, :cond_5

    invoke-static {p0, v8}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object p0, v0, Lrx;->L:Landroid/view/View;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    if-nez p0, :cond_7

    invoke-static {v1, v8}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_1

    :cond_5
    if-ge p0, v7, :cond_6

    iget p0, v0, Lrx;->h:I

    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_1

    :cond_6
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_7
    :goto_1
    iget-boolean p0, v0, Lrx;->r:Z

    if-nez p0, :cond_8

    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_8
    iget-object p0, v0, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz p0, :cond_f

    invoke-virtual {v0}, Lrx;->l()Lhy;

    move-result-object v2

    invoke-virtual {v2}, Lhy;->E()Ljs;

    move-result-object v2

    invoke-static {p0, v2}, Lfp;->f(Landroid/view/ViewGroup;Ljs;)Lfp;

    move-result-object p0

    invoke-virtual {p0, v0}, Lfp;->d(Lrx;)Lfz0;

    move-result-object v2

    if-eqz v2, :cond_9

    iget v2, v2, Lfz0;->b:I

    goto :goto_2

    :cond_9
    move v2, v3

    :goto_2
    iget-object p0, p0, Lfp;->c:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v10

    :cond_a
    :goto_3
    if-ge v3, v10, :cond_c

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    add-int/lit8 v3, v3, 0x1

    check-cast v11, Lfz0;

    iget-object v12, v11, Lfz0;->c:Lrx;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eq v12, v0, :cond_b

    goto :goto_3

    :cond_b
    iget-boolean v12, v11, Lfz0;->f:Z

    if-nez v12, :cond_a

    goto :goto_4

    :cond_c
    const/4 v11, 0x0

    :goto_4
    if-eqz v11, :cond_e

    if-eqz v2, :cond_d

    if-ne v2, v9, :cond_e

    :cond_d
    iget p0, v11, Lfz0;->b:I

    move v3, p0

    goto :goto_5

    :cond_e
    move v3, v2

    :cond_f
    :goto_5
    if-ne v3, v8, :cond_10

    const/4 p0, 0x6

    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_6

    :cond_10
    if-ne v3, v6, :cond_11

    invoke-static {v1, v6}, Ljava/lang/Math;->max(II)I

    move-result v1

    goto :goto_6

    :cond_11
    iget-boolean p0, v0, Lrx;->s:Z

    if-eqz p0, :cond_13

    invoke-virtual {v0}, Lrx;->q()Z

    move-result p0

    if-eqz p0, :cond_12

    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    move-result v1

    goto :goto_6

    :cond_12
    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_13
    :goto_6
    iget-boolean p0, v0, Lrx;->M:Z

    if-eqz p0, :cond_14

    iget p0, v0, Lrx;->h:I

    if-ge p0, v4, :cond_14

    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    move-result v1

    :cond_14
    invoke-static {v8}, Lhy;->F(I)Z

    move-result p0

    if-eqz p0, :cond_15

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_15
    return v1
.end method

.method public final e()V
    .locals 6

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-boolean v0, v1, Lrx;->Q:Z

    iget-object v2, v1, Lrx;->i:Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_2

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v4}, Llx2;->p(Z)V

    iget-object v0, v1, Lrx;->i:Landroid/os/Bundle;

    iget-object v2, v1, Lrx;->A:Lhy;

    invoke-virtual {v2}, Lhy;->M()V

    iput v3, v1, Lrx;->h:I

    iput-boolean v4, v1, Lrx;->J:Z

    iget-object v2, v1, Lrx;->T:Landroidx/lifecycle/a;

    new-instance v5, Landroidx/fragment/app/Fragment$6;

    invoke-direct {v5, v1}, Landroidx/fragment/app/Fragment$6;-><init>(Lrx;)V

    invoke-virtual {v2, v5}, Landroidx/lifecycle/a;->a(Lj90;)V

    iget-object v2, v1, Lrx;->W:Lyy;

    invoke-virtual {v2, v0}, Lyy;->d(Landroid/os/Bundle;)V

    invoke-virtual {v1, v0}, Lrx;->u(Landroid/os/Bundle;)V

    iput-boolean v3, v1, Lrx;->Q:Z

    iget-boolean v0, v1, Lrx;->J:Z

    if-eqz v0, :cond_1

    iget-object v0, v1, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v1, Ld90;->ON_CREATE:Ld90;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/a;->d(Ld90;)V

    invoke-virtual {p0, v4}, Llx2;->j(Z)V

    return-void

    :cond_1
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onCreate()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    if-eqz v2, :cond_3

    const-string p0, "android:support:fragments"

    invoke-virtual {v2, p0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    if-eqz p0, :cond_3

    iget-object v0, v1, Lrx;->A:Lhy;

    invoke-virtual {v0, p0}, Lhy;->R(Landroid/os/Parcelable;)V

    iget-object p0, v1, Lrx;->A:Lhy;

    iput-boolean v4, p0, Lhy;->E:Z

    iput-boolean v4, p0, Lhy;->F:Z

    iget-object v0, p0, Lhy;->L:Ljy;

    iput-boolean v4, v0, Ljy;->h:Z

    invoke-virtual {p0, v3}, Lhy;->t(I)V

    :cond_3
    iput v3, v1, Lrx;->h:I

    return-void
.end method

.method public final f()V
    .locals 7

    iget-object v0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-boolean v1, v0, Lrx;->t:Z

    if-eqz v1, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x3

    invoke-static {v1}, Lhy;->F(I)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_1
    iget-object v2, v0, Lrx;->i:Landroid/os/Bundle;

    invoke-virtual {v0, v2}, Lrx;->y(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object v2

    iget-object v3, v0, Lrx;->K:Landroid/view/ViewGroup;

    const/4 v4, 0x1

    if-eqz v3, :cond_2

    goto/16 :goto_1

    :cond_2
    iget v3, v0, Lrx;->D:I

    if-eqz v3, :cond_6

    const/4 v5, -0x1

    if-eq v3, v5, :cond_5

    iget-object v5, v0, Lrx;->y:Lhy;

    iget-object v5, v5, Lhy;->u:La60;

    invoke-virtual {v5, v3}, La60;->o(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/view/ViewGroup;

    if-nez v3, :cond_4

    iget-boolean v1, v0, Lrx;->v:Z

    if-eqz v1, :cond_3

    goto :goto_1

    :cond_3
    :try_start_0
    invoke-virtual {v0}, Lrx;->m()Landroid/content/res/Resources;

    move-result-object p0

    iget v1, v0, Lrx;->D:I

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p0, "unknown"

    :goto_0
    new-instance v1, Ljava/lang/IllegalArgumentException;

    iget v2, v0, Lrx;->D:I

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "No view found for id 0x"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " ("

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ") for fragment "

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_4
    instance-of v5, v3, Lvx;

    if-nez v5, :cond_7

    sget-object v5, Loy;->a:Lny;

    new-instance v5, Lpy;

    invoke-direct {v5, v0, v3, v4}, Lpy;-><init>(Lrx;Landroid/view/ViewGroup;I)V

    invoke-static {v1}, Lhy;->F(I)Z

    invoke-static {v0}, Loy;->a(Lrx;)Lny;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_1

    :cond_5
    const-string p0, "Cannot create fragment "

    const-string v1, " for a container view with no id"

    invoke-static {p0, v0, v1}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void

    :cond_6
    const/4 v3, 0x0

    :cond_7
    :goto_1
    iput-object v3, v0, Lrx;->K:Landroid/view/ViewGroup;

    iget-object v1, v0, Lrx;->i:Landroid/os/Bundle;

    invoke-virtual {v0, v2, v3, v1}, Lrx;->G(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    const/4 v2, 0x2

    if-eqz v1, :cond_c

    const/4 v5, 0x0

    invoke-virtual {v1, v5}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    const v6, 0x7f09008b

    invoke-virtual {v1, v6, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    if-eqz v3, :cond_8

    invoke-virtual {p0}, Landroidx/fragment/app/a;->b()V

    :cond_8
    iget-boolean v1, v0, Lrx;->F:Z

    if-eqz v1, :cond_9

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_9
    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    sget-object v3, Ls71;->a:Ljava/util/WeakHashMap;

    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    iget-object v3, v0, Lrx;->L:Landroid/view/View;

    if-eqz v1, :cond_a

    invoke-virtual {v3}, Landroid/view/View;->requestApplyInsets()V

    goto :goto_2

    :cond_a
    new-instance v1, Lle;

    invoke-direct {v1, v4, v3}, Lle;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v3, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :goto_2
    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    invoke-virtual {v0, v1}, Lrx;->E(Landroid/view/View;)V

    iget-object v1, v0, Lrx;->A:Lhy;

    invoke-virtual {v1, v2}, Lhy;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v5}, Llx2;->v(Z)V

    iget-object p0, v0, Lrx;->L:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result p0

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getAlpha()F

    move-result v1

    invoke-virtual {v0}, Lrx;->g()Lpx;

    move-result-object v3

    iput v1, v3, Lpx;->j:F

    iget-object v1, v0, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz v1, :cond_c

    if-nez p0, :cond_c

    iget-object p0, v0, Lrx;->L:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_b

    invoke-virtual {v0}, Lrx;->g()Lpx;

    move-result-object v1

    iput-object p0, v1, Lpx;->k:Landroid/view/View;

    invoke-static {v2}, Lhy;->F(I)Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_b
    iget-object p0, v0, Lrx;->L:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    :cond_c
    iput v2, v0, Lrx;->h:I

    return-void
.end method

.method public final g()V
    .locals 9

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v1

    iget-object v2, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v1, :cond_0

    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-boolean v1, v2, Lrx;->s:Z

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    invoke-virtual {v2}, Lrx;->q()Z

    move-result v1

    if-nez v1, :cond_1

    move v1, v3

    goto :goto_0

    :cond_1
    move v1, v4

    :goto_0
    iget-object v5, p0, Landroidx/fragment/app/a;->b:Ll41;

    if-eqz v1, :cond_2

    iget-object v6, v2, Lrx;->l:Ljava/lang/String;

    iget-object v7, v5, Ll41;->k:Ljava/lang/Object;

    check-cast v7, Ljava/util/HashMap;

    invoke-virtual {v7, v6}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lmy;

    :cond_2
    if-nez v1, :cond_7

    iget-object v6, v5, Ll41;->l:Ljava/lang/Object;

    check-cast v6, Ljy;

    iget-object v7, v6, Ljy;->c:Ljava/util/HashMap;

    iget-object v8, v2, Lrx;->l:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_3

    goto :goto_1

    :cond_3
    iget-boolean v7, v6, Ljy;->f:Z

    if-eqz v7, :cond_4

    iget-boolean v6, v6, Ljy;->g:Z

    goto :goto_2

    :cond_4
    :goto_1
    move v6, v3

    :goto_2
    if-eqz v6, :cond_5

    goto :goto_3

    :cond_5
    iget-object p0, v2, Lrx;->o:Ljava/lang/String;

    if-eqz p0, :cond_6

    invoke-virtual {v5, p0}, Ll41;->e(Ljava/lang/String;)Lrx;

    move-result-object p0

    if-eqz p0, :cond_6

    iget-boolean v0, p0, Lrx;->H:Z

    if-eqz v0, :cond_6

    iput-object p0, v2, Lrx;->n:Lrx;

    :cond_6
    iput v4, v2, Lrx;->h:I

    return-void

    :cond_7
    :goto_3
    iget-object v6, v2, Lrx;->z:Ltx;

    if-eqz v6, :cond_8

    iget-object v3, v5, Ll41;->l:Ljava/lang/Object;

    check-cast v3, Ljy;

    iget-boolean v3, v3, Ljy;->g:Z

    goto :goto_4

    :cond_8
    iget-object v6, v6, Ltx;->x:Lk6;

    invoke-virtual {v6}, Landroid/app/Activity;->isChangingConfigurations()Z

    move-result v6

    xor-int/2addr v3, v6

    :goto_4
    if-eqz v1, :cond_9

    goto :goto_5

    :cond_9
    if-eqz v3, :cond_b

    :goto_5
    iget-object v1, v5, Ll41;->l:Ljava/lang/Object;

    check-cast v1, Ljy;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_a
    iget-object v0, v2, Lrx;->l:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljy;->b(Ljava/lang/String;)V

    :cond_b
    iget-object v0, v2, Lrx;->A:Lhy;

    invoke-virtual {v0}, Lhy;->k()V

    iget-object v0, v2, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v1, Ld90;->ON_DESTROY:Ld90;

    invoke-virtual {v0, v1}, Landroidx/lifecycle/a;->d(Ld90;)V

    iput v4, v2, Lrx;->h:I

    iput-boolean v4, v2, Lrx;->J:Z

    iput-boolean v4, v2, Lrx;->Q:Z

    invoke-virtual {v2}, Lrx;->v()V

    iget-boolean v0, v2, Lrx;->J:Z

    if-eqz v0, :cond_f

    iget-object v0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {v0, v4}, Llx2;->k(Z)V

    invoke-virtual {v5}, Ll41;->j()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    :cond_c
    :goto_6
    if-ge v4, v1, :cond_d

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v4, v4, 0x1

    check-cast v3, Landroidx/fragment/app/a;

    if-eqz v3, :cond_c

    iget-object v3, v3, Landroidx/fragment/app/a;->c:Lrx;

    iget-object v6, v2, Lrx;->l:Ljava/lang/String;

    iget-object v7, v3, Lrx;->o:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_c

    iput-object v2, v3, Lrx;->n:Lrx;

    const/4 v6, 0x0

    iput-object v6, v3, Lrx;->o:Ljava/lang/String;

    goto :goto_6

    :cond_d
    iget-object v0, v2, Lrx;->o:Ljava/lang/String;

    if-eqz v0, :cond_e

    invoke-virtual {v5, v0}, Ll41;->e(Ljava/lang/String;)Lrx;

    move-result-object v0

    iput-object v0, v2, Lrx;->n:Lrx;

    :cond_e
    invoke-virtual {v5, p0}, Ll41;->s(Landroidx/fragment/app/a;)V

    return-void

    :cond_f
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v1, " did not call through to super.onDestroy()"

    invoke-static {v0, v2, v1}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final h()V
    .locals 7

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    iget-object v2, v1, Lrx;->L:Landroid/view/View;

    if-eqz v2, :cond_1

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    iget-object v0, v1, Lrx;->A:Lhy;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lhy;->t(I)V

    iget-object v0, v1, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_2

    iget-object v0, v1, Lrx;->U:Lry;

    invoke-virtual {v0}, Lry;->f()V

    iget-object v0, v0, Lry;->j:Landroidx/lifecycle/a;

    iget-object v0, v0, Landroidx/lifecycle/a;->b:Le90;

    sget-object v3, Le90;->j:Le90;

    invoke-virtual {v0, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v0

    if-ltz v0, :cond_2

    iget-object v0, v1, Lrx;->U:Lry;

    sget-object v3, Ld90;->ON_DESTROY:Ld90;

    invoke-virtual {v0, v3}, Lry;->a(Ld90;)V

    :cond_2
    iput v2, v1, Lrx;->h:I

    const/4 v0, 0x0

    iput-boolean v0, v1, Lrx;->J:Z

    invoke-virtual {v1}, Lrx;->w()V

    iget-boolean v2, v1, Lrx;->J:Z

    if-eqz v2, :cond_7

    invoke-interface {v1}, Lz71;->d()Ly71;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Ljk;->j:Ljk;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v4, Lwa0;

    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_6

    const-string v6, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    invoke-virtual {v6, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v2, v2, Ly71;->a:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lw71;

    invoke-virtual {v4, v6}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_2

    :cond_3
    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    iget-object v3, v3, Lfg4;->i:Ljava/lang/Object;

    check-cast v3, Ljava/util/LinkedHashMap;

    invoke-interface {v4, v3}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    sget-object v3, Lq24;->l:Lq24;

    invoke-interface {v4, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    new-instance v3, Lwa0;

    invoke-direct {v3}, Lwa0;-><init>()V
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    move-object v6, v3

    goto :goto_1

    :catch_0
    new-instance v3, Lwa0;

    invoke-direct {v3}, Lwa0;-><init>()V

    goto :goto_0

    :goto_1
    invoke-interface {v2, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lw71;

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Lw71;->a()V

    :cond_4
    :goto_2
    check-cast v6, Lwa0;

    iget-object v2, v6, Lwa0;->c:Lez0;

    iget v3, v2, Lez0;->j:I

    if-gtz v3, :cond_5

    iput-boolean v0, v1, Lrx;->w:Z

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v0}, Llx2;->w(Z)V

    const/4 p0, 0x0

    iput-object p0, v1, Lrx;->K:Landroid/view/ViewGroup;

    iput-object p0, v1, Lrx;->L:Landroid/view/View;

    iput-object p0, v1, Lrx;->U:Lry;

    iget-object v2, v1, Lrx;->V:Landroidx/lifecycle/b;

    invoke-virtual {v2, p0}, Landroidx/lifecycle/b;->e(Ljava/lang/Object;)V

    iput-boolean v0, v1, Lrx;->u:Z

    return-void

    :cond_5
    iget-object p0, v2, Lez0;->i:[Ljava/lang/Object;

    aget-object p0, p0, v0

    invoke-static {p0}, Loj;->h(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    move-result-object p0

    throw p0

    :cond_6
    const-string p0, "Local and anonymous classes can not be ViewModels"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void

    :cond_7
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onDestroyView()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final i()V
    .locals 6

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v1

    iget-object v2, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v1, :cond_0

    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    const/4 v1, -0x1

    iput v1, v2, Lrx;->h:I

    const/4 v3, 0x0

    iput-boolean v3, v2, Lrx;->J:Z

    invoke-virtual {v2}, Lrx;->x()V

    iget-boolean v4, v2, Lrx;->J:Z

    if-eqz v4, :cond_7

    iget-object v4, v2, Lrx;->A:Lhy;

    iget-boolean v5, v4, Lhy;->G:Z

    if-nez v5, :cond_1

    invoke-virtual {v4}, Lhy;->k()V

    new-instance v4, Lhy;

    invoke-direct {v4}, Lhy;-><init>()V

    iput-object v4, v2, Lrx;->A:Lhy;

    :cond_1
    iget-object v4, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {v4, v3}, Llx2;->l(Z)V

    iput v1, v2, Lrx;->h:I

    const/4 v1, 0x0

    iput-object v1, v2, Lrx;->z:Ltx;

    iput-object v1, v2, Lrx;->B:Lrx;

    iput-object v1, v2, Lrx;->y:Lhy;

    iget-boolean v1, v2, Lrx;->s:Z

    if-eqz v1, :cond_2

    invoke-virtual {v2}, Lrx;->q()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_2

    :cond_2
    iget-object p0, p0, Landroidx/fragment/app/a;->b:Ll41;

    iget-object p0, p0, Ll41;->l:Ljava/lang/Object;

    check-cast p0, Ljy;

    iget-object v1, p0, Ljy;->c:Ljava/util/HashMap;

    iget-object v3, v2, Lrx;->l:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    iget-boolean v1, p0, Ljy;->f:Z

    if-eqz v1, :cond_4

    iget-boolean p0, p0, Ljy;->g:Z

    goto :goto_1

    :cond_4
    :goto_0
    const/4 p0, 0x1

    :goto_1
    if-eqz p0, :cond_6

    :goto_2
    invoke-static {v0}, Lhy;->F(I)Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_5
    invoke-virtual {v2}, Lrx;->o()V

    :cond_6
    return-void

    :cond_7
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v1, " did not call through to super.onDetach()"

    invoke-static {v0, v2, v1}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final j()V
    .locals 4

    iget-object v0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-boolean v1, v0, Lrx;->t:Z

    if-eqz v1, :cond_2

    iget-boolean v1, v0, Lrx;->u:Z

    if-eqz v1, :cond_2

    iget-boolean v1, v0, Lrx;->w:Z

    if-nez v1, :cond_2

    const/4 v1, 0x3

    invoke-static {v1}, Lhy;->F(I)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v1, v0, Lrx;->i:Landroid/os/Bundle;

    invoke-virtual {v0, v1}, Lrx;->y(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    move-result-object v1

    const/4 v2, 0x0

    iget-object v3, v0, Lrx;->i:Landroid/os/Bundle;

    invoke-virtual {v0, v1, v2, v3}, Lrx;->G(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    if-eqz v1, :cond_2

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setSaveFromParentEnabled(Z)V

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    const v3, 0x7f09008b

    invoke-virtual {v1, v3, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    iget-boolean v1, v0, Lrx;->F:Z

    if-eqz v1, :cond_1

    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    const/16 v3, 0x8

    invoke-virtual {v1, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    iget-object v1, v0, Lrx;->L:Landroid/view/View;

    invoke-virtual {v0, v1}, Lrx;->E(Landroid/view/View;)V

    iget-object v1, v0, Lrx;->A:Lhy;

    const/4 v3, 0x2

    invoke-virtual {v1, v3}, Lhy;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v2}, Llx2;->v(Z)V

    iput v3, v0, Lrx;->h:I

    :cond_2
    return-void
.end method

.method public final k()V
    .locals 9

    iget-object v0, p0, Landroidx/fragment/app/a;->b:Ll41;

    iget-boolean v1, p0, Landroidx/fragment/app/a;->d:Z

    const/4 v2, 0x2

    iget-object v3, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v1, :cond_1

    invoke-static {v2}, Lhy;->F(I)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v4, 0x0

    :try_start_0
    iput-boolean v1, p0, Landroidx/fragment/app/a;->d:Z

    move v5, v4

    :goto_0
    invoke-virtual {p0}, Landroidx/fragment/app/a;->d()I

    move-result v6

    iget v7, v3, Lrx;->h:I

    const/4 v8, 0x3

    if-eq v6, v7, :cond_9

    if-le v6, v7, :cond_4

    add-int/lit8 v7, v7, 0x1

    packed-switch v7, :pswitch_data_0

    goto/16 :goto_1

    :pswitch_0
    invoke-virtual {p0}, Landroidx/fragment/app/a;->n()V

    goto/16 :goto_1

    :catchall_0
    move-exception v0

    goto/16 :goto_3

    :pswitch_1
    const/4 v5, 0x6

    iput v5, v3, Lrx;->h:I

    goto/16 :goto_1

    :pswitch_2
    invoke-virtual {p0}, Landroidx/fragment/app/a;->p()V

    goto/16 :goto_1

    :pswitch_3
    iget-object v5, v3, Lrx;->L:Landroid/view/View;

    if-eqz v5, :cond_3

    iget-object v5, v3, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz v5, :cond_3

    invoke-virtual {v3}, Lrx;->l()Lhy;

    move-result-object v6

    invoke-virtual {v6}, Lhy;->E()Ljs;

    move-result-object v6

    invoke-static {v5, v6}, Lfp;->f(Landroid/view/ViewGroup;Ljs;)Lfp;

    move-result-object v5

    iget-object v6, v3, Lrx;->L:Landroid/view/View;

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v6

    invoke-static {v6}, Lq60;->b(I)I

    move-result v6

    invoke-static {v2}, Lhy;->F(I)Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_2
    invoke-virtual {v5, v6, v2, p0}, Lfp;->a(IILandroidx/fragment/app/a;)V

    :cond_3
    const/4 v5, 0x4

    iput v5, v3, Lrx;->h:I

    goto/16 :goto_1

    :pswitch_4
    invoke-virtual {p0}, Landroidx/fragment/app/a;->a()V

    goto/16 :goto_1

    :pswitch_5
    invoke-virtual {p0}, Landroidx/fragment/app/a;->j()V

    invoke-virtual {p0}, Landroidx/fragment/app/a;->f()V

    goto/16 :goto_1

    :pswitch_6
    invoke-virtual {p0}, Landroidx/fragment/app/a;->e()V

    goto :goto_1

    :pswitch_7
    invoke-virtual {p0}, Landroidx/fragment/app/a;->c()V

    goto :goto_1

    :cond_4
    add-int/lit8 v7, v7, -0x1

    packed-switch v7, :pswitch_data_1

    goto :goto_1

    :pswitch_8
    invoke-virtual {p0}, Landroidx/fragment/app/a;->l()V

    goto :goto_1

    :pswitch_9
    const/4 v5, 0x5

    iput v5, v3, Lrx;->h:I

    goto :goto_1

    :pswitch_a
    invoke-virtual {p0}, Landroidx/fragment/app/a;->q()V

    goto :goto_1

    :pswitch_b
    invoke-static {v8}, Lhy;->F(I)Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_5
    iget-object v5, v3, Lrx;->L:Landroid/view/View;

    if-eqz v5, :cond_6

    iget-object v5, v3, Lrx;->j:Landroid/util/SparseArray;

    if-nez v5, :cond_6

    invoke-virtual {p0}, Landroidx/fragment/app/a;->o()V

    :cond_6
    iget-object v5, v3, Lrx;->L:Landroid/view/View;

    if-eqz v5, :cond_8

    iget-object v5, v3, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz v5, :cond_8

    invoke-virtual {v3}, Lrx;->l()Lhy;

    move-result-object v6

    invoke-virtual {v6}, Lhy;->E()Ljs;

    move-result-object v6

    invoke-static {v5, v6}, Lfp;->f(Landroid/view/ViewGroup;Ljs;)Lfp;

    move-result-object v5

    invoke-static {v2}, Lhy;->F(I)Z

    move-result v6

    if-eqz v6, :cond_7

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_7
    invoke-virtual {v5, v1, v8, p0}, Lfp;->a(IILandroidx/fragment/app/a;)V

    :cond_8
    iput v8, v3, Lrx;->h:I

    goto :goto_1

    :pswitch_c
    iput-boolean v4, v3, Lrx;->u:Z

    iput v2, v3, Lrx;->h:I

    goto :goto_1

    :pswitch_d
    invoke-virtual {p0}, Landroidx/fragment/app/a;->h()V

    iput v1, v3, Lrx;->h:I

    goto :goto_1

    :pswitch_e
    invoke-virtual {p0}, Landroidx/fragment/app/a;->g()V

    goto :goto_1

    :pswitch_f
    invoke-virtual {p0}, Landroidx/fragment/app/a;->i()V

    :goto_1
    move v5, v1

    goto/16 :goto_0

    :cond_9
    if-nez v5, :cond_d

    const/4 v5, -0x1

    if-ne v7, v5, :cond_d

    iget-boolean v5, v3, Lrx;->s:Z

    if-eqz v5, :cond_d

    invoke-virtual {v3}, Lrx;->q()Z

    move-result v5

    if-nez v5, :cond_d

    invoke-static {v8}, Lhy;->F(I)Z

    move-result v5

    if-eqz v5, :cond_a

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_a
    iget-object v5, v0, Ll41;->l:Ljava/lang/Object;

    check-cast v5, Ljy;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v8}, Lhy;->F(I)Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_b
    iget-object v6, v3, Lrx;->l:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljy;->b(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ll41;->s(Landroidx/fragment/app/a;)V

    invoke-static {v8}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_c
    invoke-virtual {v3}, Lrx;->o()V

    :cond_d
    iget-boolean v0, v3, Lrx;->P:Z

    if-eqz v0, :cond_13

    iget-object v0, v3, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_11

    iget-object v0, v3, Lrx;->K:Landroid/view/ViewGroup;

    if-eqz v0, :cond_11

    invoke-virtual {v3}, Lrx;->l()Lhy;

    move-result-object v5

    invoke-virtual {v5}, Lhy;->E()Ljs;

    move-result-object v5

    invoke-static {v0, v5}, Lfp;->f(Landroid/view/ViewGroup;Ljs;)Lfp;

    move-result-object v0

    iget-boolean v5, v3, Lrx;->F:Z

    if-eqz v5, :cond_f

    invoke-static {v2}, Lhy;->F(I)Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_e
    invoke-virtual {v0, v8, v1, p0}, Lfp;->a(IILandroidx/fragment/app/a;)V

    goto :goto_2

    :cond_f
    invoke-static {v2}, Lhy;->F(I)Z

    move-result v5

    if-eqz v5, :cond_10

    invoke-static {v3}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_10
    invoke-virtual {v0, v2, v1, p0}, Lfp;->a(IILandroidx/fragment/app/a;)V

    :cond_11
    :goto_2
    iget-object v0, v3, Lrx;->y:Lhy;

    if-eqz v0, :cond_12

    iget-boolean v2, v3, Lrx;->r:Z

    if-eqz v2, :cond_12

    invoke-static {v3}, Lhy;->G(Lrx;)Z

    move-result v2

    if-eqz v2, :cond_12

    iput-boolean v1, v0, Lhy;->D:Z

    :cond_12
    iput-boolean v4, v3, Lrx;->P:Z

    iget-object v0, v3, Lrx;->A:Lhy;

    invoke-virtual {v0}, Lhy;->n()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_13
    iput-boolean v4, p0, Landroidx/fragment/app/a;->d:Z

    return-void

    :goto_3
    iput-boolean v4, p0, Landroidx/fragment/app/a;->d:Z

    throw v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch -0x1
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch
.end method

.method public final l()V
    .locals 3

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->A:Lhy;

    const/4 v2, 0x5

    invoke-virtual {v0, v2}, Lhy;->t(I)V

    iget-object v0, v1, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, v1, Lrx;->U:Lry;

    sget-object v2, Ld90;->ON_PAUSE:Ld90;

    invoke-virtual {v0, v2}, Lry;->a(Ld90;)V

    :cond_1
    iget-object v0, v1, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v2, Ld90;->ON_PAUSE:Ld90;

    invoke-virtual {v0, v2}, Landroidx/lifecycle/a;->d(Ld90;)V

    const/4 v0, 0x6

    iput v0, v1, Lrx;->h:I

    const/4 v0, 0x0

    iput-boolean v0, v1, Lrx;->J:Z

    invoke-virtual {v1}, Lrx;->z()V

    iget-boolean v2, v1, Lrx;->J:Z

    if-eqz v2, :cond_2

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v0}, Llx2;->m(Z)V

    return-void

    :cond_2
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onPause()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final m(Ljava/lang/ClassLoader;)V
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-object v0, p0, Lrx;->i:Landroid/os/Bundle;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0, p1}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    iget-object p1, p0, Lrx;->i:Landroid/os/Bundle;

    const-string v0, "android:view_state"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object p1

    iput-object p1, p0, Lrx;->j:Landroid/util/SparseArray;

    iget-object p1, p0, Lrx;->i:Landroid/os/Bundle;

    const-string v0, "android:view_registry_state"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    iput-object p1, p0, Lrx;->k:Landroid/os/Bundle;

    iget-object p1, p0, Lrx;->i:Landroid/os/Bundle;

    const-string v0, "android:target_state"

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lrx;->o:Ljava/lang/String;

    if-eqz p1, :cond_1

    iget-object p1, p0, Lrx;->i:Landroid/os/Bundle;

    const-string v0, "android:target_req_state"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Lrx;->p:I

    :cond_1
    iget-object p1, p0, Lrx;->i:Landroid/os/Bundle;

    const-string v0, "android:user_visible_hint"

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    iput-boolean p1, p0, Lrx;->N:Z

    if-nez p1, :cond_2

    iput-boolean v1, p0, Lrx;->M:Z

    :cond_2
    :goto_0
    return-void
.end method

.method public final n()V
    .locals 6

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->O:Lpx;

    const/4 v2, 0x0

    if-nez v0, :cond_1

    move-object v0, v2

    goto :goto_0

    :cond_1
    iget-object v0, v0, Lpx;->k:Landroid/view/View;

    :goto_0
    if-eqz v0, :cond_4

    iget-object v3, v1, Lrx;->L:Landroid/view/View;

    if-ne v0, v3, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    :goto_1
    if-eqz v3, :cond_4

    iget-object v4, v1, Lrx;->L:Landroid/view/View;

    if-ne v3, v4, :cond_3

    :goto_2
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    const/4 v3, 0x2

    invoke-static {v3}, Lhy;->F(I)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    iget-object v0, v1, Lrx;->L:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    goto :goto_3

    :cond_3
    invoke-interface {v3}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    goto :goto_1

    :cond_4
    :goto_3
    invoke-virtual {v1}, Lrx;->g()Lpx;

    move-result-object v0

    iput-object v2, v0, Lpx;->k:Landroid/view/View;

    iget-object v0, v1, Lrx;->A:Lhy;

    invoke-virtual {v0}, Lhy;->M()V

    iget-object v0, v1, Lrx;->A:Lhy;

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lhy;->x(Z)Z

    const/4 v0, 0x7

    iput v0, v1, Lrx;->h:I

    const/4 v3, 0x0

    iput-boolean v3, v1, Lrx;->J:Z

    invoke-virtual {v1}, Lrx;->A()V

    iget-boolean v4, v1, Lrx;->J:Z

    if-eqz v4, :cond_6

    iget-object v4, v1, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v5, Ld90;->ON_RESUME:Ld90;

    invoke-virtual {v4, v5}, Landroidx/lifecycle/a;->d(Ld90;)V

    iget-object v4, v1, Lrx;->L:Landroid/view/View;

    if-eqz v4, :cond_5

    iget-object v4, v1, Lrx;->U:Lry;

    iget-object v4, v4, Lry;->j:Landroidx/lifecycle/a;

    invoke-virtual {v4, v5}, Landroidx/lifecycle/a;->d(Ld90;)V

    :cond_5
    iget-object v4, v1, Lrx;->A:Lhy;

    iput-boolean v3, v4, Lhy;->E:Z

    iput-boolean v3, v4, Lhy;->F:Z

    iget-object v5, v4, Lhy;->L:Ljy;

    iput-boolean v3, v5, Ljy;->h:Z

    invoke-virtual {v4, v0}, Lhy;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v3}, Llx2;->r(Z)V

    iput-object v2, v1, Lrx;->i:Landroid/os/Bundle;

    iput-object v2, v1, Lrx;->j:Landroid/util/SparseArray;

    iput-object v2, v1, Lrx;->k:Landroid/os/Bundle;

    return-void

    :cond_6
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onResume()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final o()V
    .locals 2

    iget-object p0, p0, Landroidx/fragment/app/a;->c:Lrx;

    iget-object v0, p0, Lrx;->L:Landroid/view/View;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x2

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    iget-object v0, p0, Lrx;->L:Landroid/view/View;

    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_1
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iget-object v1, p0, Lrx;->L:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v1

    if-lez v1, :cond_2

    iput-object v0, p0, Lrx;->j:Landroid/util/SparseArray;

    :cond_2
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lrx;->U:Lry;

    iget-object v1, v1, Lry;->k:Lyy;

    invoke-virtual {v1, v0}, Lyy;->e(Landroid/os/Bundle;)V

    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3

    iput-object v0, p0, Lrx;->k:Landroid/os/Bundle;

    :cond_3
    :goto_0
    return-void
.end method

.method public final p()V
    .locals 5

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->A:Lhy;

    invoke-virtual {v0}, Lhy;->M()V

    iget-object v0, v1, Lrx;->A:Lhy;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lhy;->x(Z)Z

    const/4 v0, 0x5

    iput v0, v1, Lrx;->h:I

    const/4 v2, 0x0

    iput-boolean v2, v1, Lrx;->J:Z

    invoke-virtual {v1}, Lrx;->C()V

    iget-boolean v3, v1, Lrx;->J:Z

    if-eqz v3, :cond_2

    iget-object v3, v1, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v4, Ld90;->ON_START:Ld90;

    invoke-virtual {v3, v4}, Landroidx/lifecycle/a;->d(Ld90;)V

    iget-object v3, v1, Lrx;->L:Landroid/view/View;

    if-eqz v3, :cond_1

    iget-object v3, v1, Lrx;->U:Lry;

    iget-object v3, v3, Lry;->j:Landroidx/lifecycle/a;

    invoke-virtual {v3, v4}, Landroidx/lifecycle/a;->d(Ld90;)V

    :cond_1
    iget-object v1, v1, Lrx;->A:Lhy;

    iput-boolean v2, v1, Lhy;->E:Z

    iput-boolean v2, v1, Lhy;->F:Z

    iget-object v3, v1, Lhy;->L:Ljy;

    iput-boolean v2, v3, Ljy;->h:Z

    invoke-virtual {v1, v0}, Lhy;->t(I)V

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v2}, Llx2;->t(Z)V

    return-void

    :cond_2
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onStart()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final q()V
    .locals 4

    const/4 v0, 0x3

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    iget-object v1, p0, Landroidx/fragment/app/a;->c:Lrx;

    if-eqz v0, :cond_0

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    iget-object v0, v1, Lrx;->A:Lhy;

    const/4 v2, 0x1

    iput-boolean v2, v0, Lhy;->F:Z

    iget-object v3, v0, Lhy;->L:Ljy;

    iput-boolean v2, v3, Ljy;->h:Z

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Lhy;->t(I)V

    iget-object v0, v1, Lrx;->L:Landroid/view/View;

    if-eqz v0, :cond_1

    iget-object v0, v1, Lrx;->U:Lry;

    sget-object v3, Ld90;->ON_STOP:Ld90;

    invoke-virtual {v0, v3}, Lry;->a(Ld90;)V

    :cond_1
    iget-object v0, v1, Lrx;->T:Landroidx/lifecycle/a;

    sget-object v3, Ld90;->ON_STOP:Ld90;

    invoke-virtual {v0, v3}, Landroidx/lifecycle/a;->d(Ld90;)V

    iput v2, v1, Lrx;->h:I

    const/4 v0, 0x0

    iput-boolean v0, v1, Lrx;->J:Z

    invoke-virtual {v1}, Lrx;->D()V

    iget-boolean v2, v1, Lrx;->J:Z

    if-eqz v2, :cond_2

    iget-object p0, p0, Landroidx/fragment/app/a;->a:Llx2;

    invoke-virtual {p0, v0}, Llx2;->u(Z)V

    return-void

    :cond_2
    new-instance p0, Lx01;

    const-string v0, "Fragment "

    const-string v2, " did not call through to super.onStop()"

    invoke-static {v0, v1, v2}, Loj;->l(Ljava/lang/String;Lrx;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
