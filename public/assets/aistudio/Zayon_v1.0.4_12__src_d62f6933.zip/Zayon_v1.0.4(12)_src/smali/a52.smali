.class public final La52;
.super Lng4;
.source "SourceFile"


# static fields
.field public static final zza:I = 0x1

.field public static final zzb:I = 0x2

.field private static final zzf:La52;


# instance fields
.field private zzc:I

.field private zzd:I

.field private zze:Lrg4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La52;

    invoke-direct {v0}, La52;-><init>()V

    sput-object v0, La52;->zzf:La52;

    const-class v1, La52;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Log4;->l:Log4;

    iput-object v0, p0, La52;->zze:Lrg4;

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lh42;

    sget-object p1, La52;->zzf:La52;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, La52;

    invoke-direct {p0}, La52;-><init>()V

    return-object p0

    :cond_2
    sget-object p0, Lnv1;->y:Lnv1;

    const-string p1, "zze"

    const-string p2, "zzc"

    const-string v0, "zzd"

    filled-new-array {p2, v0, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, La52;->zzf:La52;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u180c\u0000\u0002\u0016"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method
