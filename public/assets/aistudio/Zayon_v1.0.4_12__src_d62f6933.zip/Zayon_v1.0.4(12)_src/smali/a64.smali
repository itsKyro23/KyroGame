.class public final La64;
.super Lk24;
.source "SourceFile"


# instance fields
.field public final a:Loo4;


# direct methods
.method public constructor <init>(Loo4;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La64;->a:Loo4;

    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 1

    iget-object p0, p0, La64;->a:Loo4;

    iget-object p0, p0, Loo4;->k:Ljava/lang/Object;

    check-cast p0, Lm24;

    sget-object v0, Lm24;->f:Lm24;

    if-eq p0, v0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    instance-of v0, p1, La64;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    check-cast p1, La64;

    iget-object p1, p1, La64;->a:Loo4;

    iget-object p0, p0, La64;->a:Loo4;

    iget-object v0, p0, Loo4;->k:Ljava/lang/Object;

    check-cast v0, Lm24;

    iget-object v2, p1, Loo4;->k:Ljava/lang/Object;

    check-cast v2, Lm24;

    if-eq v0, v2, :cond_1

    return v1

    :cond_1
    iget-object v0, p0, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v2, p1, Loo4;->j:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p0, p0, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Lyf4;

    iget-object p1, p1, Loo4;->i:Ljava/lang/Object;

    check-cast p1, Lyf4;

    invoke-virtual {p0, p1}, Lyf4;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    const/4 p0, 0x1

    return p0

    :cond_2
    :goto_0
    return v1
.end method

.method public final hashCode()I
    .locals 2

    iget-object p0, p0, La64;->a:Loo4;

    iget-object v0, p0, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Loo4;->i:Ljava/lang/Object;

    check-cast v1, Lyf4;

    iget-object p0, p0, Loo4;->k:Ljava/lang/Object;

    check-cast p0, Lm24;

    filled-new-array {v0, v1, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    iget-object p0, p0, La64;->a:Loo4;

    iget-object v0, p0, Loo4;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object p0, p0, Loo4;->k:Ljava/lang/Object;

    check-cast p0, Lm24;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "(typeUrl="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", outputPrefixType="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
