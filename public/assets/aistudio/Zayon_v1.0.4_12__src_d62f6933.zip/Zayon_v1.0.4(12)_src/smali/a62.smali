.class public final La62;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final synthetic a:I

.field public final b:Lxk4;

.field public final c:Lsk4;

.field public final d:Lxk4;


# direct methods
.method public synthetic constructor <init>(Lsk4;Ljava/lang/Object;Lxk4;I)V
    .locals 0

    iput p4, p0, La62;->a:I

    iput-object p1, p0, La62;->c:Lsk4;

    check-cast p2, Lxk4;

    iput-object p2, p0, La62;->b:Lxk4;

    iput-object p3, p0, La62;->d:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltk4;Lsk4;Lxk4;I)V
    .locals 0

    .line 14
    iput p4, p0, La62;->a:I

    iput-object p1, p0, La62;->b:Lxk4;

    iput-object p2, p0, La62;->c:Lsk4;

    iput-object p3, p0, La62;->d:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lxk4;Lxk4;Lsk4;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, La62;->a:I

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La62;->b:Lxk4;

    iput-object p2, p0, La62;->d:Lxk4;

    iput-object p3, p0, La62;->c:Lsk4;

    return-void
.end method


# virtual methods
.method public final d()Ljava/lang/Object;
    .locals 11

    iget v0, p0, La62;->a:I

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v3, p0, La62;->d:Lxk4;

    iget-object v4, p0, La62;->b:Lxk4;

    iget-object p0, p0, La62;->c:Lsk4;

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/io/File;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lxp3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lju3;

    new-array v2, v2, [B

    new-instance v4, Lot3;

    const/4 v5, 0x1

    invoke-direct {v4, v3, v5}, Lot3;-><init>(Lju3;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lwp3;

    new-instance v5, Lfc;

    invoke-direct {v5, v1, v2}, Lfc;-><init>(I[B)V

    iget-object v0, v0, Lxp3;->a:Ljava/util/concurrent/ExecutorService;

    invoke-direct {v3, p0, v0, v5, v4}, Lwp3;-><init>(Ljava/io/File;Ljava/util/concurrent/ExecutorService;Lvp3;Lnv3;)V

    return-object v3

    :pswitch_0
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/io/File;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lxp3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lju3;

    new-array v4, v2, [B

    new-instance v5, Lot3;

    invoke-direct {v5, v3, v2}, Lot3;-><init>(Lju3;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lwp3;

    new-instance v3, Lfc;

    invoke-direct {v3, v1, v4}, Lfc;-><init>(I[B)V

    iget-object v0, v0, Lxp3;->a:Ljava/util/concurrent/ExecutorService;

    invoke-direct {v2, p0, v0, v3, v5}, Lwp3;-><init>(Ljava/io/File;Ljava/util/concurrent/ExecutorService;Lvp3;Lnv3;)V

    return-object v2

    :pswitch_1
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/io/File;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lxp3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lju3;

    invoke-static {}, Liq3;->F()Liq3;

    move-result-object v3

    new-instance v4, Lot3;

    invoke-direct {v4, v2, v1}, Lot3;-><init>(Lju3;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lwp3;

    new-instance v2, Ld03;

    const/16 v5, 0xc

    invoke-direct {v2, v5, v3}, Ld03;-><init>(ILjava/lang/Object;)V

    iget-object v0, v0, Lxp3;->a:Ljava/util/concurrent/ExecutorService;

    invoke-direct {v1, p0, v0, v2, v4}, Lwp3;-><init>(Ljava/io/File;Ljava/util/concurrent/ExecutorService;Lvp3;Lnv3;)V

    return-object v1

    :pswitch_2
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lns3;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lju3;

    new-instance v2, Lkt3;

    invoke-direct {v2, p0, v0, v1}, Lkt3;-><init>(Lns3;Ljava/util/concurrent/ExecutorService;Lju3;)V

    return-object v2

    :pswitch_3
    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    invoke-static {p0}, Lsk4;->b(Lxk4;)Lnk4;

    move-result-object p0

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lju3;

    new-instance v3, Lns3;

    const-string v4, "pcvmspf2"

    invoke-virtual {v0, v4, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    invoke-direct {v3, v0, v2, p0, v1}, Lns3;-><init>(Landroid/content/Context;Landroid/content/SharedPreferences;Lnk4;Lju3;)V

    return-object v3

    :pswitch_4
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ls23;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, La33;

    check-cast v3, Lfn2;

    invoke-virtual {v3}, Lfn2;->a()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Lq23;

    invoke-direct {v2, p0, v0, v1}, Lq23;-><init>(Ls23;La33;Landroid/content/Context;)V

    return-object v2

    :pswitch_5
    check-cast v4, Lmn2;

    invoke-virtual {v4}, Lmn2;->a()Lw61;

    move-result-object v7

    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lorg/json/JSONObject;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Ljava/lang/String;

    const-string p0, "native"

    invoke-virtual {p0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    new-instance v5, Ln12;

    sget-object p0, Lcw4;->B:Lcw4;

    iget-object p0, p0, Lcw4;->c:Lzu4;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct/range {v5 .. v10}, Ln12;-><init>(Ljava/lang/String;Lw61;Ljava/lang/String;Lorg/json/JSONObject;Z)V

    return-object v5

    :pswitch_6
    check-cast v4, Lfn2;

    invoke-virtual {v4}, Lfn2;->a()Landroid/content/Context;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lmi3;

    new-instance p0, Lz52;

    invoke-direct {p0, v0}, Lz52;-><init>(Ljava/util/concurrent/ScheduledExecutorService;)V

    return-object p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
