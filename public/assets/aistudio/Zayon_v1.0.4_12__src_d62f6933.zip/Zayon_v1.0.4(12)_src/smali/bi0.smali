.class public final Lbi0;
.super Lbb0;
.source "SourceFile"

# interfaces
.implements Lr50;


# virtual methods
.method public final b()Z
    .locals 0

    const/4 p0, 0x1

    return p0
.end method

.method public final d()Lbi0;
    .locals 0

    return-object p0
.end method

.method public final k()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method
