.class public final La01;
.super Llj;
.source "SourceFile"


# instance fields
.field public k:Lb01;

.field public l:Lcw;

.field public m:Lc01;

.field public n:Le80;

.field public o:Ljava/lang/Object;

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Lb01;

.field public r:I


# direct methods
.method public constructor <init>(Lb01;Llj;)V
    .locals 0

    iput-object p1, p0, La01;->q:Lb01;

    invoke-direct {p0, p2}, Llj;-><init>(Ljj;)V

    return-void
.end method


# virtual methods
.method public final m(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, La01;->p:Ljava/lang/Object;

    iget p1, p0, La01;->r:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, La01;->r:I

    iget-object p1, p0, La01;->q:Lb01;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lb01;->E(Lcw;Llj;)Ljava/lang/Object;

    sget-object p0, Lbk;->h:Lbk;

    return-object p0
.end method
