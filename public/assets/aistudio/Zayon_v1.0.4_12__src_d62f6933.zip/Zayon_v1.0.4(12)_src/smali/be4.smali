.class public final Lbe4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp24;


# instance fields
.field public final a:Lp64;


# direct methods
.method public constructor <init>(Lp64;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbe4;->a:Lp64;

    return-void
.end method


# virtual methods
.method public final b([B[B)V
    .locals 1

    iget-object p0, p0, Lbe4;->a:Lp64;

    invoke-virtual {p0, p1}, Lp64;->a([B)Ljava/lang/Iterable;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :catch_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lce4;

    :try_start_0
    iget-object v0, v0, Lce4;->a:Lp24;

    invoke-interface {v0, p1, p2}, Lp24;->b([B[B)V
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :cond_0
    const-string p0, "invalid signature"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-void
.end method
