.class public final Lbr2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lhu2;


# instance fields
.field public final h:Lsl2;

.field public final i:Lu23;

.field public final j:Lbg3;


# direct methods
.method public constructor <init>(Lsl2;Lu23;Lbg3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbr2;->h:Lsl2;

    iput-object p2, p0, Lbr2;->i:Lu23;

    iput-object p3, p0, Lbr2;->j:Lbg3;

    return-void
.end method


# virtual methods
.method public final t0()V
    .locals 4

    sget-object v0, Lk52;->Le:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lbr2;->h:Lsl2;

    if-eqz v0, :cond_2

    invoke-interface {v0}, Lsl2;->j0()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    :goto_0
    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "androidx.compose.ui"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v0, "1"

    goto :goto_1

    :cond_0
    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    goto :goto_0

    :cond_1
    const-string v0, "0"

    :goto_1
    iget-object v1, p0, Lbr2;->i:Lu23;

    invoke-virtual {v1}, Lu23;->a()Lry2;

    move-result-object v1

    const-string v2, "action"

    const-string v3, "hcp"

    invoke-virtual {v1, v2, v3}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v3, v0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, Lbr2;->j:Lbg3;

    invoke-virtual {v1, p0}, Lry2;->I(Lbg3;)V

    invoke-virtual {v1}, Lry2;->M()V

    :cond_2
    return-void
.end method
