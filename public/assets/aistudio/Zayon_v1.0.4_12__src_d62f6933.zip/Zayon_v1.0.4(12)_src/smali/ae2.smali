.class public final Lae2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final h:Lxc;

.field public final i:Lt72;

.field public final j:Lt72;

.field public final k:I

.field public final synthetic l:Lwc;


# direct methods
.method public constructor <init>(Lwc;Lxc;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lae2;->l:Lwc;

    iget-object p1, p1, Lwc;->E:Lvm;

    new-instance v0, Lt72;

    invoke-direct {v0, p1}, Lt72;-><init>(Lvm;)V

    iput-object v0, p0, Lae2;->i:Lt72;

    new-instance v0, Lt72;

    invoke-direct {v0, p1}, Lt72;-><init>(Lvm;)V

    iput-object v0, p0, Lae2;->j:Lt72;

    iput-object p2, p0, Lae2;->h:Lxc;

    iput p3, p0, Lae2;->k:I

    return-void
.end method


# virtual methods
.method public final a(Z)Ljava/lang/Long;
    .locals 11

    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v0, v0, Lwc;->a:Ljava/lang/Object;

    const-wide/32 v1, 0xf4240

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    :try_start_0
    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    iget-object p0, p0, Lae2;->i:Lt72;

    iget-boolean p1, p0, Lt72;->i:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Lt72;->l:Ljava/lang/Object;

    check-cast p1, Lvm;

    invoke-virtual {p1}, Lvm;->l()J

    move-result-wide v5

    iget-boolean p1, p0, Lt72;->i:Z

    const-string v7, "This stopwatch is already stopped."

    if-eqz p1, :cond_0

    iput-boolean v3, p0, Lt72;->i:Z

    iget-wide v7, p0, Lt72;->j:J

    iget-wide v9, p0, Lt72;->k:J

    sub-long/2addr v5, v9

    add-long/2addr v5, v7

    iput-wide v5, p0, Lt72;->j:J

    div-long/2addr v5, v1

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    monitor-exit v0

    return-object v4

    :goto_0
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    throw p0

    :cond_2
    monitor-enter v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    iget-object p0, p0, Lae2;->j:Lt72;

    iget-boolean p1, p0, Lt72;->i:Z

    if-eqz p1, :cond_4

    iget-object p1, p0, Lt72;->l:Ljava/lang/Object;

    check-cast p1, Lvm;

    invoke-virtual {p1}, Lvm;->l()J

    move-result-wide v5

    iget-boolean p1, p0, Lt72;->i:Z

    const-string v7, "This stopwatch is already stopped."

    if-eqz p1, :cond_3

    iput-boolean v3, p0, Lt72;->i:Z

    iget-wide v7, p0, Lt72;->j:J

    iget-wide v9, p0, Lt72;->k:J

    sub-long/2addr v5, v9

    add-long/2addr v5, v7

    iput-wide v5, p0, Lt72;->j:J

    div-long/2addr v5, v1

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    monitor-exit v0

    return-object p0

    :catchall_1
    move-exception p0

    goto :goto_1

    :cond_3
    new-instance p0, Ljava/lang/IllegalStateException;

    invoke-direct {p0, v7}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    monitor-exit v0

    return-object v4

    :goto_1
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :catchall_2
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-object v4
.end method

.method public final b(Lad;ILjava/lang/String;ZI)V
    .locals 3

    :try_start_0
    invoke-static {}, Lrm4;->q()Lnm4;

    move-result-object v0

    iget v1, p1, Lad;->a:I

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v2, v0, Lmr3;->i:Lus3;

    check-cast v2, Lrm4;

    invoke-static {v2, v1}, Lrm4;->p(Lrm4;I)V

    iget-object p1, p1, Lad;->c:Ljava/lang/String;

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v1, v0, Lmr3;->i:Lus3;

    check-cast v1, Lrm4;

    invoke-static {v1, p1}, Lrm4;->s(Lrm4;Ljava/lang/String;)V

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p1, v0, Lmr3;->i:Lus3;

    check-cast p1, Lrm4;

    invoke-static {p1, p2}, Lrm4;->v(Lrm4;I)V

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p1, v0, Lmr3;->i:Lus3;

    check-cast p1, Lrm4;

    invoke-static {p1, p5}, Lrm4;->t(Lrm4;I)V

    if-eqz p3, :cond_0

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p1, v0, Lmr3;->i:Lus3;

    check-cast p1, Lrm4;

    invoke-static {p1, p3}, Lrm4;->r(Lrm4;Ljava/lang/String;)V

    :cond_0
    invoke-virtual {p0, p4}, Lae2;->a(Z)Ljava/lang/Long;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object p2, p0, Lae2;->l:Lwc;

    if-eqz p4, :cond_3

    :try_start_1
    invoke-static {}, Lfp4;->p()Lcp4;

    move-result-object p3

    iget p0, p0, Lae2;->k:I

    if-lez p0, :cond_1

    const/4 p4, 0x1

    goto :goto_0

    :cond_1
    const/4 p4, 0x0

    :goto_0
    invoke-virtual {p3, p4}, Lcp4;->c(Z)V

    invoke-virtual {p3, p0}, Lcp4;->d(I)V

    invoke-virtual {p3}, Lmr3;->b()V

    iget-object p0, p3, Lmr3;->i:Lus3;

    check-cast p0, Lfp4;

    invoke-static {p0, p5}, Lfp4;->t(Lfp4;I)V

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    invoke-virtual {p3}, Lmr3;->b()V

    iget-object p4, p3, Lmr3;->i:Lus3;

    check-cast p4, Lfp4;

    invoke-static {p4, p0, p1}, Lfp4;->s(Lfp4;J)V

    :cond_2
    invoke-static {}, Lgm4;->s()Ldm4;

    move-result-object p0

    invoke-virtual {p0, v0}, Ldm4;->c(Lnm4;)V

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p1, p0, Lmr3;->i:Lus3;

    check-cast p1, Lgm4;

    const/4 p4, 0x6

    invoke-static {p1, p4}, Lgm4;->r(Lgm4;I)V

    invoke-virtual {p0, p3}, Ldm4;->d(Lcp4;)V

    invoke-virtual {p0}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lgm4;

    invoke-virtual {p2, p0}, Lwc;->t(Lgm4;)V

    return-void

    :cond_3
    invoke-static {}, Lxo4;->p()Lvo4;

    move-result-object p0

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p3, p0, Lmr3;->i:Lus3;

    check-cast p3, Lxo4;

    invoke-virtual {v0}, Lmr3;->a()Lus3;

    move-result-object p4

    check-cast p4, Lrm4;

    invoke-static {p3, p4}, Lxo4;->q(Lxo4;Lrm4;)V

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p3

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p1, p0, Lmr3;->i:Lus3;

    check-cast p1, Lxo4;

    invoke-static {p1, p3, p4}, Lxo4;->r(Lxo4;J)V

    :cond_4
    iget-object p1, p2, Lwc;->h:Ley2;

    invoke-virtual {p0}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lxo4;

    invoke-virtual {p1, p0}, Ley2;->y(Lxo4;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    return-void

    :catchall_0
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-void
.end method

.method public final c(IZ)V
    .locals 5

    :try_start_0
    invoke-virtual {p0, p2}, Lae2;->a(Z)Ljava/lang/Long;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v1, p0, Lae2;->l:Lwc;

    const/4 v2, 0x0

    if-eqz p2, :cond_2

    :try_start_1
    invoke-static {}, Lmm4;->q()Ljm4;

    move-result-object p2

    invoke-virtual {p2}, Lmr3;->b()V

    iget-object v3, p2, Lmr3;->i:Lus3;

    check-cast v3, Lmm4;

    const/4 v4, 0x6

    invoke-static {v3, v4}, Lmm4;->p(Lmm4;I)V

    invoke-static {}, Lfp4;->p()Lcp4;

    move-result-object v3

    iget p0, p0, Lae2;->k:I

    if-lez p0, :cond_0

    const/4 v2, 0x1

    :cond_0
    invoke-virtual {v3, v2}, Lcp4;->c(Z)V

    invoke-virtual {v3, p0}, Lcp4;->d(I)V

    invoke-virtual {v3}, Lmr3;->b()V

    iget-object p0, v3, Lmr3;->i:Lus3;

    check-cast p0, Lfp4;

    invoke-static {p0, p1}, Lfp4;->t(Lfp4;I)V

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    invoke-virtual {v3}, Lmr3;->b()V

    iget-object v0, v3, Lmr3;->i:Lus3;

    check-cast v0, Lfp4;

    invoke-static {v0, p0, p1}, Lfp4;->s(Lfp4;J)V

    :cond_1
    invoke-virtual {p2}, Lmr3;->b()V

    iget-object p0, p2, Lmr3;->i:Lus3;

    check-cast p0, Lmm4;

    invoke-virtual {v3}, Lmr3;->a()Lus3;

    move-result-object p1

    check-cast p1, Lfp4;

    invoke-static {p0, p1}, Lmm4;->u(Lmm4;Lfp4;)V

    invoke-virtual {p2}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lmm4;

    invoke-virtual {v1, p0}, Lwc;->u(Lmm4;)V

    return-void

    :cond_2
    invoke-static {}, Lxo4;->p()Lvo4;

    move-result-object p0

    invoke-static {}, Lrm4;->q()Lnm4;

    move-result-object p2

    invoke-virtual {p2}, Lmr3;->b()V

    iget-object v3, p2, Lmr3;->i:Lus3;

    check-cast v3, Lrm4;

    invoke-static {v3, v2}, Lrm4;->p(Lrm4;I)V

    invoke-virtual {p2}, Lmr3;->b()V

    iget-object v2, p2, Lmr3;->i:Lus3;

    check-cast v2, Lrm4;

    invoke-static {v2, p1}, Lrm4;->t(Lrm4;I)V

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p1, p0, Lmr3;->i:Lus3;

    check-cast p1, Lxo4;

    invoke-virtual {p2}, Lmr3;->a()Lus3;

    move-result-object p2

    check-cast p2, Lrm4;

    invoke-static {p1, p2}, Lxo4;->q(Lxo4;Lrm4;)V

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object v0, p0, Lmr3;->i:Lus3;

    check-cast v0, Lxo4;

    invoke-static {v0, p1, p2}, Lxo4;->r(Lxo4;J)V

    :cond_3
    iget-object p1, v1, Lwc;->h:Ley2;

    invoke-virtual {p0}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lxo4;

    invoke-virtual {p1, p0}, Ley2;->y(Lxo4;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    return-void

    :catchall_0
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-void
.end method

.method public final d(Lad;)V
    .locals 3

    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v1, v0, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget v0, v0, Lwc;->b:I

    const/4 v2, 0x3

    if-ne v0, v2, :cond_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object p0, p0, Lae2;->h:Lxc;

    invoke-interface {p0, p1}, Lxc;->k(Lad;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    return-void

    :catchall_1
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-void

    :goto_0
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public final e(Ljava/lang/Exception;ZI)V
    .locals 8

    const-string v0, "BillingClient"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V

    instance-of v0, p1, Landroid/os/DeadObjectException;

    if-eqz v0, :cond_0

    const/16 v1, 0x84

    :goto_0
    move v4, v1

    goto :goto_1

    :cond_0
    instance-of v1, p1, Landroid/os/RemoteException;

    if-eqz v1, :cond_1

    const/16 v1, 0x86

    goto :goto_0

    :cond_1
    instance-of v1, p1, Ljava/lang/SecurityException;

    if-eqz v1, :cond_2

    const/16 v1, 0x85

    goto :goto_0

    :cond_2
    const/16 v1, 0x83

    goto :goto_0

    :goto_1
    invoke-static {p1}, Lbt2;->a(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v5

    iget-object p1, p0, Lae2;->l:Lwc;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Lwc;->w(I)V

    if-eqz v0, :cond_3

    sget-object p1, Lbv2;->h:Lad;

    :goto_2
    move-object v2, p0

    move-object v3, p1

    move v6, p2

    move v7, p3

    goto :goto_3

    :cond_3
    sget-object p1, Lbv2;->f:Lad;

    goto :goto_2

    :goto_3
    invoke-virtual/range {v2 .. v7}, Lae2;->b(Lad;ILjava/lang/String;ZI)V

    if-eqz v0, :cond_4

    sget-object p0, Lbv2;->h:Lad;

    goto :goto_4

    :cond_4
    sget-object p0, Lbv2;->f:Lad;

    :goto_4
    invoke-virtual {v2, p0}, Lae2;->d(Lad;)V

    return-void
.end method

.method public final f(Ljava/lang/Exception;Z)V
    .locals 9

    const-string v0, "BillingClient"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V

    instance-of v0, p1, Landroid/os/DeadObjectException;

    const/16 v1, 0x2a

    if-eqz v0, :cond_0

    const/16 v2, 0x5b

    :goto_0
    move v5, v2

    goto :goto_1

    :cond_0
    instance-of v2, p1, Landroid/os/RemoteException;

    if-eqz v2, :cond_1

    const/16 v2, 0x5a

    goto :goto_0

    :cond_1
    instance-of v2, p1, Ljava/lang/SecurityException;

    if-eqz v2, :cond_2

    const/16 v2, 0x5c

    goto :goto_0

    :cond_2
    move v5, v1

    :goto_1
    invoke-static {v5, v1}, Loj;->a(II)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-static {p1}, Lbt2;->a(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object p1

    :goto_2
    move-object v6, p1

    goto :goto_3

    :cond_3
    const/4 p1, 0x0

    goto :goto_2

    :goto_3
    iget-object p1, p0, Lae2;->l:Lwc;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Lwc;->w(I)V

    if-eqz v0, :cond_4

    sget-object p1, Lbv2;->h:Lad;

    :goto_4
    move-object v4, p1

    goto :goto_5

    :cond_4
    sget-object p1, Lbv2;->f:Lad;

    goto :goto_4

    :goto_5
    const/4 v8, 0x0

    move-object v3, p0

    move v7, p2

    invoke-virtual/range {v3 .. v8}, Lae2;->b(Lad;ILjava/lang/String;ZI)V

    if-eqz v0, :cond_5

    sget-object p0, Lbv2;->h:Lad;

    goto :goto_6

    :cond_5
    sget-object p0, Lbv2;->f:Lad;

    :goto_6
    invoke-virtual {v3, p0}, Lae2;->d(Lad;)V

    return-void
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 6

    const-string p1, "BillingClient"

    sget v0, Lre2;->a:I

    const/4 v0, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    const/4 p1, 0x0

    :try_start_0
    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v1, v0, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    iget v2, v0, Lwc;->b:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, p1

    :goto_0
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    iget-object v0, v0, Lwc;->h:Ley2;

    if-eqz v2, :cond_2

    :try_start_2
    invoke-static {}, Lgm4;->s()Ldm4;

    move-result-object v1

    invoke-virtual {v1}, Lmr3;->b()V

    iget-object v2, v1, Lmr3;->i:Lus3;

    check-cast v2, Lgm4;

    const/4 v4, 0x6

    invoke-static {v2, v4}, Lgm4;->r(Lgm4;I)V

    invoke-static {}, Lrm4;->q()Lnm4;

    move-result-object v2

    invoke-virtual {v2}, Lmr3;->b()V

    iget-object v4, v2, Lmr3;->i:Lus3;

    check-cast v4, Lrm4;

    const/16 v5, 0x6e

    invoke-static {v4, v5}, Lrm4;->v(Lrm4;I)V

    invoke-virtual {v1, v2}, Ldm4;->c(Lnm4;)V

    invoke-static {}, Lfp4;->p()Lcp4;

    move-result-object v2

    iget v4, p0, Lae2;->k:I

    if-lez v4, :cond_1

    goto :goto_1

    :cond_1
    move v3, p1

    :goto_1
    invoke-virtual {v2, v3}, Lcp4;->c(Z)V

    invoke-virtual {v2, v4}, Lcp4;->d(I)V

    invoke-virtual {v1, v2}, Ldm4;->d(Lcp4;)V

    invoke-virtual {v1}, Lmr3;->a()Lus3;

    move-result-object v1

    check-cast v1, Lgm4;

    invoke-virtual {v0, v1}, Ley2;->e(Lgm4;)V

    goto :goto_2

    :cond_2
    invoke-static {}, Lum4;->p()Lum4;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    invoke-static {}, Lho4;->r()Lfo4;

    move-result-object v2

    iget-object v3, v0, Ley2;->i:Ljava/lang/Object;

    check-cast v3, Lmn4;

    invoke-virtual {v2, v3}, Lfo4;->c(Lmn4;)V

    invoke-virtual {v2}, Lmr3;->b()V

    iget-object v3, v2, Lmr3;->i:Lus3;

    check-cast v3, Lho4;

    invoke-static {v3, v1}, Lho4;->u(Lho4;Lum4;)V

    invoke-virtual {v2}, Lmr3;->a()Lus3;

    move-result-object v1

    check-cast v1, Lho4;

    iget-object v0, v0, Ley2;->j:Ljava/lang/Object;

    check-cast v0, Ldm0;

    invoke-virtual {v0, v1}, Ldm0;->e(Lho4;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_2

    :catchall_0
    :try_start_4
    const-string v0, "BillingLogger"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto :goto_2

    :catchall_1
    move-exception v0

    :try_start_5
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    const-string v0, "BillingClient"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V

    :goto_2
    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v1, v0, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    iget v2, v0, Lwc;->b:I

    const/4 v3, 0x3

    if-eq v2, v3, :cond_4

    iget v2, v0, Lwc;->b:I

    if-nez v2, :cond_3

    goto :goto_3

    :cond_3
    invoke-virtual {v0, p1}, Lwc;->w(I)V

    invoke-virtual {v0}, Lwc;->y()V

    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    :try_start_8
    iget-object p0, p0, Lae2;->h:Lxc;

    invoke-interface {p0}, Lxc;->m()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    goto :goto_4

    :catchall_3
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-void

    :catchall_4
    move-exception p0

    goto :goto_5

    :cond_4
    :goto_3
    :try_start_9
    monitor-exit v1

    :goto_4
    return-void

    :goto_5
    monitor-exit v1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    throw p0
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 8

    const-string p1, "BillingClient"

    const-string v0, "Billing service connected."

    invoke-static {p1, v0}, Lre2;->g(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p1, p0, Lae2;->l:Lwc;

    iget-object v1, p1, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget v0, p1, Lwc;->b:I

    const/4 v2, 0x3

    if-ne v0, v2, :cond_0

    monitor-exit v1

    return-void

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_3

    :cond_0
    sget v0, Lsq1;->i:I

    const-string v0, "com.android.vending.billing.IInAppBillingService"

    if-nez p2, :cond_1

    const/4 p2, 0x0

    goto :goto_0

    :cond_1
    invoke-interface {p2, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v3

    instance-of v4, v3, Lkr1;

    if-eqz v4, :cond_2

    move-object p2, v3

    check-cast p2, Lkr1;

    goto :goto_0

    :cond_2
    new-instance v3, Ltp1;

    invoke-direct {v3, p2, v0, v2}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    move-object p2, v3

    :goto_0
    iput-object p2, p1, Lwc;->i:Lkr1;

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    new-instance v2, Lvy1;

    const/4 p2, 0x2

    invoke-direct {v2, p2, p0}, Lvy1;-><init>(ILjava/lang/Object;)V

    new-instance v5, Lsh1;

    const/16 p2, 0x13

    invoke-direct {v5, p2, p0}, Lsh1;-><init>(ILjava/lang/Object;)V

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p2

    if-nez p2, :cond_3

    iget-object p2, p1, Lwc;->e:Landroid/os/Handler;

    :goto_1
    move-object v6, p2

    goto :goto_2

    :cond_3
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    goto :goto_1

    :goto_2
    invoke-virtual {p1}, Lwc;->d()Ljava/util/concurrent/ExecutorService;

    move-result-object v7

    const-wide/16 v3, 0x7530

    invoke-static/range {v2 .. v7}, Lwc;->e(Ljava/util/concurrent/Callable;JLjava/lang/Runnable;Landroid/os/Handler;Ljava/util/concurrent/ExecutorService;)Ljava/util/concurrent/Future;

    move-result-object p2

    if-nez p2, :cond_4

    iget p2, p0, Lae2;->k:I

    invoke-virtual {p1}, Lwc;->h()Lad;

    move-result-object v0

    const/16 v1, 0x19

    invoke-virtual {p1, v1, p2, v0}, Lwc;->v(IILad;)V

    invoke-virtual {p0, v0}, Lae2;->d(Lad;)V

    :cond_4
    return-void

    :goto_3
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 6

    const-string p1, "BillingClient"

    sget v0, Lre2;->a:I

    const/4 v0, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    const/4 p1, 0x0

    :try_start_0
    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v1, v0, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    iget v2, v0, Lwc;->b:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    move v2, v3

    goto :goto_0

    :cond_0
    move v2, p1

    :goto_0
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    iget-object v0, v0, Lwc;->h:Ley2;

    if-eqz v2, :cond_2

    :try_start_2
    invoke-static {}, Lgm4;->s()Ldm4;

    move-result-object v1

    invoke-virtual {v1}, Lmr3;->b()V

    iget-object v2, v1, Lmr3;->i:Lus3;

    check-cast v2, Lgm4;

    const/4 v4, 0x6

    invoke-static {v2, v4}, Lgm4;->r(Lgm4;I)V

    invoke-static {}, Lrm4;->q()Lnm4;

    move-result-object v2

    invoke-virtual {v2}, Lmr3;->b()V

    iget-object v4, v2, Lmr3;->i:Lus3;

    check-cast v4, Lrm4;

    const/16 v5, 0x6d

    invoke-static {v4, v5}, Lrm4;->v(Lrm4;I)V

    invoke-virtual {v1, v2}, Ldm4;->c(Lnm4;)V

    invoke-static {}, Lfp4;->p()Lcp4;

    move-result-object v2

    iget v4, p0, Lae2;->k:I

    if-lez v4, :cond_1

    goto :goto_1

    :cond_1
    move v3, p1

    :goto_1
    invoke-virtual {v2, v3}, Lcp4;->c(Z)V

    invoke-virtual {v2, v4}, Lcp4;->d(I)V

    invoke-virtual {v1, v2}, Ldm4;->d(Lcp4;)V

    invoke-virtual {v1}, Lmr3;->a()Lus3;

    move-result-object v1

    check-cast v1, Lgm4;

    invoke-virtual {v0, v1}, Ley2;->e(Lgm4;)V

    goto :goto_2

    :cond_2
    invoke-static {}, Lap4;->p()Lap4;

    move-result-object v1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    if-nez v1, :cond_3

    goto :goto_2

    :cond_3
    :try_start_3
    invoke-static {}, Lho4;->r()Lfo4;

    move-result-object v2

    iget-object v3, v0, Ley2;->i:Ljava/lang/Object;

    check-cast v3, Lmn4;

    invoke-virtual {v2, v3}, Lfo4;->c(Lmn4;)V

    invoke-virtual {v2}, Lmr3;->b()V

    iget-object v3, v2, Lmr3;->i:Lus3;

    check-cast v3, Lho4;

    invoke-static {v3, v1}, Lho4;->q(Lho4;Lap4;)V

    iget-object v0, v0, Ley2;->j:Ljava/lang/Object;

    check-cast v0, Ldm0;

    invoke-virtual {v2}, Lmr3;->a()Lus3;

    move-result-object v1

    check-cast v1, Lho4;

    invoke-virtual {v0, v1}, Ldm0;->e(Lho4;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_2

    :catchall_0
    :try_start_4
    const-string v0, "BillingLogger"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    goto :goto_2

    :catchall_1
    move-exception v0

    :try_start_5
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :try_start_6
    throw v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    const-string v0, "BillingClient"

    invoke-static {v0}, Lre2;->h(Ljava/lang/String;)V

    :goto_2
    iget-object v0, p0, Lae2;->l:Lwc;

    iget-object v1, v0, Lwc;->a:Ljava/lang/Object;

    monitor-enter v1

    :try_start_7
    sget-boolean v2, Lb64;->n:Z

    const-wide/16 v3, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_6

    iget v2, v0, Lwc;->b:I

    if-eq v2, v5, :cond_5

    iget v2, v0, Lwc;->b:I

    if-nez v2, :cond_4

    goto :goto_3

    :cond_4
    iget-object v2, p0, Lae2;->j:Lt72;

    iput-wide v3, v2, Lt72;->j:J

    iput-boolean p1, v2, Lt72;->i:Z

    invoke-virtual {v2}, Lt72;->c()V

    goto :goto_4

    :catchall_3
    move-exception p0

    goto :goto_6

    :cond_5
    :goto_3
    monitor-exit v1

    goto :goto_5

    :cond_6
    iget-object v2, p0, Lae2;->j:Lt72;

    iput-wide v3, v2, Lt72;->j:J

    iput-boolean p1, v2, Lt72;->i:Z

    invoke-virtual {v2}, Lt72;->c()V

    iget v2, v0, Lwc;->b:I

    if-ne v2, v5, :cond_7

    monitor-exit v1

    goto :goto_5

    :cond_7
    :goto_4
    invoke-virtual {v0, p1}, Lwc;->w(I)V

    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    :try_start_8
    iget-object p0, p0, Lae2;->h:Lxc;

    invoke-interface {p0}, Lxc;->m()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    :goto_5
    return-void

    :catchall_4
    const-string p0, "BillingClient"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-void

    :goto_6
    :try_start_9
    monitor-exit v1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    throw p0
.end method
