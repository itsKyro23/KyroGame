.class public abstract Lbf4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public b()Ljava/lang/String;
    .locals 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-virtual {p0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()Ldf4;
    .locals 1

    instance-of v0, p0, Ldf4;

    if-eqz v0, :cond_0

    check-cast p0, Ldf4;

    return-object p0

    :cond_0
    invoke-virtual {p0}, Lbf4;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "Not a JSON Object: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final d()Lff4;
    .locals 1

    instance-of v0, p0, Lff4;

    if-eqz v0, :cond_0

    check-cast p0, Lff4;

    return-object p0

    :cond_0
    invoke-virtual {p0}, Lbf4;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "Not a JSON Primitive: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    :try_start_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v1, Lpf4;

    new-instance v2, Lmf4;

    invoke-direct {v2, v0}, Lmf4;-><init>(Ljava/lang/StringBuilder;)V

    invoke-direct {v1, v2}, Lpf4;-><init>(Lmf4;)V

    const/4 v2, 0x1

    iput v2, v1, Lpf4;->o:I

    invoke-static {v1, p0}, Lp54;->V(Lpf4;Lbf4;)V

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    new-instance v0, Ljava/lang/AssertionError;

    invoke-direct {v0, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0
.end method
