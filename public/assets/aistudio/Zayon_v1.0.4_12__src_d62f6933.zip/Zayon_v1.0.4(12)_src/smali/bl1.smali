.class public final Lbl1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkj1;


# instance fields
.field public final a:[B

.field public final b:Lzb3;

.field public final c:Loj1;

.field public d:Lmj1;

.field public e:Llk1;

.field public f:I

.field public g:Lrp1;

.field public h:Ltj1;

.field public i:I

.field public j:I

.field public k:Lal1;

.field public l:I

.field public m:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Lex1;->v:I

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x2a

    new-array v0, v0, [B

    iput-object v0, p0, Lbl1;->a:[B

    new-instance v0, Lzb3;

    const v1, 0x8000

    new-array v1, v1, [B

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1}, Lzb3;-><init>(I[B)V

    iput-object v0, p0, Lbl1;->b:Lzb3;

    new-instance v0, Loj1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lbl1;->c:Loj1;

    iput v2, p0, Lbl1;->f:I

    return-void
.end method


# virtual methods
.method public final b(Llj1;)Z
    .locals 4

    sget-object p0, Ljs;->l:Ljs;

    new-instance v0, Ls93;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Ls93;-><init>(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, p1, p0, v1}, Ls93;->x(Llj1;Ljs;I)Lrp1;

    move-result-object p0

    if-eqz p0, :cond_0

    iget-object p0, p0, Lrp1;->a:[Lyo1;

    array-length p0, p0

    :cond_0
    new-instance p0, Lzb3;

    const/4 v0, 0x4

    invoke-direct {p0, v0}, Lzb3;-><init>(I)V

    iget-object v2, p0, Lzb3;->a:[B

    check-cast p1, Lfj1;

    invoke-virtual {p1, v2, v1, v0, v1}, Lfj1;->y([BIIZ)Z

    invoke-virtual {p0}, Lzb3;->N()J

    move-result-wide p0

    const-wide/32 v2, 0x664c6143

    cmp-long p0, p0, v2

    if-nez p0, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    return v1
.end method

.method public final c()V
    .locals 0

    return-void
.end method

.method public final e(Lmj1;)V
    .locals 2

    iput-object p1, p0, Lbl1;->d:Lmj1;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-interface {p1, v0, v1}, Lmj1;->c(II)Llk1;

    move-result-object v0

    iput-object v0, p0, Lbl1;->e:Llk1;

    invoke-interface {p1}, Lmj1;->e0()V

    return-void
.end method

.method public final f(JJ)V
    .locals 2

    const-wide/16 v0, 0x0

    cmp-long p1, p1, v0

    const/4 p2, 0x0

    if-nez p1, :cond_0

    iput p2, p0, Lbl1;->f:I

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lbl1;->k:Lal1;

    if-eqz p1, :cond_1

    invoke-virtual {p1, p3, p4}, Lal1;->a(J)V

    :cond_1
    :goto_0
    cmp-long p1, p3, v0

    if-nez p1, :cond_2

    goto :goto_1

    :cond_2
    const-wide/16 v0, -0x1

    :goto_1
    iput-wide v0, p0, Lbl1;->m:J

    iput p2, p0, Lbl1;->l:I

    iget-object p0, p0, Lbl1;->b:Lzb3;

    invoke-virtual {p0, p2}, Lzb3;->y(I)V

    return-void
.end method

.method public final g(Llj1;Loj1;)I
    .locals 31

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget v2, v0, Lbl1;->f:I

    const/16 v3, 0x10

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_29

    iget-object v7, v0, Lbl1;->a:[B

    const/4 v8, 0x2

    if-eq v2, v5, :cond_28

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eq v2, v8, :cond_26

    const/4 v11, 0x7

    if-eq v2, v9, :cond_1d

    const-wide/16 v13, 0x0

    const-wide/16 v15, -0x1

    if-eq v2, v10, :cond_17

    iget-object v2, v0, Lbl1;->e:Llk1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v0, Lbl1;->h:Ltj1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v0, Lbl1;->k:Lal1;

    if-eqz v7, :cond_0

    iget-object v9, v7, Lal1;->c:Lwi1;

    if-eqz v9, :cond_0

    move-object/from16 v9, p2

    invoke-virtual {v7, v1, v9}, Lal1;->b(Llj1;Loj1;)I

    move-result v0

    return v0

    :cond_0
    iget-wide v9, v0, Lbl1;->m:J

    cmp-long v7, v9, v15

    const/4 v9, -0x1

    if-nez v7, :cond_8

    invoke-interface {v1}, Llj1;->j()V

    invoke-interface {v1, v5}, Llj1;->t(I)V

    new-array v3, v5, [B

    invoke-interface {v1, v6, v5, v3}, Llj1;->v(II[B)V

    aget-byte v3, v3, v6

    and-int/2addr v3, v5

    if-eq v5, v3, :cond_1

    move v7, v6

    goto :goto_0

    :cond_1
    move v7, v5

    :goto_0
    invoke-interface {v1, v8}, Llj1;->t(I)V

    if-eq v5, v3, :cond_2

    const/4 v11, 0x6

    :cond_2
    new-instance v3, Lzb3;

    invoke-direct {v3, v11}, Lzb3;-><init>(I)V

    iget-object v8, v3, Lzb3;->a:[B

    move v10, v6

    :goto_1
    if-ge v10, v11, :cond_4

    sub-int v12, v11, v10

    invoke-interface {v1, v10, v12, v8}, Llj1;->z(II[B)I

    move-result v12

    if-ne v12, v9, :cond_3

    goto :goto_2

    :cond_3
    add-int/2addr v10, v12

    goto :goto_1

    :cond_4
    :goto_2
    invoke-virtual {v3, v10}, Lzb3;->C(I)V

    invoke-interface {v1}, Llj1;->j()V

    :try_start_0
    invoke-virtual {v3}, Lzb3;->o()J

    move-result-wide v8
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v7, :cond_5

    goto :goto_3

    :cond_5
    iget v1, v2, Ltj1;->b:I

    int-to-long v10, v1

    mul-long/2addr v8, v10

    :goto_3
    iget-wide v1, v2, Ltj1;->j:J

    cmp-long v3, v1, v13

    if-eqz v3, :cond_6

    cmp-long v1, v8, v1

    if-lez v1, :cond_6

    goto :goto_4

    :cond_6
    move-wide v13, v8

    goto :goto_5

    :catch_0
    :goto_4
    move v5, v6

    :goto_5
    if-eqz v5, :cond_7

    iput-wide v13, v0, Lbl1;->m:J

    goto/16 :goto_e

    :cond_7
    invoke-static {v4, v4}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_8
    iget-object v2, v0, Lbl1;->b:Lzb3;

    iget v4, v2, Lzb3;->c:I

    const-wide/32 v7, 0xf4240

    const v10, 0x8000

    if-ge v4, v10, :cond_b

    iget-object v11, v2, Lzb3;->a:[B

    sub-int/2addr v10, v4

    invoke-interface {v1, v4, v10, v11}, Ltl4;->b(II[B)I

    move-result v1

    if-ne v1, v9, :cond_9

    goto :goto_6

    :cond_9
    move v5, v6

    :goto_6
    if-nez v5, :cond_a

    add-int/2addr v4, v1

    invoke-virtual {v2, v4}, Lzb3;->C(I)V

    goto :goto_7

    :cond_a
    invoke-virtual {v2}, Lzb3;->B()I

    move-result v1

    if-nez v1, :cond_c

    iget-wide v1, v0, Lbl1;->m:J

    mul-long/2addr v1, v7

    iget-object v3, v0, Lbl1;->h:Ltj1;

    sget-object v4, Lvh3;->a:Ljava/lang/String;

    iget v3, v3, Ltj1;->e:I

    int-to-long v3, v3

    div-long v11, v1, v3

    iget-object v10, v0, Lbl1;->e:Llk1;

    iget v14, v0, Lbl1;->l:I

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/4 v13, 0x1

    invoke-interface/range {v10 .. v16}, Llk1;->d(JIIILhk1;)V

    return v9

    :cond_b
    move v5, v6

    :cond_c
    :goto_7
    iget v1, v2, Lzb3;->b:I

    iget v4, v0, Lbl1;->l:I

    iget v9, v0, Lbl1;->i:I

    if-ge v4, v9, :cond_d

    invoke-virtual {v2}, Lzb3;->B()I

    move-result v10

    sub-int/2addr v9, v4

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {v2, v4}, Lzb3;->E(I)V

    :cond_d
    iget-object v4, v0, Lbl1;->h:Ltj1;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v4, v2, Lzb3;->b:I

    :goto_8
    iget v9, v2, Lzb3;->c:I

    add-int/lit8 v9, v9, -0x10

    iget-object v10, v0, Lbl1;->c:Loj1;

    if-gt v4, v9, :cond_f

    invoke-virtual {v2, v4}, Lzb3;->D(I)V

    iget-object v9, v0, Lbl1;->h:Ltj1;

    iget v11, v0, Lbl1;->j:I

    invoke-static {v2, v9, v11, v10}, Ltb1;->s(Lzb3;Ltj1;ILoj1;)Z

    move-result v9

    if-eqz v9, :cond_e

    invoke-virtual {v2, v4}, Lzb3;->D(I)V

    iget-wide v4, v10, Loj1;->h:J

    goto :goto_d

    :cond_e
    add-int/lit8 v4, v4, 0x1

    goto :goto_8

    :cond_f
    if-eqz v5, :cond_13

    :goto_9
    iget v5, v2, Lzb3;->c:I

    iget v9, v0, Lbl1;->i:I

    sub-int v9, v5, v9

    if-gt v4, v9, :cond_12

    invoke-virtual {v2, v4}, Lzb3;->D(I)V

    :try_start_1
    iget-object v5, v0, Lbl1;->h:Ltj1;

    iget v9, v0, Lbl1;->j:I

    invoke-static {v2, v5, v9, v10}, Ltb1;->s(Lzb3;Ltj1;ILoj1;)Z

    move-result v5
    :try_end_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_a

    :catch_1
    move v5, v6

    :goto_a
    iget v9, v2, Lzb3;->b:I

    iget v11, v2, Lzb3;->c:I

    if-le v9, v11, :cond_10

    goto :goto_b

    :cond_10
    if-eqz v5, :cond_11

    invoke-virtual {v2, v4}, Lzb3;->D(I)V

    iget-wide v4, v10, Loj1;->h:J

    goto :goto_d

    :cond_11
    :goto_b
    add-int/lit8 v4, v4, 0x1

    goto :goto_9

    :cond_12
    invoke-virtual {v2, v5}, Lzb3;->D(I)V

    goto :goto_c

    :cond_13
    invoke-virtual {v2, v4}, Lzb3;->D(I)V

    :goto_c
    move-wide v4, v15

    :goto_d
    iget v9, v2, Lzb3;->b:I

    sub-int/2addr v9, v1

    invoke-virtual {v2, v1}, Lzb3;->D(I)V

    iget-object v1, v0, Lbl1;->e:Llk1;

    invoke-interface {v1, v9, v2}, Llk1;->a(ILzb3;)V

    iget v1, v0, Lbl1;->l:I

    add-int/2addr v1, v9

    iput v1, v0, Lbl1;->l:I

    cmp-long v9, v4, v15

    if-eqz v9, :cond_14

    iget-wide v9, v0, Lbl1;->m:J

    mul-long/2addr v9, v7

    iget-object v7, v0, Lbl1;->h:Ltj1;

    sget-object v8, Lvh3;->a:Ljava/lang/String;

    iget v7, v7, Ltj1;->e:I

    int-to-long v7, v7

    div-long v18, v9, v7

    iget-object v7, v0, Lbl1;->e:Llk1;

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v20, 0x1

    move/from16 v21, v1

    move-object/from16 v17, v7

    invoke-interface/range {v17 .. v23}, Llk1;->d(JIIILhk1;)V

    iput v6, v0, Lbl1;->l:I

    iput-wide v4, v0, Lbl1;->m:J

    :cond_14
    iget-object v0, v2, Lzb3;->a:[B

    array-length v0, v0

    iget v1, v2, Lzb3;->c:I

    sub-int/2addr v0, v1

    invoke-virtual {v2}, Lzb3;->B()I

    move-result v1

    if-ge v1, v3, :cond_16

    if-lt v0, v3, :cond_15

    goto :goto_e

    :cond_15
    invoke-virtual {v2}, Lzb3;->B()I

    move-result v0

    iget-object v1, v2, Lzb3;->a:[B

    iget v3, v2, Lzb3;->b:I

    invoke-static {v1, v3, v1, v6, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-virtual {v2, v6}, Lzb3;->D(I)V

    invoke-virtual {v2, v0}, Lzb3;->C(I)V

    :cond_16
    :goto_e
    return v6

    :cond_17
    invoke-interface {v1}, Llj1;->j()V

    new-instance v2, Lzb3;

    invoke-direct {v2, v8}, Lzb3;-><init>(I)V

    iget-object v5, v2, Lzb3;->a:[B

    invoke-interface {v1, v6, v8, v5}, Llj1;->v(II[B)V

    invoke-virtual {v2}, Lzb3;->J()I

    move-result v2

    shr-int/lit8 v5, v2, 0x2

    const/16 v7, 0x3ffe

    if-ne v5, v7, :cond_1c

    invoke-interface {v1}, Llj1;->j()V

    iput v2, v0, Lbl1;->j:I

    iget-object v2, v0, Lbl1;->d:Lmj1;

    sget-object v4, Lvh3;->a:Ljava/lang/String;

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v4

    invoke-interface {v1}, Llj1;->s()J

    move-result-wide v26

    iget-object v1, v0, Lbl1;->h:Ltj1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v1, Ltj1;->k:Llx2;

    if-eqz v7, :cond_18

    iget-object v7, v7, Llx2;->i:Ljava/lang/Object;

    check-cast v7, [J

    array-length v7, v7

    if-lez v7, :cond_18

    new-instance v3, Lpj1;

    invoke-direct {v3, v1, v4, v5, v6}, Lpj1;-><init>(Ljava/lang/Object;JI)V

    move v15, v6

    goto/16 :goto_11

    :cond_18
    cmp-long v7, v26, v15

    if-eqz v7, :cond_1b

    iget-wide v7, v1, Ltj1;->j:J

    cmp-long v7, v7, v13

    if-lez v7, :cond_1b

    new-instance v17, Lal1;

    iget v7, v0, Lbl1;->j:I

    iget v8, v1, Ltj1;->c:I

    new-instance v9, Lxo3;

    invoke-direct {v9, v3, v1}, Lxo3;-><init>(ILjava/lang/Object;)V

    new-instance v3, Lzk1;

    invoke-direct {v3, v1, v7}, Lzk1;-><init>(Ltj1;I)V

    invoke-virtual {v1}, Ltj1;->a()J

    move-result-wide v20

    iget-wide v10, v1, Ltj1;->j:J

    iget v7, v1, Ltj1;->d:I

    if-lez v7, :cond_19

    int-to-long v13, v8

    move v15, v6

    int-to-long v6, v7

    add-long/2addr v6, v13

    const-wide/16 v13, 0x2

    div-long/2addr v6, v13

    const-wide/16 v13, 0x1

    add-long/2addr v6, v13

    :goto_f
    move-wide/from16 v28, v6

    const/4 v1, 0x6

    goto :goto_10

    :cond_19
    move v15, v6

    iget v6, v1, Ltj1;->a:I

    iget v7, v1, Ltj1;->b:I

    const-wide/16 v13, 0x1000

    if-ne v6, v7, :cond_1a

    if-lez v6, :cond_1a

    int-to-long v13, v6

    :cond_1a
    iget v6, v1, Ltj1;->g:I

    int-to-long v6, v6

    iget v1, v1, Ltj1;->h:I

    move-wide/from16 p1, v13

    int-to-long v12, v1

    mul-long v6, v6, p1

    mul-long/2addr v6, v12

    const-wide/16 v12, 0x8

    div-long/2addr v6, v12

    const-wide/16 v12, 0x40

    add-long/2addr v6, v12

    goto :goto_f

    :goto_10
    invoke-static {v1, v8}, Ljava/lang/Math;->max(II)I

    move-result v30

    move-object/from16 v19, v3

    move-wide/from16 v24, v4

    move-object/from16 v18, v9

    move-wide/from16 v22, v10

    invoke-direct/range {v17 .. v30}, Lal1;-><init>(Lxi1;Lzi1;JJJJJI)V

    move-object/from16 v1, v17

    iput-object v1, v0, Lbl1;->k:Lal1;

    iget-object v3, v1, Lal1;->a:Lvi1;

    goto :goto_11

    :cond_1b
    move v15, v6

    new-instance v3, Lpj1;

    invoke-virtual {v1}, Ltj1;->a()J

    move-result-wide v4

    invoke-direct {v3, v4, v5, v13, v14}, Lpj1;-><init>(JJ)V

    :goto_11
    invoke-interface {v2, v3}, Lmj1;->f0(Lbk1;)V

    const/4 v1, 0x5

    iput v1, v0, Lbl1;->f:I

    return v15

    :cond_1c
    invoke-interface {v1}, Llj1;->j()V

    const-string v0, "First frame does not start with sync code."

    invoke-static {v4, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_1d
    move v15, v6

    iget-object v2, v0, Lbl1;->h:Ltj1;

    :goto_12
    invoke-interface {v1}, Llj1;->j()V

    new-instance v3, Lu93;

    new-array v4, v10, [B

    invoke-direct {v3, v10, v4}, Lu93;-><init>(I[B)V

    invoke-interface {v1, v15, v10, v4}, Llj1;->v(II[B)V

    invoke-virtual {v3}, Lu93;->g()Z

    move-result v4

    invoke-virtual {v3, v11}, Lu93;->h(I)I

    move-result v5

    const/16 v6, 0x18

    invoke-virtual {v3, v6}, Lu93;->h(I)I

    move-result v3

    add-int/2addr v3, v10

    if-nez v5, :cond_1e

    const/16 v2, 0x26

    new-array v3, v2, [B

    invoke-interface {v1, v15, v2, v3}, Llj1;->B(II[B)V

    new-instance v2, Ltj1;

    invoke-direct {v2, v10, v3}, Ltj1;-><init>(I[B)V

    goto/16 :goto_18

    :cond_1e
    if-eqz v2, :cond_25

    iget-object v6, v2, Ltj1;->l:Lrp1;

    if-ne v5, v9, :cond_1f

    new-instance v5, Lzb3;

    invoke-direct {v5, v3}, Lzb3;-><init>(I)V

    iget-object v6, v5, Lzb3;->a:[B

    invoke-interface {v1, v15, v3, v6}, Llj1;->B(II[B)V

    invoke-static {v5}, Lic1;->x(Lzb3;)Llx2;

    move-result-object v27

    iget-object v3, v2, Ltj1;->l:Lrp1;

    new-instance v17, Ltj1;

    iget v5, v2, Ltj1;->a:I

    iget v6, v2, Ltj1;->b:I

    iget v8, v2, Ltj1;->c:I

    iget v12, v2, Ltj1;->d:I

    iget v13, v2, Ltj1;->e:I

    iget v14, v2, Ltj1;->g:I

    iget v11, v2, Ltj1;->h:I

    iget-wide v9, v2, Ltj1;->j:J

    move-object/from16 v28, v3

    move/from16 v18, v5

    move/from16 v19, v6

    move/from16 v20, v8

    move-wide/from16 v25, v9

    move/from16 v24, v11

    move/from16 v21, v12

    move/from16 v22, v13

    move/from16 v23, v14

    invoke-direct/range {v17 .. v28}, Ltj1;-><init>(IIIIIIIJLlx2;Lrp1;)V

    :goto_13
    move-object/from16 v2, v17

    goto/16 :goto_18

    :cond_1f
    move v8, v10

    if-ne v5, v8, :cond_21

    new-instance v5, Lzb3;

    invoke-direct {v5, v3}, Lzb3;-><init>(I)V

    iget-object v9, v5, Lzb3;->a:[B

    const/4 v15, 0x0

    invoke-interface {v1, v15, v3, v9}, Llj1;->B(II[B)V

    invoke-virtual {v5, v8}, Lzb3;->E(I)V

    invoke-static {v5, v15, v15}, Lic1;->t(Lzb3;ZZ)Ls53;

    move-result-object v3

    iget-object v3, v3, Ls53;->i:Ljava/lang/Object;

    check-cast v3, [Ljava/lang/String;

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-static {v3}, Lnk1;->a(Ljava/util/List;)Lrp1;

    move-result-object v3

    if-nez v6, :cond_20

    :goto_14
    move-object/from16 v28, v3

    goto :goto_15

    :cond_20
    invoke-virtual {v6, v3}, Lrp1;->b(Lrp1;)Lrp1;

    move-result-object v3

    goto :goto_14

    :goto_15
    iget v3, v2, Ltj1;->a:I

    iget v5, v2, Ltj1;->b:I

    iget v6, v2, Ltj1;->c:I

    iget v8, v2, Ltj1;->d:I

    iget v9, v2, Ltj1;->e:I

    iget v10, v2, Ltj1;->g:I

    iget v11, v2, Ltj1;->h:I

    iget-wide v12, v2, Ltj1;->j:J

    iget-object v2, v2, Ltj1;->k:Llx2;

    new-instance v17, Ltj1;

    move-object/from16 v27, v2

    move/from16 v18, v3

    move/from16 v19, v5

    move/from16 v20, v6

    move/from16 v21, v8

    move/from16 v22, v9

    move/from16 v23, v10

    move/from16 v24, v11

    move-wide/from16 v25, v12

    invoke-direct/range {v17 .. v28}, Ltj1;-><init>(IIIIIIIJLlx2;Lrp1;)V

    goto :goto_13

    :cond_21
    const/4 v8, 0x6

    if-ne v5, v8, :cond_23

    new-instance v5, Lzb3;

    invoke-direct {v5, v3}, Lzb3;-><init>(I)V

    iget-object v8, v5, Lzb3;->a:[B

    const/4 v15, 0x0

    invoke-interface {v1, v15, v3, v8}, Llj1;->B(II[B)V

    const/4 v8, 0x4

    invoke-virtual {v5, v8}, Lzb3;->E(I)V

    invoke-static {v5}, Ltl1;->b(Lzb3;)Ltl1;

    move-result-object v3

    invoke-static {v3}, Lmx3;->j(Ljava/lang/Object;)Lqy3;

    move-result-object v3

    new-instance v5, Lrp1;

    invoke-direct {v5, v3}, Lrp1;-><init>(Ljava/util/List;)V

    if-nez v6, :cond_22

    :goto_16
    move-object/from16 v28, v5

    goto :goto_17

    :cond_22
    invoke-virtual {v6, v5}, Lrp1;->b(Lrp1;)Lrp1;

    move-result-object v5

    goto :goto_16

    :goto_17
    iget v3, v2, Ltj1;->a:I

    iget v5, v2, Ltj1;->b:I

    iget v6, v2, Ltj1;->c:I

    iget v8, v2, Ltj1;->d:I

    iget v9, v2, Ltj1;->e:I

    iget v10, v2, Ltj1;->g:I

    iget v11, v2, Ltj1;->h:I

    iget-wide v12, v2, Ltj1;->j:J

    iget-object v2, v2, Ltj1;->k:Llx2;

    new-instance v17, Ltj1;

    move-object/from16 v27, v2

    move/from16 v18, v3

    move/from16 v19, v5

    move/from16 v20, v6

    move/from16 v21, v8

    move/from16 v22, v9

    move/from16 v23, v10

    move/from16 v24, v11

    move-wide/from16 v25, v12

    invoke-direct/range {v17 .. v28}, Ltj1;-><init>(IIIIIIIJLlx2;Lrp1;)V

    goto/16 :goto_13

    :cond_23
    invoke-interface {v1, v3}, Llj1;->w(I)V

    :goto_18
    sget-object v3, Lvh3;->a:Ljava/lang/String;

    iput-object v2, v0, Lbl1;->h:Ltj1;

    if-eqz v4, :cond_24

    iget v1, v2, Ltj1;->c:I

    const/4 v8, 0x6

    invoke-static {v1, v8}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Lbl1;->i:I

    iget-object v1, v0, Lbl1;->h:Ltj1;

    iget-object v2, v0, Lbl1;->g:Lrp1;

    invoke-virtual {v1, v7, v2}, Ltj1;->b([BLrp1;)Lfx4;

    move-result-object v1

    iget-object v2, v0, Lbl1;->e:Llk1;

    new-instance v3, Law4;

    invoke-direct {v3, v1}, Law4;-><init>(Lfx4;)V

    const-string v1, "audio/flac"

    invoke-virtual {v3, v1}, Law4;->c(Ljava/lang/String;)V

    new-instance v1, Lfx4;

    invoke-direct {v1, v3}, Lfx4;-><init>(Law4;)V

    invoke-interface {v2, v1}, Llk1;->c(Lfx4;)V

    iget-object v1, v0, Lbl1;->e:Llk1;

    iget-object v2, v0, Lbl1;->h:Ltj1;

    invoke-virtual {v2}, Ltj1;->a()J

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x4

    iput v3, v0, Lbl1;->f:I

    const/4 v15, 0x0

    return v15

    :cond_24
    const/4 v15, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    goto/16 :goto_12

    :cond_25
    invoke-static {}, Lnu0;->a()V

    return v15

    :cond_26
    move v15, v6

    move v3, v10

    new-instance v2, Lzb3;

    invoke-direct {v2, v3}, Lzb3;-><init>(I)V

    iget-object v5, v2, Lzb3;->a:[B

    invoke-interface {v1, v15, v3, v5}, Llj1;->B(II[B)V

    invoke-virtual {v2}, Lzb3;->N()J

    move-result-wide v1

    const-wide/32 v5, 0x664c6143

    cmp-long v1, v1, v5

    if-nez v1, :cond_27

    const/4 v1, 0x3

    iput v1, v0, Lbl1;->f:I

    return v15

    :cond_27
    const-string v0, "Failed to read FLAC stream marker."

    invoke-static {v4, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_28
    move v15, v6

    const/16 v2, 0x2a

    invoke-interface {v1, v15, v2, v7}, Llj1;->v(II[B)V

    invoke-interface {v1}, Llj1;->j()V

    iput v8, v0, Lbl1;->f:I

    return v15

    :cond_29
    move v15, v6

    invoke-interface {v1}, Llj1;->j()V

    invoke-interface {v1}, Llj1;->n()J

    move-result-wide v6

    new-instance v2, Ls93;

    invoke-direct {v2, v3}, Ls93;-><init>(I)V

    invoke-virtual {v2, v1, v4, v15}, Ls93;->x(Llj1;Ljs;I)Lrp1;

    move-result-object v2

    if-eqz v2, :cond_2b

    iget-object v3, v2, Lrp1;->a:[Lyo1;

    array-length v3, v3

    if-nez v3, :cond_2a

    goto :goto_19

    :cond_2a
    move-object v4, v2

    :cond_2b
    :goto_19
    invoke-interface {v1}, Llj1;->n()J

    move-result-wide v2

    sub-long/2addr v2, v6

    long-to-int v2, v2

    invoke-interface {v1, v2}, Llj1;->w(I)V

    iput-object v4, v0, Lbl1;->g:Lrp1;

    iput v5, v0, Lbl1;->f:I

    const/4 v15, 0x0

    return v15
.end method
