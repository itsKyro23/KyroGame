.class public final Lag2;
.super Lb1;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lag2;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final h:Z

.field public final i:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lox1;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lox1;-><init>(I)V

    sput-object v0, Lag2;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(ZLjava/util/List;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lag2;->h:Z

    iput-object p2, p0, Lag2;->i:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/16 p2, 0x4f45

    invoke-static {p1, p2}, Lgv3;->S(Landroid/os/Parcel;I)I

    move-result p2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1, v0, v1}, Lgv3;->O(Landroid/os/Parcel;II)V

    iget-boolean v0, p0, Lag2;->h:Z

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x3

    iget-object p0, p0, Lag2;->i:Ljava/util/List;

    invoke-static {p1, v0, p0}, Lgv3;->G(Landroid/os/Parcel;ILjava/util/List;)V

    invoke-static {p1, p2}, Lgv3;->X(Landroid/os/Parcel;I)V

    return-void
.end method
