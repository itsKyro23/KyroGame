.class public abstract La14;
.super Lb14;
.source "SourceFile"

# interfaces
.implements Le04;
