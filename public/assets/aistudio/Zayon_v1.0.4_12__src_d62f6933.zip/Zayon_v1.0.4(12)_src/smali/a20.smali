.class public final La20;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbm0;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    invoke-static {}, Lut;->a()Lut;

    return-void
.end method
