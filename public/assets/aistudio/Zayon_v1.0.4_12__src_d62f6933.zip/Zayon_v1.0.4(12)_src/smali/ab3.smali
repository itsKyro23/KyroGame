.class public final Lab3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lud3;


# instance fields
.field public final synthetic a:I

.field public final b:J

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Leo;Log3;J)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lab3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lab3;->c:Ljava/lang/Object;

    iput-object p2, p0, Lab3;->d:Ljava/lang/Object;

    iput-wide p3, p0, Lab3;->b:J

    return-void
.end method

.method public constructor <init>(Lud3;JLjava/util/concurrent/ScheduledExecutorService;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lab3;->a:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lab3;->c:Ljava/lang/Object;

    iput-wide p2, p0, Lab3;->b:J

    iput-object p4, p0, Lab3;->d:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a()Lna0;
    .locals 7

    iget v0, p0, Lab3;->a:I

    iget-object v1, p0, Lab3;->d:Ljava/lang/Object;

    iget-object v2, p0, Lab3;->c:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_0

    check-cast v2, Lud3;

    invoke-interface {v2}, Lud3;->a()Lna0;

    move-result-object v0

    sget-object v2, Lk52;->d3:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_0

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MICROSECONDS:Ljava/util/concurrent/TimeUnit;

    goto :goto_0

    :cond_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    :goto_0
    const-wide/16 v3, 0x0

    iget-wide v5, p0, Lab3;->b:J

    cmp-long v3, v5, v3

    if-lez v3, :cond_1

    check-cast v1, Ljava/util/concurrent/ScheduledExecutorService;

    invoke-static {v0, v5, v6, v2, v1}, Ln50;->F(Lna0;JLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/ScheduledExecutorService;)Lna0;

    move-result-object v0

    :cond_1
    new-instance v1, Lia2;

    const/16 v2, 0x8

    invoke-direct {v1, v2, p0}, Lia2;-><init>(ILjava/lang/Object;)V

    sget-object p0, Laj2;->h:Lzi2;

    const-class v2, Ljava/lang/Throwable;

    invoke-static {v0, v2, v1, p0}, Ln50;->D(Lna0;Ljava/lang/Class;Lu04;Ljava/util/concurrent/Executor;)Lxz3;

    move-result-object p0

    return-object p0

    :pswitch_0
    new-instance v0, Lbb3;

    check-cast v2, Leo;

    check-cast v1, Log3;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, p0, Lab3;->b:J

    invoke-direct/range {v0 .. v5}, Lbb3;-><init>(Log3;JJ)V

    invoke-static {v0}, Ln50;->m(Ljava/lang/Object;)Li14;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final d()I
    .locals 1

    iget v0, p0, Lab3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object p0, p0, Lab3;->c:Ljava/lang/Object;

    check-cast p0, Lud3;

    invoke-interface {p0}, Lud3;->d()I

    move-result p0

    return p0

    :pswitch_0
    const/4 p0, 0x4

    return p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
