.class public final Lbc0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final h:Landroid/graphics/Paint;

.field public final i:Landroid/graphics/Paint;

.field public final j:Landroid/graphics/Paint;

.field public final k:Landroid/graphics/RectF;

.field public final l:Ljava/lang/String;

.field public final synthetic m:Ldc0;


# direct methods
.method public constructor <init>(Ldc0;Landroid/app/Activity;)V
    .locals 4

    iput-object p1, p0, Lbc0;->m:Ldc0;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p2, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p2, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p2, p0, Lbc0;->h:Landroid/graphics/Paint;

    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p2, p0, Lbc0;->i:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lbc0;->j:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lbc0;->k:Landroid/graphics/RectF;

    iget-object v0, p1, Ldc0;->b:Landroid/app/Activity;

    iget v2, p1, Ldc0;->f:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const v3, 0x7f0f03ee

    invoke-virtual {v0, v3, v2}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lbc0;->l:Ljava/lang/String;

    const p0, 0x7f080004

    invoke-static {v0, p0}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p0

    invoke-virtual {p2, p0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->scaledDensity:F

    const/high16 v2, 0x42100000    # 36.0f

    mul-float/2addr p0, v2

    invoke-virtual {p2, p0}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object p0, p1, Ldc0;->c:Landroid/content/Context;

    const p1, 0x7f050231

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p1

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setColor(I)V

    sget-object p1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    iget p2, p2, Landroid/util/DisplayMetrics;->scaledDensity:F

    const/high16 v0, 0x41400000    # 12.0f

    mul-float/2addr p2, v0

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setTextSize(F)V

    const p2, 0x7f050119

    invoke-virtual {p0, p2}, Landroid/content/Context;->getColor(I)I

    move-result p0

    invoke-virtual {v1, p0}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v1, p1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 14

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    const/high16 v6, 0x40000000    # 2.0f

    div-float v7, v1, v6

    iget-object v1, p0, Lbc0;->m:Ldc0;

    iget v8, v1, Ldc0;->e:I

    iget v9, v1, Ldc0;->d:F

    const/high16 v2, 0x40800000    # 4.0f

    mul-float/2addr v2, v9

    add-float v10, v2, v7

    sub-float v2, v7, v7

    sub-float v3, v10, v7

    add-float v4, v7, v7

    add-float v5, v10, v7

    iget-object v11, p0, Lbc0;->k:Landroid/graphics/RectF;

    invoke-virtual {v11, v2, v3, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v12, v1, Ldc0;->c:Landroid/content/Context;

    const v2, 0x7f050112

    invoke-virtual {v12, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iget-object v5, p0, Lbc0;->h:Landroid/graphics/Paint;

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p1, v11, v5}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    iget v1, v1, Ldc0;->f:I

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v13, 0x0

    if-gtz v1, :cond_0

    goto :goto_0

    :cond_0
    int-to-float v3, v8

    int-to-float v1, v1

    div-float/2addr v3, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v13, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    :goto_0
    cmpl-float v1, v2, v13

    if-lez v1, :cond_1

    const v1, 0x7f050100

    invoke-virtual {v12, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x43b40000    # 360.0f

    mul-float v3, v2, v1

    const/4 v4, 0x1

    const/high16 v2, -0x3d4c0000    # -90.0f

    move-object v0, p1

    move-object v1, v11

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    goto :goto_1

    :cond_1
    move-object v1, v11

    :goto_1
    const v2, 0x7f05010b

    invoke-virtual {v12, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x41200000    # 10.0f

    mul-float/2addr v2, v9

    sub-float v2, v7, v2

    invoke-virtual {p1, v7, v10, v2, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v2, 0x7f05010a

    invoke-virtual {v12, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x3fc00000    # 1.5f

    mul-float/2addr v2, v9

    sub-float v3, v7, v2

    add-float/2addr v2, v7

    const/high16 v4, 0x41900000    # 18.0f

    mul-float/2addr v4, v9

    invoke-virtual {v1, v3, v13, v2, v4}, Landroid/graphics/RectF;->set(FFFF)V

    mul-float v2, v9, v6

    invoke-virtual {p1, v1, v2, v2, v5}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    iget-object v1, p0, Lbc0;->i:Landroid/graphics/Paint;

    invoke-virtual {v1}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    move-result-object v2

    iget-object v3, p0, Lbc0;->j:Landroid/graphics/Paint;

    invoke-virtual {v3}, Landroid/graphics/Paint;->getFontMetrics()Landroid/graphics/Paint$FontMetrics;

    move-result-object v4

    invoke-virtual {v1}, Landroid/graphics/Paint;->getTextSize()F

    move-result v5

    iget v11, v4, Landroid/graphics/Paint$FontMetrics;->descent:F

    iget v12, v4, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v11, v12

    mul-float v12, v9, v6

    add-float/2addr v12, v5

    add-float/2addr v12, v11

    div-float/2addr v12, v6

    sub-float/2addr v10, v12

    div-float v11, v5, v6

    add-float/2addr v11, v10

    iget v12, v2, Landroid/graphics/Paint$FontMetrics;->ascent:F

    iget v2, v2, Landroid/graphics/Paint$FontMetrics;->descent:F

    add-float/2addr v12, v2

    div-float/2addr v12, v6

    sub-float/2addr v11, v12

    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2, v7, v11, v1}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    add-float/2addr v10, v5

    mul-float/2addr v9, v6

    add-float/2addr v9, v10

    iget v1, v4, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v9, v1

    iget-object p0, p0, Lbc0;->l:Ljava/lang/String;

    invoke-virtual {p1, p0, v7, v9, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method
