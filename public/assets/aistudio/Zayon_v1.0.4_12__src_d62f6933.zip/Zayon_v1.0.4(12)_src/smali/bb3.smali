.class public final Lbb3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltd3;


# instance fields
.field public final a:Log3;

.field public final b:J

.field public final c:J


# direct methods
.method public constructor <init>(Log3;JJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbb3;->a:Log3;

    iput-wide p2, p0, Lbb3;->b:J

    iput-wide p4, p0, Lbb3;->c:J

    return-void
.end method


# virtual methods
.method public final l(Ljava/lang/Object;)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, Landroid/os/Bundle;

    iget-object v2, v0, Lbb3;->a:Log3;

    iget-object v3, v2, Log3;->d:Ltp4;

    iget-object v4, v3, Ltp4;->j:Landroid/os/Bundle;

    iget v5, v3, Ltp4;->D:I

    const-string v6, "http_timeout_millis"

    invoke-virtual {v1, v6, v5}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "slotname"

    iget-object v6, v2, Log3;->g:Ljava/lang/String;

    invoke-virtual {v1, v5, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v5, v2, Log3;->p:Llb0;

    iget v5, v5, Llb0;->i:I

    if-eqz v5, :cond_13

    const/4 v6, -0x1

    add-int/2addr v5, v6

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eq v5, v8, :cond_1

    if-eq v5, v7, :cond_0

    goto :goto_0

    :cond_0
    const-string v5, "is_rewarded_interstitial"

    invoke-virtual {v1, v5, v8}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    goto :goto_0

    :cond_1
    const-string v5, "is_new_rewarded"

    invoke-virtual {v1, v5, v8}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :goto_0
    const-string v5, "start_signals_timestamp"

    iget-wide v9, v0, Lbb3;->b:J

    invoke-virtual {v1, v5, v9, v10}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    sget-object v5, Lk52;->pf:Lg52;

    sget-object v11, Lvx1;->e:Lvx1;

    iget-object v11, v11, Lvx1;->c:Li52;

    invoke-virtual {v11, v5}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_2

    iget-wide v11, v0, Lbb3;->c:J

    sub-long/2addr v9, v11

    const-string v0, "tsi"

    invoke-virtual {v1, v0, v9, v10}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_2
    const-string v0, "is_sdk_preload"

    const/4 v5, 0x0

    invoke-virtual {v4, v0, v5}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    invoke-static {v1, v0, v8, v9}, Lhd1;->F(Landroid/os/Bundle;Ljava/lang/String;ZZ)V

    const-string v0, "zenith_v2"

    invoke-virtual {v4, v0, v5}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const-string v10, "prefetch_type"

    invoke-static {v10, v0, v1, v9}, Lhd1;->C(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Z)V

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v9, "yyyyMMdd"

    sget-object v10, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v9, v10}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iget-wide v9, v3, Ltp4;->i:J

    new-instance v11, Ljava/util/Date;

    invoke-direct {v11, v9, v10}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v11}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const-wide/16 v11, -0x1

    cmp-long v9, v9, v11

    if-eqz v9, :cond_3

    move v9, v8

    goto :goto_1

    :cond_3
    move v9, v5

    :goto_1
    const-string v10, "cust_age"

    invoke-static {v10, v0, v1, v9}, Lhd1;->C(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Z)V

    const-string v0, "extras"

    invoke-virtual {v1, v0, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget v0, v3, Ltp4;->k:I

    if-eq v0, v6, :cond_4

    move v4, v8

    goto :goto_2

    :cond_4
    move v4, v5

    :goto_2
    const-string v9, "cust_gender"

    invoke-static {v1, v9, v0, v4}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    iget-object v0, v3, Ltp4;->l:Ljava/util/List;

    if-eqz v0, :cond_5

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-string v0, "kw"

    invoke-virtual {v1, v0, v4}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_5
    iget v0, v3, Ltp4;->n:I

    if-eq v0, v6, :cond_6

    move v4, v8

    goto :goto_3

    :cond_6
    move v4, v5

    :goto_3
    const-string v9, "tag_for_child_directed_treatment"

    invoke-static {v1, v9, v0, v4}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    iget-boolean v0, v3, Ltp4;->m:Z

    if-eqz v0, :cond_7

    const-string v0, "test_request"

    invoke-virtual {v1, v0, v8}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_7
    iget v0, v3, Ltp4;->F:I

    const-string v4, "ppt_p13n"

    invoke-virtual {v1, v4, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget v0, v3, Ltp4;->h:I

    if-lt v0, v7, :cond_8

    iget-boolean v4, v3, Ltp4;->o:Z

    if-eqz v4, :cond_8

    move v4, v8

    goto :goto_4

    :cond_8
    move v4, v5

    :goto_4
    const-string v9, "d_imp_hdr"

    invoke-static {v1, v9, v8, v4}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    iget-object v4, v3, Ltp4;->p:Ljava/lang/String;

    if-lt v0, v7, :cond_9

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_9

    move v7, v8

    goto :goto_5

    :cond_9
    move v7, v5

    :goto_5
    const-string v9, "ppid"

    invoke-static {v9, v4, v1, v7}, Lhd1;->C(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;Z)V

    iget-object v4, v3, Ltp4;->r:Landroid/location/Location;

    if-eqz v4, :cond_a

    invoke-virtual {v4}, Landroid/location/Location;->getAccuracy()F

    move-result v7

    const/high16 v9, 0x447a0000    # 1000.0f

    mul-float/2addr v7, v9

    invoke-virtual {v4}, Landroid/location/Location;->getTime()J

    move-result-wide v9

    const-wide/16 v11, 0x3e8

    mul-long/2addr v9, v11

    invoke-virtual {v4}, Landroid/location/Location;->getLatitude()D

    move-result-wide v11

    const-wide v13, 0x416312d000000000L    # 1.0E7

    mul-double/2addr v11, v13

    invoke-virtual {v4}, Landroid/location/Location;->getLongitude()D

    move-result-wide v15

    mul-double/2addr v13, v15

    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const-string v15, "radius"

    invoke-virtual {v4, v15, v7}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    const-string v7, "lat"

    double-to-long v11, v11

    invoke-virtual {v4, v7, v11, v12}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const-string v7, "long"

    double-to-long v11, v13

    invoke-virtual {v4, v7, v11, v12}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const-string v7, "time"

    invoke-virtual {v4, v7, v9, v10}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const-string v7, "uule"

    invoke-virtual {v1, v7, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_a
    iget-object v4, v3, Ltp4;->s:Ljava/lang/String;

    const-string v7, "url"

    invoke-static {v7, v1, v4}, Lhd1;->I(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V

    iget-object v4, v3, Ltp4;->C:Ljava/util/List;

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-string v4, "neighboring_content_urls"

    invoke-virtual {v1, v4, v7}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    iget-object v4, v3, Ltp4;->u:Landroid/os/Bundle;

    if-eqz v4, :cond_b

    const-string v7, "custom_targeting"

    invoke-virtual {v1, v7, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_b
    iget-object v4, v3, Ltp4;->v:Ljava/util/List;

    if-eqz v4, :cond_c

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const-string v4, "category_exclusions"

    invoke-virtual {v1, v4, v7}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_c
    iget-object v4, v3, Ltp4;->w:Ljava/lang/String;

    const-string v7, "request_agent"

    invoke-static {v7, v1, v4}, Lhd1;->I(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V

    iget-object v4, v3, Ltp4;->x:Ljava/lang/String;

    const-string v7, "request_pkg"

    invoke-static {v7, v1, v4}, Lhd1;->I(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V

    iget-boolean v4, v3, Ltp4;->y:Z

    const/4 v7, 0x7

    if-lt v0, v7, :cond_d

    move v7, v8

    goto :goto_6

    :cond_d
    move v7, v5

    :goto_6
    const-string v9, "is_designed_for_families"

    invoke-static {v1, v9, v4, v7}, Lhd1;->F(Landroid/os/Bundle;Ljava/lang/String;ZZ)V

    const/16 v4, 0x8

    if-lt v0, v4, :cond_f

    iget v0, v3, Ltp4;->A:I

    if-eq v0, v6, :cond_e

    move v4, v8

    goto :goto_7

    :cond_e
    move v4, v5

    :goto_7
    const-string v7, "tag_for_under_age_of_consent"

    invoke-static {v1, v7, v0, v4}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    iget-object v0, v3, Ltp4;->B:Ljava/lang/String;

    const-string v4, "max_ad_content_rating"

    invoke-static {v4, v1, v0}, Lhd1;->I(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V

    :cond_f
    iget v0, v3, Ltp4;->I:I

    if-eq v0, v6, :cond_10

    move v4, v8

    goto :goto_8

    :cond_10
    move v4, v5

    :goto_8
    const-string v6, "tfat"

    invoke-static {v1, v6, v0, v4}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    iget-object v0, v2, Log3;->e:Landroid/os/Bundle;

    const-string v4, "plcs"

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v1, v4, v6}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "plbs"

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v1, v4, v6}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "plid"

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v1, v0}, Lhd1;->I(Ljava/lang/String;Landroid/os/Bundle;Ljava/lang/String;)V

    iget-boolean v0, v2, Log3;->v:Z

    if-eqz v0, :cond_12

    iget-object v0, v3, Ltp4;->z:Lwe2;

    if-nez v0, :cond_11

    iget-object v0, v3, Ltp4;->E:Ljava/lang/String;

    if-eqz v0, :cond_12

    :cond_11
    move v5, v8

    :cond_12
    const-string v0, "s2s_rr"

    invoke-static {v1, v0, v8, v5}, Lhd1;->D(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    return-void

    :cond_13
    const/4 v0, 0x0

    throw v0
.end method
