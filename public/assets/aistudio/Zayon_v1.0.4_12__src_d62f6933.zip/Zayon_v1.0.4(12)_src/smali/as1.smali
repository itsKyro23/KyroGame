.class public final Las1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbs1;


# static fields
.field public static final m:[I

.field public static final n:[I


# instance fields
.field public final a:Lmj1;

.field public final b:Llk1;

.field public final c:Les1;

.field public final d:I

.field public final e:[B

.field public final f:Lzb3;

.field public final g:I

.field public final h:Lfx4;

.field public i:I

.field public j:J

.field public k:I

.field public l:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x10

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Las1;->m:[I

    const/16 v0, 0x59

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    sput-object v0, Las1;->n:[I

    return-void

    nop

    :array_0
    .array-data 4
        -0x1
        -0x1
        -0x1
        -0x1
        0x2
        0x4
        0x6
        0x8
        -0x1
        -0x1
        -0x1
        -0x1
        0x2
        0x4
        0x6
        0x8
    .end array-data

    :array_1
    .array-data 4
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0x10
        0x11
        0x13
        0x15
        0x17
        0x19
        0x1c
        0x1f
        0x22
        0x25
        0x29
        0x2d
        0x32
        0x37
        0x3c
        0x42
        0x49
        0x50
        0x58
        0x61
        0x6b
        0x76
        0x82
        0x8f
        0x9d
        0xad
        0xbe
        0xd1
        0xe6
        0xfd
        0x117
        0x133
        0x151
        0x173
        0x198
        0x1c1
        0x1ee
        0x220
        0x256
        0x292
        0x2d4
        0x31c
        0x36c
        0x3c3
        0x424
        0x48e
        0x502
        0x583
        0x610
        0x6ab
        0x756
        0x812
        0x8e0
        0x9c3
        0xabd
        0xbd0
        0xcff
        0xe4c
        0xfba
        0x114c
        0x1307
        0x14ee
        0x1706
        0x1954
        0x1bdc
        0x1ea5
        0x21b6
        0x2515
        0x28ca
        0x2cdf
        0x315b
        0x364b
        0x3bb9
        0x41b2
        0x4844
        0x4f7e
        0x5771
        0x602f
        0x69ce
        0x7462
        0x7fff
    .end array-data
.end method

.method public constructor <init>(Lmj1;Llk1;Les1;)V
    .locals 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Las1;->a:Lmj1;

    iput-object p2, p0, Las1;->b:Llk1;

    iput-object p3, p0, Las1;->c:Les1;

    iget p1, p3, Les1;->b:I

    div-int/lit8 p2, p1, 0xa

    const/4 v0, 0x1

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    iput p2, p0, Las1;->g:I

    new-instance v1, Lzb3;

    iget-object v2, p3, Les1;->f:Ljava/lang/Cloneable;

    check-cast v2, [B

    invoke-direct {v1, v2}, Lzb3;-><init>([B)V

    invoke-virtual {v1}, Lzb3;->K()I

    invoke-virtual {v1}, Lzb3;->K()I

    move-result v1

    iput v1, p0, Las1;->d:I

    iget v2, p3, Les1;->a:I

    mul-int/lit8 v3, v2, 0x4

    iget v4, p3, Les1;->c:I

    sub-int v3, v4, v3

    iget v5, p3, Les1;->d:I

    mul-int/2addr v5, v2

    mul-int/lit8 v3, v3, 0x8

    div-int/2addr v3, v5

    add-int/2addr v3, v0

    if-ne v1, v3, :cond_1

    sget-object v0, Lvh3;->a:Ljava/lang/String;

    add-int v0, p2, v1

    const/4 v3, -0x1

    add-int/2addr v0, v3

    div-int/2addr v0, v1

    mul-int v5, v0, v4

    new-array v5, v5, [B

    iput-object v5, p0, Las1;->e:[B

    new-instance v5, Lzb3;

    add-int v6, v1, v1

    mul-int/2addr v6, v2

    mul-int/2addr v6, v0

    invoke-direct {v5, v6}, Lzb3;-><init>(I)V

    iput-object v5, p0, Las1;->f:Lzb3;

    mul-int/2addr v4, p1

    mul-int/lit8 v4, v4, 0x8

    div-int/2addr v4, v1

    new-instance v0, Law4;

    invoke-direct {v0}, Law4;-><init>()V

    const-string v1, "audio/raw"

    invoke-virtual {v0, v1}, Law4;->d(Ljava/lang/String;)V

    iput v4, v0, Law4;->h:I

    iput v4, v0, Law4;->i:I

    add-int/2addr p2, p2

    mul-int/2addr p2, v2

    iput p2, v0, Law4;->o:I

    iput v2, v0, Law4;->G:I

    iget p2, p3, Les1;->e:I

    const/4 p3, 0x2

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    shl-int/lit8 v3, p2, 0x2

    :goto_0
    iput v3, v0, Law4;->H:I

    iput p1, v0, Law4;->I:I

    iput p3, v0, Law4;->J:I

    new-instance p1, Lfx4;

    invoke-direct {p1, v0}, Lfx4;-><init>(Law4;)V

    iput-object p1, p0, Las1;->h:Lfx4;

    return-void

    :cond_1
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    add-int/lit8 p0, p0, 0x22

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    new-instance p2, Ljava/lang/StringBuilder;

    add-int/2addr p0, p1

    invoke-direct {p2, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "Expected frames per block: "

    const-string p1, "; got: "

    invoke-static {p2, p0, v3, p1, v1}, Lq60;->o(Ljava/lang/StringBuilder;Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0
.end method


# virtual methods
.method public final a(Llj1;J)Z
    .locals 24

    move-object/from16 v0, p0

    move-wide/from16 v1, p2

    iget v3, v0, Las1;->k:I

    iget-object v4, v0, Las1;->c:Les1;

    iget v5, v4, Les1;->a:I

    add-int/2addr v5, v5

    div-int/2addr v3, v5

    iget v5, v0, Las1;->g:I

    sub-int v3, v5, v3

    sget-object v6, Lvh3;->a:Ljava/lang/String;

    iget v6, v0, Las1;->d:I

    add-int/2addr v3, v6

    const/4 v7, -0x1

    add-int/2addr v3, v7

    div-int/2addr v3, v6

    iget v8, v4, Les1;->c:I

    mul-int/2addr v3, v8

    const-wide/16 v9, 0x0

    cmp-long v9, v1, v9

    if-nez v9, :cond_0

    :goto_0
    const/4 v9, 0x1

    goto :goto_1

    :cond_0
    const/4 v9, 0x0

    :goto_1
    iget-object v12, v0, Las1;->e:[B

    if-nez v9, :cond_2

    iget v13, v0, Las1;->i:I

    if-ge v13, v3, :cond_2

    sub-int v13, v3, v13

    int-to-long v13, v13

    invoke-static {v13, v14, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v13

    long-to-int v13, v13

    iget v14, v0, Las1;->i:I

    move-object/from16 v15, p1

    invoke-interface {v15, v14, v13, v12}, Ltl4;->b(II[B)I

    move-result v12

    if-ne v12, v7, :cond_1

    goto :goto_0

    :cond_1
    iget v13, v0, Las1;->i:I

    add-int/2addr v13, v12

    iput v13, v0, Las1;->i:I

    goto :goto_1

    :cond_2
    iget v1, v0, Las1;->i:I

    div-int/2addr v1, v8

    if-lez v1, :cond_8

    const/4 v2, 0x0

    :goto_2
    iget-object v3, v0, Las1;->f:Lzb3;

    if-ge v2, v1, :cond_7

    const/4 v7, 0x0

    :goto_3
    iget v13, v4, Les1;->a:I

    if-ge v7, v13, :cond_6

    iget-object v14, v3, Lzb3;->a:[B

    mul-int v15, v2, v8

    div-int v16, v8, v13

    add-int/lit8 v16, v16, -0x4

    mul-int/lit8 v17, v7, 0x4

    add-int v17, v17, v15

    add-int/lit8 v15, v17, 0x1

    aget-byte v15, v12, v15

    and-int/lit16 v15, v15, 0xff

    const/16 v18, 0x1

    aget-byte v11, v12, v17

    and-int/lit16 v11, v11, 0xff

    add-int/lit8 v19, v17, 0x2

    aget-byte v10, v12, v19

    and-int/lit16 v10, v10, 0xff

    move/from16 p1, v1

    const/16 v1, 0x58

    invoke-static {v10, v1}, Ljava/lang/Math;->min(II)I

    move-result v10

    sget-object v19, Las1;->n:[I

    aget v20, v19, v10

    mul-int v21, v2, v6

    mul-int v21, v21, v13

    add-int v21, v21, v7

    shl-int/lit8 v15, v15, 0x8

    or-int/2addr v11, v15

    int-to-short v11, v11

    and-int/lit16 v15, v11, 0xff

    add-int v21, v21, v21

    int-to-byte v15, v15

    aput-byte v15, v14, v21

    add-int/lit8 v15, v21, 0x1

    shr-int/lit8 v1, v11, 0x8

    int-to-byte v1, v1

    aput-byte v1, v14, v15

    const/4 v1, 0x0

    :goto_4
    add-int v15, v16, v16

    if-ge v1, v15, :cond_5

    mul-int/lit8 v15, v13, 0x4

    add-int v15, v15, v17

    div-int/lit8 v22, v1, 0x8

    div-int/lit8 v23, v1, 0x2

    rem-int/lit8 v23, v23, 0x4

    mul-int v22, v22, v13

    mul-int/lit8 v22, v22, 0x4

    add-int v22, v22, v15

    add-int v22, v22, v23

    aget-byte v15, v12, v22

    move/from16 v22, v1

    and-int/lit16 v1, v15, 0xff

    rem-int/lit8 v23, v22, 0x2

    if-nez v23, :cond_3

    and-int/lit8 v1, v15, 0xf

    goto :goto_5

    :cond_3
    shr-int/lit8 v1, v1, 0x4

    :goto_5
    and-int/lit8 v15, v1, 0x7

    add-int/2addr v15, v15

    add-int/lit8 v15, v15, 0x1

    mul-int v15, v15, v20

    and-int/lit8 v20, v1, 0x8

    shr-int/lit8 v15, v15, 0x3

    if-eqz v20, :cond_4

    neg-int v15, v15

    :cond_4
    add-int/2addr v11, v15

    const/16 v15, 0x7fff

    invoke-static {v11, v15}, Ljava/lang/Math;->min(II)I

    move-result v11

    const/16 v15, -0x8000

    invoke-static {v15, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    add-int v15, v13, v13

    add-int v21, v15, v21

    and-int/lit16 v15, v11, 0xff

    int-to-byte v15, v15

    aput-byte v15, v14, v21

    add-int/lit8 v15, v21, 0x1

    move/from16 p3, v1

    shr-int/lit8 v1, v11, 0x8

    int-to-byte v1, v1

    aput-byte v1, v14, v15

    sget-object v1, Las1;->m:[I

    aget v1, v1, p3

    add-int/2addr v10, v1

    const/16 v1, 0x58

    invoke-static {v10, v1}, Ljava/lang/Math;->min(II)I

    move-result v10

    const/4 v15, 0x0

    invoke-static {v15, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    aget v20, v19, v10

    add-int/lit8 v15, v22, 0x1

    move v1, v15

    goto :goto_4

    :cond_5
    add-int/lit8 v7, v7, 0x1

    move/from16 v1, p1

    goto/16 :goto_3

    :cond_6
    move/from16 p1, v1

    const/16 v18, 0x1

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_2

    :cond_7
    move/from16 p1, v1

    mul-int v6, v6, p1

    add-int/2addr v6, v6

    iget v1, v4, Les1;->a:I

    mul-int/2addr v6, v1

    const/4 v15, 0x0

    invoke-virtual {v3, v15}, Lzb3;->D(I)V

    invoke-virtual {v3, v6}, Lzb3;->C(I)V

    iget v1, v0, Las1;->i:I

    mul-int v2, p1, v8

    sub-int/2addr v1, v2

    iput v1, v0, Las1;->i:I

    iget v1, v3, Lzb3;->c:I

    iget-object v2, v0, Las1;->b:Llk1;

    invoke-interface {v2, v1, v3}, Llk1;->a(ILzb3;)V

    iget v2, v0, Las1;->k:I

    add-int/2addr v2, v1

    iput v2, v0, Las1;->k:I

    iget v1, v4, Les1;->a:I

    add-int/2addr v1, v1

    div-int/2addr v2, v1

    if-lt v2, v5, :cond_8

    invoke-virtual {v0, v5}, Las1;->c(I)V

    :cond_8
    if-eqz v9, :cond_9

    iget v1, v0, Las1;->k:I

    iget v2, v4, Les1;->a:I

    add-int/2addr v2, v2

    div-int/2addr v1, v2

    if-lez v1, :cond_9

    invoke-virtual {v0, v1}, Las1;->c(I)V

    :cond_9
    return v9
.end method

.method public final b(IJ)V
    .locals 7

    new-instance v0, Lfs1;

    iget v2, p0, Las1;->d:I

    int-to-long v3, p1

    iget-object v1, p0, Las1;->c:Les1;

    move-wide v5, p2

    invoke-direct/range {v0 .. v6}, Lfs1;-><init>(Les1;IJJ)V

    iget-object p1, p0, Las1;->a:Lmj1;

    invoke-interface {p1, v0}, Lmj1;->f0(Lbk1;)V

    iget-object p1, p0, Las1;->b:Llk1;

    iget-object p0, p0, Las1;->h:Lfx4;

    invoke-interface {p1, p0}, Llk1;->c(Lfx4;)V

    return-void
.end method

.method public final c(I)V
    .locals 20

    move-object/from16 v0, p0

    move/from16 v1, p1

    iget-object v2, v0, Las1;->c:Les1;

    iget v3, v2, Les1;->b:I

    int-to-long v8, v3

    sget-object v10, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    iget-wide v11, v0, Las1;->j:J

    iget-wide v4, v0, Las1;->l:J

    const-wide/32 v6, 0xf4240

    invoke-static/range {v4 .. v10}, Lvh3;->w(JJJLjava/math/RoundingMode;)J

    move-result-wide v3

    add-long v14, v11, v3

    add-int v3, v1, v1

    iget v2, v2, Les1;->a:I

    mul-int v17, v3, v2

    iget v2, v0, Las1;->k:I

    sub-int v18, v2, v17

    const/16 v16, 0x1

    const/16 v19, 0x0

    iget-object v13, v0, Las1;->b:Llk1;

    invoke-interface/range {v13 .. v19}, Llk1;->d(JIIILhk1;)V

    iget-wide v2, v0, Las1;->l:J

    int-to-long v4, v1

    add-long/2addr v2, v4

    iput-wide v2, v0, Las1;->l:J

    iget v1, v0, Las1;->k:I

    sub-int v1, v1, v17

    iput v1, v0, Las1;->k:I

    return-void
.end method

.method public final d(J)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Las1;->i:I

    iput-wide p1, p0, Las1;->j:J

    iput v0, p0, Las1;->k:I

    const-wide/16 p1, 0x0

    iput-wide p1, p0, Las1;->l:J

    return-void
.end method
