.class public final Laj4;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzi:Laj4;


# instance fields
.field private zza:I

.field private zzb:Lzi4;

.field private zzc:Lug4;

.field private zzd:Lyf4;

.field private zze:Lyf4;

.field private zzf:I

.field private zzg:Lyf4;

.field private zzh:B


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Laj4;

    invoke-direct {v0}, Laj4;-><init>()V

    sput-object v0, Laj4;->zzi:Laj4;

    const-class v1, Laj4;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    const/4 v0, 0x2

    iput-byte v0, p0, Laj4;->zzh:B

    sget-object v0, Lkh4;->l:Lkh4;

    iput-object v0, p0, Laj4;->zzc:Lug4;

    sget-object v0, Lyf4;->i:Lwf4;

    iput-object v0, p0, Laj4;->zzd:Lyf4;

    iput-object v0, p0, Laj4;->zze:Lyf4;

    iput-object v0, p0, Laj4;->zzg:Lyf4;

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 8

    invoke-static {p1}, Loj;->x(I)I

    move-result p1

    if-eqz p1, :cond_5

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eq p1, v1, :cond_3

    const/4 p0, 0x2

    if-eq p1, p0, :cond_2

    const/4 p0, 0x3

    if-eq p1, p0, :cond_1

    const/4 p0, 0x4

    if-eq p1, p0, :cond_0

    return-object v0

    :cond_0
    new-instance p0, Lab4;

    sget-object p1, Laj4;->zzi:Laj4;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Laj4;

    invoke-direct {p0}, Laj4;-><init>()V

    return-object p0

    :cond_2
    const-string v6, "zzf"

    const-string v7, "zzg"

    const-string v0, "zza"

    const-string v1, "zzb"

    const-string v2, "zzc"

    const-class v3, Lvi4;

    const-string v4, "zzd"

    const-string v5, "zze"

    filled-new-array/range {v0 .. v7}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Laj4;->zzi:Laj4;

    new-instance p2, Llh4;

    const-string v0, "\u0001\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0001\u0001\u0001\u1009\u0000\u0002\u041b\u0003\u100a\u0001\u0004\u100a\u0002\u0005\u1004\u0003\u0006\u100a\u0004"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_3
    if-nez p2, :cond_4

    const/4 v1, 0x0

    :cond_4
    iput-byte v1, p0, Laj4;->zzh:B

    return-object v0

    :cond_5
    iget-byte p0, p0, Laj4;->zzh:B

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
