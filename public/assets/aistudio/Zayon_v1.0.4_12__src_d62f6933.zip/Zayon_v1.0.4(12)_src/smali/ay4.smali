.class public final synthetic Lay4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic h:Lby4;


# direct methods
.method public synthetic constructor <init>(Lby4;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lay4;->h:Lby4;

    return-void
.end method


# virtual methods
.method public final synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 1

    sget-object v0, Lcy4;->a:Ljava/util/HashMap;

    iget-object p0, p0, Lay4;->h:Lby4;

    invoke-interface {p0, p2}, Lby4;->l(Ljava/lang/Object;)I

    move-result p2

    invoke-interface {p0, p1}, Lby4;->l(Ljava/lang/Object;)I

    move-result p0

    sub-int/2addr p2, p0

    return p2
.end method
