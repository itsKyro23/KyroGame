.class public interface abstract Lb6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La6;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La6;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb6;->a:La6;

    return-void
.end method
