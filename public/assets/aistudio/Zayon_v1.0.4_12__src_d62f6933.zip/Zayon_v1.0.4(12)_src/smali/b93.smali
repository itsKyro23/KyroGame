.class public final Lb93;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final synthetic a:I

.field public final b:Lxk4;

.field public final c:Lxk4;

.field public final d:Lxk4;


# direct methods
.method public synthetic constructor <init>(Lxk4;Lxk4;Lxk4;I)V
    .locals 0

    iput p4, p0, Lb93;->a:I

    iput-object p1, p0, Lb93;->b:Lxk4;

    iput-object p2, p0, Lb93;->c:Lxk4;

    iput-object p3, p0, Lb93;->d:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Lya3;
    .locals 6

    sget-object v1, Laj2;->a:Lzi2;

    invoke-static {v1}, Lms2;->q(Ljava/lang/Object;)V

    iget-object v0, p0, Lb93;->b:Lxk4;

    invoke-interface {v0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lr13;

    iget-object v0, p0, Lb93;->c:Lxk4;

    invoke-interface {v0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Lw33;

    iget-object p0, p0, Lb93;->d:Lxk4;

    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Llb3;

    new-instance v0, Lya3;

    const/4 v5, 0x2

    invoke-direct/range {v0 .. v5}, Lya3;-><init>(Lzi2;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-object v0
.end method

.method public final d()Ljava/lang/Object;
    .locals 5

    iget v0, p0, Lb93;->a:I

    const/4 v1, 0x1

    iget-object v2, p0, Lb93;->d:Lxk4;

    iget-object v3, p0, Lb93;->c:Lxk4;

    iget-object v4, p0, Lb93;->b:Lxk4;

    packed-switch v0, :pswitch_data_0

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lyo3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lju3;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcp3;

    new-instance v1, Ltt3;

    invoke-virtual {v0}, Lcp3;->Z()Ljp3;

    move-result-object v0

    invoke-virtual {v0}, Ljp3;->z()J

    move-result-wide v2

    invoke-direct {v1, p0, v2, v3}, Ltt3;-><init>(Lju3;J)V

    return-object v1

    :pswitch_0
    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Leq3;

    new-instance v2, Lks3;

    invoke-direct {v2, p0, v0, v1}, Lks3;-><init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;Leq3;)V

    return-object v2

    :pswitch_1
    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcp3;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvt3;

    new-instance v2, Lls3;

    invoke-direct {v2, p0, v0, v1}, Lls3;-><init>(Landroid/content/Context;Lcp3;Lvt3;)V

    return-object v2

    :pswitch_2
    check-cast v4, Ljd3;

    invoke-virtual {v4}, Ljd3;->a()Lgb3;

    move-result-object p0

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lfc3;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    const-string v3, "29"

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    move-object p0, v0

    :goto_0
    invoke-static {p0}, Lms2;->q(Ljava/lang/Object;)V

    return-object p0

    :pswitch_3
    sget-object p0, Laj2;->a:Lzi2;

    invoke-static {p0}, Lms2;->q(Ljava/lang/Object;)V

    new-instance v0, Lgc3;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lgc3;-><init>(Lzi2;I)V

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfc3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/concurrent/ScheduledExecutorService;

    const-string v3, "24"

    invoke-interface {v1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v0, Lab3;

    sget-object v1, Lk52;->Pd:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v3, v1

    invoke-direct {v0, p0, v3, v4, v2}, Lab3;-><init>(Lud3;JLjava/util/concurrent/ScheduledExecutorService;)V

    goto :goto_1

    :cond_1
    new-instance p0, Lab3;

    sget-object v1, Lk52;->Pd:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    int-to-long v3, v1

    invoke-direct {p0, v0, v3, v4, v2}, Lab3;-><init>(Lud3;JLjava/util/concurrent/ScheduledExecutorService;)V

    move-object v0, p0

    :goto_1
    return-object v0

    :pswitch_4
    check-cast v4, Lxa3;

    iget-object p0, v4, Lxa3;->a:Lxk4;

    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    new-instance v0, Lva3;

    const/4 v4, 0x0

    invoke-direct {v0, v4, p0}, Lva3;-><init>(ILjava/lang/Object;)V

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfc3;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    const-string v3, "2"

    invoke-interface {v2, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eq v1, v2, :cond_2

    goto :goto_2

    :cond_2
    move-object v0, p0

    :goto_2
    invoke-static {v0}, Lms2;->q(Ljava/lang/Object;)V

    return-object v0

    :pswitch_5
    check-cast v4, Lfn2;

    invoke-virtual {v4}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lui2;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/concurrent/ScheduledExecutorService;

    sget-object v2, Laj2;->a:Lzi2;

    invoke-static {v2}, Lms2;->q(Ljava/lang/Object;)V

    new-instance v3, Lrb3;

    invoke-direct {v3, p0, v0, v1, v2}, Lrb3;-><init>(Landroid/content/Context;Lui2;Ljava/util/concurrent/ScheduledExecutorService;Lzi2;)V

    return-object v3

    :pswitch_6
    invoke-virtual {p0}, Lb93;->a()Lya3;

    move-result-object p0

    return-object p0

    :pswitch_7
    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvg3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lq13;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lu23;

    new-instance v2, Loo4;

    const/16 v3, 0x13

    invoke-direct {v2, v3, p0, v0, v1}, Loo4;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
