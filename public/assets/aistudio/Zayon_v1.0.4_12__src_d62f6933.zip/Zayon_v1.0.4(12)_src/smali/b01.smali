.class public final Lb01;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lbw;
.implements Lzz;
.implements Lcw;


# static fields
.field public static final synthetic l:J


# instance fields
.field private volatile synthetic _state$volatile:Ljava/lang/Object;

.field public h:[Lc01;

.field public i:I

.field public j:I

.field public k:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    sget-object v0, Lt9;->a:Lsun/misc/Unsafe;

    const-class v1, Lb01;

    const-string v2, "_state$volatile"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    invoke-virtual {v0, v1}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v0

    sput-wide v0, Lb01;->l:J

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb01;->_state$volatile:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final E(Lcw;Llj;)Ljava/lang/Object;
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    instance-of v2, v0, La01;

    if-eqz v2, :cond_0

    move-object v2, v0

    check-cast v2, La01;

    iget v3, v2, La01;->r:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_0

    sub-int/2addr v3, v4

    iput v3, v2, La01;->r:I

    goto :goto_0

    :cond_0
    new-instance v2, La01;

    invoke-direct {v2, v1, v0}, La01;-><init>(Lb01;Llj;)V

    :goto_0
    iget-object v0, v2, La01;->p:Ljava/lang/Object;

    sget-object v3, Lbk;->h:Lbk;

    iget v4, v2, La01;->r:I

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v4, :cond_4

    if-eq v4, v9, :cond_3

    if-eq v4, v8, :cond_2

    if-ne v4, v5, :cond_1

    iget-object v1, v2, La01;->o:Ljava/lang/Object;

    iget-object v4, v2, La01;->n:Le80;

    iget-object v10, v2, La01;->m:Lc01;

    iget-object v11, v2, La01;->l:Lcw;

    iget-object v12, v2, La01;->k:Lb01;

    :try_start_0
    invoke-static {v0}, Lsl3;->j(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v0, v1

    goto/16 :goto_b

    :catchall_0
    move-exception v0

    goto/16 :goto_c

    :cond_1
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lb;->d(Ljava/lang/String;)V

    return-object v6

    :cond_2
    iget-object v1, v2, La01;->o:Ljava/lang/Object;

    iget-object v4, v2, La01;->n:Le80;

    iget-object v10, v2, La01;->m:Lc01;

    iget-object v11, v2, La01;->l:Lcw;

    iget-object v12, v2, La01;->k:Lb01;

    :try_start_1
    invoke-static {v0}, Lsl3;->j(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto/16 :goto_7

    :cond_3
    iget-object v10, v2, La01;->m:Lc01;

    iget-object v1, v2, La01;->l:Lcw;

    iget-object v4, v2, La01;->k:Lb01;

    :try_start_2
    invoke-static {v0}, Lsl3;->j(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v0, v1

    move-object v1, v4

    goto :goto_3

    :catchall_1
    move-exception v0

    move-object v12, v4

    goto/16 :goto_c

    :cond_4
    invoke-static {v0}, Lsl3;->j(Ljava/lang/Object;)V

    monitor-enter p0

    :try_start_3
    iget-object v0, v1, Lb01;->h:[Lc01;

    if-nez v0, :cond_5

    new-array v0, v8, [Lc01;

    iput-object v0, v1, Lb01;->h:[Lc01;

    goto :goto_1

    :catchall_2
    move-exception v0

    goto/16 :goto_f

    :cond_5
    iget v4, v1, Lb01;->i:I

    array-length v10, v0

    if-lt v4, v10, :cond_6

    array-length v4, v0

    mul-int/2addr v4, v8

    invoke-static {v0, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, [Lc01;

    iput-object v4, v1, Lb01;->h:[Lc01;

    check-cast v0, [Lc01;

    :cond_6
    :goto_1
    iget v4, v1, Lb01;->j:I

    :goto_2
    aget-object v10, v0, v4

    if-nez v10, :cond_7

    new-instance v10, Lc01;

    invoke-direct {v10}, Lc01;-><init>()V

    aput-object v10, v0, v4

    :cond_7
    add-int/lit8 v4, v4, 0x1

    array-length v11, v0

    if-lt v4, v11, :cond_8

    move v4, v7

    :cond_8
    iget-object v11, v10, Lc01;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v11}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v12

    if-eqz v12, :cond_9

    goto :goto_2

    :cond_9
    sget-object v0, Lvm;->i:Lc34;

    invoke-virtual {v11, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iput v4, v1, Lb01;->j:I

    iget v0, v1, Lb01;->i:I

    add-int/2addr v0, v9

    iput v0, v1, Lb01;->i:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    monitor-exit p0

    move-object/from16 v0, p1

    :goto_3
    :try_start_4
    iget-object v4, v2, Llj;->i:Lsj;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v11, Lq24;->j:Lq24;

    invoke-interface {v4, v11}, Lsj;->h(Lrj;)Lqj;

    move-result-object v4

    check-cast v4, Le80;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    move-object v11, v0

    move-object v12, v1

    move-object v0, v6

    :goto_4
    if-eqz v12, :cond_15

    :try_start_5
    sget-object v1, Lt9;->a:Lsun/misc/Unsafe;

    sget-wide v13, Lb01;->l:J

    invoke-virtual {v1, v12, v13, v14}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v1

    if-eqz v4, :cond_b

    invoke-virtual {v4}, Le80;->F()Z

    move-result v13

    if-eqz v13, :cond_a

    goto :goto_5

    :cond_a
    invoke-virtual {v4}, Le80;->w()Ljava/util/concurrent/CancellationException;

    move-result-object v0

    throw v0

    :cond_b
    :goto_5
    if-eqz v0, :cond_c

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_f

    :cond_c
    sget-object v0, Lw93;->a:Lc34;

    if-ne v1, v0, :cond_d

    move-object v0, v6

    goto :goto_6

    :cond_d
    move-object v0, v1

    :goto_6
    iput-object v12, v2, La01;->k:Lb01;

    iput-object v11, v2, La01;->l:Lcw;

    iput-object v10, v2, La01;->m:Lc01;

    iput-object v4, v2, La01;->n:Le80;

    iput-object v1, v2, La01;->o:Ljava/lang/Object;

    iput v8, v2, La01;->r:I

    invoke-interface {v11, v0, v2}, Lcw;->i(Ljava/lang/Object;Ljj;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v3, :cond_e

    goto :goto_a

    :cond_e
    :goto_7
    move-object v0, v1

    :cond_f
    iget-object v1, v10, Lc01;->a:Ljava/util/concurrent/atomic/AtomicReference;

    sget-object v13, Lvm;->i:Lc34;

    invoke-virtual {v1, v13}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v14, Lvm;->j:Lc34;

    if-ne v1, v14, :cond_10

    goto :goto_4

    :cond_10
    iput-object v12, v2, La01;->k:Lb01;

    iput-object v11, v2, La01;->l:Lcw;

    iput-object v10, v2, La01;->m:Lc01;

    iput-object v4, v2, La01;->n:Le80;

    iput-object v0, v2, La01;->o:Ljava/lang/Object;

    iput v5, v2, La01;->r:I

    sget-object v1, Lm51;->a:Lm51;

    new-instance v14, Lhe;

    invoke-static {v2}, Lms2;->e(Ljj;)Ljj;

    move-result-object v15

    invoke-direct {v14, v9, v15}, Lhe;-><init>(ILjj;)V

    invoke-virtual {v14}, Lhe;->t()V

    iget-object v15, v10, Lc01;->a:Ljava/util/concurrent/atomic/AtomicReference;

    :goto_8
    invoke-virtual {v15, v13, v14}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v16

    if-eqz v16, :cond_11

    goto :goto_9

    :cond_11
    invoke-virtual {v15}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    if-eq v5, v13, :cond_14

    invoke-virtual {v14, v1}, Lhe;->d(Ljava/lang/Object;)V

    :goto_9
    invoke-virtual {v14}, Lhe;->s()Ljava/lang/Object;

    move-result-object v5

    sget-object v13, Lbk;->h:Lbk;

    if-ne v5, v13, :cond_12

    move-object v1, v5

    :cond_12
    if-ne v1, v3, :cond_13

    :goto_a
    return-object v3

    :cond_13
    :goto_b
    const/4 v5, 0x3

    goto/16 :goto_4

    :cond_14
    const/4 v5, 0x3

    goto :goto_8

    :cond_15
    new-instance v0, Ljava/lang/ClassCastException;

    invoke-direct {v0}, Ljava/lang/ClassCastException;-><init>()V

    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :catchall_3
    move-exception v0

    move-object v12, v1

    :goto_c
    monitor-enter v12

    :try_start_6
    iget v1, v12, Lb01;->i:I

    add-int/lit8 v1, v1, -0x1

    iput v1, v12, Lb01;->i:I

    if-nez v1, :cond_16

    iput v7, v12, Lb01;->j:I

    goto :goto_d

    :catchall_4
    move-exception v0

    goto :goto_e

    :cond_16
    :goto_d
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v10, Lc01;->a:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1, v6}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    monitor-exit v12

    throw v0

    :goto_e
    monitor-exit v12

    throw v0

    :goto_f
    monitor-exit p0

    throw v0
.end method

.method public final a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 9

    monitor-enter p0

    :try_start_0
    sget-object v0, Lt9;->a:Lsun/misc/Unsafe;

    sget-wide v1, Lb01;->l:J

    invoke-virtual {v0, p0, v1, v2}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    invoke-static {v3, p1}, Li60;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez p1, :cond_0

    monitor-exit p0

    return v4

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_0
    :try_start_1
    invoke-static {v3, p2}, Li60;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    monitor-exit p0

    return v3

    :cond_1
    :try_start_2
    invoke-virtual {v0, p0, v1, v2, p2}, Lsun/misc/Unsafe;->putObjectVolatile(Ljava/lang/Object;JLjava/lang/Object;)V

    iget p1, p0, Lb01;->k:I

    and-int/lit8 p2, p1, 0x1

    if-nez p2, :cond_b

    add-int/2addr p1, v3

    iput p1, p0, Lb01;->k:I

    iget-object p2, p0, Lb01;->h:[Lc01;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    :goto_0
    if-eqz p2, :cond_9

    array-length v0, p2

    move v1, v4

    :goto_1
    if-ge v1, v0, :cond_9

    aget-object v2, p2, v1

    if-eqz v2, :cond_8

    iget-object v2, v2, Lc01;->a:Ljava/util/concurrent/atomic/AtomicReference;

    :goto_2
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_2

    goto :goto_3

    :cond_2
    sget-object v6, Lvm;->j:Lc34;

    if-ne v5, v6, :cond_3

    goto :goto_3

    :cond_3
    sget-object v7, Lvm;->i:Lc34;

    if-ne v5, v7, :cond_6

    :cond_4
    invoke-virtual {v2, v5, v6}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v7

    if-eq v7, v5, :cond_4

    goto :goto_2

    :cond_6
    invoke-virtual {v2, v5, v7}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_7

    check-cast v5, Lhe;

    sget-object v2, Lm51;->a:Lm51;

    invoke-virtual {v5, v2}, Lhe;->d(Ljava/lang/Object;)V

    goto :goto_3

    :cond_7
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v6

    if-eq v6, v5, :cond_6

    goto :goto_2

    :cond_8
    :goto_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_9
    monitor-enter p0

    :try_start_3
    iget p2, p0, Lb01;->k:I

    if-ne p2, p1, :cond_a

    add-int/2addr p1, v3

    iput p1, p0, Lb01;->k:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit p0

    return v3

    :catchall_1
    move-exception p1

    goto :goto_4

    :cond_a
    :try_start_4
    iget-object p1, p0, Lb01;->h:[Lc01;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    monitor-exit p0

    move v8, p2

    move-object p2, p1

    move p1, v8

    goto :goto_0

    :goto_4
    monitor-exit p0

    throw p1

    :cond_b
    add-int/lit8 p1, p1, 0x2

    :try_start_5
    iput p1, p0, Lb01;->k:I
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    monitor-exit p0

    return v3

    :goto_5
    monitor-exit p0

    throw p1
.end method

.method public final c(Lsj;ILid;)Lbw;
    .locals 1

    if-ltz p2, :cond_0

    const/4 v0, 0x2

    if-ge p2, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, -0x2

    if-ne p2, v0, :cond_1

    :goto_0
    sget-object v0, Lid;->i:Lid;

    if-ne p3, v0, :cond_1

    goto :goto_1

    :cond_1
    if-eqz p2, :cond_2

    const/4 v0, -0x3

    if-ne p2, v0, :cond_3

    :cond_2
    sget-object v0, Lid;->h:Lid;

    if-ne p3, v0, :cond_3

    :goto_1
    return-object p0

    :cond_3
    new-instance v0, Lwe;

    invoke-direct {v0, p0, p1, p2, p3}, Lwe;-><init>(Lbw;Lsj;ILid;)V

    return-object v0
.end method

.method public final i(Ljava/lang/Object;Ljj;)Ljava/lang/Object;
    .locals 0

    if-nez p1, :cond_0

    sget-object p1, Lw93;->a:Lc34;

    :cond_0
    const/4 p2, 0x0

    invoke-virtual {p0, p2, p1}, Lb01;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    sget-object p0, Lm51;->a:Lm51;

    return-object p0
.end method
