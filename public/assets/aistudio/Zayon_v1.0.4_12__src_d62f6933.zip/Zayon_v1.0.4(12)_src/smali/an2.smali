.class public final Lan2;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Lfi4;

.field public c:Ldk4;

.field public final d:Ljava/util/concurrent/ScheduledExecutorService;

.field public final e:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/ScheduledExecutorService;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lan2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput-object p1, p0, Lan2;->d:Ljava/util/concurrent/ScheduledExecutorService;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    sget-object v0, Lk52;->ha:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lan2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lan2;->b()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final b()V
    .locals 4

    :try_start_0
    const-string v0, "GET_VARIATIONS_HEADER"

    invoke-static {v0}, Lu81;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lr81;->b()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    iput-object v0, p0, Lan2;->a:Ljava/lang/String;

    const/16 v1, 0xa

    invoke-static {v0, v1}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    invoke-static {}, Lgg4;->a()Lgg4;

    move-result-object v1

    invoke-static {v0, v1}, Lfi4;->y([BLgg4;)Lfi4;

    move-result-object v1

    iput-object v1, p0, Lan2;->b:Lfi4;

    sget-object v1, Lk52;->ka:Lg52;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lyg4; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v3, v2, Lvx1;->c:Li52;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lyg4; {:try_start_1 .. :try_end_1} :catch_0

    :try_start_2
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {}, Lgg4;->a()Lgg4;

    move-result-object v1

    invoke-static {v0, v1}, Ldk4;->y([BLgg4;)Ldk4;

    move-result-object v0

    iput-object v0, p0, Lan2;->c:Ldk4;

    :cond_2
    sget-object v0, Lk52;->ia:Lg52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_3

    sget-object v0, Lk52;->ha:Lg52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lan2;->d:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lzm2;

    const/4 v3, 0x0

    invoke-direct {v1, v3, p0}, Lzm2;-><init>(ILjava/lang/Object;)V

    sget-object p0, Lk52;->ja:Lg52;

    invoke-virtual {v2, p0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    int-to-long v2, p0

    sget-object p0, Ljava/util/concurrent/TimeUnit;->MINUTES:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v0, v1, v2, v3, p0}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Lyg4; {:try_start_2 .. :try_end_2} :catch_1

    return-void

    :catch_0
    move-exception p0

    goto :goto_2

    :cond_3
    :goto_1
    return-void

    :catch_1
    move-exception p0

    :goto_2
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->h:Lui2;

    const-string v1, "ChromeVariations"

    invoke-virtual {v0, v1, p0}, Lui2;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
