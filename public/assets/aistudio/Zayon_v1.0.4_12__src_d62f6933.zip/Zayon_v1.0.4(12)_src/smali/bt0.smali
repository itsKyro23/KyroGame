.class public final Lbt0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final f:Landroid/graphics/PorterDuff$Mode;

.field public static g:Lbt0;

.field public static final h:Lat0;


# instance fields
.field public a:Ljava/util/WeakHashMap;

.field public final b:Ljava/util/WeakHashMap;

.field public c:Landroid/util/TypedValue;

.field public d:Z

.field public e:Lfu1;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    sput-object v0, Lbt0;->f:Landroid/graphics/PorterDuff$Mode;

    new-instance v0, Lat0;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lec0;-><init>(I)V

    sput-object v0, Lbt0;->h:Lat0;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    iput-object v0, p0, Lbt0;->b:Ljava/util/WeakHashMap;

    return-void
.end method

.method public static declared-synchronized c()Lbt0;
    .locals 2

    const-class v0, Lbt0;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lbt0;->g:Lbt0;

    if-nez v1, :cond_0

    new-instance v1, Lbt0;

    invoke-direct {v1}, Lbt0;-><init>()V

    sput-object v1, Lbt0;->g:Lbt0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    return-object v1

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method public static declared-synchronized f(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;
    .locals 4

    const-class v0, Lbt0;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lbt0;->h:Lat0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x1f

    add-int v3, v2, p0

    mul-int/2addr v3, v2

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Lec0;->f(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/PorterDuffColorFilter;

    if-nez v2, :cond_0

    new-instance v2, Landroid/graphics/PorterDuffColorFilter;

    invoke-direct {v2, p0, p1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr p0, v3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {v1, p0, v2}, Lec0;->j(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/PorterDuffColorFilter;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    return-object v2

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static i(Landroid/graphics/drawable/Drawable;Lcl3;[I)V
    .locals 4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-ne v1, p0, :cond_7

    instance-of v1, p0, Landroid/graphics/drawable/LayerDrawable;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v1

    if-eqz v1, :cond_0

    new-array v1, v2, [I

    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_0
    iget-boolean v0, p1, Lcl3;->b:Z

    if-nez v0, :cond_2

    iget-boolean v1, p1, Lcl3;->a:Z

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->clearColorFilter()V

    return-void

    :cond_2
    :goto_0
    const/4 v1, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p1, Lcl3;->c:Ljava/lang/Object;

    check-cast v0, Landroid/content/res/ColorStateList;

    goto :goto_1

    :cond_3
    move-object v0, v1

    :goto_1
    iget-boolean v3, p1, Lcl3;->a:Z

    if-eqz v3, :cond_4

    iget-object p1, p1, Lcl3;->d:Ljava/lang/Object;

    check-cast p1, Landroid/graphics/PorterDuff$Mode;

    goto :goto_2

    :cond_4
    sget-object p1, Lbt0;->f:Landroid/graphics/PorterDuff$Mode;

    :goto_2
    if-eqz v0, :cond_6

    if-nez p1, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {v0, p2, v2}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p2

    invoke-static {p2, p1}, Lbt0;->f(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v1

    :cond_6
    :goto_3
    invoke-virtual {p0, v1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :cond_7
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    .locals 7

    iget-object v0, p0, Lbt0;->a:Ljava/util/WeakHashMap;

    if-nez v0, :cond_0

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Lbt0;->a:Ljava/util/WeakHashMap;

    :cond_0
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lez0;

    if-nez v0, :cond_1

    new-instance v0, Lez0;

    invoke-direct {v0}, Lez0;-><init>()V

    iget-object p0, p0, Lbt0;->a:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    iget p0, v0, Lez0;->j:I

    const/16 p1, 0x20

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p0, :cond_8

    iget-object v3, v0, Lez0;->h:[I

    add-int/lit8 v4, p0, -0x1

    aget v4, v3, v4

    if-gt p2, v4, :cond_8

    invoke-static {p0, p2, v3}, Lhd1;->e(II[I)I

    move-result p0

    if-ltz p0, :cond_2

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    aput-object p3, p1, p0

    return-void

    :cond_2
    not-int p0, p0

    iget v3, v0, Lez0;->j:I

    if-ge p0, v3, :cond_3

    iget-object v4, v0, Lez0;->i:[Ljava/lang/Object;

    aget-object v5, v4, p0

    sget-object v6, Lgd;->h:Ljava/lang/Object;

    if-ne v5, v6, :cond_3

    iget-object p1, v0, Lez0;->h:[I

    aput p2, p1, p0

    aput-object p3, v4, p0

    return-void

    :cond_3
    iget-object v4, v0, Lez0;->h:[I

    array-length v4, v4

    if-lt v3, v4, :cond_6

    add-int/2addr v3, v2

    mul-int/2addr v3, v1

    move v4, v1

    :goto_0
    if-ge v4, p1, :cond_5

    shl-int v5, v2, v4

    add-int/lit8 v5, v5, -0xc

    if-gt v3, v5, :cond_4

    move v3, v5

    goto :goto_1

    :cond_4
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_5
    :goto_1
    div-int/2addr v3, v1

    iget-object p1, v0, Lez0;->h:[I

    invoke-static {p1, v3}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    iput-object p1, v0, Lez0;->h:[I

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    invoke-static {p1, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    iput-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    :cond_6
    iget p1, v0, Lez0;->j:I

    sub-int v1, p1, p0

    if-eqz v1, :cond_7

    iget-object v1, v0, Lez0;->h:[I

    add-int/lit8 v3, p0, 0x1

    invoke-static {v3, p0, p1, v1, v1}, Ls9;->b(III[I[I)V

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    iget v1, v0, Lez0;->j:I

    invoke-static {v3, p0, v1, p1, p1}, Ls9;->c(III[Ljava/lang/Object;[Ljava/lang/Object;)V

    :cond_7
    iget-object p1, v0, Lez0;->h:[I

    aput p2, p1, p0

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    aput-object p3, p1, p0

    iget p0, v0, Lez0;->j:I

    add-int/2addr p0, v2

    iput p0, v0, Lez0;->j:I

    return-void

    :cond_8
    iget-object v3, v0, Lez0;->h:[I

    array-length v3, v3

    if-lt p0, v3, :cond_b

    add-int/lit8 v3, p0, 0x1

    mul-int/2addr v3, v1

    move v4, v1

    :goto_2
    if-ge v4, p1, :cond_a

    shl-int v5, v2, v4

    add-int/lit8 v5, v5, -0xc

    if-gt v3, v5, :cond_9

    move v3, v5

    goto :goto_3

    :cond_9
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_a
    :goto_3
    div-int/2addr v3, v1

    iget-object p1, v0, Lez0;->h:[I

    invoke-static {p1, v3}, Ljava/util/Arrays;->copyOf([II)[I

    move-result-object p1

    iput-object p1, v0, Lez0;->h:[I

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    invoke-static {p1, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    iput-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    :cond_b
    iget-object p1, v0, Lez0;->h:[I

    aput p2, p1, p0

    iget-object p1, v0, Lez0;->i:[Ljava/lang/Object;

    aput-object p3, p1, p0

    add-int/2addr p0, v2

    iput p0, v0, Lez0;->j:I

    return-void
.end method

.method public final b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 10

    iget-object v0, p0, Lbt0;->c:Landroid/util/TypedValue;

    if-nez v0, :cond_0

    new-instance v0, Landroid/util/TypedValue;

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    iput-object v0, p0, Lbt0;->c:Landroid/util/TypedValue;

    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, p2, v0, v2}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    iget v1, v0, Landroid/util/TypedValue;->assetCookie:I

    int-to-long v3, v1

    const/16 v1, 0x20

    shl-long/2addr v3, v1

    iget v1, v0, Landroid/util/TypedValue;->data:I

    int-to-long v5, v1

    or-long/2addr v3, v5

    monitor-enter p0

    :try_start_0
    iget-object v1, p0, Lbt0;->b:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lmb0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    if-nez v1, :cond_1

    monitor-exit p0

    :goto_0
    move-object v1, v5

    goto :goto_1

    :cond_1
    :try_start_1
    iget-object v6, v1, Lmb0;->i:[J

    iget v7, v1, Lmb0;->k:I

    invoke-static {v7, v3, v4, v6}, Lhd1;->f(IJ[J)I

    move-result v6

    if-ltz v6, :cond_2

    iget-object v7, v1, Lmb0;->j:[Ljava/lang/Object;

    aget-object v6, v7, v6

    sget-object v7, Luo2;->i:Ljava/lang/Object;

    if-ne v6, v7, :cond_3

    :cond_2
    move-object v6, v5

    :cond_3
    check-cast v6, Ljava/lang/ref/WeakReference;

    if-eqz v6, :cond_5

    invoke-virtual {v6}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/graphics/drawable/Drawable$ConstantState;

    if-eqz v6, :cond_4

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p0

    goto :goto_1

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_4
    :try_start_2
    iget-object v6, v1, Lmb0;->i:[J

    iget v7, v1, Lmb0;->k:I

    invoke-static {v7, v3, v4, v6}, Lhd1;->f(IJ[J)I

    move-result v6

    if-ltz v6, :cond_5

    iget-object v7, v1, Lmb0;->j:[Ljava/lang/Object;

    aget-object v8, v7, v6

    sget-object v9, Luo2;->i:Ljava/lang/Object;

    if-eq v8, v9, :cond_5

    aput-object v9, v7, v6

    iput-boolean v2, v1, Lmb0;->h:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_5
    monitor-exit p0

    goto :goto_0

    :goto_1
    if-eqz v1, :cond_6

    return-object v1

    :cond_6
    iget-object v1, p0, Lbt0;->e:Lfu1;

    if-nez v1, :cond_7

    goto :goto_2

    :cond_7
    const v1, 0x7f070013

    if-ne p2, v1, :cond_8

    new-instance v5, Landroid/graphics/drawable/LayerDrawable;

    const p2, 0x7f070012

    invoke-virtual {p0, p1, p2}, Lbt0;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const v1, 0x7f070014

    invoke-virtual {p0, p1, v1}, Lbt0;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    filled-new-array {p2, v1}, [Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-direct {v5, p2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    goto :goto_2

    :cond_8
    const v1, 0x7f070036

    if-ne p2, v1, :cond_9

    const p2, 0x7f06003b

    invoke-static {p0, p1, p2}, Lfu1;->c(Lbt0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    move-result-object v5

    goto :goto_2

    :cond_9
    const v1, 0x7f070035

    if-ne p2, v1, :cond_a

    const p2, 0x7f06003c

    invoke-static {p0, p1, p2}, Lfu1;->c(Lbt0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    move-result-object v5

    goto :goto_2

    :cond_a
    const v1, 0x7f070037

    if-ne p2, v1, :cond_b

    const p2, 0x7f06003d

    invoke-static {p0, p1, p2}, Lfu1;->c(Lbt0;Landroid/content/Context;I)Landroid/graphics/drawable/LayerDrawable;

    move-result-object v5

    :cond_b
    :goto_2
    if-eqz v5, :cond_e

    iget p2, v0, Landroid/util/TypedValue;->changingConfigurations:I

    invoke-virtual {v5, p2}, Landroid/graphics/drawable/Drawable;->setChangingConfigurations(I)V

    monitor-enter p0

    :try_start_3
    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p2

    if-eqz p2, :cond_d

    iget-object v0, p0, Lbt0;->b:Ljava/util/WeakHashMap;

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lmb0;

    if-nez v0, :cond_c

    new-instance v0, Lmb0;

    invoke-direct {v0}, Lmb0;-><init>()V

    iget-object v1, p0, Lbt0;->b:Ljava/util/WeakHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :catchall_1
    move-exception p1

    goto :goto_4

    :cond_c
    :goto_3
    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, v3, v4, p1}, Lmb0;->a(JLjava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit p0

    return-object v5

    :cond_d
    monitor-exit p0

    return-object v5

    :goto_4
    :try_start_4
    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p1

    :cond_e
    return-object v5

    :goto_5
    :try_start_5
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    throw p1
.end method

.method public final declared-synchronized d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .locals 1

    monitor-enter p0

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p0, p1, p2, v0}, Lbt0;->e(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized e(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, Lbt0;->d:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lbt0;->d:Z

    const v0, 0x7f070051

    invoke-virtual {p0, p1, v0}, Lbt0;->d(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_4

    const-string v1, "android.graphics.drawable.VectorDrawable"

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    :goto_0
    invoke-virtual {p0, p1, p2}, Lbt0;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_1

    invoke-virtual {p1, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_1
    :goto_1
    if-eqz v0, :cond_2

    invoke-virtual {p0, p1, p2, p3, v0}, Lbt0;->h(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :cond_2
    if-eqz v0, :cond_3

    invoke-static {v0}, Lgr;->a(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    monitor-exit p0

    return-object v0

    :cond_4
    const/4 p1, 0x0

    :try_start_1
    iput-boolean p1, p0, Lbt0;->d:Z

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat."

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_2
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lbt0;->a:Ljava/util/WeakHashMap;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lez0;

    if-eqz v0, :cond_2

    iget-object v2, v0, Lez0;->h:[I

    iget v3, v0, Lez0;->j:I

    invoke-static {v3, p2, v2}, Lhd1;->e(II[I)I

    move-result v2

    if-ltz v2, :cond_0

    iget-object v0, v0, Lez0;->i:[Ljava/lang/Object;

    aget-object v0, v0, v2

    sget-object v2, Lgd;->h:Ljava/lang/Object;

    if-ne v0, v2, :cond_1

    :cond_0
    move-object v0, v1

    :cond_1
    check-cast v0, Landroid/content/res/ColorStateList;

    goto :goto_0

    :cond_2
    move-object v0, v1

    :goto_0
    if-nez v0, :cond_5

    iget-object v0, p0, Lbt0;->e:Lfu1;

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0, p1, p2}, Lfu1;->e(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    :goto_1
    if-eqz v1, :cond_4

    invoke-virtual {p0, p1, p2, v1}, Lbt0;->a(Landroid/content/Context;ILandroid/content/res/ColorStateList;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_4
    :goto_2
    move-object v0, v1

    :cond_5
    monitor-exit p0

    return-object v0

    :goto_3
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final h(Landroid/content/Context;IZLandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 8

    invoke-virtual {p0, p1, p2}, Lbt0;->g(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    iget-object p0, p0, Lbt0;->e:Lfu1;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const p0, 0x7f070044

    if-ne p2, p0, :cond_1

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    :cond_1
    :goto_0
    if-eqz v1, :cond_2

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    return-object p1

    :cond_3
    iget-object v0, p0, Lbt0;->e:Lfu1;

    const v2, 0x7f03005b

    const v3, 0x7f030059

    if-eqz v0, :cond_6

    const v0, 0x7f07003f

    const v4, 0x102000d

    const v5, 0x102000f

    const/high16 v6, 0x1020000

    if-ne p2, v0, :cond_4

    move-object p0, p4

    check-cast p0, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p0, v6}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v2}, Lg31;->c(Landroid/content/Context;I)I

    move-result p3

    sget-object v0, Ll7;->b:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p2, p3, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v5}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v2}, Lg31;->c(Landroid/content/Context;I)I

    move-result p3

    invoke-static {p2, p3, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-static {p1, v3}, Lg31;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-static {p0, p1, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    return-object p4

    :cond_4
    const v0, 0x7f070036

    if-eq p2, v0, :cond_5

    const v0, 0x7f070035

    if-eq p2, v0, :cond_5

    const v0, 0x7f070037

    if-ne p2, v0, :cond_6

    :cond_5
    move-object p0, p4

    check-cast p0, Landroid/graphics/drawable/LayerDrawable;

    invoke-virtual {p0, v6}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v2}, Lg31;->b(Landroid/content/Context;I)I

    move-result p3

    sget-object v0, Ll7;->b:Landroid/graphics/PorterDuff$Mode;

    invoke-static {p2, p3, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v5}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v3}, Lg31;->c(Landroid/content/Context;I)I

    move-result p3

    invoke-static {p2, p3, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {p0, v4}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    invoke-static {p1, v3}, Lg31;->c(Landroid/content/Context;I)I

    move-result p1

    invoke-static {p0, p1, v0}, Lfu1;->f(Landroid/graphics/drawable/Drawable;ILandroid/graphics/PorterDuff$Mode;)V

    return-object p4

    :cond_6
    iget-object p0, p0, Lbt0;->e:Lfu1;

    const/4 v0, 0x0

    if-eqz p0, :cond_d

    sget-object v4, Ll7;->b:Landroid/graphics/PorterDuff$Mode;

    iget-object v5, p0, Lfu1;->h:Ljava/lang/Object;

    check-cast v5, [I

    invoke-static {v5, p2}, Lfu1;->a([II)Z

    move-result v5

    const/4 v6, 0x1

    const/4 v7, -0x1

    if-eqz v5, :cond_7

    :goto_1
    move p2, v6

    :goto_2
    move p0, v7

    goto :goto_3

    :cond_7
    iget-object v2, p0, Lfu1;->j:Ljava/lang/Object;

    check-cast v2, [I

    invoke-static {v2, p2}, Lfu1;->a([II)Z

    move-result v2

    if-eqz v2, :cond_8

    move v2, v3

    goto :goto_1

    :cond_8
    iget-object p0, p0, Lfu1;->k:Ljava/lang/Object;

    check-cast p0, [I

    invoke-static {p0, p2}, Lfu1;->a([II)Z

    move-result p0

    const v2, 0x1010031

    if-eqz p0, :cond_9

    sget-object v4, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    goto :goto_1

    :cond_9
    const p0, 0x7f070028

    if-ne p2, p0, :cond_a

    const p0, 0x42233333    # 40.8f

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const v2, 0x1010030

    move p2, v6

    goto :goto_3

    :cond_a
    const p0, 0x7f070016

    if-ne p2, p0, :cond_b

    goto :goto_1

    :cond_b
    move p2, v0

    move v2, p2

    goto :goto_2

    :goto_3
    if-eqz p2, :cond_d

    invoke-virtual {p4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-static {p1, v2}, Lg31;->c(Landroid/content/Context;I)I

    move-result p1

    const-class v2, Ll7;

    monitor-enter v2

    :try_start_0
    invoke-static {p1, v4}, Lbt0;->f(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v2

    invoke-virtual {p2, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    if-eq p0, v7, :cond_c

    invoke-virtual {p2, p0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_c
    move v0, v6

    goto :goto_4

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_d
    :goto_4
    if-nez v0, :cond_e

    if-eqz p3, :cond_e

    return-object v1

    :cond_e
    return-object p4
.end method
