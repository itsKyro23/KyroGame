.class public final synthetic Lbk2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    .line 12
    iput p2, p0, Lbk2;->h:I

    iput-object p1, p0, Lbk2;->i:Ljava/lang/Object;

    iput-object p3, p0, Lbk2;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lt30;Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 0

    const/16 p1, 0x1b

    iput p1, p0, Lbk2;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lbk2;->i:Ljava/lang/Object;

    iput-object p3, p0, Lbk2;->j:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lyj3;Lc13;)V
    .locals 1

    const/16 v0, 0x1a

    iput v0, p0, Lbk2;->h:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lbk2;->i:Ljava/lang/Object;

    iput-object p1, p0, Lbk2;->j:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v0, p0

    iget v1, v0, Lbk2;->h:I

    const/16 v3, 0x1f

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    packed-switch v1, :pswitch_data_0

    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    move-object v3, v1

    check-cast v3, Lbu3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lr14;

    new-instance v2, Lzt3;

    const/4 v8, 0x1

    const/4 v5, 0x1

    const-wide/16 v6, 0x0

    invoke-direct/range {v2 .. v8}, Lzt3;-><init>(Lbu3;Lr14;IJI)V

    iget-object v0, v3, Lbu3;->c:Lzi2;

    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_0
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lrs3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lgn3;

    iget-object v2, v1, Lrs3;->a:Lln3;

    invoke-virtual {v2, v0}, Lln3;->a(Lgn3;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, v1, Lrs3;->h:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v0, v0, Lgn3;->a:Ld12;

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "2.960507516."

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    return-void

    :cond_0
    new-instance v0, Lyg;

    invoke-direct {v0, v8}, Lyg;-><init>(I)V

    throw v0

    :pswitch_1
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Landroid/webkit/WebView;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-static {v1, v0}, Lt30;->l(Landroid/webkit/WebView;Ljava/lang/String;)V

    return-void

    :pswitch_2
    iget-object v1, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v1, Lyj3;

    iget-object v0, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v0, Lc13;

    iget-object v2, v1, Lyj3;->h:Lwd2;

    if-eqz v2, :cond_1

    :try_start_0
    iget-object v3, v1, Lyj3;->e:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lqh3;

    invoke-virtual {v2}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v4

    invoke-static {v4, v3}, Lg12;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    invoke-virtual {v2, v4, v10}, Ljd1;->R0(Landroid/os/Parcel;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    sget v2, Lj23;->b:I

    const-string v2, "Failed to call onAdsAvailable"

    invoke-static {v2}, Lj23;->g(Ljava/lang/String;)V

    :cond_1
    :goto_0
    iget-object v2, v1, Lyj3;->i:Lig2;

    if-eqz v2, :cond_2

    :try_start_1
    iget-object v1, v1, Lyj3;->l:Ljava/lang/String;

    invoke-virtual {v2}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-static {v3, v0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    invoke-virtual {v2, v3, v10}, Ljd1;->R0(Landroid/os/Parcel;I)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    sget v0, Lj23;->b:I

    const-string v0, "Failed to call onAdPreloaded"

    invoke-static {v0}, Lj23;->g(Ljava/lang/String;)V

    :cond_2
    :goto_1
    return-void

    :pswitch_3
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lry2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    monitor-enter v1

    :try_start_2
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, v1, Lry2;->j:Ljava/lang/Object;

    check-cast v0, Landroid/os/PowerManager$WakeLock;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_3
    monitor-exit v1

    goto :goto_2

    :catchall_0
    move-exception v0

    goto :goto_3

    :goto_2
    return-void

    :goto_3
    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v0

    :pswitch_4
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lr60;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-eqz v2, :cond_4

    iget-object v1, v1, Lr60;->j:Ljava/lang/Object;

    check-cast v1, Lry2;

    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lbk2;

    const/16 v4, 0x19

    invoke-direct {v3, v1, v4, v0}, Lbk2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    const-string v0, "ExoPlayer:WakeLockManager"

    invoke-direct {v2, v3, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    :cond_4
    return-void

    :pswitch_5
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lfu1;

    iget-object v1, v1, Lfu1;->m:Ljava/lang/Object;

    check-cast v1, Lai3;

    iget-object v1, v1, Lai3;->c:Lzh3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lxh3;

    new-instance v2, Ls43;

    invoke-direct {v2, v7, v0}, Ls43;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Lfg4;->S1(Luv2;)V

    return-void

    :pswitch_6
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Log;

    iget-object v1, v1, Log;->m:Ljava/lang/Object;

    check-cast v1, Lwf3;

    iget-object v1, v1, Lwf3;->d:Lrf3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lh23;

    invoke-virtual {v1, v0}, Lrf3;->X0(Lh23;)V

    return-void

    :pswitch_7
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Log;

    iget-object v1, v1, Log;->m:Ljava/lang/Object;

    check-cast v1, Lof3;

    iget-object v1, v1, Lof3;->d:Lia3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lh23;

    invoke-virtual {v1, v0}, Lia3;->X0(Lh23;)V

    return-void

    :pswitch_8
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Log;

    iget-object v1, v1, Log;->m:Ljava/lang/Object;

    check-cast v1, Lte3;

    iget-object v1, v1, Lte3;->d:Lse3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lh23;

    invoke-virtual {v1, v0}, Lse3;->X0(Lh23;)V

    return-void

    :pswitch_9
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lf7;

    iget-object v1, v1, Lf7;->b:Ljava/lang/Object;

    check-cast v1, Lm93;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    const-string v2, "connectivity"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/net/ConnectivityManager;

    if-nez v2, :cond_6

    :catch_2
    :cond_5
    move v5, v9

    goto :goto_4

    :cond_6
    :try_start_4
    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v2
    :try_end_4
    .catch Ljava/lang/SecurityException; {:try_start_4 .. :try_end_4} :catch_2

    if-eqz v2, :cond_7

    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v11

    if-nez v11, :cond_8

    :cond_7
    move v5, v10

    goto :goto_4

    :cond_8
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->getType()I

    move-result v11

    const/16 v12, 0x9

    const/4 v13, 0x6

    if-eqz v11, :cond_c

    if-eq v11, v10, :cond_b

    if-eq v11, v5, :cond_c

    if-eq v11, v4, :cond_c

    if-eq v11, v13, :cond_a

    if-eq v11, v12, :cond_9

    const/16 v5, 0x8

    goto :goto_4

    :cond_9
    move v5, v7

    goto :goto_4

    :cond_a
    :pswitch_a
    move v5, v4

    goto :goto_4

    :cond_b
    :pswitch_b
    move v5, v8

    goto :goto_4

    :cond_c
    invoke-virtual {v2}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result v2

    packed-switch v2, :pswitch_data_1

    :pswitch_c
    move v5, v13

    goto :goto_4

    :pswitch_d
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1d

    if-lt v2, v5, :cond_5

    move v5, v12

    goto :goto_4

    :pswitch_e
    const/4 v5, 0x3

    :goto_4
    :pswitch_f
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v3, :cond_e

    if-ne v5, v4, :cond_e

    :try_start_5
    const-string v2, "phone"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/telephony/TelephonyManager;

    if-eqz v0, :cond_d

    new-instance v2, Lq63;

    invoke-direct {v2, v1}, Lq63;-><init>(Lm93;)V

    iget-object v3, v1, Lm93;->a:Ljava/util/concurrent/Executor;

    invoke-static {v0, v3, v2}, Ljz0;->r(Landroid/telephony/TelephonyManager;Ljava/util/concurrent/Executor;Lq63;)V

    invoke-static {v0, v2}, Ljz0;->s(Landroid/telephony/TelephonyManager;Lq63;)V

    goto :goto_5

    :cond_d
    throw v6
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_3

    :catch_3
    invoke-virtual {v1, v4}, Lm93;->c(I)V

    goto :goto_5

    :cond_e
    invoke-virtual {v1, v5}, Lm93;->c(I)V

    :goto_5
    return-void

    :pswitch_10
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, La83;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lsl2;

    invoke-interface {v0}, Lsl2;->H0()V

    iget-object v1, v1, La83;->d:Log3;

    invoke-interface {v0}, Lsl2;->g()Lkm2;

    move-result-object v2

    iget-object v1, v1, Log3;->a:Lmk3;

    if-eqz v1, :cond_f

    if-eqz v2, :cond_f

    invoke-virtual {v2, v1}, Lkm2;->Q3(Lmk3;)V

    :cond_f
    sget-object v1, Lk52;->T1:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-interface {v0}, Lsl2;->isAttachedToWindow()Z

    move-result v1

    if-nez v1, :cond_10

    invoke-interface {v0}, Lsl2;->onPause()V

    invoke-interface {v0}, Lsl2;->G0()V

    :cond_10
    return-void

    :pswitch_11
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Luk3;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lxy1;

    iget-object v2, v1, Luk3;->k:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_11

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lpk3;

    invoke-virtual {v3}, Lpk3;->c()V

    goto :goto_6

    :cond_11
    new-instance v2, Ljava/util/Timer;

    invoke-direct {v2}, Ljava/util/Timer;-><init>()V

    new-instance v3, Lw63;

    invoke-direct {v3, v1, v0, v2}, Lw63;-><init>(Luk3;Lxy1;Ljava/util/Timer;)V

    const-wide/16 v0, 0x3e8

    invoke-virtual {v2, v3, v0, v1}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    return-void

    :pswitch_12
    sget-object v1, Lk52;->o6:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_14

    sget-object v1, Lpw0;->n:Lyn1;

    iget-boolean v1, v1, Lyn1;->i:Z

    if-nez v1, :cond_12

    goto :goto_7

    :cond_12
    iget-object v1, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v1, Landroid/view/View;

    iget-object v0, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v0, Lpk3;

    iget-boolean v2, v0, Lpk3;->f:Z

    if-eqz v2, :cond_13

    goto :goto_7

    :cond_13
    iget-object v0, v0, Lpk3;->b:Lil3;

    invoke-virtual {v0, v1}, Lil3;->a(Landroid/view/View;)V

    :cond_14
    :goto_7
    return-void

    :pswitch_13
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Ly43;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v1, v1, Ly43;->i:Lu23;

    sget-object v2, Lcw4;->B:Lcw4;

    iget-object v2, v2, Lcw4;->m:Lv52;

    iget-object v3, v2, Lv52;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v3

    if-eqz v3, :cond_15

    goto :goto_8

    :cond_15
    iput-object v0, v2, Lv52;->j:Landroid/content/Context;

    iput-object v1, v2, Lv52;->k:Lu23;

    iget-object v1, v2, Lv52;->m:Lkl;

    if-nez v1, :cond_17

    invoke-static {v0}, Lkl;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_17

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    iput-object v3, v2, Lll;->h:Landroid/content/Context;

    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.support.customtabs.action.CustomTabsService"

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v3, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_16
    const/16 v1, 0x21

    invoke-virtual {v0, v3, v2, v1}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    :cond_17
    :goto_8
    return-void

    :pswitch_14
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lw33;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lfj2;

    new-instance v2, Lzm2;

    const/16 v3, 0xf

    invoke-direct {v2, v3, v0}, Lzm2;-><init>(ILjava/lang/Object;)V

    iget-object v0, v1, Lw33;->i:Lzi2;

    invoke-virtual {v0, v2}, Lzi2;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_15
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, La33;

    iget-object v1, v1, La33;->d:Ltw4;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0, v6}, Ltw4;->a(Ljava/lang/String;Ljava/util/HashMap;)Lyv4;

    return-void

    :pswitch_16
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lu23;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Long;

    sget-object v2, Lcw4;->B:Lcw4;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-string v0, "cld_r"

    invoke-static {v1, v0, v2, v3}, Lhf;->D(Lu23;Ljava/lang/String;J)V

    return-void

    :pswitch_17
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lsy2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lhz2;

    iget-object v3, v1, Lsy2;->c:Lky2;

    invoke-virtual {v3}, Lky2;->d()Z

    move-result v4

    if-nez v4, :cond_19

    invoke-virtual {v3}, Lky2;->b()Z

    move-result v3

    if-eqz v3, :cond_18

    goto :goto_9

    :cond_18
    move-object v11, v6

    goto :goto_b

    :cond_19
    :goto_9
    const-string v3, "1098"

    const-string v4, "3011"

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    move v4, v9

    :goto_a
    if-ge v4, v8, :cond_18

    aget-object v11, v3, v4

    invoke-interface {v0, v11}, Lhz2;->W(Ljava/lang/String;)Landroid/view/View;

    move-result-object v11

    instance-of v12, v11, Landroid/view/ViewGroup;

    if-eqz v12, :cond_1a

    check-cast v11, Landroid/view/ViewGroup;

    goto :goto_b

    :cond_1a
    add-int/lit8 v4, v4, 0x1

    goto :goto_a

    :goto_b
    invoke-interface {v0}, Lhz2;->M1()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    new-instance v4, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v8, -0x2

    invoke-direct {v4, v8, v8}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    iget-object v12, v1, Lsy2;->d:Liy2;

    monitor-enter v12

    :try_start_6
    iget-object v13, v12, Liy2;->d:Landroid/view/View;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    monitor-exit v12

    if-eqz v13, :cond_1c

    monitor-enter v12

    :try_start_7
    iget-object v3, v12, Liy2;->d:Landroid/view/View;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    monitor-exit v12

    iget-object v5, v1, Lsy2;->i:Lo72;

    if-nez v5, :cond_1b

    goto/16 :goto_e

    :cond_1b
    if-nez v11, :cond_23

    iget v5, v5, Lo72;->l:I

    invoke-static {v4, v5}, Lsy2;->b(Landroid/widget/RelativeLayout$LayoutParams;I)V

    invoke-virtual {v3, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move-object v11, v6

    goto/16 :goto_e

    :catchall_1
    move-exception v0

    :try_start_8
    monitor-exit v12
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    throw v0

    :cond_1c
    invoke-virtual {v12}, Liy2;->s()Lr72;

    move-result-object v13

    instance-of v13, v13, Lk72;

    if-nez v13, :cond_1d

    move-object v3, v6

    goto/16 :goto_e

    :cond_1d
    invoke-virtual {v12}, Liy2;->s()Lr72;

    move-result-object v13

    check-cast v13, Lk72;

    if-nez v11, :cond_1e

    iget v11, v13, Lk72;->o:I

    invoke-static {v4, v11}, Lsy2;->b(Landroid/widget/RelativeLayout$LayoutParams;I)V

    move-object v11, v6

    :cond_1e
    new-instance v14, Ll72;

    invoke-direct {v14, v3}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    invoke-static {v13}, Lck2;->h(Ljava/lang/Object;)V

    new-instance v15, Landroid/graphics/drawable/ShapeDrawable;

    new-instance v7, Landroid/graphics/drawable/shapes/RoundRectShape;

    sget-object v2, Ll72;->i:[F

    invoke-direct {v7, v2, v6, v6}, Landroid/graphics/drawable/shapes/RoundRectShape;-><init>([FLandroid/graphics/RectF;[F)V

    invoke-direct {v15, v7}, Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V

    invoke-virtual {v15}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    move-result-object v2

    iget v7, v13, Lk72;->k:I

    invoke-virtual {v2, v7}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v14, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;

    invoke-direct {v2, v8, v8}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    iget-object v4, v13, Lk72;->h:Ljava/lang/String;

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_1f

    new-instance v7, Landroid/widget/RelativeLayout$LayoutParams;

    invoke-direct {v7, v8, v8}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v8, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v7, 0x47470001

    invoke-virtual {v8, v7}, Landroid/view/View;->setId(I)V

    sget-object v7, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v8, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v4, v13, Lk72;->l:I

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget v4, v13, Lk72;->m:I

    int-to-float v4, v4

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v4, Lwv1;->g:Lwv1;

    iget-object v4, v4, Lwv1;->a:Lsc3;

    invoke-static {v3, v5}, Lsc3;->b(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    invoke-static {v7, v5}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v5

    invoke-virtual {v8, v4, v9, v5, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v14, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v8}, Landroid/view/View;->getId()I

    move-result v4

    invoke-virtual {v2, v10, v4}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    :cond_1f
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v2, 0x47470002

    invoke-virtual {v4, v2}, Landroid/view/View;->setId(I)V

    iget-object v2, v13, Lk72;->i:Ljava/util/ArrayList;

    if-eqz v2, :cond_21

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-le v3, v10, :cond_21

    new-instance v3, Landroid/graphics/drawable/AnimationDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/AnimationDrawable;-><init>()V

    iput-object v3, v14, Ll72;->h:Landroid/graphics/drawable/AnimationDrawable;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v5, v9

    :goto_c
    if-ge v5, v3, :cond_20

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v5, v5, 0x1

    check-cast v7, Lm72;

    :try_start_9
    invoke-virtual {v7}, Lm72;->a()Ll50;

    move-result-object v7

    invoke-static {v7}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/drawable/Drawable;

    iget-object v8, v14, Ll72;->h:Landroid/graphics/drawable/AnimationDrawable;

    iget v15, v13, Lk72;->n:I

    invoke-virtual {v8, v7, v15}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4

    goto :goto_c

    :catch_4
    sget v7, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    goto :goto_c

    :cond_20
    iget-object v2, v14, Ll72;->h:Landroid/graphics/drawable/AnimationDrawable;

    invoke-virtual {v4, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_d

    :cond_21
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ne v3, v10, :cond_22

    :try_start_a
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lm72;

    invoke-virtual {v2}, Lm72;->a()Ll50;

    move-result-object v2

    invoke-static {v2}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_5

    goto :goto_d

    :catch_5
    sget v2, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :cond_22
    :goto_d
    invoke-virtual {v14, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    sget-object v2, Lk52;->N4:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-virtual {v14, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    move-object v3, v14

    :cond_23
    :goto_e
    if-nez v3, :cond_24

    goto :goto_10

    :cond_24
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v2, v2, Landroid/view/ViewGroup;

    if-eqz v2, :cond_25

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_25
    if-eqz v11, :cond_26

    invoke-virtual {v11}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v11, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_f

    :cond_26
    new-instance v2, Laf1;

    invoke-interface {v0}, Lhz2;->M1()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-interface {v0}, Lhz2;->M0()Landroid/widget/FrameLayout;

    move-result-object v4

    if-eqz v4, :cond_27

    invoke-virtual {v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_27
    :goto_f
    invoke-interface {v0}, Lhz2;->j()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v3, v2}, Lhz2;->R0(Landroid/view/View;Ljava/lang/String;)V

    :goto_10
    sget-object v2, Lpy2;->w:Lqy3;

    iget v3, v2, Lqy3;->k:I

    move v4, v9

    :cond_28
    if-ge v4, v3, :cond_29

    invoke-virtual {v2, v4}, Lqy3;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v0, v5}, Lhz2;->W(Ljava/lang/String;)Landroid/view/View;

    move-result-object v5

    instance-of v7, v5, Landroid/view/ViewGroup;

    add-int/lit8 v4, v4, 0x1

    if-eqz v7, :cond_28

    check-cast v5, Landroid/view/ViewGroup;

    goto :goto_11

    :cond_29
    move-object v5, v6

    :goto_11
    iget-object v2, v1, Lsy2;->h:Lzi2;

    new-instance v3, Lmo2;

    const/4 v4, 0x7

    invoke-direct {v3, v1, v4, v5}, Lmo2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v2, v3}, Lzi2;->execute(Ljava/lang/Runnable;)V

    if-nez v5, :cond_2a

    goto/16 :goto_14

    :cond_2a
    invoke-virtual {v1, v5, v10}, Lsy2;->c(Landroid/view/ViewGroup;Z)Z

    move-result v2

    if-eqz v2, :cond_2b

    invoke-virtual {v12}, Liy2;->h()Lsl2;

    move-result-object v1

    if-eqz v1, :cond_30

    invoke-virtual {v12}, Liy2;->h()Lsl2;

    move-result-object v1

    new-instance v2, Lry2;

    invoke-direct {v2, v0, v9, v5}, Lry2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-interface {v1, v2}, Lsl2;->L0(Ln72;)V

    goto/16 :goto_14

    :cond_2b
    sget-object v2, Lk52;->Bb:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v4, v3, Lvx1;->c:Li52;

    invoke-virtual {v4, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_2c

    invoke-virtual {v1, v5, v9}, Lsy2;->c(Landroid/view/ViewGroup;Z)Z

    move-result v2

    if-eqz v2, :cond_2c

    invoke-virtual {v12}, Liy2;->i()Lsl2;

    move-result-object v1

    if-eqz v1, :cond_30

    invoke-virtual {v12}, Liy2;->i()Lsl2;

    move-result-object v1

    new-instance v2, Lry2;

    invoke-direct {v2, v0, v9, v5}, Lry2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-interface {v1, v2}, Lsl2;->L0(Ln72;)V

    goto :goto_14

    :cond_2c
    invoke-virtual {v5}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-interface {v0}, Lhz2;->M1()Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_2d

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    :cond_2d
    if-eqz v6, :cond_30

    iget-object v1, v1, Lsy2;->j:Lgy2;

    monitor-enter v1

    :try_start_b
    iget-object v2, v1, Lgy2;->a:Lw72;
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    monitor-exit v1

    if-eqz v2, :cond_30

    :try_start_c
    invoke-interface {v2}, Lw72;->e()Ll50;

    move-result-object v1
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_c} :catch_6

    if-eqz v1, :cond_30

    invoke-static {v1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_30

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v6}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-interface {v0}, Lhz2;->Q()Ll50;

    move-result-object v0

    if-eqz v0, :cond_2f

    sget-object v1, Lk52;->k7:Lg52;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_2e

    goto :goto_12

    :cond_2e
    invoke-static {v0}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    goto :goto_13

    :cond_2f
    :goto_12
    sget-object v0, Lsy2;->k:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    :goto_13
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v5, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_14

    :catch_6
    sget v0, Lj23;->b:I

    const-string v0, "Could not get main image drawable"

    invoke-static {v0}, Lj23;->g(Ljava/lang/String;)V

    goto :goto_14

    :catchall_2
    move-exception v0

    :try_start_d
    monitor-exit v1
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    throw v0

    :cond_30
    :goto_14
    return-void

    :catchall_3
    move-exception v0

    :try_start_e
    monitor-exit v12
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    throw v0

    :pswitch_18
    sget-object v1, Lby2;->J:Lqy3;

    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lsl2;

    const-string v2, "onVideoEvent"

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    invoke-interface {v1, v2, v0}, Lxa2;->c(Ljava/lang/String;Lorg/json/JSONObject;)V

    return-void

    :pswitch_19
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lby2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lhz2;

    invoke-virtual {v1, v0}, Lby2;->g(Lhz2;)V

    return-void

    :pswitch_1a
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lv4;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    iget v2, v1, Lv4;->a:I

    const/16 v16, -0x1

    add-int/lit8 v2, v2, -0x1

    iput v2, v1, Lv4;->a:I

    if-nez v2, :cond_31

    invoke-virtual {v1, v0}, Lv4;->y(Ljava/lang/Object;)V

    :cond_31
    return-void

    :pswitch_1b
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lv4;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    iget v2, v1, Lv4;->a:I

    if-nez v2, :cond_32

    invoke-virtual {v1, v0}, Lv4;->y(Ljava/lang/Object;)V

    :cond_32
    return-void

    :pswitch_1c
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Liq2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Lorg/json/JSONObject;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    add-int/2addr v4, v3

    invoke-direct {v5, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v3, "Calling AFMA_updateActiveView("

    const-string v4, ")"

    invoke-static {v5, v3, v2, v4}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget v3, Lj23;->b:I

    invoke-static {v2}, Lj23;->c(Ljava/lang/String;)V

    iget-object v1, v1, Liq2;->h:Lsl2;

    const-string v2, "AFMA_updateActiveView"

    invoke-interface {v1, v2, v0}, Leb2;->b(Ljava/lang/String;Lorg/json/JSONObject;)V

    return-void

    :pswitch_1d
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lkp2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Throwable;

    sget-object v2, Lk52;->Qb:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    iget-object v1, v1, Lkp2;->a:Landroid/content/Context;

    if-eqz v2, :cond_33

    invoke-static {v1}, Lwf2;->e(Landroid/content/Context;)Lxf2;

    move-result-object v1

    const-string v2, "AttributionReporting.getUpdatedUrlAndRegisterSource"

    invoke-interface {v1, v2, v0}, Lxf2;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_15

    :cond_33
    invoke-static {v1}, Lwf2;->a(Landroid/content/Context;)Lxf2;

    move-result-object v1

    const-string v2, "AttributionReportingSampled.getUpdatedUrlAndRegisterSource"

    invoke-interface {v1, v2, v0}, Lxf2;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_15
    return-void

    :pswitch_1e
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lno2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    const-string v2, "Adapters must be initialized on the main thread."

    invoke-static {v2}, Lck2;->d(Ljava/lang/String;)V

    sget-object v2, Lcw4;->B:Lcw4;

    iget-object v2, v2, Lcw4;->h:Lui2;

    invoke-virtual {v2}, Lui2;->g()Lol4;

    move-result-object v2

    invoke-virtual {v2}, Lol4;->n()Lsi2;

    move-result-object v2

    iget-object v2, v2, Lsi2;->c:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->isEmpty()Z

    move-result v3

    const-string v5, "Initialized rewarded video mediation adapter "

    if-eqz v3, :cond_34

    goto/16 :goto_19

    :cond_34
    if-eqz v0, :cond_35

    :try_start_f
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    goto :goto_16

    :catchall_4
    sget v0, Lj23;->b:I

    invoke-static {v4}, Lj23;->j(I)Z

    goto/16 :goto_19

    :cond_35
    :goto_16
    iget-object v0, v1, Lno2;->j:Lr13;

    iget-object v0, v0, Lr13;->a:Lwg3;

    iget-object v0, v0, Lwg3;->k:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lgc2;

    if-eqz v0, :cond_3c

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v2}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_36
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldc2;

    iget-object v3, v3, Ldc2;->a:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_37
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_36

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lac2;

    iget-object v7, v6, Lac2;->b:Ljava/lang/String;

    iget-object v6, v6, Lac2;->a:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_38
    :goto_17
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_37

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_39

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, v8, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_39
    if-eqz v7, :cond_38

    invoke-virtual {v0, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/List;

    invoke-interface {v8, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_17

    :cond_3a
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3b
    :goto_18
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    :try_start_10
    iget-object v7, v1, Lno2;->k:Lm73;

    invoke-interface {v7, v6, v2}, Lm73;->a(Ljava/lang/String;Lorg/json/JSONObject;)Ln73;

    move-result-object v7

    if-eqz v7, :cond_3b

    iget-object v8, v7, Ln73;->b:Ljava/lang/Object;

    check-cast v8, Lxg3;

    invoke-virtual {v8}, Lxg3;->a()Z

    move-result v9
    :try_end_10
    .catch Lqg3; {:try_start_10 .. :try_end_10} :catch_7

    iget-object v8, v8, Lxg3;->a:Lic2;

    if-nez v9, :cond_3b

    :try_start_11
    invoke-interface {v8}, Lic2;->K()Z

    move-result v9
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_6

    if-eqz v9, :cond_3b

    :try_start_12
    iget-object v7, v7, Ln73;->c:Lmu2;

    check-cast v7, Lh83;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    iget-object v9, v1, Lno2;->h:Landroid/content/Context;
    :try_end_12
    .catch Lqg3; {:try_start_12 .. :try_end_12} :catch_7

    :try_start_13
    new-instance v10, Lui0;

    invoke-direct {v10, v9}, Lui0;-><init>(Ljava/lang/Object;)V

    invoke-interface {v8, v10, v7, v0}, Lic2;->l1(Ll50;Lvg2;Ljava/util/List;)V
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_5

    :try_start_14
    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x2d

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget v7, Lj23;->b:I

    invoke-static {v0}, Lj23;->c(Ljava/lang/String;)V

    goto :goto_18

    :catchall_5
    move-exception v0

    new-instance v7, Lqg3;

    invoke-direct {v7, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v7

    :catchall_6
    move-exception v0

    new-instance v7, Lqg3;

    invoke-direct {v7, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v7
    :try_end_14
    .catch Lqg3; {:try_start_14 .. :try_end_14} :catch_7

    :catch_7
    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v6, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x38

    invoke-direct {v6, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    sget v0, Lj23;->b:I

    invoke-static {v4}, Lj23;->j(I)Z

    goto/16 :goto_18

    :cond_3c
    :goto_19
    return-void

    :pswitch_1f
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Llm2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, v1, Llm2;->a:Ls93;

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    iget-object v1, v1, Ls93;->i:Ljava/lang/Object;

    check-cast v1, Lim2;

    iget-object v1, v1, Lim2;->u:Lmm2;

    if-nez v1, :cond_3d

    sget v0, Lj23;->b:I

    const-string v0, "Unable to pass GMSG, no AdWebViewClient for AdWebView!"

    invoke-static {v0}, Lj23;->d(Ljava/lang/String;)V

    goto :goto_1a

    :cond_3d
    invoke-virtual {v1, v0}, Lmm2;->f(Landroid/net/Uri;)V

    :goto_1a
    return-void

    :pswitch_20
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lim2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0}, Lim2;->J(Ljava/lang/String;)V

    return-void

    :pswitch_21
    sget-object v1, Lkl2;->B:Ljava/util/concurrent/atomic/AtomicInteger;

    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lsl2;

    const-string v2, "onGcacheInfoEvent"

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-interface {v1, v2, v0}, Lxa2;->a(Ljava/lang/String;Ljava/util/Map;)V

    return-void

    :pswitch_22
    iget-object v1, v0, Lbk2;->i:Ljava/lang/Object;

    check-cast v1, Lgk2;

    iget-object v0, v0, Lbk2;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, v1, Lgk2;->n:Lsj2;

    if-eqz v1, :cond_3e

    const-string v2, "what"

    const-string v3, "ExoPlayerAdapter exception"

    const-string v4, "extra"

    filled-new-array {v2, v3, v4, v0}, [Ljava/lang/String;

    move-result-object v0

    const-string v2, "exception"

    invoke-virtual {v1, v2, v0}, Lsj2;->c(Ljava/lang/String;[Ljava/lang/String;)V

    :cond_3e
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_e
        :pswitch_e
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_f
        :pswitch_a
        :pswitch_f
        :pswitch_f
        :pswitch_c
        :pswitch_f
        :pswitch_b
        :pswitch_c
        :pswitch_d
    .end packed-switch
.end method
