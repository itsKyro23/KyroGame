.class public final Lbu;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public b:Z

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ldu;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lbu;->a:I

    .line 12
    iput-object p1, p0, Lbu;->c:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    .line 13
    iput-boolean v0, p0, Lbu;->b:Z

    return-void
.end method

.method public constructor <init>(Lsf0;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lbu;->a:I

    .line 11
    iput-object p1, p0, Lbu;->c:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method

.method public constructor <init>(Lsy0;Z)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lbu;->a:I

    iput-boolean p2, p0, Lbu;->b:Z

    iput-object p1, p0, Lbu;->c:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 1

    iget v0, p0, Lbu;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationCancel(Landroid/animation/Animator;)V

    return-void

    :pswitch_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Lbu;->b:Z

    return-void

    :pswitch_1
    const/4 p1, 0x1

    iput-boolean p1, p0, Lbu;->b:Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 4

    iget p1, p0, Lbu;->a:I

    iget-object v0, p0, Lbu;->c:Ljava/lang/Object;

    const/4 v1, 0x0

    packed-switch p1, :pswitch_data_0

    check-cast v0, Lsy0;

    const/4 p1, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    iget-boolean p1, v0, Lsy0;->g2:Z

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean p0, p0, Lbu;->b:Z

    if-nez p0, :cond_1

    iget-object p0, v0, Lsy0;->j:Lxo3;

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p1, Lbx0;

    const/4 v1, 0x4

    invoke-direct {p1, v1, p0}, Lbx0;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-boolean p0, p0, Lbu;->b:Z

    if-nez p0, :cond_2

    check-cast v0, Lsf0;

    iget-boolean p0, v0, Lsf0;->O:Z

    if-eqz p0, :cond_2

    const/4 p0, 0x1

    iput-boolean p0, v0, Lsf0;->N:Z

    iput-boolean v1, v0, Lsf0;->O:Z

    const/high16 p1, 0x3f800000    # 1.0f

    iput p1, v0, Lsf0;->Q:F

    invoke-virtual {v0, v1}, Lsf0;->a(Z)V

    iget-boolean p1, v0, Lsf0;->P:Z

    iget-object v2, v0, Lsf0;->R:Ld00;

    iget-object v3, v0, Lsf0;->a0:Lm10;

    invoke-virtual {v0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v3, v0, Lsf0;->b0:Lqf0;

    invoke-virtual {v0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    new-instance v3, Lm10;

    invoke-direct {v3, p0, v0, v2, p1}, Lm10;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    iput-object v3, v0, Lsf0;->a0:Lm10;

    new-instance p0, Lqf0;

    invoke-direct {p0, v0, v1}, Lqf0;-><init>(Lsf0;I)V

    iput-object p0, v0, Lsf0;->b0:Lqf0;

    const-wide/16 p0, 0x320

    invoke-virtual {v0, v3, p0, p1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object p0, v0, Lsf0;->b0:Lqf0;

    const-wide/16 v1, 0xa28

    invoke-virtual {v0, p0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    return-void

    :pswitch_1
    check-cast v0, Ldu;

    iget-boolean p1, p0, Lbu;->b:Z

    if-eqz p1, :cond_3

    iput-boolean v1, p0, Lbu;->b:Z

    goto :goto_1

    :cond_3
    iget-object p0, v0, Ldu;->z:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Float;

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    const/4 p1, 0x0

    cmpl-float p0, p0, p1

    if-nez p0, :cond_4

    iput v1, v0, Ldu;->A:I

    invoke-virtual {v0, v1}, Ldu;->f(I)V

    goto :goto_1

    :cond_4
    const/4 p0, 0x2

    iput p0, v0, Ldu;->A:I

    iget-object p0, v0, Ldu;->s:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
