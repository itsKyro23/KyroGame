.class public final Lbk3;
.super Le52;
.source "SourceFile"


# instance fields
.field public h:Lla3;

.field public i:Lzy2;

.field public j:Ljava/lang/String;


# virtual methods
.method public final X2(Lh23;)V
    .locals 6

    iget-object v0, p0, Lbk3;->i:Lzy2;

    iget-object v1, p0, Lbk3;->h:Lla3;

    if-eqz v1, :cond_1

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lh23;->b()Lva0;

    move-result-object v1

    invoke-virtual {v1}, Lva0;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lbk3;->j:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    add-int/lit8 v3, v3, 0x39

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    add-int/2addr v3, v4

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v3, "Failed to load interstitial ad with error: "

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " for ad unit: "

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lj23;->g(Ljava/lang/String;)V

    iget-object v0, v0, Lzy2;->j:Ljava/lang/Object;

    check-cast v0, Lyj3;

    invoke-virtual {v0, p1}, Lyj3;->c(Lh23;)V

    const/4 p1, 0x0

    iput-object p1, p0, Lbk3;->h:Lla3;

    iput-object p1, p0, Lbk3;->i:Lzy2;

    iput-object p1, p0, Lbk3;->j:Ljava/lang/String;

    :cond_1
    :goto_0
    return-void
.end method

.method public final q()V
    .locals 2

    iget-object v0, p0, Lbk3;->i:Lzy2;

    iget-object v1, p0, Lbk3;->h:Lla3;

    if-eqz v1, :cond_1

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lzy2;->i:Ljava/lang/Object;

    check-cast v0, Lr14;

    invoke-virtual {v0, v1}, Lg04;->e(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    iput-object v0, p0, Lbk3;->h:Lla3;

    iput-object v0, p0, Lbk3;->i:Lzy2;

    iput-object v0, p0, Lbk3;->j:Ljava/lang/String;

    :cond_1
    :goto_0
    return-void
.end method
