.class public final Lbs3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final synthetic a:I

.field public final b:Lsk4;

.field public final c:Lsk4;

.field public final d:Lsk4;

.field public final e:Lxk4;

.field public final f:Lxk4;

.field public final g:Lxk4;


# direct methods
.method public synthetic constructor <init>(Lsk4;Lsk4;Lsk4;Lsk4;Ljava/lang/Object;Luk4;I)V
    .locals 0

    iput p7, p0, Lbs3;->a:I

    iput-object p1, p0, Lbs3;->b:Lsk4;

    iput-object p2, p0, Lbs3;->c:Lsk4;

    iput-object p3, p0, Lbs3;->d:Lsk4;

    iput-object p4, p0, Lbs3;->e:Lxk4;

    check-cast p5, Lxk4;

    iput-object p5, p0, Lbs3;->f:Lxk4;

    iput-object p6, p0, Lbs3;->g:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final bridge synthetic d()Ljava/lang/Object;
    .locals 18

    move-object/from16 v0, p0

    iget v1, v0, Lbs3;->a:I

    iget-object v2, v0, Lbs3;->g:Lxk4;

    iget-object v3, v0, Lbs3;->f:Lxk4;

    iget-object v4, v0, Lbs3;->e:Lxk4;

    iget-object v5, v0, Lbs3;->d:Lsk4;

    iget-object v6, v0, Lbs3;->c:Lsk4;

    iget-object v0, v0, Lbs3;->b:Lsk4;

    packed-switch v1, :pswitch_data_0

    invoke-virtual {v0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lln3;

    invoke-virtual {v6}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lkt3;

    invoke-virtual {v5}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lrt3;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lju3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lcp3;

    new-instance v7, Lrs3;

    invoke-direct/range {v7 .. v13}, Lrs3;-><init>(Lln3;Lkt3;Lrt3;Lju3;Ljava/util/concurrent/ExecutorService;Lcp3;)V

    return-object v7

    :pswitch_0
    invoke-virtual {v0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lrt3;

    invoke-virtual {v6}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lys3;

    invoke-virtual {v5}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lit3;

    invoke-interface {v4}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lju3;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lqp3;

    invoke-interface {v2}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcp3;

    new-instance v7, Ljs3;

    invoke-virtual {v0}, Lcp3;->Z()Ljp3;

    move-result-object v1

    invoke-virtual {v1}, Ljp3;->C()Z

    move-result v13

    invoke-virtual {v0}, Lcp3;->Z()Ljp3;

    move-result-object v1

    invoke-virtual {v1}, Ljp3;->D()J

    move-result-wide v14

    invoke-virtual {v0}, Lcp3;->Z()Ljp3;

    move-result-object v0

    invoke-virtual {v0}, Ljp3;->E()J

    move-result-wide v16

    invoke-direct/range {v7 .. v17}, Ljs3;-><init>(Lrt3;Lys3;Lit3;Lju3;Lqp3;ZJJ)V

    return-object v7

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
