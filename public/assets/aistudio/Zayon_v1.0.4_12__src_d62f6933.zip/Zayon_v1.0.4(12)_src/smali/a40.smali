.class public final synthetic La40;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:Lb40;

.field public final synthetic i:I

.field public final synthetic j:Z


# direct methods
.method public synthetic constructor <init>(Lb40;IZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La40;->h:Lb40;

    iput p2, p0, La40;->i:I

    iput-boolean p3, p0, La40;->j:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, La40;->h:Lb40;

    iget-boolean v1, v0, Lb40;->i:Z

    if-nez v1, :cond_0

    iget-object v1, v0, Lb40;->d:Llk0;

    iget v0, v0, Lb40;->j:F

    iget v2, p0, La40;->i:I

    iget-boolean p0, p0, La40;->j:Z

    invoke-virtual {v1, v2, v0, p0}, Llk0;->c(IFZ)V

    :cond_0
    return-void
.end method
