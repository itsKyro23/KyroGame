.class public final Lal3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:F

.field public final synthetic i:Lpe3;


# direct methods
.method public constructor <init>(Lpe3;F)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, Lal3;->h:F

    iput-object p1, p0, Lal3;->i:Lpe3;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget-object v0, p0, Lal3;->i:Lpe3;

    iget-object v0, v0, Lpe3;->i:Ljava/lang/Object;

    check-cast v0, Lbl3;

    iget-object v0, v0, Lbl3;->g:Lzy0;

    iget p0, p0, Lal3;->h:F

    iput p0, v0, Lzy0;->a:F

    iget-object v1, v0, Lzy0;->c:Ljava/lang/Object;

    check-cast v1, Lel3;

    if-nez v1, :cond_0

    sget-object v1, Lel3;->c:Lel3;

    iput-object v1, v0, Lzy0;->c:Ljava/lang/Object;

    :cond_0
    iget-object v0, v1, Lel3;->b:Ljava/util/ArrayList;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableCollection(Ljava/util/Collection;)Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lpk3;

    iget-object v1, v1, Lpk3;->d:Lol3;

    sget-object v2, Lt30;->o:Lt30;

    invoke-virtual {v1}, Lol3;->c()Landroid/webkit/WebView;

    move-result-object v3

    iget-object v1, v1, Lol3;->a:Ljava/lang/String;

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    filled-new-array {v4, v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v4, "setDeviceVolume"

    invoke-virtual {v2, v3, v4, v1}, Lt30;->j(Landroid/webkit/WebView;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_0

    :cond_1
    return-void
.end method
