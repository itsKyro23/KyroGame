.class public final La70;
.super Luq0;
.source "SourceFile"


# instance fields
.field public final c:Lm70;

.field public final d:Lj00;

.field public final e:La90;

.field public final f:Landroid/view/View;

.field public g:Ljava/util/ArrayList;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lm70;Landroid/view/View;Lj00;La90;)V
    .locals 1

    invoke-direct {p0}, Luq0;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La70;->g:Ljava/util/ArrayList;

    const-string v0, ""

    iput-object v0, p0, La70;->h:Ljava/lang/String;

    iput-object p1, p0, La70;->c:Lm70;

    iput-object p2, p0, La70;->f:Landroid/view/View;

    iput-object p3, p0, La70;->d:Lj00;

    iput-object p4, p0, La70;->e:La90;

    iget-object p1, p0, Luq0;->a:Lvq0;

    invoke-virtual {p1}, Lvq0;->a()Z

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Luq0;->b:Z

    return-void

    :cond_0
    const-string p0, "Cannot change whether this adapter has stable IDs while the adapter has registered observers."

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final a()I
    .locals 0

    iget-object p0, p0, La70;->g:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    add-int/lit8 p0, p0, 0x2

    return p0
.end method

.method public final b(I)J
    .locals 4

    const-wide/high16 v0, -0x8000000000000000L

    if-nez p1, :cond_0

    return-wide v0

    :cond_0
    iget-object p0, p0, La70;->g:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne p1, v3, :cond_2

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    move v2, v3

    :goto_0
    int-to-long p0, v2

    add-long/2addr p0, v0

    return-wide p0

    :cond_2
    sub-int/2addr p1, v2

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ld00;

    iget-object p0, p0, Ld00;->a:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    int-to-long p0, p0

    return-wide p0
.end method

.method public final c(I)I
    .locals 1

    if-nez p1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_2

    iget-object p0, p0, La70;->g:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_1

    const/4 p0, 0x3

    return p0

    :cond_1
    return v0

    :cond_2
    const/4 p0, 0x2

    return p0
.end method

.method public final d(Lqr0;I)V
    .locals 10

    iget v0, p1, Lqr0;->f:I

    iget-object v1, p1, Lqr0;->a:Landroid/view/View;

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v0, v2, :cond_3

    const p1, 0x7f090172

    invoke-virtual {v1, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object p2, p0, La70;->h:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x7f090171

    invoke-virtual {v1, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object p2, p0, La70;->i:Ljava/lang/String;

    if-nez p2, :cond_1

    const/16 p2, 0x8

    goto :goto_0

    :cond_1
    move p2, v3

    :goto_0
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    iget-object p2, p0, La70;->i:Ljava/lang/String;

    if-eqz p2, :cond_2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    iget-object p1, p0, La70;->c:Lm70;

    const p2, 0x7f090176

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p2

    check-cast p2, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result p1

    sub-int/2addr v0, p1

    iget-object p0, p0, La70;->f:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p0

    sub-int/2addr v0, p0

    iget p0, p2, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    sub-int/2addr v0, p0

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    invoke-virtual {v1, p0}, Landroid/view/View;->setMinimumHeight(I)V

    return-void

    :cond_3
    const/4 v2, 0x1

    if-ne v0, v2, :cond_4

    move-object p1, v1

    check-cast p1, Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    iget-object p0, p0, La70;->g:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const v0, 0x7f0f0279

    invoke-virtual {p2, v0, p0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_4
    check-cast p1, Lz60;

    iget-object v0, p1, Lz60;->z:Landroid/widget/TextView;

    iget-object v1, p1, Lz60;->A:Landroid/widget/ImageView;

    iget-object p0, p0, La70;->g:Ljava/util/ArrayList;

    add-int/lit8 p2, p2, -0x2

    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ld00;

    iget-object p2, p1, Lz60;->u:Lcom/zayon/optimize/ui/ZyBox;

    iget-object v4, p1, Lqr0;->a:Landroid/view/View;

    iget-object v5, p1, Lz60;->M:La70;

    iget-object v6, p1, Lz60;->v:Lcom/zayon/optimize/ui/ZyBox;

    iput-object p0, p1, Lz60;->K:Ld00;

    iget-object v7, p1, Lz60;->x:Landroid/widget/TextView;

    iget-object v8, p0, Ld00;->b:Ljava/lang/String;

    iget-object v9, p0, Ld00;->a:Ljava/lang/String;

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v7, p1, Lz60;->y:Landroid/widget/TextView;

    iget-boolean v8, p0, Ld00;->c:Z

    if-eqz v8, :cond_5

    const v8, 0x7f0f0284

    goto :goto_1

    :cond_5
    const v8, 0x7f0f0276

    :goto_1
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(I)V

    iget-object v7, p1, Lz60;->w:Lcom/zayon/optimize/ui/GameIconView;

    const/4 v8, 0x0

    iput-object v8, v7, Lcom/zayon/optimize/ui/GameIconView;->l:Landroid/graphics/Bitmap;

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    iget-object v7, v5, La70;->d:Lj00;

    new-instance v8, Ln40;

    invoke-direct {v8, p1, v2, v9}, Ln40;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v7, p0, v8}, Lj00;->d(Ld00;Li00;)V

    iget-object p0, v5, La70;->e:La90;

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Ljava/util/ArrayList;

    invoke-virtual {p0, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_6

    const v2, 0x7f070090

    goto :goto_2

    :cond_6
    const v2, 0x7f07007f

    :goto_2
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz p0, :cond_7

    const v2, 0x7f0f0281

    goto :goto_3

    :cond_7
    const v2, 0x7f0f0274

    :goto_3
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(I)V

    if-eqz p0, :cond_8

    iget v2, p1, Lz60;->C:I

    goto :goto_4

    :cond_8
    iget v2, p1, Lz60;->D:I

    :goto_4
    invoke-virtual {p2, v2}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    if-eqz p0, :cond_9

    iget v2, p1, Lz60;->E:I

    goto :goto_5

    :cond_9
    iget v2, p1, Lz60;->F:I

    :goto_5
    invoke-virtual {p2, v2}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    if-eqz p0, :cond_a

    iget p2, p1, Lz60;->G:I

    goto :goto_6

    :cond_a
    iget p2, p1, Lz60;->H:I

    :goto_6
    invoke-virtual {v6, p2}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    if-eqz p0, :cond_b

    iget p2, p1, Lz60;->I:I

    goto :goto_7

    :cond_b
    iget p2, p1, Lz60;->J:I

    :goto_7
    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    const/4 p2, 0x0

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p0, :cond_c

    move v1, v0

    goto :goto_8

    :cond_c
    move v1, p2

    :goto_8
    invoke-virtual {v6, v1}, Lcom/zayon/optimize/ui/ZyBox;->setShadowMix(F)V

    iput-boolean p0, p1, Lz60;->L:Z

    invoke-virtual {p1, v3}, Lz60;->q(Z)V

    iget-object p0, v5, La70;->c:Lm70;

    iget-object p0, p0, Lm70;->P:Ljava/util/HashMap;

    invoke-virtual {p0, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v4}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {v6}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const-string v1, "leave"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    move v2, p2

    goto :goto_9

    :cond_d
    move v2, v0

    :goto_9
    invoke-virtual {v4, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    const/high16 p2, 0x42200000    # 40.0f

    iget p1, p1, Lz60;->B:F

    mul-float/2addr p2, p1

    :cond_e
    invoke-virtual {v4, p2}, Landroid/view/View;->setTranslationX(F)V

    const-string p1, "pop"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_f

    const v0, 0x3f8a3d71    # 1.08f

    :cond_f
    invoke-virtual {v6, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v6, v0}, Landroid/view/View;->setScaleY(F)V

    return-void
.end method

.method public final e(Lqr0;ILjava/util/List;)V
    .locals 27

    move-object/from16 v0, p1

    invoke-interface/range {p3 .. p3}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_f

    instance-of v1, v0, Lz60;

    if-nez v1, :cond_0

    goto/16 :goto_c

    :cond_0
    move-object v3, v0

    check-cast v3, Lz60;

    iget-object v0, v3, Lz60;->z:Landroid/widget/TextView;

    invoke-interface/range {p3 .. p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v10, v2

    check-cast v10, Ljava/lang/String;

    iget-object v11, v3, Lqr0;->a:Landroid/view/View;

    iget-object v2, v3, Lz60;->K:Ld00;

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    const-string v2, "limit"

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x1

    if-eqz v2, :cond_2

    invoke-virtual {v3, v12}, Lz60;->q(Z)V

    goto :goto_0

    :cond_2
    iget-object v2, v3, Lz60;->M:La70;

    iget-object v2, v2, La70;->e:La90;

    iget-object v4, v3, Lz60;->K:Ld00;

    iget-object v4, v4, Ld00;->a:Ljava/lang/String;

    iget-object v2, v2, La90;->j:Ljava/lang/Object;

    check-cast v2, Ljava/util/ArrayList;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    iget-boolean v4, v3, Lz60;->L:Z

    const/4 v13, 0x0

    const/high16 v14, 0x3f800000    # 1.0f

    if-eq v2, v4, :cond_a

    iput-boolean v2, v3, Lz60;->L:Z

    iget-object v4, v3, Lz60;->A:Landroid/widget/ImageView;

    if-eqz v2, :cond_3

    const v5, 0x7f070090

    goto :goto_1

    :cond_3
    const v5, 0x7f07007f

    :goto_1
    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz v2, :cond_4

    const v4, 0x7f0f0281

    goto :goto_2

    :cond_4
    const v4, 0x7f0f0274

    :goto_2
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(I)V

    iget-object v4, v3, Lz60;->u:Lcom/zayon/optimize/ui/ZyBox;

    move-object v5, v4

    invoke-virtual {v5}, Lcom/zayon/optimize/ui/ZyBox;->getBg()I

    move-result v4

    invoke-virtual {v5}, Lcom/zayon/optimize/ui/ZyBox;->getBorderColor()I

    move-result v6

    iget-object v5, v3, Lz60;->v:Lcom/zayon/optimize/ui/ZyBox;

    invoke-virtual {v5}, Lcom/zayon/optimize/ui/ZyBox;->getBg()I

    move-result v15

    invoke-virtual {v0}, Landroid/widget/TextView;->getCurrentTextColor()I

    move-result v16

    invoke-virtual {v5}, Lcom/zayon/optimize/ui/ZyBox;->getShadowMix()F

    move-result v8

    if-eqz v2, :cond_5

    iget v5, v3, Lz60;->C:I

    goto :goto_3

    :cond_5
    iget v5, v3, Lz60;->D:I

    :goto_3
    if-eqz v2, :cond_6

    iget v7, v3, Lz60;->E:I

    goto :goto_4

    :cond_6
    iget v7, v3, Lz60;->F:I

    :goto_4
    if-eqz v2, :cond_7

    iget v9, v3, Lz60;->G:I

    :goto_5
    move/from16 v17, v9

    goto :goto_6

    :cond_7
    iget v9, v3, Lz60;->H:I

    goto :goto_5

    :goto_6
    if-eqz v2, :cond_8

    iget v9, v3, Lz60;->I:I

    :goto_7
    move/from16 v18, v9

    goto :goto_8

    :cond_8
    iget v9, v3, Lz60;->J:I

    goto :goto_7

    :goto_8
    if-eqz v2, :cond_9

    move v9, v14

    goto :goto_9

    :cond_9
    move v9, v13

    :goto_9
    sget-object v25, Lsr;->h:Landroid/view/animation/PathInterpolator;

    new-instance v2, Ly60;

    invoke-direct/range {v2 .. v9}, Ly60;-><init>(Lz60;IIIIFF)V

    const/16 v19, 0x0

    const/high16 v20, 0x3f800000    # 1.0f

    const-wide/16 v21, 0x12c

    const-wide/16 v23, 0x0

    move-object/from16 v26, v2

    invoke-static/range {v19 .. v26}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    new-instance v2, Lof0;

    const/4 v8, 0x2

    move v4, v15

    move/from16 v6, v16

    move/from16 v5, v17

    move/from16 v7, v18

    invoke-direct/range {v2 .. v8}, Lof0;-><init>(Ljava/lang/Object;IIIII)V

    const-wide/16 v21, 0xfa

    move-object/from16 v26, v2

    invoke-static/range {v19 .. v26}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    :cond_a
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v4, -0x1

    sparse-switch v2, :sswitch_data_0

    :goto_a
    move v12, v4

    goto :goto_b

    :sswitch_0
    const-string v2, "restore"

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_b

    goto :goto_a

    :cond_b
    const/4 v12, 0x2

    goto :goto_b

    :sswitch_1
    const-string v2, "leave"

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_d

    goto :goto_a

    :sswitch_2
    const-string v2, "pop"

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_c

    goto :goto_a

    :cond_c
    const/4 v12, 0x0

    :cond_d
    :goto_b
    const/4 v2, 0x4

    const-wide/16 v4, 0x12c

    packed-switch v12, :pswitch_data_0

    goto/16 :goto_0

    :pswitch_0
    invoke-virtual {v3, v14}, Lz60;->r(F)V

    invoke-virtual {v11}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v6

    invoke-virtual {v6, v14}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v6

    invoke-virtual {v6, v4, v5}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    sget-object v5, Lsr;->h:Landroid/view/animation/PathInterpolator;

    invoke-virtual {v4, v5}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->start()V

    invoke-virtual {v11}, Landroid/view/View;->getTranslationX()F

    move-result v12

    sget-object v18, Lsr;->a:Landroid/view/animation/PathInterpolator;

    new-instance v4, Lnc0;

    invoke-direct {v4, v11, v2}, Lnc0;-><init>(Landroid/view/View;I)V

    const/4 v13, 0x0

    const-wide/16 v14, 0x15e

    const-wide/16 v16, 0x0

    move-object/from16 v19, v4

    invoke-static/range {v12 .. v19}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    goto/16 :goto_0

    :pswitch_1
    invoke-virtual {v3, v14}, Lz60;->r(F)V

    invoke-virtual {v11}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v6

    invoke-virtual {v6, v13}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v6

    invoke-virtual {v6, v4, v5}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    sget-object v5, Lsr;->h:Landroid/view/animation/PathInterpolator;

    invoke-virtual {v4, v5}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->start()V

    invoke-virtual {v11}, Landroid/view/View;->getTranslationX()F

    move-result v12

    const/high16 v4, 0x42200000    # 40.0f

    iget v5, v3, Lz60;->B:F

    mul-float v13, v5, v4

    sget-object v18, Lsr;->a:Landroid/view/animation/PathInterpolator;

    new-instance v4, Lnc0;

    invoke-direct {v4, v11, v2}, Lnc0;-><init>(Landroid/view/View;I)V

    const-wide/16 v14, 0x15e

    const-wide/16 v16, 0x0

    move-object/from16 v19, v4

    invoke-static/range {v12 .. v19}, Li60;->n(FFJJLandroid/view/animation/Interpolator;Ly5;)Landroid/animation/ValueAnimator;

    goto/16 :goto_0

    :pswitch_2
    const v2, 0x3f8a3d71    # 1.08f

    invoke-virtual {v3, v2}, Lz60;->r(F)V

    goto/16 :goto_0

    :cond_e
    return-void

    :cond_f
    :goto_c
    invoke-virtual/range {p0 .. p2}, La70;->d(Lqr0;I)V

    return-void

    :sswitch_data_0
    .sparse-switch
        0x1b251 -> :sswitch_2
        0x6214eb7 -> :sswitch_1
        0x416ad28e -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final f(Landroid/view/ViewGroup;I)Lqr0;
    .locals 3

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v1, 0x0

    if-nez p2, :cond_1

    iget-object p0, p0, La70;->f:Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of p1, p1, Landroid/view/ViewGroup;

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    invoke-virtual {p1, p0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    new-instance p1, Lx60;

    invoke-direct {p1, p0}, Lqr0;-><init>(Landroid/view/View;)V

    invoke-virtual {p1, v1}, Lqr0;->n(Z)V

    return-object p1

    :cond_1
    const/4 v2, 0x3

    if-ne p2, v2, :cond_2

    new-instance p0, Lx60;

    const p2, 0x7f0c0040

    invoke-virtual {v0, p2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-direct {p0, p1}, Lqr0;-><init>(Landroid/view/View;)V

    return-object p0

    :cond_2
    const/4 v2, 0x1

    if-ne p2, v2, :cond_3

    new-instance p0, Lx60;

    const p2, 0x7f0c0041

    invoke-virtual {v0, p2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-direct {p0, p1}, Lqr0;-><init>(Landroid/view/View;)V

    return-object p0

    :cond_3
    new-instance p2, Lz60;

    const v2, 0x7f0c003f

    invoke-virtual {v0, v2, p1, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-direct {p2, p0, p1}, Lz60;-><init>(La70;Landroid/view/View;)V

    return-object p2
.end method

.method public final h(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, La70;->g:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    iget-object v1, p0, La70;->g:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld00;

    iget-object v1, v1, Ld00;->a:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    add-int/lit8 v0, v0, 0x2

    iget-object p0, p0, Luq0;->a:Lvq0;

    const/4 p1, 0x1

    invoke-virtual {p0, v0, p1, p2}, Lvq0;->c(IILjava/lang/String;)V

    return-void

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
