.class public final La02;
.super Lk02;
.source "SourceFile"


# instance fields
.field public final h:J


# direct methods
.method public constructor <init>(Lmz1;Lbw1;JI)V
    .locals 7

    const-string v3, "qP7oA5YZCnlM0GasGhjRykxMC65mV5SDJ64BQ3cUrQM="

    const/16 v6, 0x19

    const-string v2, "GN3pwajeSKC9vStuq8/7toSg5Hl8NuHCGYd/lap9KB2W9wK7JFaYvfpiW9ms3dza"

    move-object v0, p0

    move-object v1, p1

    move-object v4, p2

    move v5, p5

    invoke-direct/range {v0 .. v6}, Lk02;-><init>(Lmz1;Ljava/lang/String;Ljava/lang/String;Lbw1;II)V

    iput-wide p3, v0, La02;->h:J

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 7

    iget-object v0, p0, Lk02;->e:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    invoke-virtual {v0, v1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    iget-object v2, p0, Lk02;->d:Lbw1;

    monitor-enter v2

    :try_start_0
    invoke-virtual {v2}, Lkg4;->c()V

    iget-object v3, v2, Lkg4;->i:Lng4;

    check-cast v3, Lsw1;

    invoke-virtual {v3, v0, v1}, Lsw1;->u0(J)V

    iget-wide v3, p0, La02;->h:J

    const-wide/16 v5, 0x0

    cmp-long p0, v3, v5

    if-eqz p0, :cond_0

    sub-long/2addr v0, v3

    invoke-virtual {v2}, Lkg4;->c()V

    iget-object p0, v2, Lkg4;->i:Lng4;

    check-cast p0, Lsw1;

    invoke-virtual {p0, v0, v1}, Lsw1;->S0(J)V

    invoke-virtual {v2}, Lkg4;->c()V

    iget-object p0, v2, Lkg4;->i:Lng4;

    check-cast p0, Lsw1;

    invoke-virtual {p0, v3, v4}, Lsw1;->y(J)V

    :cond_0
    monitor-exit v2

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method
