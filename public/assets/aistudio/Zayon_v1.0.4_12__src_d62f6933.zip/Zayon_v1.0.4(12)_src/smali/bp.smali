.class public final Lbp;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:Landroid/view/ViewGroup;

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:Z

.field public final synthetic d:Lfz0;

.field public final synthetic e:Ldp;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;Landroid/view/View;ZLfz0;Ldp;)V
    .locals 0

    iput-object p1, p0, Lbp;->a:Landroid/view/ViewGroup;

    iput-object p2, p0, Lbp;->b:Landroid/view/View;

    iput-boolean p3, p0, Lbp;->c:Z

    iput-object p4, p0, Lbp;->d:Lfz0;

    iput-object p5, p0, Lbp;->e:Ldp;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    iget-object p1, p0, Lbp;->a:Landroid/view/ViewGroup;

    iget-object v0, p0, Lbp;->b:Landroid/view/View;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-boolean p1, p0, Lbp;->c:Z

    iget-object v1, p0, Lbp;->d:Lfz0;

    if-eqz p1, :cond_0

    iget p1, v1, Lfz0;->a:I

    invoke-static {v0, p1}, Lq60;->a(Landroid/view/View;I)V

    :cond_0
    iget-object p0, p0, Lbp;->e:Ldp;

    invoke-virtual {p0}, Lg7;->e()V

    const/4 p0, 0x2

    invoke-static {p0}, Lhy;->F(I)Z

    move-result p0

    if-eqz p0, :cond_1

    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_1
    return-void
.end method
