.class public final La74;
.super Lk74;
.source "SourceFile"


# instance fields
.field public final o:Lc74;

.field public final p:Lf53;

.field public final q:Lxe4;

.field public final r:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Lc74;Lf53;Lxe4;Ljava/lang/Integer;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La74;->o:Lc74;

    iput-object p2, p0, La74;->p:Lf53;

    iput-object p3, p0, La74;->q:Lxe4;

    iput-object p4, p0, La74;->r:Ljava/lang/Integer;

    return-void
.end method


# virtual methods
.method public final H()Lxe4;
    .locals 0

    iget-object p0, p0, La74;->q:Lxe4;

    return-object p0
.end method

.method public final synthetic n()Lk24;
    .locals 0

    iget-object p0, p0, La74;->o:Lc74;

    return-object p0
.end method

.method public final s()Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, La74;->r:Ljava/lang/Integer;

    return-object p0
.end method
