.class public final Lan1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkj1;


# static fields
.field public static final r0:[B

.field public static final s0:[B

.field public static final t0:[B

.field public static final u0:[B

.field public static final v0:Ljava/util/UUID;

.field public static final w0:Ljava/util/Map;


# instance fields
.field public A:Lum1;

.field public B:Z

.field public C:I

.field public D:J

.field public final E:Landroid/util/SparseArray;

.field public F:Z

.field public G:J

.field public H:I

.field public I:J

.field public J:J

.field public K:I

.field public L:Z

.field public M:J

.field public N:J

.field public O:J

.field public P:Z

.field public Q:J

.field public R:Z

.field public S:J

.field public T:Z

.field public U:I

.field public V:J

.field public W:J

.field public X:I

.field public Y:I

.field public Z:[I

.field public final a:Lbn1;

.field public a0:I

.field public final b:Landroid/util/SparseArray;

.field public b0:I

.field public final c:Landroid/util/LongSparseArray;

.field public c0:I

.field public final d:Z

.field public d0:I

.field public final e:Z

.field public e0:Z

.field public final f:Z

.field public f0:J

.field public final g:Lcp1;

.field public g0:I

.field public final h:Lzb3;

.field public h0:I

.field public final i:Lzb3;

.field public i0:I

.field public final j:Lzb3;

.field public j0:Z

.field public final k:Lzb3;

.field public k0:Z

.field public final l:Lzb3;

.field public l0:Z

.field public final m:Lzb3;

.field public m0:I

.field public final n:Lzb3;

.field public n0:B

.field public final o:Lzb3;

.field public o0:Z

.field public final p:Lzb3;

.field public p0:Lmj1;

.field public final q:Lzb3;

.field public final q0:Lqm1;

.field public r:Ljava/nio/ByteBuffer;

.field public s:J

.field public t:J

.field public u:J

.field public v:J

.field public w:J

.field public x:Z

.field public y:Z

.field public z:Lrm1;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/16 v0, 0x20

    new-array v1, v0, [B

    fill-array-data v1, :array_0

    sput-object v1, Lan1;->r0:[B

    sget-object v1, Lvh3;->a:Ljava/lang/String;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    const-string v2, "Format: Start, End, ReadOrder, Layer, Style, Name, MarginL, MarginR, MarginV, Effect, Text"

    invoke-virtual {v2, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    sput-object v1, Lan1;->s0:[B

    new-array v0, v0, [B

    fill-array-data v0, :array_1

    sput-object v0, Lan1;->t0:[B

    const/16 v0, 0x26

    new-array v0, v0, [B

    fill-array-data v0, :array_2

    sput-object v0, Lan1;->u0:[B

    new-instance v0, Ljava/util/UUID;

    const-wide v1, 0x100000000001000L

    const-wide v3, -0x7fffff55ffc7648fL    # -3.607411173533E-312

    invoke-direct {v0, v1, v2, v3, v4}, Ljava/util/UUID;-><init>(JJ)V

    sput-object v0, Lan1;->v0:Ljava/util/UUID;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const-string v1, "htc_video_rotA-090"

    const/16 v2, 0x5a

    const/4 v3, 0x0

    const-string v4, "htc_video_rotA-000"

    invoke-static {v3, v0, v4, v2, v1}, Lq60;->u(ILjava/util/HashMap;Ljava/lang/String;ILjava/lang/String;)V

    const-string v1, "htc_video_rotA-270"

    const/16 v2, 0x10e

    const/16 v3, 0xb4

    const-string v4, "htc_video_rotA-180"

    invoke-static {v3, v0, v4, v2, v1}, Lq60;->u(ILjava/util/HashMap;Ljava/lang/String;ILjava/lang/String;)V

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lan1;->w0:Ljava/util/Map;

    return-void

    nop

    :array_0
    .array-data 1
        0x31t
        0xat
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2ct
        0x30t
        0x30t
        0x30t
        0x20t
        0x2dt
        0x2dt
        0x3et
        0x20t
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2ct
        0x30t
        0x30t
        0x30t
        0xat
    .end array-data

    :array_1
    .array-data 1
        0x44t
        0x69t
        0x61t
        0x6ct
        0x6ft
        0x67t
        0x75t
        0x65t
        0x3at
        0x20t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2ct
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2ct
    .end array-data

    :array_2
    .array-data 1
        0x57t
        0x45t
        0x42t
        0x56t
        0x54t
        0x54t
        0xat
        0xat
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2et
        0x30t
        0x30t
        0x30t
        0x20t
        0x2dt
        0x2dt
        0x3et
        0x20t
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x3at
        0x30t
        0x30t
        0x2et
        0x30t
        0x30t
        0x30t
        0xat
    .end array-data
.end method

.method public constructor <init>()V
    .locals 3

    .line 188
    new-instance v0, Lqm1;

    invoke-direct {v0}, Lqm1;-><init>()V

    const/4 v1, 0x2

    sget-object v2, Lcp1;->f:Ljs;

    invoke-direct {p0, v0, v1, v2}, Lan1;-><init>(Lqm1;ILcp1;)V

    return-void
.end method

.method public constructor <init>(Lqm1;ILcp1;)V
    .locals 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lan1;->t:J

    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v2, p0, Lan1;->u:J

    iput-wide v2, p0, Lan1;->v:J

    iput-wide v2, p0, Lan1;->w:J

    iput-wide v2, p0, Lan1;->G:J

    const/4 v4, -0x1

    iput v4, p0, Lan1;->H:I

    iput-wide v0, p0, Lan1;->I:J

    iput-wide v0, p0, Lan1;->J:J

    iput v4, p0, Lan1;->K:I

    iput-wide v0, p0, Lan1;->M:J

    iput-wide v0, p0, Lan1;->N:J

    iput-wide v0, p0, Lan1;->O:J

    iput-wide v0, p0, Lan1;->Q:J

    iput-wide v2, p0, Lan1;->S:J

    iput-object p1, p0, Lan1;->q0:Lqm1;

    new-instance v0, Lo81;

    const/16 v1, 0xe

    invoke-direct {v0, v1, p0}, Lo81;-><init>(ILjava/lang/Object;)V

    iput-object v0, p1, Lqm1;->d:Lo81;

    iput-object p3, p0, Lan1;->g:Lcp1;

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, Lan1;->E:Landroid/util/SparseArray;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lan1;->d:Z

    and-int/lit8 p2, p2, 0x2

    if-nez p2, :cond_0

    move p2, p1

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    iput-boolean p2, p0, Lan1;->f:Z

    iput-boolean p1, p0, Lan1;->e:Z

    new-instance p2, Lbn1;

    invoke-direct {p2}, Lbn1;-><init>()V

    iput-object p2, p0, Lan1;->a:Lbn1;

    new-instance p2, Landroid/util/LongSparseArray;

    invoke-direct {p2}, Landroid/util/LongSparseArray;-><init>()V

    iput-object p2, p0, Lan1;->c:Landroid/util/LongSparseArray;

    new-instance p2, Landroid/util/SparseArray;

    invoke-direct {p2}, Landroid/util/SparseArray;-><init>()V

    iput-object p2, p0, Lan1;->b:Landroid/util/SparseArray;

    new-instance p2, Lzb3;

    const/4 p3, 0x4

    invoke-direct {p2, p3}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lan1;->j:Lzb3;

    new-instance p2, Lzb3;

    invoke-static {p3}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    invoke-direct {p2, v0}, Lzb3;-><init>([B)V

    iput-object p2, p0, Lan1;->k:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2, p3}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lan1;->l:Lzb3;

    new-instance p2, Lzb3;

    sget-object v0, Lic1;->o:[B

    invoke-direct {p2, v0}, Lzb3;-><init>([B)V

    iput-object p2, p0, Lan1;->h:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2, p3}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lan1;->i:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2}, Lzb3;-><init>()V

    iput-object p2, p0, Lan1;->m:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2}, Lzb3;-><init>()V

    iput-object p2, p0, Lan1;->n:Lzb3;

    new-instance p2, Lzb3;

    const/16 p3, 0x8

    invoke-direct {p2, p3}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lan1;->o:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2}, Lzb3;-><init>()V

    iput-object p2, p0, Lan1;->p:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2}, Lzb3;-><init>()V

    iput-object p2, p0, Lan1;->q:Lzb3;

    new-array p2, p1, [I

    iput-object p2, p0, Lan1;->Z:[I

    iput-boolean p1, p0, Lan1;->y:Z

    return-void
.end method

.method public static s(JJLjava/lang/String;)[B
    .locals 9

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v0, p0, v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, La60;->t(Z)V

    const-wide v0, 0xd693a400L

    div-long v2, p0, v0

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    long-to-int v2, v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    int-to-long v5, v2

    mul-long/2addr v5, v0

    sub-long/2addr p0, v5

    const-wide/32 v0, 0x3938700

    div-long v5, p0, v0

    long-to-int v2, v5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    int-to-long v6, v2

    mul-long/2addr v6, v0

    sub-long/2addr p0, v6

    const-wide/32 v0, 0xf4240

    div-long v6, p0, v0

    long-to-int v2, v6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    int-to-long v7, v2

    mul-long/2addr v7, v0

    sub-long/2addr p0, v7

    div-long/2addr p0, p2

    long-to-int p0, p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {v3, v5, v6, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v4, p4, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    sget-object p1, Lvh3;->a:Ljava/lang/String;

    sget-object p1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(J)J
    .locals 7

    iget-wide v2, p0, Lan1;->u:J

    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long p0, v2, v0

    if-eqz p0, :cond_0

    const-wide/16 v4, 0x3e8

    sget-object v6, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    move-wide v0, p1

    invoke-static/range {v0 .. v6}, Lvh3;->w(JJJLjava/math/RoundingMode;)J

    move-result-wide p0

    return-wide p0

    :cond_0
    const-string p0, "Can\'t scale timecode prior to timecodeScale being set."

    const/4 p1, 0x0

    invoke-static {p1, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0
.end method

.method public final b(Llj1;)Z
    .locals 12

    new-instance p0, Lgo2;

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, v0, v1}, Lgo2;-><init>(CI)V

    check-cast p1, Lfj1;

    iget-wide v1, p1, Lfj1;->j:J

    const-wide/16 v3, -0x1

    cmp-long v3, v1, v3

    const-wide/16 v4, 0x400

    if-eqz v3, :cond_1

    cmp-long v6, v1, v4

    if-lez v6, :cond_0

    goto :goto_0

    :cond_0
    move-wide v4, v1

    :cond_1
    :goto_0
    iget-object v6, p0, Lgo2;->j:Ljava/lang/Object;

    check-cast v6, Lzb3;

    iget-object v7, v6, Lzb3;->a:[B

    const/4 v8, 0x4

    invoke-virtual {p1, v7, v0, v8, v0}, Lfj1;->y([BIIZ)Z

    invoke-virtual {v6}, Lzb3;->N()J

    move-result-wide v9

    iput v8, p0, Lgo2;->i:I

    :goto_1
    const-wide/32 v7, 0x1a45dfa3

    cmp-long v7, v9, v7

    const/4 v8, 0x1

    if-eqz v7, :cond_3

    long-to-int v7, v4

    iget v11, p0, Lgo2;->i:I

    add-int/2addr v11, v8

    iput v11, p0, Lgo2;->i:I

    if-ne v11, v7, :cond_2

    goto :goto_3

    :cond_2
    iget-object v7, v6, Lzb3;->a:[B

    invoke-virtual {p1, v7, v0, v8, v0}, Lfj1;->y([BIIZ)Z

    const/16 v7, 0x8

    shl-long v7, v9, v7

    iget-object v9, v6, Lzb3;->a:[B

    aget-byte v9, v9, v0

    and-int/lit16 v9, v9, 0xff

    const-wide/16 v10, -0x100

    and-long/2addr v7, v10

    int-to-long v9, v9

    or-long/2addr v9, v7

    goto :goto_1

    :cond_3
    invoke-virtual {p0, p1}, Lgo2;->k(Lfj1;)J

    move-result-wide v4

    iget v6, p0, Lgo2;->i:I

    int-to-long v6, v6

    const-wide/high16 v9, -0x8000000000000000L

    cmp-long v11, v4, v9

    if-eqz v11, :cond_8

    add-long/2addr v6, v4

    if-nez v3, :cond_4

    goto :goto_2

    :cond_4
    cmp-long v1, v6, v1

    if-ltz v1, :cond_5

    goto :goto_3

    :cond_5
    :goto_2
    iget v1, p0, Lgo2;->i:I

    int-to-long v1, v1

    cmp-long v1, v1, v6

    if-gez v1, :cond_7

    invoke-virtual {p0, p1}, Lgo2;->k(Lfj1;)J

    move-result-wide v1

    cmp-long v1, v1, v9

    if-nez v1, :cond_6

    goto :goto_3

    :cond_6
    invoke-virtual {p0, p1}, Lgo2;->k(Lfj1;)J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v3, v1, v3

    if-ltz v3, :cond_8

    if-eqz v3, :cond_5

    long-to-int v1, v1

    invoke-virtual {p1, v1, v0}, Lfj1;->a(IZ)Z

    iget v2, p0, Lgo2;->i:I

    add-int/2addr v2, v1

    iput v2, p0, Lgo2;->i:I

    goto :goto_2

    :cond_7
    if-nez v1, :cond_8

    return v8

    :cond_8
    :goto_3
    return v0
.end method

.method public final c()V
    .locals 0

    return-void
.end method

.method public final e(Lmj1;)V
    .locals 2

    iget-boolean v0, p0, Lan1;->f:Z

    if-eqz v0, :cond_0

    new-instance v0, Ljl;

    iget-object v1, p0, Lan1;->g:Lcp1;

    invoke-direct {v0, p1, v1}, Ljl;-><init>(Lmj1;Lcp1;)V

    move-object p1, v0

    :cond_0
    iput-object p1, p0, Lan1;->p0:Lmj1;

    return-void
.end method

.method public final f(JJ)V
    .locals 1

    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide p1, p0, Lan1;->S:J

    const/4 p3, 0x0

    iput p3, p0, Lan1;->U:I

    iget-object p4, p0, Lan1;->q0:Lqm1;

    iput p3, p4, Lqm1;->e:I

    iget-object v0, p4, Lqm1;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    iget-object p4, p4, Lqm1;->c:Lbn1;

    iput p3, p4, Lbn1;->a:I

    iput p3, p4, Lbn1;->b:I

    iget-object p4, p0, Lan1;->a:Lbn1;

    iput p3, p4, Lbn1;->a:I

    iput p3, p4, Lbn1;->b:I

    invoke-virtual {p0}, Lan1;->q()V

    iput-boolean p3, p0, Lan1;->F:Z

    iput-wide p1, p0, Lan1;->G:J

    const/4 p1, -0x1

    iput p1, p0, Lan1;->H:I

    const-wide/16 p1, -0x1

    iput-wide p1, p0, Lan1;->I:J

    iput-wide p1, p0, Lan1;->J:J

    iget-boolean p1, p0, Lan1;->B:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Lan1;->E:Landroid/util/SparseArray;

    invoke-virtual {p1}, Landroid/util/SparseArray;->clear()V

    :cond_0
    move p1, p3

    :goto_0
    iget-object p2, p0, Lan1;->b:Landroid/util/SparseArray;

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p4

    if-ge p1, p4, :cond_2

    invoke-virtual {p2, p1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lum1;

    iget-object p2, p2, Lum1;->W:Lmk1;

    if-eqz p2, :cond_1

    iput-boolean p3, p2, Lmk1;->b:Z

    iput p3, p2, Lmk1;->c:I

    :cond_1
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final g(Llj1;Loj1;)I
    .locals 44

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const/4 v3, 0x0

    iput-boolean v3, v0, Lan1;->T:Z

    :goto_0
    iget-boolean v4, v0, Lan1;->T:Z

    if-nez v4, :cond_8c

    iget-object v4, v0, Lan1;->q0:Lqm1;

    iget-object v5, v4, Lqm1;->c:Lbn1;

    iget-object v6, v4, Lqm1;->d:Lo81;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_1
    iget-object v6, v4, Lqm1;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lpm1;

    const-string v15, "V_VP9"

    const-wide/16 v16, -0x1

    const/16 v18, 0x8

    const v10, 0x1549a966

    const/16 v3, 0x4dbb

    const/16 v12, 0xae

    const-wide/16 v21, 0x0

    const/16 v8, 0xa0

    const/16 v9, 0x80

    const-wide v24, -0x7fffffffffffffffL    # -4.9E-324

    const v13, 0x1654ae6b

    const/4 v11, 0x0

    if-eqz v7, :cond_30

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v28

    move-object/from16 v30, v15

    iget-wide v14, v7, Lpm1;->b:J

    cmp-long v7, v28, v14

    if-ltz v7, :cond_2f

    iget-object v4, v4, Lqm1;->d:Lo81;

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lpm1;

    iget v5, v5, Lpm1;->a:I

    iget-object v4, v4, Lo81;->i:Ljava/lang/Object;

    check-cast v4, Lan1;

    iget-object v6, v4, Lan1;->E:Landroid/util/SparseArray;

    iget-object v7, v4, Lan1;->b:Landroid/util/SparseArray;

    iget-object v14, v4, Lan1;->p0:Lmj1;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eq v5, v9, :cond_2d

    const-string v9, "A_OPUS"

    if-eq v5, v8, :cond_27

    if-eq v5, v12, :cond_24

    const/16 v8, 0x45b9

    if-eq v5, v8, :cond_23

    if-eq v5, v3, :cond_20

    const/16 v3, 0x6240

    if-eq v5, v3, :cond_1e

    const/16 v3, 0x6d80

    if-eq v5, v3, :cond_1c

    if-eq v5, v10, :cond_1a

    if-eq v5, v13, :cond_b

    const v3, 0x1c53bb6b

    if-eq v5, v3, :cond_4

    const/16 v3, 0xb6

    if-eq v5, v3, :cond_2

    const/16 v3, 0xb7

    if-eq v5, v3, :cond_0

    goto/16 :goto_14

    :cond_0
    iget-boolean v3, v4, Lan1;->B:Z

    if-nez v3, :cond_2e

    invoke-virtual {v4, v5}, Lan1;->m(I)V

    iget-wide v7, v4, Lan1;->G:J

    cmp-long v3, v7, v24

    if-eqz v3, :cond_2e

    iget v3, v4, Lan1;->H:I

    const/4 v5, -0x1

    if-eq v3, v5, :cond_2e

    iget-wide v7, v4, Lan1;->I:J

    cmp-long v5, v7, v16

    if-eqz v5, :cond_2e

    invoke-virtual {v6, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    if-nez v3, :cond_1

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iget v5, v4, Lan1;->H:I

    invoke-virtual {v6, v5, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_1
    new-instance v5, Lsm1;

    iget-wide v6, v4, Lan1;->G:J

    iget-wide v8, v4, Lan1;->t:J

    iget-wide v10, v4, Lan1;->I:J

    add-long/2addr v8, v10

    iget-wide v10, v4, Lan1;->J:J

    invoke-direct/range {v5 .. v11}, Lsm1;-><init>(JJJ)V

    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_14

    :cond_2
    iget-object v3, v4, Lan1;->z:Lrm1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v5, v3, Lrm1;->a:J

    cmp-long v7, v5, v21

    if-eqz v7, :cond_3

    iget-object v7, v4, Lan1;->c:Landroid/util/LongSparseArray;

    invoke-virtual {v7, v5, v6, v3}, Landroid/util/LongSparseArray;->put(JLjava/lang/Object;)V

    :cond_3
    iput-object v11, v4, Lan1;->z:Lrm1;

    goto/16 :goto_14

    :cond_4
    iget-boolean v3, v4, Lan1;->B:Z

    if-nez v3, :cond_2e

    const/4 v3, 0x0

    :goto_2
    invoke-virtual {v6}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v3, v5, :cond_8

    invoke-virtual {v6, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_7

    iget-wide v8, v4, Lan1;->w:J

    cmp-long v3, v8, v24

    if-nez v3, :cond_5

    goto :goto_5

    :cond_5
    const/4 v3, 0x0

    :goto_3
    invoke-virtual {v6}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v3, v5, :cond_6

    invoke-virtual {v6, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/List;

    invoke-static {v5}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_6
    new-instance v31, Ltm1;

    iget-wide v8, v4, Lan1;->w:J

    iget v3, v4, Lan1;->K:I

    iget-wide v10, v4, Lan1;->t:J

    iget-wide v12, v4, Lan1;->s:J

    move/from16 v35, v3

    move-object/from16 v32, v6

    move-wide/from16 v33, v8

    move-wide/from16 v36, v10

    move-wide/from16 v38, v12

    invoke-direct/range {v31 .. v39}, Ltm1;-><init>(Landroid/util/SparseArray;JIJJ)V

    move-object/from16 v3, v31

    iget-object v5, v4, Lan1;->p0:Lmj1;

    invoke-interface {v5, v3}, Lmj1;->f0(Lbk1;)V

    :goto_4
    const/4 v3, 0x1

    goto :goto_6

    :cond_7
    move-object/from16 v32, v6

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_8
    :goto_5
    iget-object v3, v4, Lan1;->p0:Lmj1;

    new-instance v5, Lpj1;

    iget-wide v8, v4, Lan1;->w:J

    move-wide/from16 v10, v21

    invoke-direct {v5, v8, v9, v10, v11}, Lpj1;-><init>(JJ)V

    invoke-interface {v3, v5}, Lmj1;->f0(Lbk1;)V

    goto :goto_4

    :goto_6
    iput-boolean v3, v4, Lan1;->B:Z

    const/4 v3, 0x0

    iput-boolean v3, v4, Lan1;->F:Z

    const/4 v3, 0x0

    :goto_7
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v3, v5, :cond_a

    invoke-virtual {v7, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lum1;

    iget-boolean v6, v5, Lum1;->X:Z

    if-nez v6, :cond_9

    invoke-virtual {v4, v5}, Lan1;->i(Lum1;)V

    iget-object v6, v5, Lum1;->d0:Llk1;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v6, v5, Lum1;->d0:Llk1;

    iget-object v5, v5, Lum1;->e0:Lfx4;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v6, v5}, Llk1;->c(Lfx4;)V

    :cond_9
    add-int/lit8 v3, v3, 0x1

    goto :goto_7

    :cond_a
    invoke-virtual {v4}, Lan1;->h()V

    goto/16 :goto_14

    :cond_b
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-eqz v3, :cond_19

    iget-boolean v3, v4, Lan1;->d:Z

    if-eqz v3, :cond_c

    iget-wide v5, v4, Lan1;->M:J

    cmp-long v3, v5, v16

    if-eqz v3, :cond_c

    iget-boolean v3, v4, Lan1;->B:Z

    if-eqz v3, :cond_d

    :cond_c
    const/4 v3, 0x1

    goto :goto_8

    :cond_d
    const/4 v3, 0x0

    :goto_8
    const/4 v5, 0x0

    const/4 v6, -0x1

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, -0x1

    :goto_9
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v11

    if-ge v5, v11, :cond_13

    invoke-virtual {v7, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lum1;

    iget v12, v11, Lum1;->f:I

    const/4 v13, 0x2

    if-ne v12, v13, :cond_f

    iget-boolean v12, v11, Lum1;->b0:Z

    if-eqz v12, :cond_e

    iget v6, v11, Lum1;->d:I

    :cond_e
    const/4 v13, -0x1

    if-ne v8, v13, :cond_11

    iget v8, v11, Lum1;->d:I

    goto :goto_a

    :cond_f
    const/4 v13, -0x1

    const/4 v14, 0x1

    if-ne v12, v14, :cond_11

    iget-boolean v12, v11, Lum1;->b0:Z

    if-eqz v12, :cond_10

    iget v9, v11, Lum1;->d:I

    :cond_10
    if-ne v10, v13, :cond_11

    iget v10, v11, Lum1;->d:I

    :cond_11
    :goto_a
    if-eqz v3, :cond_12

    iget-boolean v12, v11, Lum1;->X:Z

    if-nez v12, :cond_12

    invoke-virtual {v4, v11}, Lan1;->i(Lum1;)V

    iget-object v12, v11, Lum1;->d0:Llk1;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v11, Lum1;->d0:Llk1;

    iget-object v11, v11, Lum1;->e0:Lfx4;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v12, v11}, Llk1;->c(Lfx4;)V

    :cond_12
    add-int/lit8 v5, v5, 0x1

    goto :goto_9

    :cond_13
    const/4 v13, -0x1

    if-eq v6, v13, :cond_14

    iput v6, v4, Lan1;->K:I

    :goto_b
    const/4 v14, 0x1

    goto :goto_d

    :cond_14
    if-eq v8, v13, :cond_15

    iput v8, v4, Lan1;->K:I

    goto :goto_b

    :cond_15
    if-eq v9, v13, :cond_16

    iput v9, v4, Lan1;->K:I

    goto :goto_b

    :cond_16
    if-eq v10, v13, :cond_17

    iput v10, v4, Lan1;->K:I

    goto :goto_b

    :cond_17
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-lez v5, :cond_18

    const/4 v5, 0x0

    invoke-virtual {v7, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lum1;

    iget v5, v6, Lum1;->d:I

    goto :goto_c

    :cond_18
    const/4 v5, -0x1

    :goto_c
    iput v5, v4, Lan1;->K:I

    goto :goto_b

    :goto_d
    iput-boolean v14, v4, Lan1;->R:Z

    if-eqz v3, :cond_2e

    invoke-virtual {v4}, Lan1;->h()V

    goto/16 :goto_14

    :cond_19
    const-string v0, "No valid tracks were found"

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_1a
    iget-wide v5, v4, Lan1;->u:J

    cmp-long v3, v5, v24

    if-nez v3, :cond_1b

    const-wide/32 v5, 0xf4240

    iput-wide v5, v4, Lan1;->u:J

    :cond_1b
    iget-wide v5, v4, Lan1;->v:J

    cmp-long v3, v5, v24

    if-eqz v3, :cond_2e

    invoke-virtual {v4, v5, v6}, Lan1;->a(J)J

    move-result-wide v5

    iput-wide v5, v4, Lan1;->w:J

    goto/16 :goto_14

    :cond_1c
    invoke-virtual {v4, v5}, Lan1;->l(I)V

    iget-object v3, v4, Lan1;->A:Lum1;

    iget-boolean v4, v3, Lum1;->j:Z

    if-eqz v4, :cond_2e

    iget-object v3, v3, Lum1;->k:[B

    if-nez v3, :cond_1d

    goto/16 :goto_14

    :cond_1d
    const-string v0, "Combining encryption and compression is not supported"

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_1e
    invoke-virtual {v4, v5}, Lan1;->l(I)V

    iget-object v3, v4, Lan1;->A:Lum1;

    iget-boolean v4, v3, Lum1;->j:Z

    if-eqz v4, :cond_2e

    iget-object v4, v3, Lum1;->l:Lhk1;

    if-eqz v4, :cond_1f

    new-instance v5, Lat4;

    new-instance v6, Lms4;

    sget-object v7, Ldm3;->a:Ljava/util/UUID;

    iget-object v4, v4, Lhk1;->b:[B

    const-string v8, "video/webm"

    invoke-direct {v6, v7, v8, v4}, Lms4;-><init>(Ljava/util/UUID;Ljava/lang/String;[B)V

    filled-new-array {v6}, [Lms4;

    move-result-object v4

    const/4 v14, 0x1

    invoke-direct {v5, v11, v14, v4}, Lat4;-><init>(Ljava/lang/String;Z[Lms4;)V

    iput-object v5, v3, Lum1;->n:Lat4;

    goto/16 :goto_14

    :cond_1f
    const-string v0, "Encrypted Track found but ContentEncKeyID was not found"

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_20
    iget v3, v4, Lan1;->C:I

    const/4 v5, -0x1

    if-eq v3, v5, :cond_22

    iget-wide v5, v4, Lan1;->D:J

    cmp-long v7, v5, v16

    if-eqz v7, :cond_22

    const v7, 0x1c53bb6b

    if-ne v3, v7, :cond_21

    iput-wide v5, v4, Lan1;->M:J

    goto/16 :goto_14

    :cond_21
    if-ne v3, v13, :cond_2e

    iput-wide v5, v4, Lan1;->O:J

    goto/16 :goto_14

    :cond_22
    const-string v0, "Mandatory element SeekID or SeekPosition not found"

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_23
    const/4 v3, 0x0

    :goto_e
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    move-result v5

    if-ge v3, v5, :cond_2e

    invoke-virtual {v7, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lum1;

    invoke-virtual {v4, v5}, Lan1;->i(Lum1;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    :cond_24
    iget-object v3, v4, Lan1;->A:Lum1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, v3, Lum1;->c:Ljava/lang/String;

    if-eqz v5, :cond_26

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v6

    sparse-switch v6, :sswitch_data_0

    goto/16 :goto_10

    :sswitch_0
    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_1
    const-string v6, "A_FLAC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_2
    const-string v6, "A_EAC3"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_3
    const-string v6, "A_ALAC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_4
    const-string v6, "V_MPEG2"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_5
    const-string v6, "S_TEXT/UTF8"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_6
    const-string v6, "S_TEXT/WEBVTT"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_7
    const-string v6, "V_MPEGH/ISO/HEVC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_8
    const-string v6, "S_TEXT/SSA"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_9
    const-string v6, "S_TEXT/ASS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_a
    const-string v6, "A_PCM/INT/LIT"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_b
    const-string v6, "A_PCM/INT/BIG"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_c
    const-string v6, "A_PCM/FLOAT/IEEE"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_d
    const-string v6, "A_DTS/EXPRESS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_e
    const-string v6, "V_THEORA"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_f
    const-string v6, "S_HDMV/PGS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_10
    move-object/from16 v14, v30

    invoke-virtual {v5, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_11
    const-string v6, "V_VP8"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_12
    const-string v6, "V_AV1"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_13
    const-string v6, "A_DTS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_14
    const-string v6, "A_AC3"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_15
    const-string v6, "A_AAC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_16
    const-string v6, "A_DTS/LOSSLESS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_17
    const-string v6, "S_VOBSUB"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto/16 :goto_f

    :sswitch_18
    const-string v6, "V_MPEG4/ISO/AVC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_19
    const-string v6, "V_MPEG4/ISO/ASP"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1a
    const-string v6, "S_DVBSUB"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1b
    const-string v6, "V_MS/VFW/FOURCC"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1c
    const-string v6, "A_MPEG/L3"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1d
    const-string v6, "A_MPEG/L2"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1e
    const-string v6, "A_VORBIS"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_1f
    const-string v6, "A_TRUEHD"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_20
    const-string v6, "A_MS/ACM"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_21
    const-string v6, "V_MPEG4/ISO/SP"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    goto :goto_f

    :sswitch_22
    const-string v6, "V_MPEG4/ISO/AP"

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_25

    :goto_f
    iget v5, v3, Lum1;->d:I

    invoke-virtual {v3, v5}, Lum1;->a(I)V

    iget-object v5, v4, Lan1;->p0:Lmj1;

    iget v6, v3, Lum1;->d:I

    iget v8, v3, Lum1;->f:I

    invoke-interface {v5, v6, v8}, Lmj1;->c(II)Llk1;

    move-result-object v5

    iput-object v5, v3, Lum1;->d0:Llk1;

    iget v5, v3, Lum1;->d:I

    invoke-virtual {v7, v5, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_25
    :goto_10
    iput-object v11, v4, Lan1;->A:Lum1;

    goto/16 :goto_14

    :cond_26
    const-string v0, "CodecId is missing in TrackEntry element"

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_27
    iget v3, v4, Lan1;->U:I

    const/4 v13, 0x2

    if-ne v3, v13, :cond_2e

    iget v3, v4, Lan1;->a0:I

    invoke-virtual {v7, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lum1;

    iget-object v5, v3, Lum1;->d0:Llk1;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-wide v5, v4, Lan1;->f0:J

    const-wide/16 v21, 0x0

    cmp-long v5, v5, v21

    if-lez v5, :cond_28

    iget-object v5, v3, Lum1;->c:Ljava/lang/String;

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_28

    iget-object v5, v4, Lan1;->q:Lzb3;

    invoke-static/range {v18 .. v18}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v6

    sget-object v7, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v6, v7}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v6

    iget-wide v7, v4, Lan1;->f0:J

    invoke-virtual {v6, v7, v8}, Ljava/nio/ByteBuffer;->putLong(J)Ljava/nio/ByteBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    array-length v7, v6

    invoke-virtual {v5, v7, v6}, Lzb3;->z(I[B)V

    :cond_28
    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_11
    iget v7, v4, Lan1;->Y:I

    if-ge v5, v7, :cond_29

    iget-object v7, v4, Lan1;->Z:[I

    aget v7, v7, v5

    add-int/2addr v6, v7

    add-int/lit8 v5, v5, 0x1

    goto :goto_11

    :cond_29
    const/4 v5, 0x0

    :goto_12
    iget v7, v4, Lan1;->Y:I

    if-ge v5, v7, :cond_2c

    iget-wide v7, v4, Lan1;->V:J

    iget v9, v3, Lum1;->g:I

    mul-int/2addr v9, v5

    const/16 v10, 0x3e8

    div-int/2addr v9, v10

    int-to-long v9, v9

    add-long v33, v7, v9

    iget v7, v4, Lan1;->c0:I

    if-nez v5, :cond_2b

    iget-boolean v5, v4, Lan1;->e0:Z

    if-nez v5, :cond_2a

    or-int/lit8 v7, v7, 0x1

    :cond_2a
    move/from16 v35, v7

    const/4 v5, 0x0

    goto :goto_13

    :cond_2b
    move/from16 v35, v7

    :goto_13
    iget-object v7, v4, Lan1;->Z:[I

    aget v36, v7, v5

    sub-int v37, v6, v36

    move-object/from16 v32, v3

    move-object/from16 v31, v4

    invoke-virtual/range {v31 .. v37}, Lan1;->n(Lum1;JIII)V

    const/16 v20, 0x1

    add-int/lit8 v5, v5, 0x1

    move/from16 v6, v37

    goto :goto_12

    :cond_2c
    const/4 v3, 0x0

    iput v3, v4, Lan1;->U:I

    goto :goto_14

    :cond_2d
    iget-object v3, v4, Lan1;->z:Lrm1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, v3, Lrm1;->f:Ljava/lang/String;

    if-nez v4, :cond_2e

    iget-object v4, v3, Lrm1;->h:Ljava/lang/String;

    if-eqz v4, :cond_2e

    iput-object v4, v3, Lrm1;->f:Ljava/lang/String;

    iget-object v4, v3, Lrm1;->i:Ljava/lang/String;

    if-eqz v4, :cond_2e

    iput-object v4, v3, Lrm1;->g:Ljava/lang/String;

    :cond_2e
    :goto_14
    const/4 v3, 0x1

    :goto_15
    const/4 v8, 0x0

    goto/16 :goto_48

    :cond_2f
    move-object/from16 v14, v30

    goto :goto_16

    :cond_30
    move-object v14, v15

    :goto_16
    iget v7, v4, Lqm1;->e:I

    const v15, 0x1f43b675

    const/4 v3, 0x4

    if-nez v7, :cond_38

    const/4 v8, 0x0

    const/4 v12, 0x1

    invoke-virtual {v5, v1, v12, v8, v3}, Lbn1;->e(Llj1;ZZI)J

    move-result-wide v31

    const-wide/16 v33, -0x2

    cmp-long v7, v31, v33

    if-nez v7, :cond_36

    invoke-interface {v1}, Llj1;->j()V

    :goto_17
    iget-object v7, v4, Lqm1;->a:[B

    invoke-interface {v1, v8, v3, v7}, Llj1;->v(II[B)V

    aget-byte v12, v7, v8

    move/from16 v9, v18

    const/4 v8, 0x0

    :goto_18
    if-ge v8, v9, :cond_32

    add-int/lit8 v9, v8, 0x1

    sget-object v31, Lbn1;->d:[J

    aget-wide v34, v31, v8

    move-object/from16 v36, v14

    int-to-long v13, v12

    and-long v13, v34, v13

    const-wide/16 v21, 0x0

    cmp-long v13, v13, v21

    if-eqz v13, :cond_31

    :goto_19
    const/4 v13, -0x1

    goto :goto_1a

    :cond_31
    move v8, v9

    move-object/from16 v14, v36

    const/16 v9, 0x8

    const v13, 0x1654ae6b

    goto :goto_18

    :cond_32
    move-object/from16 v36, v14

    const/4 v9, -0x1

    goto :goto_19

    :goto_1a
    if-eq v9, v13, :cond_35

    if-gt v9, v3, :cond_35

    const/4 v12, 0x0

    invoke-static {v9, v12, v7}, Lbn1;->h(IZ[B)J

    move-result-wide v13

    long-to-int v7, v13

    iget-object v12, v4, Lqm1;->d:Lo81;

    iget-object v12, v12, Lo81;->i:Ljava/lang/Object;

    if-eq v7, v10, :cond_34

    const v12, 0x1043a770

    if-eq v7, v12, :cond_34

    if-eq v7, v15, :cond_34

    const v12, 0x1c53bb6b

    if-eq v7, v12, :cond_34

    const v8, 0x1654ae6b

    if-ne v7, v8, :cond_33

    move v13, v8

    goto :goto_1c

    :cond_33
    :goto_1b
    const/4 v14, 0x1

    goto :goto_1e

    :cond_34
    move v13, v7

    :goto_1c
    invoke-interface {v1, v9}, Llj1;->w(I)V

    int-to-long v7, v13

    :goto_1d
    const/4 v14, 0x1

    goto :goto_1f

    :cond_35
    const v8, 0x1654ae6b

    goto :goto_1b

    :goto_1e
    invoke-interface {v1, v14}, Llj1;->w(I)V

    move v13, v8

    move-object/from16 v14, v36

    const/4 v8, 0x0

    const/16 v9, 0x80

    const/16 v18, 0x8

    goto :goto_17

    :cond_36
    move-object/from16 v36, v14

    move-wide/from16 v7, v31

    goto :goto_1d

    :goto_1f
    cmp-long v9, v7, v16

    if-nez v9, :cond_37

    const/4 v3, 0x0

    goto/16 :goto_15

    :cond_37
    long-to-int v7, v7

    iput v7, v4, Lqm1;->f:I

    iput v14, v4, Lqm1;->e:I

    :goto_20
    const/4 v8, 0x0

    const/16 v9, 0x8

    goto :goto_21

    :cond_38
    move-object/from16 v36, v14

    const/4 v14, 0x1

    if-ne v7, v14, :cond_39

    goto :goto_20

    :goto_21
    invoke-virtual {v5, v1, v8, v14, v9}, Lbn1;->e(Llj1;ZZI)J

    move-result-wide v12

    iput-wide v12, v4, Lqm1;->g:J

    const/4 v13, 0x2

    iput v13, v4, Lqm1;->e:I

    :cond_39
    iget-object v7, v4, Lqm1;->d:Lo81;

    iget v8, v4, Lqm1;->f:I

    iget-object v7, v7, Lo81;->i:Ljava/lang/Object;

    check-cast v7, Lan1;

    const-wide/16 v12, 0x8

    sparse-switch v8, :sswitch_data_1

    iget-wide v6, v4, Lqm1;->g:J

    long-to-int v3, v6

    invoke-interface {v1, v3}, Llj1;->w(I)V

    const/4 v3, 0x0

    iput v3, v4, Lqm1;->e:I

    goto/16 :goto_1

    :sswitch_23
    iget-wide v5, v4, Lqm1;->g:J

    const-wide/16 v9, 0x4

    cmp-long v9, v5, v9

    if-eqz v9, :cond_3b

    cmp-long v9, v5, v12

    if-nez v9, :cond_3a

    goto :goto_22

    :cond_3a
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x14

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "Invalid float size: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_3b
    :goto_22
    long-to-int v5, v5

    invoke-virtual {v4, v1, v5}, Lqm1;->a(Llj1;I)J

    move-result-wide v9

    if-ne v5, v3, :cond_3c

    long-to-int v3, v9

    invoke-static {v3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v3

    float-to-double v5, v3

    goto :goto_23

    :cond_3c
    invoke-static {v9, v10}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v5

    :goto_23
    const/16 v3, 0xb5

    if-eq v8, v3, :cond_3e

    const/16 v3, 0x4489

    if-eq v8, v3, :cond_3d

    packed-switch v8, :pswitch_data_0

    packed-switch v8, :pswitch_data_1

    :goto_24
    const/4 v3, 0x0

    goto/16 :goto_25

    :pswitch_0
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->x:F

    goto :goto_24

    :pswitch_1
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->w:F

    goto :goto_24

    :pswitch_2
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->v:F

    goto :goto_24

    :pswitch_3
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->O:F

    goto :goto_24

    :pswitch_4
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->N:F

    goto :goto_24

    :pswitch_5
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->M:F

    goto :goto_24

    :pswitch_6
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->L:F

    goto :goto_24

    :pswitch_7
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->K:F

    goto :goto_24

    :pswitch_8
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->J:F

    goto :goto_24

    :pswitch_9
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->I:F

    goto :goto_24

    :pswitch_a
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->H:F

    goto :goto_24

    :pswitch_b
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->G:F

    goto :goto_24

    :pswitch_c
    double-to-float v3, v5

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    iput v3, v5, Lum1;->F:F

    goto :goto_24

    :cond_3d
    double-to-long v5, v5

    iput-wide v5, v7, Lan1;->v:J

    goto :goto_24

    :cond_3e
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    double-to-int v5, v5

    iput v5, v3, Lum1;->T:I

    goto/16 :goto_24

    :goto_25
    iput v3, v4, Lqm1;->e:I

    :goto_26
    move v8, v3

    :goto_27
    const/4 v3, 0x1

    goto/16 :goto_48

    :sswitch_24
    iget-wide v5, v4, Lqm1;->g:J

    long-to-int v5, v5

    iget-object v6, v7, Lan1;->j:Lzb3;

    iget-object v12, v7, Lan1;->b:Landroid/util/SparseArray;

    const/16 v13, 0xa1

    const/16 v14, 0xa3

    if-eq v8, v13, :cond_4d

    if-eq v8, v14, :cond_4d

    const/16 v6, 0xa5

    if-eq v8, v6, :cond_47

    const/16 v3, 0x41ed

    if-eq v8, v3, :cond_44

    const/16 v3, 0x4255

    if-eq v8, v3, :cond_43

    const/16 v3, 0x47e2

    if-eq v8, v3, :cond_42

    const/16 v3, 0x53ab

    if-eq v8, v3, :cond_41

    const/16 v3, 0x63a2

    if-eq v8, v3, :cond_40

    const/16 v3, 0x7672

    if-ne v8, v3, :cond_3f

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    new-array v6, v5, [B

    iput-object v6, v3, Lum1;->y:[B

    const/4 v3, 0x0

    invoke-interface {v1, v3, v5, v6}, Llj1;->B(II[B)V

    goto/16 :goto_3e

    :cond_3f
    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0xf

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "Unexpected id: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v11, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_40
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    new-array v6, v5, [B

    iput-object v6, v3, Lum1;->m:[B

    const/4 v3, 0x0

    invoke-interface {v1, v3, v5, v6}, Llj1;->B(II[B)V

    goto/16 :goto_3e

    :cond_41
    const/4 v3, 0x0

    iget-object v6, v7, Lan1;->l:Lzb3;

    iget-object v8, v6, Lzb3;->a:[B

    invoke-static {v8, v3}, Ljava/util/Arrays;->fill([BB)V

    rsub-int/lit8 v8, v5, 0x4

    iget-object v9, v6, Lzb3;->a:[B

    invoke-interface {v1, v8, v5, v9}, Llj1;->B(II[B)V

    invoke-virtual {v6, v3}, Lzb3;->D(I)V

    invoke-virtual {v6}, Lzb3;->N()J

    move-result-wide v5

    long-to-int v5, v5

    iput v5, v7, Lan1;->C:I

    goto/16 :goto_3e

    :cond_42
    const/4 v3, 0x0

    new-array v6, v5, [B

    invoke-interface {v1, v3, v5, v6}, Llj1;->B(II[B)V

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v5, v7, Lan1;->A:Lum1;

    new-instance v7, Lhk1;

    const/4 v14, 0x1

    invoke-direct {v7, v14, v3, v3, v6}, Lhk1;-><init>(III[B)V

    iput-object v7, v5, Lum1;->l:Lhk1;

    goto/16 :goto_3e

    :cond_43
    const/4 v3, 0x0

    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v6, v7, Lan1;->A:Lum1;

    new-array v7, v5, [B

    iput-object v7, v6, Lum1;->k:[B

    invoke-interface {v1, v3, v5, v7}, Llj1;->B(II[B)V

    goto/16 :goto_3e

    :cond_44
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    iget v6, v3, Lum1;->i:I

    const v7, 0x64767643

    if-eq v6, v7, :cond_46

    const v7, 0x64766343

    if-ne v6, v7, :cond_45

    goto :goto_29

    :cond_45
    invoke-interface {v1, v5}, Llj1;->w(I)V

    :goto_28
    const/4 v3, 0x0

    goto/16 :goto_3e

    :cond_46
    :goto_29
    new-array v6, v5, [B

    iput-object v6, v3, Lum1;->P:[B

    const/4 v3, 0x0

    invoke-interface {v1, v3, v5, v6}, Llj1;->B(II[B)V

    goto/16 :goto_3e

    :cond_47
    iget v6, v7, Lan1;->U:I

    const/4 v13, 0x2

    if-eq v6, v13, :cond_49

    :cond_48
    :goto_2a
    move-object/from16 v34, v4

    goto/16 :goto_3d

    :cond_49
    iget v6, v7, Lan1;->a0:I

    invoke-virtual {v12, v6}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lum1;

    iget v8, v7, Lan1;->d0:I

    if-ne v8, v3, :cond_4c

    iget-object v3, v6, Lum1;->c:Ljava/lang/String;

    move-object/from16 v14, v36

    invoke-virtual {v14, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4c

    iget-object v3, v7, Lan1;->q:Lzb3;

    invoke-virtual {v3, v5}, Lzb3;->y(I)V

    iget-object v6, v3, Lzb3;->a:[B

    const/4 v8, 0x0

    invoke-interface {v1, v8, v5, v6}, Llj1;->B(II[B)V

    iget-boolean v6, v7, Lan1;->e:Z

    if-nez v6, :cond_48

    iget-object v6, v3, Lzb3;->a:[B

    sget-object v7, Ldy2;->e:[B

    array-length v8, v7

    const/4 v8, 0x5

    if-lt v5, v8, :cond_48

    const/4 v5, 0x0

    :goto_2b
    if-ge v5, v8, :cond_4b

    aget-byte v9, v6, v5

    aget-byte v10, v7, v5

    if-eq v9, v10, :cond_4a

    goto :goto_2a

    :cond_4a
    add-int/lit8 v5, v5, 0x1

    goto :goto_2b

    :cond_4b
    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Lzb3;->y(I)V

    move v3, v5

    goto/16 :goto_3e

    :cond_4c
    invoke-interface {v1, v5}, Llj1;->w(I)V

    goto :goto_28

    :cond_4d
    iget v13, v7, Lan1;->U:I

    if-nez v13, :cond_4e

    iget-object v13, v7, Lan1;->a:Lbn1;

    move-object/from16 v34, v4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v15, 0x8

    const-wide/32 v31, 0x7fffffff

    invoke-virtual {v13, v1, v10, v9, v15}, Lbn1;->e(Llj1;ZZI)J

    move-result-wide v3

    long-to-int v3, v3

    iput v3, v7, Lan1;->a0:I

    iget v3, v13, Lbn1;->b:I

    iput v3, v7, Lan1;->b0:I

    move-wide/from16 v3, v24

    iput-wide v3, v7, Lan1;->W:J

    iput v9, v7, Lan1;->U:I

    invoke-virtual {v6, v10}, Lzb3;->y(I)V

    goto :goto_2c

    :cond_4e
    move-object/from16 v34, v4

    const/4 v10, 0x0

    const-wide/32 v31, 0x7fffffff

    :goto_2c
    iget v3, v7, Lan1;->a0:I

    invoke-virtual {v12, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lum1;

    if-nez v3, :cond_4f

    iget v3, v7, Lan1;->b0:I

    sub-int/2addr v5, v3

    invoke-interface {v1, v5}, Llj1;->w(I)V

    iput v10, v7, Lan1;->U:I

    move v3, v10

    :goto_2d
    move-object/from16 v4, v34

    goto/16 :goto_3e

    :cond_4f
    iget-object v4, v3, Lum1;->d0:Llk1;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v4, v7, Lan1;->U:I

    const/4 v9, 0x1

    if-ne v4, v9, :cond_65

    const/4 v4, 0x3

    invoke-virtual {v7, v1, v4}, Lan1;->o(Llj1;I)V

    iget-object v10, v6, Lzb3;->a:[B

    const/16 v27, 0x2

    aget-byte v10, v10, v27

    and-int/lit8 v10, v10, 0x6

    shr-int/2addr v10, v9

    const/16 v12, 0xff

    if-nez v10, :cond_52

    iput v9, v7, Lan1;->Y:I

    iget-object v4, v7, Lan1;->Z:[I

    if-nez v4, :cond_50

    new-array v4, v9, [I

    goto :goto_2e

    :cond_50
    array-length v10, v4

    if-lt v10, v9, :cond_51

    goto :goto_2e

    :cond_51
    add-int/2addr v10, v10

    invoke-static {v10, v9}, Ljava/lang/Math;->max(II)I

    move-result v4

    new-array v4, v4, [I

    :goto_2e
    iput-object v4, v7, Lan1;->Z:[I

    iget v9, v7, Lan1;->b0:I

    sub-int/2addr v5, v9

    add-int/lit8 v5, v5, -0x3

    const/16 v19, 0x0

    aput v5, v4, v19

    goto/16 :goto_37

    :cond_52
    const/4 v9, 0x4

    invoke-virtual {v7, v1, v9}, Lan1;->o(Llj1;I)V

    iget-object v13, v6, Lzb3;->a:[B

    aget-byte v13, v13, v4

    and-int/2addr v13, v12

    const/16 v20, 0x1

    add-int/lit8 v13, v13, 0x1

    iput v13, v7, Lan1;->Y:I

    iget-object v15, v7, Lan1;->Z:[I

    if-nez v15, :cond_53

    new-array v15, v13, [I

    goto :goto_2f

    :cond_53
    array-length v9, v15

    if-lt v9, v13, :cond_54

    goto :goto_2f

    :cond_54
    add-int/2addr v9, v9

    invoke-static {v9, v13}, Ljava/lang/Math;->max(II)I

    move-result v9

    new-array v15, v9, [I

    :goto_2f
    iput-object v15, v7, Lan1;->Z:[I

    const/4 v13, 0x2

    if-ne v10, v13, :cond_55

    iget v4, v7, Lan1;->b0:I

    sub-int/2addr v5, v4

    add-int/lit8 v5, v5, -0x4

    iget v4, v7, Lan1;->Y:I

    div-int/2addr v5, v4

    const/4 v9, 0x0

    invoke-static {v15, v9, v4, v5}, Ljava/util/Arrays;->fill([IIII)V

    goto/16 :goto_37

    :cond_55
    const/4 v9, 0x0

    const/4 v13, 0x1

    if-ne v10, v13, :cond_58

    move v4, v9

    move v10, v4

    const/16 v35, 0x4

    :goto_30
    iget v11, v7, Lan1;->Y:I

    const/16 v26, -0x1

    add-int/lit8 v11, v11, -0x1

    iget-object v13, v7, Lan1;->Z:[I

    if-ge v4, v11, :cond_57

    aput v9, v13, v4

    :goto_31
    add-int/lit8 v9, v35, 0x1

    invoke-virtual {v7, v1, v9}, Lan1;->o(Llj1;I)V

    iget-object v11, v6, Lzb3;->a:[B

    aget-byte v11, v11, v35

    and-int/2addr v11, v12

    iget-object v13, v7, Lan1;->Z:[I

    aget v15, v13, v4

    add-int/2addr v15, v11

    aput v15, v13, v4

    if-eq v11, v12, :cond_56

    add-int/2addr v10, v15

    add-int/lit8 v4, v4, 0x1

    move/from16 v35, v9

    const/4 v9, 0x0

    goto :goto_30

    :cond_56
    move/from16 v35, v9

    goto :goto_31

    :cond_57
    iget v4, v7, Lan1;->b0:I

    sub-int/2addr v5, v4

    sub-int v5, v5, v35

    sub-int/2addr v5, v10

    aput v5, v13, v11

    goto/16 :goto_37

    :cond_58
    if-ne v10, v4, :cond_64

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/16 v35, 0x4

    :goto_32
    iget v10, v7, Lan1;->Y:I

    const/16 v26, -0x1

    add-int/lit8 v10, v10, -0x1

    iget-object v13, v7, Lan1;->Z:[I

    if-ge v4, v10, :cond_60

    const/16 v19, 0x0

    aput v19, v13, v4

    add-int/lit8 v10, v35, 0x1

    invoke-virtual {v7, v1, v10}, Lan1;->o(Llj1;I)V

    iget-object v13, v6, Lzb3;->a:[B

    aget-byte v13, v13, v35

    if-eqz v13, :cond_5f

    const/4 v13, 0x0

    :goto_33
    const/16 v15, 0x8

    if-ge v13, v15, :cond_5c

    rsub-int/lit8 v15, v13, 0x7

    const/16 v20, 0x1

    shl-int v15, v20, v15

    iget-object v14, v6, Lzb3;->a:[B

    aget-byte v14, v14, v35

    and-int/2addr v14, v15

    if-eqz v14, :cond_5b

    add-int v14, v10, v13

    invoke-virtual {v7, v1, v14}, Lan1;->o(Llj1;I)V

    iget-object v11, v6, Lzb3;->a:[B

    aget-byte v11, v11, v35

    and-int/2addr v11, v12

    not-int v15, v15

    and-int/2addr v11, v15

    move/from16 v23, v13

    int-to-long v12, v11

    :goto_34
    if-ge v10, v14, :cond_59

    const/16 v18, 0x8

    shl-long v11, v12, v18

    iget-object v13, v6, Lzb3;->a:[B

    add-int/lit8 v24, v10, 0x1

    aget-byte v10, v13, v10

    const/16 v15, 0xff

    and-int/2addr v10, v15

    move/from16 v28, v4

    move/from16 v25, v5

    int-to-long v4, v10

    or-long v12, v11, v4

    move/from16 v10, v24

    move/from16 v5, v25

    move/from16 v4, v28

    goto :goto_34

    :cond_59
    move/from16 v28, v4

    move/from16 v25, v5

    if-lez v28, :cond_5a

    mul-int/lit8 v4, v23, 0x7

    add-int/lit8 v4, v4, 0x6

    const-wide/16 v10, 0x1

    shl-long v4, v10, v4

    add-long v4, v4, v16

    sub-long v4, v12, v4

    :goto_35
    move/from16 v35, v14

    goto :goto_36

    :cond_5a
    move-wide v4, v12

    goto :goto_35

    :cond_5b
    move/from16 v28, v4

    move/from16 v25, v5

    move/from16 v23, v13

    add-int/lit8 v13, v23, 0x1

    const/4 v11, 0x0

    const/16 v12, 0xff

    const/16 v14, 0xa3

    goto :goto_33

    :cond_5c
    move/from16 v28, v4

    move/from16 v25, v5

    move/from16 v35, v10

    const-wide/16 v4, 0x0

    :goto_36
    const-wide/32 v10, -0x80000000

    cmp-long v10, v4, v10

    if-ltz v10, :cond_5e

    cmp-long v10, v4, v31

    if-gtz v10, :cond_5e

    iget-object v10, v7, Lan1;->Z:[I

    long-to-int v4, v4

    if-eqz v28, :cond_5d

    add-int/lit8 v5, v28, -0x1

    aget v5, v10, v5

    add-int/2addr v4, v5

    :cond_5d
    aput v4, v10, v28

    add-int/2addr v9, v4

    add-int/lit8 v4, v28, 0x1

    move/from16 v5, v25

    const/4 v11, 0x0

    const/16 v12, 0xff

    const/16 v14, 0xa3

    goto/16 :goto_32

    :cond_5e
    const-string v0, "EBML lacing sample size out of range."

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_5f
    move-object v1, v11

    const-string v0, "No valid varint length mask found"

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_60
    move/from16 v25, v5

    iget v4, v7, Lan1;->b0:I

    sub-int v5, v25, v4

    sub-int v5, v5, v35

    sub-int/2addr v5, v9

    aput v5, v13, v10

    :goto_37
    iget-object v4, v6, Lzb3;->a:[B

    const/16 v19, 0x0

    aget-byte v5, v4, v19

    const/16 v18, 0x8

    shl-int/lit8 v5, v5, 0x8

    const/4 v14, 0x1

    aget-byte v4, v4, v14

    const/16 v15, 0xff

    and-int/2addr v4, v15

    iget-wide v9, v7, Lan1;->S:J

    or-int/2addr v4, v5

    int-to-long v4, v4

    invoke-virtual {v7, v4, v5}, Lan1;->a(J)J

    move-result-wide v4

    add-long/2addr v4, v9

    iput-wide v4, v7, Lan1;->V:J

    iget v4, v3, Lum1;->f:I

    if-eq v4, v14, :cond_63

    const/16 v4, 0xa3

    if-ne v8, v4, :cond_62

    iget-object v4, v6, Lzb3;->a:[B

    const/4 v13, 0x2

    aget-byte v4, v4, v13

    const/16 v5, 0x80

    and-int/2addr v4, v5

    if-ne v4, v5, :cond_61

    const/4 v4, 0x1

    :goto_38
    const/16 v8, 0xa3

    goto :goto_39

    :cond_61
    const/4 v4, 0x0

    goto :goto_38

    :cond_62
    const/4 v13, 0x2

    const/4 v4, 0x0

    goto :goto_39

    :cond_63
    const/4 v13, 0x2

    const/4 v4, 0x1

    :goto_39
    iput v4, v7, Lan1;->c0:I

    iput v13, v7, Lan1;->U:I

    const/4 v5, 0x0

    iput v5, v7, Lan1;->X:I

    const/16 v4, 0xa3

    goto :goto_3a

    :cond_64
    const-string v0, "Unexpected lacing value: 2"

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_65
    move v4, v14

    :goto_3a
    if-ne v8, v4, :cond_67

    :goto_3b
    iget v4, v7, Lan1;->X:I

    iget v5, v7, Lan1;->Y:I

    if-ge v4, v5, :cond_66

    iget-object v5, v7, Lan1;->Z:[I

    aget v4, v5, v4

    const/4 v5, 0x0

    invoke-virtual {v7, v1, v3, v4, v5}, Lan1;->p(Llj1;Lum1;IZ)I

    move-result v42

    iget-wide v4, v7, Lan1;->V:J

    iget v6, v7, Lan1;->X:I

    iget v8, v3, Lum1;->g:I

    mul-int/2addr v6, v8

    const/16 v10, 0x3e8

    div-int/2addr v6, v10

    int-to-long v8, v6

    add-long v39, v4, v8

    iget v4, v7, Lan1;->c0:I

    const/16 v43, 0x0

    move-object/from16 v38, v3

    move/from16 v41, v4

    move-object/from16 v37, v7

    invoke-virtual/range {v37 .. v43}, Lan1;->n(Lum1;JIII)V

    iget v4, v7, Lan1;->X:I

    const/4 v14, 0x1

    add-int/2addr v4, v14

    iput v4, v7, Lan1;->X:I

    goto :goto_3b

    :cond_66
    const/4 v5, 0x0

    const/4 v14, 0x1

    iput v5, v7, Lan1;->U:I

    move v3, v5

    goto/16 :goto_2d

    :cond_67
    :goto_3c
    const/4 v14, 0x1

    iget v4, v7, Lan1;->X:I

    iget v5, v7, Lan1;->Y:I

    if-ge v4, v5, :cond_68

    iget-object v5, v7, Lan1;->Z:[I

    aget v6, v5, v4

    invoke-virtual {v7, v1, v3, v6, v14}, Lan1;->p(Llj1;Lum1;IZ)I

    move-result v6

    aput v6, v5, v4

    iget v4, v7, Lan1;->X:I

    add-int/2addr v4, v14

    iput v4, v7, Lan1;->X:I

    goto :goto_3c

    :cond_68
    :goto_3d
    move-object/from16 v4, v34

    goto/16 :goto_28

    :goto_3e
    iput v3, v4, Lqm1;->e:I

    goto/16 :goto_26

    :sswitch_25
    const/4 v3, 0x0

    const-wide/32 v31, 0x7fffffff

    iget-wide v5, v4, Lqm1;->g:J

    cmp-long v9, v5, v31

    if-gtz v9, :cond_73

    long-to-int v5, v5

    if-nez v5, :cond_69

    const-string v5, ""

    goto :goto_40

    :cond_69
    new-array v6, v5, [B

    invoke-interface {v1, v3, v5, v6}, Llj1;->B(II[B)V

    :goto_3f
    if-lez v5, :cond_6a

    add-int/lit8 v9, v5, -0x1

    aget-byte v10, v6, v9

    if-nez v10, :cond_6a

    move v5, v9

    goto :goto_3f

    :cond_6a
    new-instance v9, Ljava/lang/String;

    invoke-direct {v9, v6, v3, v5}, Ljava/lang/String;-><init>([BII)V

    move-object v5, v9

    :goto_40
    const/16 v3, 0x85

    if-eq v8, v3, :cond_72

    const/16 v3, 0x86

    if-eq v8, v3, :cond_71

    const/16 v3, 0x4282

    if-eq v8, v3, :cond_6e

    const/16 v3, 0x437c

    if-eq v8, v3, :cond_6d

    const/16 v3, 0x536e

    if-eq v8, v3, :cond_6c

    const v3, 0x22b59c

    if-eq v8, v3, :cond_6b

    :goto_41
    const/4 v3, 0x0

    goto :goto_43

    :cond_6b
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    iput-object v5, v3, Lum1;->c0:Ljava/lang/String;

    goto :goto_41

    :cond_6c
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    iput-object v5, v3, Lum1;->b:Ljava/lang/String;

    goto :goto_41

    :cond_6d
    invoke-virtual {v7, v8}, Lan1;->k(I)V

    iget-object v3, v7, Lan1;->z:Lrm1;

    iput-object v5, v3, Lrm1;->i:Ljava/lang/String;

    goto :goto_41

    :cond_6e
    const-string v3, "webm"

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_70

    const-string v6, "matroska"

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6f

    goto :goto_42

    :cond_6f
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x16

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "DocType "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " not supported"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_70
    :goto_42
    invoke-virtual {v5, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    iput-boolean v3, v7, Lan1;->x:Z

    goto :goto_41

    :cond_71
    invoke-virtual {v7, v8}, Lan1;->l(I)V

    iget-object v3, v7, Lan1;->A:Lum1;

    iput-object v5, v3, Lum1;->c:Ljava/lang/String;

    goto :goto_41

    :cond_72
    invoke-virtual {v7, v8}, Lan1;->k(I)V

    iget-object v3, v7, Lan1;->z:Lrm1;

    iput-object v5, v3, Lrm1;->h:Ljava/lang/String;

    goto :goto_41

    :goto_43
    iput v3, v4, Lqm1;->e:I

    goto/16 :goto_26

    :cond_73
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x15

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "String element size: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :sswitch_26
    iget-wide v5, v4, Lqm1;->g:J

    cmp-long v3, v5, v12

    if-gtz v3, :cond_74

    long-to-int v3, v5

    invoke-virtual {v4, v1, v3}, Lqm1;->a(Llj1;I)J

    move-result-wide v5

    invoke-virtual {v7, v8, v5, v6}, Lan1;->j(IJ)V

    const/4 v3, 0x0

    iput v3, v4, Lqm1;->e:I

    goto/16 :goto_26

    :cond_74
    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x16

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "Invalid integer size: "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :sswitch_27
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v9

    iget-wide v11, v4, Lqm1;->g:J

    add-long/2addr v11, v9

    new-instance v3, Lpm1;

    invoke-direct {v3, v8, v11, v12}, Lpm1;-><init>(IJ)V

    invoke-virtual {v6, v3}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    iget-object v3, v4, Lqm1;->d:Lo81;

    iget v5, v4, Lqm1;->f:I

    iget-wide v6, v4, Lqm1;->g:J

    iget-object v3, v3, Lo81;->i:Ljava/lang/Object;

    check-cast v3, Lan1;

    iget-object v8, v3, Lan1;->p0:Lmj1;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x80

    if-eq v5, v11, :cond_84

    const/16 v11, 0xa0

    if-eq v5, v11, :cond_83

    const/16 v11, 0xae

    if-eq v5, v11, :cond_82

    const/16 v11, 0xbb

    if-eq v5, v11, :cond_81

    const/16 v11, 0x4dbb

    if-eq v5, v11, :cond_80

    const/16 v11, 0x5035

    if-eq v5, v11, :cond_7f

    const v11, 0x18538067

    if-eq v5, v11, :cond_7c

    const v12, 0x1c53bb6b

    if-eq v5, v12, :cond_7b

    if-eq v5, v15, :cond_78

    const/16 v6, 0xb6

    if-eq v5, v6, :cond_77

    const/16 v6, 0xb7

    if-eq v5, v6, :cond_75

    goto :goto_44

    :cond_75
    iget-boolean v6, v3, Lan1;->B:Z

    if-nez v6, :cond_76

    invoke-virtual {v3, v5}, Lan1;->m(I)V

    const/4 v13, -0x1

    iput v13, v3, Lan1;->H:I

    move-wide/from16 v5, v16

    iput-wide v5, v3, Lan1;->I:J

    iput-wide v5, v3, Lan1;->J:J

    :cond_76
    :goto_44
    const/4 v8, 0x0

    goto/16 :goto_47

    :cond_77
    move-wide/from16 v5, v16

    new-instance v7, Lrm1;

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v8, v7, Lrm1;->b:J

    iput-wide v8, v7, Lrm1;->c:J

    iput-object v7, v3, Lan1;->z:Lrm1;

    goto :goto_44

    :cond_78
    move-wide/from16 v5, v16

    iget-wide v9, v3, Lan1;->O:J

    cmp-long v7, v9, v5

    if-eqz v7, :cond_79

    iget-boolean v5, v3, Lan1;->R:Z

    if-nez v5, :cond_79

    const/4 v14, 0x1

    iput-boolean v14, v3, Lan1;->P:Z

    goto :goto_45

    :cond_79
    const/4 v14, 0x1

    :goto_45
    iget-boolean v5, v3, Lan1;->B:Z

    if-nez v5, :cond_76

    iget-boolean v5, v3, Lan1;->d:Z

    if-eqz v5, :cond_7a

    iget-wide v5, v3, Lan1;->M:J

    const-wide/16 v16, -0x1

    cmp-long v5, v5, v16

    if-eqz v5, :cond_7a

    iput-boolean v14, v3, Lan1;->L:Z

    goto :goto_44

    :cond_7a
    new-instance v5, Lpj1;

    iget-wide v6, v3, Lan1;->w:J

    const-wide/16 v10, 0x0

    invoke-direct {v5, v6, v7, v10, v11}, Lpj1;-><init>(JJ)V

    invoke-interface {v8, v5}, Lmj1;->f0(Lbk1;)V

    iput-boolean v14, v3, Lan1;->B:Z

    goto :goto_44

    :cond_7b
    const/4 v14, 0x1

    iget-boolean v5, v3, Lan1;->B:Z

    if-nez v5, :cond_76

    iput-boolean v14, v3, Lan1;->F:Z

    goto :goto_44

    :cond_7c
    iget-wide v11, v3, Lan1;->t:J

    const-wide/16 v16, -0x1

    cmp-long v5, v11, v16

    if-eqz v5, :cond_7e

    cmp-long v5, v11, v9

    if-nez v5, :cond_7d

    goto :goto_46

    :cond_7d
    const-string v0, "Multiple Segment elements not supported"

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_7e
    :goto_46
    iput-wide v9, v3, Lan1;->t:J

    iput-wide v6, v3, Lan1;->s:J

    goto :goto_44

    :cond_7f
    invoke-virtual {v3, v5}, Lan1;->l(I)V

    iget-object v3, v3, Lan1;->A:Lum1;

    const/4 v14, 0x1

    iput-boolean v14, v3, Lum1;->j:Z

    goto :goto_44

    :cond_80
    const/4 v13, -0x1

    iput v13, v3, Lan1;->C:I

    const-wide/16 v5, -0x1

    iput-wide v5, v3, Lan1;->D:J

    goto :goto_44

    :cond_81
    iget-boolean v6, v3, Lan1;->B:Z

    if-nez v6, :cond_76

    invoke-virtual {v3, v5}, Lan1;->m(I)V

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    iput-wide v8, v3, Lan1;->G:J

    goto/16 :goto_44

    :cond_82
    new-instance v5, Lum1;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    const/4 v13, -0x1

    iput v13, v5, Lum1;->o:I

    iput v13, v5, Lum1;->p:I

    iput v13, v5, Lum1;->q:I

    iput v13, v5, Lum1;->r:I

    iput v13, v5, Lum1;->s:I

    const/4 v8, 0x0

    iput v8, v5, Lum1;->t:I

    iput v13, v5, Lum1;->u:I

    const/4 v6, 0x0

    iput v6, v5, Lum1;->v:F

    iput v6, v5, Lum1;->w:F

    iput v6, v5, Lum1;->x:F

    const/4 v6, 0x0

    iput-object v6, v5, Lum1;->y:[B

    iput v13, v5, Lum1;->z:I

    iput v13, v5, Lum1;->A:I

    iput v13, v5, Lum1;->B:I

    iput v13, v5, Lum1;->C:I

    const/16 v10, 0x3e8

    iput v10, v5, Lum1;->D:I

    const/16 v6, 0xc8

    iput v6, v5, Lum1;->E:I

    const/high16 v6, -0x40800000    # -1.0f

    iput v6, v5, Lum1;->F:F

    iput v6, v5, Lum1;->G:F

    iput v6, v5, Lum1;->H:F

    iput v6, v5, Lum1;->I:F

    iput v6, v5, Lum1;->J:F

    iput v6, v5, Lum1;->K:F

    iput v6, v5, Lum1;->L:F

    iput v6, v5, Lum1;->M:F

    iput v6, v5, Lum1;->N:F

    iput v6, v5, Lum1;->O:F

    const/4 v14, 0x1

    iput v14, v5, Lum1;->Q:I

    const/4 v13, -0x1

    iput v13, v5, Lum1;->R:I

    iput v13, v5, Lum1;->S:I

    const/16 v6, 0x1f40

    iput v6, v5, Lum1;->T:I

    const-wide/16 v10, 0x0

    iput-wide v10, v5, Lum1;->U:J

    iput-wide v10, v5, Lum1;->V:J

    const/4 v8, 0x0

    iput-boolean v8, v5, Lum1;->X:Z

    iput-boolean v14, v5, Lum1;->b0:Z

    const-string v6, "eng"

    iput-object v6, v5, Lum1;->c0:Ljava/lang/String;

    iput-object v5, v3, Lan1;->A:Lum1;

    iget-boolean v3, v3, Lan1;->x:Z

    iput-boolean v3, v5, Lum1;->a:Z

    goto :goto_47

    :cond_83
    const/4 v8, 0x0

    const-wide/16 v10, 0x0

    iput-boolean v8, v3, Lan1;->e0:Z

    iput-wide v10, v3, Lan1;->f0:J

    goto :goto_47

    :cond_84
    const/4 v8, 0x0

    invoke-virtual {v3, v5}, Lan1;->k(I)V

    iget-object v6, v3, Lan1;->z:Lrm1;

    const/4 v7, 0x0

    iput-object v7, v6, Lrm1;->h:Ljava/lang/String;

    invoke-virtual {v3, v5}, Lan1;->k(I)V

    iget-object v3, v3, Lan1;->z:Lrm1;

    iput-object v7, v3, Lrm1;->i:Ljava/lang/String;

    :goto_47
    iput v8, v4, Lqm1;->e:I

    goto/16 :goto_27

    :goto_48
    if-eqz v3, :cond_88

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v4

    iget-boolean v6, v0, Lan1;->P:Z

    if-eqz v6, :cond_85

    iput-wide v4, v0, Lan1;->Q:J

    iget-wide v3, v0, Lan1;->O:J

    iput-wide v3, v2, Loj1;->h:J

    iput-boolean v8, v0, Lan1;->P:Z

    const/16 v20, 0x1

    return v20

    :cond_85
    const/16 v20, 0x1

    iget-boolean v4, v0, Lan1;->R:Z

    if-eqz v4, :cond_86

    iget-wide v4, v0, Lan1;->Q:J

    const-wide/16 v6, -0x1

    cmp-long v8, v4, v6

    if-eqz v8, :cond_86

    iput-wide v4, v2, Loj1;->h:J

    iput-wide v6, v0, Lan1;->Q:J

    return v20

    :cond_86
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v4

    iget-boolean v6, v0, Lan1;->L:Z

    if-eqz v6, :cond_87

    iput-wide v4, v0, Lan1;->N:J

    iget-wide v3, v0, Lan1;->M:J

    iput-wide v3, v2, Loj1;->h:J

    const/4 v3, 0x0

    iput-boolean v3, v0, Lan1;->L:Z

    return v20

    :cond_87
    iget-boolean v4, v0, Lan1;->B:Z

    if-eqz v4, :cond_88

    iget-wide v4, v0, Lan1;->N:J

    const-wide/16 v6, -0x1

    cmp-long v8, v4, v6

    if-eqz v8, :cond_88

    iput-wide v4, v2, Loj1;->h:J

    iput-wide v6, v0, Lan1;->N:J

    return v20

    :cond_88
    if-nez v3, :cond_8b

    const/4 v3, 0x0

    :goto_49
    iget-object v1, v0, Lan1;->b:Landroid/util/SparseArray;

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v2

    if-ge v3, v2, :cond_8a

    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lum1;

    iget-object v2, v1, Lum1;->d0:Llk1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v1, Lum1;->W:Lmk1;

    if-eqz v2, :cond_89

    iget-object v4, v1, Lum1;->d0:Llk1;

    iget-object v1, v1, Lum1;->l:Lhk1;

    invoke-virtual {v2, v4, v1}, Lmk1;->c(Llk1;Lhk1;)V

    :cond_89
    add-int/lit8 v3, v3, 0x1

    goto :goto_49

    :cond_8a
    const/16 v26, -0x1

    return v26

    :cond_8b
    const/4 v3, 0x0

    goto/16 :goto_0

    :cond_8c
    move/from16 v19, v3

    return v19

    :sswitch_data_0
    .sparse-switch
        -0x7ce7f5de -> :sswitch_22
        -0x7ce7f3b0 -> :sswitch_21
        -0x76567dc0 -> :sswitch_20
        -0x6a615338 -> :sswitch_1f
        -0x672350af -> :sswitch_1e
        -0x585f4fce -> :sswitch_1d
        -0x585f4fcd -> :sswitch_1c
        -0x51dc40b2 -> :sswitch_1b
        -0x37a9c464 -> :sswitch_1a
        -0x2016c535 -> :sswitch_19
        -0x2016c4e5 -> :sswitch_18
        -0x19552dbd -> :sswitch_17
        -0x1538b2ba -> :sswitch_16
        0x3c02325 -> :sswitch_15
        0x3c02353 -> :sswitch_14
        0x3c030c5 -> :sswitch_13
        0x4e81333 -> :sswitch_12
        0x4e86155 -> :sswitch_11
        0x4e86156 -> :sswitch_10
        0x5e8da3e -> :sswitch_f
        0x1a8350d6 -> :sswitch_e
        0x2056f406 -> :sswitch_d
        0x25e26ee2 -> :sswitch_c
        0x2b45174d -> :sswitch_b
        0x2b453ce4 -> :sswitch_a
        0x2c0618eb -> :sswitch_9
        0x2c065c6b -> :sswitch_8
        0x32fdf009 -> :sswitch_7
        0x3e4ca2d8 -> :sswitch_6
        0x54c61e47 -> :sswitch_5
        0x6bd6c624 -> :sswitch_4
        0x74446acb -> :sswitch_3
        0x7446132a -> :sswitch_2
        0x7446b0a6 -> :sswitch_1
        0x744ad97d -> :sswitch_0
    .end sparse-switch

    :sswitch_data_1
    .sparse-switch
        0x80 -> :sswitch_27
        0x83 -> :sswitch_26
        0x85 -> :sswitch_25
        0x86 -> :sswitch_25
        0x88 -> :sswitch_26
        0x89 -> :sswitch_26
        0x8f -> :sswitch_27
        0x91 -> :sswitch_26
        0x92 -> :sswitch_26
        0x98 -> :sswitch_26
        0x9b -> :sswitch_26
        0x9f -> :sswitch_26
        0xa0 -> :sswitch_27
        0xa1 -> :sswitch_24
        0xa3 -> :sswitch_24
        0xa5 -> :sswitch_24
        0xa6 -> :sswitch_27
        0xae -> :sswitch_27
        0xb0 -> :sswitch_26
        0xb3 -> :sswitch_26
        0xb5 -> :sswitch_23
        0xb6 -> :sswitch_27
        0xb7 -> :sswitch_27
        0xba -> :sswitch_26
        0xbb -> :sswitch_27
        0xd7 -> :sswitch_26
        0xe0 -> :sswitch_27
        0xe1 -> :sswitch_27
        0xe7 -> :sswitch_26
        0xee -> :sswitch_26
        0xf0 -> :sswitch_26
        0xf1 -> :sswitch_26
        0xf7 -> :sswitch_26
        0xfb -> :sswitch_26
        0x41e4 -> :sswitch_27
        0x41e7 -> :sswitch_26
        0x41ed -> :sswitch_24
        0x4254 -> :sswitch_26
        0x4255 -> :sswitch_24
        0x4282 -> :sswitch_25
        0x4285 -> :sswitch_26
        0x42f7 -> :sswitch_26
        0x437c -> :sswitch_25
        0x4489 -> :sswitch_23
        0x45b9 -> :sswitch_27
        0x47e1 -> :sswitch_26
        0x47e2 -> :sswitch_24
        0x47e7 -> :sswitch_27
        0x47e8 -> :sswitch_26
        0x4dbb -> :sswitch_27
        0x5031 -> :sswitch_26
        0x5032 -> :sswitch_26
        0x5034 -> :sswitch_27
        0x5035 -> :sswitch_27
        0x536e -> :sswitch_25
        0x53ab -> :sswitch_24
        0x53ac -> :sswitch_26
        0x53b8 -> :sswitch_26
        0x54b0 -> :sswitch_26
        0x54b2 -> :sswitch_26
        0x54ba -> :sswitch_26
        0x55aa -> :sswitch_26
        0x55b0 -> :sswitch_27
        0x55b2 -> :sswitch_26
        0x55b9 -> :sswitch_26
        0x55ba -> :sswitch_26
        0x55bb -> :sswitch_26
        0x55bc -> :sswitch_26
        0x55bd -> :sswitch_26
        0x55d0 -> :sswitch_27
        0x55d1 -> :sswitch_23
        0x55d2 -> :sswitch_23
        0x55d3 -> :sswitch_23
        0x55d4 -> :sswitch_23
        0x55d5 -> :sswitch_23
        0x55d6 -> :sswitch_23
        0x55d7 -> :sswitch_23
        0x55d8 -> :sswitch_23
        0x55d9 -> :sswitch_23
        0x55da -> :sswitch_23
        0x55ee -> :sswitch_26
        0x56aa -> :sswitch_26
        0x56bb -> :sswitch_26
        0x6240 -> :sswitch_27
        0x6264 -> :sswitch_26
        0x63a2 -> :sswitch_24
        0x6d80 -> :sswitch_27
        0x73c4 -> :sswitch_26
        0x73c5 -> :sswitch_26
        0x75a1 -> :sswitch_27
        0x75a2 -> :sswitch_26
        0x7670 -> :sswitch_27
        0x7671 -> :sswitch_26
        0x7672 -> :sswitch_24
        0x7673 -> :sswitch_23
        0x7674 -> :sswitch_23
        0x7675 -> :sswitch_23
        0x22b59c -> :sswitch_25
        0x23e383 -> :sswitch_26
        0x2ad7b1 -> :sswitch_26
        0x1043a770 -> :sswitch_27
        0x114d9b74 -> :sswitch_27
        0x1549a966 -> :sswitch_27
        0x1654ae6b -> :sswitch_27
        0x18538067 -> :sswitch_27
        0x1a45dfa3 -> :sswitch_27
        0x1c53bb6b -> :sswitch_27
        0x1f43b675 -> :sswitch_27
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x55d1
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x7673
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final h()V
    .locals 4

    iget-boolean v0, p0, Lan1;->y:Z

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-wide v0, p0, Lan1;->O:J

    const-wide/16 v2, -0x1

    cmp-long v0, v0, v2

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lan1;->R:Z

    if-eqz v0, :cond_2

    :cond_1
    move v0, v1

    :goto_0
    iget-object v2, p0, Lan1;->b:Landroid/util/SparseArray;

    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    move-result v3

    if-ge v0, v3, :cond_3

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lum1;

    iget-boolean v2, v2, Lum1;->X:Z

    if-nez v2, :cond_2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    return-void

    :cond_3
    iget-object v0, p0, Lan1;->p0:Lmj1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, Lmj1;->e0()V

    iput-boolean v1, p0, Lan1;->y:Z

    return-void
.end method

.method public final i(Lum1;)V
    .locals 31

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v1, Lum1;->Y:Z

    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    const-wide/16 v5, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v2, :cond_a

    iget-object v2, v0, Lan1;->c:Landroid/util/LongSparseArray;

    invoke-virtual {v2}, Landroid/util/LongSparseArray;->size()I

    move-result v9

    if-nez v9, :cond_0

    goto/16 :goto_6

    :cond_0
    new-instance v9, Ljava/util/ArrayList;

    invoke-virtual {v2}, Landroid/util/LongSparseArray;->size()I

    move-result v10

    invoke-direct {v9, v10}, Ljava/util/ArrayList;-><init>(I)V

    move v10, v8

    :goto_0
    invoke-virtual {v2}, Landroid/util/LongSparseArray;->size()I

    move-result v11

    if-ge v10, v11, :cond_8

    invoke-virtual {v2, v10}, Landroid/util/LongSparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lrm1;

    iget-wide v12, v11, Lrm1;->e:J

    cmp-long v14, v12, v5

    if-eqz v14, :cond_1

    iget-wide v14, v1, Lum1;->e:J

    cmp-long v12, v12, v14

    if-nez v12, :cond_7

    :cond_1
    iget-wide v12, v11, Lrm1;->b:J

    sget-object v14, Lvh3;->a:Ljava/lang/String;

    cmp-long v14, v12, v3

    const-wide/32 v15, 0xf4240

    const-wide/high16 v17, -0x8000000000000000L

    if-eqz v14, :cond_3

    cmp-long v14, v12, v17

    if-nez v14, :cond_2

    goto :goto_1

    :cond_2
    div-long/2addr v12, v15

    :cond_3
    :goto_1
    move-wide/from16 v20, v12

    iget-wide v12, v11, Lrm1;->c:J

    cmp-long v14, v12, v3

    if-eqz v14, :cond_5

    cmp-long v14, v12, v17

    if-nez v14, :cond_4

    goto :goto_2

    :cond_4
    div-long/2addr v12, v15

    :cond_5
    :goto_2
    move-wide/from16 v22, v12

    iget-boolean v12, v11, Lrm1;->d:Z

    iget-object v13, v11, Lrm1;->f:Ljava/lang/String;

    if-eqz v13, :cond_6

    new-instance v13, Liy4;

    iget-object v14, v11, Lrm1;->g:Ljava/lang/String;

    iget-object v11, v11, Lrm1;->f:Ljava/lang/String;

    invoke-direct {v13, v14, v11}, Liy4;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    move-object/from16 v25, v13

    goto :goto_4

    :cond_6
    const/4 v13, 0x0

    goto :goto_3

    :goto_4
    new-instance v19, Lpl1;

    move/from16 v24, v12

    invoke-direct/range {v19 .. v25}, Lpl1;-><init>(JJZLiy4;)V

    move-object/from16 v11, v19

    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    :cond_8
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_a

    iget-object v2, v1, Lum1;->e0:Lfx4;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Law4;

    invoke-direct {v10, v2}, Law4;-><init>(Lfx4;)V

    iget-object v2, v2, Lfx4;->l:Lrp1;

    if-eqz v2, :cond_9

    new-array v11, v8, [Lol1;

    invoke-virtual {v9, v11}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v9

    check-cast v9, [Lyo1;

    invoke-virtual {v2, v9}, Lrp1;->c([Lyo1;)Lrp1;

    move-result-object v2

    goto :goto_5

    :cond_9
    new-instance v2, Lrp1;

    invoke-direct {v2, v9}, Lrp1;-><init>(Ljava/util/List;)V

    :goto_5
    iput-object v2, v10, Law4;->k:Lrp1;

    new-instance v2, Lfx4;

    invoke-direct {v2, v10}, Lfx4;-><init>(Law4;)V

    iput-object v2, v1, Lum1;->e0:Lfx4;

    iput-boolean v7, v1, Lum1;->Y:Z

    :cond_a
    :goto_6
    iget-wide v9, v0, Lan1;->w:J

    iget-wide v11, v0, Lan1;->t:J

    iget-wide v13, v0, Lan1;->s:J

    iget v2, v1, Lum1;->f:I

    const/4 v15, 0x2

    if-eq v2, v15, :cond_b

    goto/16 :goto_e

    :cond_b
    iget v2, v1, Lum1;->d:I

    iget-object v0, v0, Lan1;->E:Landroid/util/SparseArray;

    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    iget-boolean v2, v1, Lum1;->Z:Z

    if-nez v2, :cond_13

    if-eqz v0, :cond_13

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_13

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_c

    move-wide/from16 v18, v3

    move/from16 p0, v8

    :goto_7
    move-wide/from16 v2, v18

    goto/16 :goto_c

    :cond_c
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/16 v15, 0x14

    invoke-static {v2, v15}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v15, -0x1

    const-wide/16 v16, 0x0

    move-wide/from16 v18, v3

    move v3, v8

    move v4, v15

    :goto_8
    if-ge v3, v2, :cond_10

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    move-wide/from16 v21, v5

    move-object/from16 v5, v20

    check-cast v5, Lsm1;

    move v6, v8

    move-wide/from16 v23, v9

    iget-wide v8, v5, Lsm1;->h:J

    move/from16 p0, v6

    iget-wide v6, v5, Lsm1;->j:J

    move-wide/from16 v25, v11

    iget-wide v10, v5, Lsm1;->i:J

    const-wide/32 v27, 0x989680

    cmp-long v5, v8, v27

    if-lez v5, :cond_d

    goto :goto_b

    :cond_d
    add-int/lit8 v5, v3, 0x1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v20

    add-int/lit8 v12, v20, -0x1

    if-ge v3, v12, :cond_e

    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lsm1;

    move/from16 v20, v2

    move/from16 v28, v3

    iget-wide v2, v12, Lsm1;->i:J

    move-wide/from16 v29, v2

    iget-wide v2, v12, Lsm1;->j:J

    add-long v2, v29, v2

    add-long/2addr v10, v6

    iget-wide v6, v12, Lsm1;->h:J

    sub-long/2addr v6, v8

    :goto_9
    sub-long/2addr v2, v10

    goto :goto_a

    :cond_e
    move/from16 v20, v2

    move/from16 v28, v3

    add-long v2, v25, v13

    add-long/2addr v10, v6

    sub-long v6, v23, v8

    goto :goto_9

    :goto_a
    cmp-long v8, v6, v21

    if-lez v8, :cond_f

    long-to-double v2, v2

    long-to-double v6, v6

    div-double/2addr v2, v6

    cmpl-double v6, v2, v16

    if-lez v6, :cond_f

    move-wide/from16 v16, v2

    move/from16 v4, v28

    :cond_f
    move/from16 v8, p0

    move v3, v5

    move/from16 v2, v20

    move-wide/from16 v5, v21

    move-wide/from16 v9, v23

    move-wide/from16 v11, v25

    const/4 v7, 0x1

    goto :goto_8

    :cond_10
    move/from16 p0, v8

    :goto_b
    if-ne v4, v15, :cond_11

    goto/16 :goto_7

    :cond_11
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lsm1;

    iget-wide v2, v0, Lsm1;->h:J

    :goto_c
    cmp-long v0, v2, v18

    if-eqz v0, :cond_13

    iget-object v0, v1, Lum1;->e0:Lfx4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lfx4;->l:Lrp1;

    new-instance v4, Lrl1;

    invoke-direct {v4, v2, v3}, Lrl1;-><init>(J)V

    if-nez v0, :cond_12

    new-instance v0, Lrp1;

    const/4 v10, 0x1

    new-array v2, v10, [Lyo1;

    aput-object v4, v2, p0

    invoke-direct {v0, v2}, Lrp1;-><init>([Lyo1;)V

    goto :goto_d

    :cond_12
    const/4 v10, 0x1

    new-array v2, v10, [Lyo1;

    aput-object v4, v2, p0

    invoke-virtual {v0, v2}, Lrp1;->c([Lyo1;)Lrp1;

    move-result-object v0

    :goto_d
    iget-object v2, v1, Lum1;->e0:Lfx4;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Law4;

    invoke-direct {v3, v2}, Law4;-><init>(Lfx4;)V

    iput-object v0, v3, Law4;->k:Lrp1;

    new-instance v0, Lfx4;

    invoke-direct {v0, v3}, Lfx4;-><init>(Law4;)V

    iput-object v0, v1, Lum1;->e0:Lfx4;

    const/4 v10, 0x1

    iput-boolean v10, v1, Lum1;->Z:Z

    :cond_13
    :goto_e
    return-void
.end method

.method public final j(IJ)V
    .locals 10

    const/16 v0, 0x88

    const/4 v1, 0x0

    const-wide/16 v2, 0x1

    const/4 v4, 0x1

    if-eq p1, v0, :cond_21

    const/16 v0, 0x89

    if-eq p1, v0, :cond_20

    const/16 v0, 0x91

    if-eq p1, v0, :cond_1f

    const/16 v0, 0x92

    if-eq p1, v0, :cond_1e

    const/16 v0, 0xf0

    const-wide/16 v5, -0x1

    if-eq p1, v0, :cond_1c

    const/16 v0, 0xf1

    if-eq p1, v0, :cond_1b

    const/16 v0, 0x5031

    const/4 v5, 0x0

    const-string v6, " not supported"

    if-eq p1, v0, :cond_19

    const/16 v0, 0x5032

    if-eq p1, v0, :cond_17

    const/16 v0, 0x73c4

    if-eq p1, v0, :cond_16

    const/16 v0, 0x73c5

    if-eq p1, v0, :cond_15

    const/16 v0, 0x21

    const/4 v7, -0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    sparse-switch p1, :sswitch_data_0

    packed-switch p1, :pswitch_data_0

    goto/16 :goto_0

    :pswitch_0
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->E:I

    return-void

    :pswitch_1
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->D:I

    return-void

    :pswitch_2
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    invoke-static {p2}, Lfd4;->b(I)I

    move-result p1

    if-eq p1, v7, :cond_1d

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p1, p0, Lum1;->A:I

    return-void

    :pswitch_3
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    invoke-static {p2}, Lfd4;->c(I)I

    move-result p1

    if-eq p1, v7, :cond_1d

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p1, p0, Lum1;->B:I

    return-void

    :pswitch_4
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    if-eq p2, v4, :cond_1

    if-eq p2, v9, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v4, p0, Lum1;->C:I

    return-void

    :cond_1
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v9, p0, Lum1;->C:I

    return-void

    :sswitch_0
    iput-wide p2, p0, Lan1;->u:J

    return-void

    :sswitch_1
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->g:I

    return-void

    :sswitch_2
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    if-eqz p2, :cond_5

    if-eq p2, v4, :cond_4

    if-eq p2, v9, :cond_3

    if-eq p2, v8, :cond_2

    goto/16 :goto_0

    :cond_2
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v8, p0, Lum1;->u:I

    return-void

    :cond_3
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v9, p0, Lum1;->u:I

    return-void

    :cond_4
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v4, p0, Lum1;->u:I

    return-void

    :cond_5
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v1, p0, Lum1;->u:I

    return-void

    :sswitch_3
    iput-wide p2, p0, Lan1;->f0:J

    return-void

    :sswitch_4
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->R:I

    return-void

    :sswitch_5
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput-wide p2, p0, Lum1;->V:J

    return-void

    :sswitch_6
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput-wide p2, p0, Lum1;->U:J

    return-void

    :sswitch_7
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->h:I

    return-void

    :sswitch_8
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->q:I

    return-void

    :sswitch_9
    cmp-long p2, p2, v2

    if-nez p2, :cond_6

    move v1, v4

    :cond_6
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput-boolean v1, p0, Lum1;->a0:Z

    return-void

    :sswitch_a
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->s:I

    return-void

    :sswitch_b
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->t:I

    return-void

    :sswitch_c
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->r:I

    return-void

    :sswitch_d
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    if-eqz p2, :cond_a

    if-eq p2, v4, :cond_9

    if-eq p2, v8, :cond_8

    const/16 p1, 0xf

    if-eq p2, p1, :cond_7

    goto/16 :goto_0

    :cond_7
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v8, p0, Lum1;->z:I

    return-void

    :cond_8
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v4, p0, Lum1;->z:I

    return-void

    :cond_9
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v9, p0, Lum1;->z:I

    return-void

    :cond_a
    iget-object p0, p0, Lan1;->A:Lum1;

    iput v1, p0, Lum1;->z:I

    return-void

    :sswitch_e
    iget-wide v0, p0, Lan1;->t:J

    add-long/2addr p2, v0

    iput-wide p2, p0, Lan1;->D:J

    return-void

    :sswitch_f
    cmp-long p0, p2, v2

    if-nez p0, :cond_b

    goto/16 :goto_0

    :cond_b
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance p1, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0x24

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "AESSettingsCipherMode "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :sswitch_10
    const-wide/16 p0, 0x5

    cmp-long p0, p2, p0

    if-nez p0, :cond_c

    goto/16 :goto_0

    :cond_c
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance p1, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0x1d

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "ContentEncAlgo "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :sswitch_11
    cmp-long p0, p2, v2

    if-nez p0, :cond_d

    goto/16 :goto_0

    :cond_d
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x1e

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "EBMLReadVersion "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :sswitch_12
    cmp-long p0, p2, v2

    if-ltz p0, :cond_e

    const-wide/16 p0, 0x2

    cmp-long p0, p2, p0

    if-gtz p0, :cond_e

    goto/16 :goto_0

    :cond_e
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance p1, Ljava/lang/StringBuilder;

    add-int/2addr p0, v0

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "DocTypeReadVersion "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :sswitch_13
    const-wide/16 p0, 0x3

    cmp-long p0, p2, p0

    if-nez p0, :cond_f

    goto/16 :goto_0

    :cond_f
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x1e

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "ContentCompAlgo "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :sswitch_14
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->i:I

    return-void

    :sswitch_15
    iput-boolean v4, p0, Lan1;->e0:Z

    return-void

    :sswitch_16
    iget-boolean v0, p0, Lan1;->B:Z

    if-nez v0, :cond_1d

    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->m(I)V

    iput p2, p0, Lan1;->H:I

    return-void

    :sswitch_17
    long-to-int p1, p2

    iput p1, p0, Lan1;->d0:I

    return-void

    :sswitch_18
    invoke-virtual {p0, p2, p3}, Lan1;->a(J)J

    move-result-wide p1

    iput-wide p1, p0, Lan1;->S:J

    return-void

    :sswitch_19
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->d:I

    return-void

    :sswitch_1a
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->p:I

    return-void

    :sswitch_1b
    iget-boolean v0, p0, Lan1;->B:Z

    if-nez v0, :cond_1d

    invoke-virtual {p0, p1}, Lan1;->m(I)V

    invoke-virtual {p0, p2, p3}, Lan1;->a(J)J

    move-result-wide p1

    iput-wide p1, p0, Lan1;->G:J

    return-void

    :sswitch_1c
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->o:I

    return-void

    :sswitch_1d
    long-to-int p2, p2

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput p2, p0, Lum1;->Q:I

    return-void

    :sswitch_1e
    invoke-virtual {p0, p2, p3}, Lan1;->a(J)J

    move-result-wide p1

    iput-wide p1, p0, Lan1;->W:J

    return-void

    :sswitch_1f
    cmp-long p2, p2, v2

    if-nez p2, :cond_10

    move v1, v4

    :cond_10
    invoke-virtual {p0, p1}, Lan1;->k(I)V

    iget-object p0, p0, Lan1;->z:Lrm1;

    iput-boolean v1, p0, Lrm1;->d:Z

    return-void

    :sswitch_20
    long-to-int p2, p2

    if-eq p2, v4, :cond_14

    if-eq p2, v9, :cond_13

    const/16 p3, 0x11

    if-eq p2, p3, :cond_12

    if-eq p2, v0, :cond_11

    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput v7, p0, Lum1;->f:I

    return-void

    :cond_11
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    const/4 p1, 0x5

    iput p1, p0, Lum1;->f:I

    return-void

    :cond_12
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput v8, p0, Lum1;->f:I

    return-void

    :cond_13
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput v4, p0, Lum1;->f:I

    return-void

    :cond_14
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput v9, p0, Lum1;->f:I

    return-void

    :cond_15
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput-wide p2, p0, Lum1;->e:J

    return-void

    :cond_16
    invoke-virtual {p0, p1}, Lan1;->k(I)V

    iget-object p0, p0, Lan1;->z:Lrm1;

    iput-wide p2, p0, Lrm1;->a:J

    return-void

    :cond_17
    cmp-long p0, p2, v2

    if-nez p0, :cond_18

    goto :goto_0

    :cond_18
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x23

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "ContentEncodingScope "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :cond_19
    const-wide/16 p0, 0x0

    cmp-long p0, p2, p0

    if-nez p0, :cond_1a

    goto :goto_0

    :cond_1a
    invoke-static {p2, p3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x23

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "ContentEncodingOrder "

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v5, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0

    :cond_1b
    iget-boolean v0, p0, Lan1;->B:Z

    if-nez v0, :cond_1d

    invoke-virtual {p0, p1}, Lan1;->m(I)V

    iget-wide v0, p0, Lan1;->I:J

    cmp-long p1, v0, v5

    if-nez p1, :cond_1d

    iput-wide p2, p0, Lan1;->I:J

    return-void

    :cond_1c
    iget-boolean v0, p0, Lan1;->B:Z

    if-nez v0, :cond_1d

    invoke-virtual {p0, p1}, Lan1;->m(I)V

    iget-wide v0, p0, Lan1;->J:J

    cmp-long p1, v0, v5

    if-nez p1, :cond_1d

    iput-wide p2, p0, Lan1;->J:J

    :cond_1d
    :goto_0
    return-void

    :cond_1e
    invoke-virtual {p0, p1}, Lan1;->k(I)V

    iget-object p0, p0, Lan1;->z:Lrm1;

    iput-wide p2, p0, Lrm1;->c:J

    return-void

    :cond_1f
    invoke-virtual {p0, p1}, Lan1;->k(I)V

    iget-object p0, p0, Lan1;->z:Lrm1;

    iput-wide p2, p0, Lrm1;->b:J

    return-void

    :cond_20
    invoke-virtual {p0, p1}, Lan1;->k(I)V

    iget-object p0, p0, Lan1;->z:Lrm1;

    iput-wide p2, p0, Lrm1;->e:J

    return-void

    :cond_21
    cmp-long p2, p2, v2

    if-nez p2, :cond_22

    move v1, v4

    :cond_22
    invoke-virtual {p0, p1}, Lan1;->l(I)V

    iget-object p0, p0, Lan1;->A:Lum1;

    iput-boolean v1, p0, Lum1;->b0:Z

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x83 -> :sswitch_20
        0x98 -> :sswitch_1f
        0x9b -> :sswitch_1e
        0x9f -> :sswitch_1d
        0xb0 -> :sswitch_1c
        0xb3 -> :sswitch_1b
        0xba -> :sswitch_1a
        0xd7 -> :sswitch_19
        0xe7 -> :sswitch_18
        0xee -> :sswitch_17
        0xf7 -> :sswitch_16
        0xfb -> :sswitch_15
        0x41e7 -> :sswitch_14
        0x4254 -> :sswitch_13
        0x4285 -> :sswitch_12
        0x42f7 -> :sswitch_11
        0x47e1 -> :sswitch_10
        0x47e8 -> :sswitch_f
        0x53ac -> :sswitch_e
        0x53b8 -> :sswitch_d
        0x54b0 -> :sswitch_c
        0x54b2 -> :sswitch_b
        0x54ba -> :sswitch_a
        0x55aa -> :sswitch_9
        0x55b2 -> :sswitch_8
        0x55ee -> :sswitch_7
        0x56aa -> :sswitch_6
        0x56bb -> :sswitch_5
        0x6264 -> :sswitch_4
        0x75a2 -> :sswitch_3
        0x7671 -> :sswitch_2
        0x23e383 -> :sswitch_1
        0x2ad7b1 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x55b9
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final k(I)V
    .locals 1

    iget-object p0, p0, Lan1;->z:Lrm1;

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0x23

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "Element "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " must be in an EditionEntry"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0
.end method

.method public final l(I)V
    .locals 1

    iget-object p0, p0, Lan1;->A:Lum1;

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0x20

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "Element "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " must be in a TrackEntry"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0
.end method

.method public final m(I)V
    .locals 1

    iget-boolean p0, p0, Lan1;->F:Z

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0x1a

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "Element "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, " must be in a Cues"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object p0

    throw p0
.end method

.method public final n(Lum1;JIII)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v1, Lum1;->W:Lmk1;

    const/4 v9, 0x1

    if-eqz v2, :cond_0

    move-object v3, v2

    iget-object v2, v1, Lum1;->d0:Llk1;

    iget-object v8, v1, Lum1;->l:Lhk1;

    move/from16 v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move-object v1, v3

    move-wide/from16 v3, p2

    invoke-virtual/range {v1 .. v8}, Lmk1;->b(Llk1;JIIILhk1;)V

    goto/16 :goto_7

    :cond_0
    iget-object v2, v1, Lum1;->c:Ljava/lang/String;

    const-string v3, "S_TEXT/UTF8"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v5, 0x0

    const-string v6, "S_TEXT/WEBVTT"

    const-string v7, "S_TEXT/SSA"

    const-string v8, "S_TEXT/ASS"

    if-nez v4, :cond_1

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v6, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3

    :cond_1
    iget v4, v0, Lan1;->Y:I

    if-le v4, v9, :cond_2

    const-string v2, "Skipping subtitle sample in laced block."

    invoke-static {v2}, Lhd1;->E(Ljava/lang/String;)V

    goto :goto_0

    :cond_2
    iget-wide v10, v0, Lan1;->W:J

    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    cmp-long v4, v10, v12

    if-nez v4, :cond_4

    const-string v2, "Skipping subtitle sample with no duration."

    invoke-static {v2}, Lhd1;->E(Ljava/lang/String;)V

    :cond_3
    :goto_0
    move/from16 v2, p5

    goto :goto_5

    :cond_4
    iget-object v4, v0, Lan1;->n:Lzb3;

    iget-object v12, v4, Lzb3;->a:[B

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v13

    const-wide/16 v14, 0x3e8

    sparse-switch v13, :sswitch_data_0

    goto/16 :goto_8

    :sswitch_0
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    const-string v2, "%02d:%02d:%02d,%03d"

    invoke-static {v10, v11, v14, v15, v2}, Lan1;->s(JJLjava/lang/String;)[B

    move-result-object v2

    const/16 v3, 0x13

    goto :goto_2

    :sswitch_1
    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    const-string v2, "%02d:%02d:%02d.%03d"

    invoke-static {v10, v11, v14, v15, v2}, Lan1;->s(JJLjava/lang/String;)[B

    move-result-object v2

    const/16 v3, 0x19

    goto :goto_2

    :sswitch_2
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    goto :goto_1

    :sswitch_3
    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9

    :goto_1
    const-string v2, "%01d:%02d:%02d:%02d"

    const-wide/16 v6, 0x2710

    invoke-static {v10, v11, v6, v7, v2}, Lan1;->s(JJLjava/lang/String;)[B

    move-result-object v2

    const/16 v3, 0x15

    :goto_2
    array-length v6, v2

    invoke-static {v2, v5, v12, v3, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v2, v4, Lzb3;->b:I

    :goto_3
    iget v3, v4, Lzb3;->c:I

    if-ge v2, v3, :cond_6

    iget-object v3, v4, Lzb3;->a:[B

    aget-byte v3, v3, v2

    if-nez v3, :cond_5

    invoke-virtual {v4, v2}, Lzb3;->C(I)V

    goto :goto_4

    :cond_5
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_6
    :goto_4
    iget-object v2, v1, Lum1;->d0:Llk1;

    iget v3, v4, Lzb3;->c:I

    invoke-interface {v2, v3, v4}, Llk1;->a(ILzb3;)V

    iget v2, v4, Lzb3;->c:I

    add-int v2, p5, v2

    :goto_5
    const/high16 v3, 0x10000000

    and-int v3, p4, v3

    if-eqz v3, :cond_8

    iget v3, v0, Lan1;->Y:I

    iget-object v4, v0, Lan1;->q:Lzb3;

    if-le v3, v9, :cond_7

    invoke-virtual {v4, v5}, Lzb3;->y(I)V

    goto :goto_6

    :cond_7
    iget v3, v4, Lzb3;->c:I

    iget-object v5, v1, Lum1;->d0:Llk1;

    const/4 v6, 0x2

    invoke-interface {v5, v4, v3, v6}, Llk1;->f(Lzb3;II)V

    add-int/2addr v2, v3

    :cond_8
    :goto_6
    move v14, v2

    iget-object v10, v1, Lum1;->d0:Llk1;

    iget-object v1, v1, Lum1;->l:Lhk1;

    move-wide/from16 v11, p2

    move/from16 v13, p4

    move/from16 v15, p6

    move-object/from16 v16, v1

    invoke-interface/range {v10 .. v16}, Llk1;->d(JIIILhk1;)V

    :goto_7
    iput-boolean v9, v0, Lan1;->T:Z

    return-void

    :cond_9
    :goto_8
    invoke-static {}, Lnu0;->a()V

    return-void

    :sswitch_data_0
    .sparse-switch
        0x2c0618eb -> :sswitch_3
        0x2c065c6b -> :sswitch_2
        0x3e4ca2d8 -> :sswitch_1
        0x54c61e47 -> :sswitch_0
    .end sparse-switch
.end method

.method public final o(Llj1;I)V
    .locals 3

    iget-object p0, p0, Lan1;->j:Lzb3;

    iget v0, p0, Lzb3;->c:I

    if-lt v0, p2, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lzb3;->a:[B

    array-length v1, v0

    if-ge v1, p2, :cond_1

    array-length v0, v0

    add-int/2addr v0, v0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0, v0}, Lzb3;->A(I)V

    :cond_1
    iget-object v0, p0, Lzb3;->a:[B

    iget v1, p0, Lzb3;->c:I

    sub-int v2, p2, v1

    invoke-interface {p1, v1, v2, v0}, Llj1;->B(II[B)V

    invoke-virtual {p0, p2}, Lzb3;->C(I)V

    return-void
.end method

.method public final p(Llj1;Lum1;IZ)I
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    iget-object v4, v2, Lum1;->c:Ljava/lang/String;

    const-string v5, "S_TEXT/UTF8"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    sget-object v2, Lan1;->r0:[B

    invoke-virtual {v0, v1, v2, v3}, Lan1;->r(Llj1;[BI)V

    iget v1, v0, Lan1;->h0:I

    invoke-virtual {v0}, Lan1;->q()V

    return v1

    :cond_0
    const-string v5, "S_TEXT/ASS"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1e

    const-string v5, "S_TEXT/SSA"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    goto/16 :goto_d

    :cond_1
    const-string v5, "S_TEXT/WEBVTT"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    sget-object v2, Lan1;->u0:[B

    invoke-virtual {v0, v1, v2, v3}, Lan1;->r(Llj1;[BI)V

    iget v1, v0, Lan1;->h0:I

    invoke-virtual {v0}, Lan1;->q()V

    return v1

    :cond_2
    iget-boolean v4, v2, Lum1;->X:Z

    const/4 v5, 0x0

    if-eqz v4, :cond_3

    iget-object v4, v2, Lum1;->e0:Lfx4;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v3, v4}, Ls9;->x(Llj1;ILfx4;)Lfx4;

    move-result-object v4

    iput-object v4, v2, Lum1;->e0:Lfx4;

    iget-object v6, v2, Lum1;->d0:Llk1;

    invoke-interface {v6, v4}, Llk1;->c(Lfx4;)V

    iput-boolean v5, v2, Lum1;->X:Z

    invoke-virtual {v0}, Lan1;->h()V

    :cond_3
    iget-object v4, v2, Lum1;->d0:Llk1;

    iget-boolean v6, v0, Lan1;->j0:Z

    iget-object v7, v0, Lan1;->m:Lzb3;

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-nez v6, :cond_13

    iget-boolean v6, v2, Lum1;->j:Z

    iget-object v11, v0, Lan1;->j:Lzb3;

    if-eqz v6, :cond_f

    iget v6, v0, Lan1;->c0:I

    const v12, -0x40000001    # -1.9999999f

    and-int/2addr v6, v12

    iput v6, v0, Lan1;->c0:I

    iget-boolean v6, v0, Lan1;->k0:Z

    const/16 v12, 0x80

    if-nez v6, :cond_5

    iget-object v6, v11, Lzb3;->a:[B

    invoke-interface {v1, v5, v10, v6}, Llj1;->B(II[B)V

    iget v6, v0, Lan1;->g0:I

    add-int/2addr v6, v10

    iput v6, v0, Lan1;->g0:I

    iget-object v6, v11, Lzb3;->a:[B

    aget-byte v6, v6, v5

    and-int/lit16 v13, v6, 0x80

    if-eq v13, v12, :cond_4

    iput-byte v6, v0, Lan1;->n0:B

    iput-boolean v10, v0, Lan1;->k0:Z

    goto :goto_0

    :cond_4
    const-string v0, "Extension bit is set in signal byte"

    const/4 v1, 0x0

    invoke-static {v1, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_5
    :goto_0
    iget-byte v6, v0, Lan1;->n0:B

    and-int/lit8 v13, v6, 0x1

    if-ne v13, v10, :cond_e

    and-int/2addr v6, v8

    iget v13, v0, Lan1;->c0:I

    const/high16 v14, 0x40000000    # 2.0f

    or-int/2addr v13, v14

    iput v13, v0, Lan1;->c0:I

    iget-boolean v13, v0, Lan1;->o0:Z

    if-nez v13, :cond_7

    iget-object v13, v0, Lan1;->o:Lzb3;

    iget-object v14, v13, Lzb3;->a:[B

    const/16 v15, 0x8

    invoke-interface {v1, v5, v15, v14}, Llj1;->B(II[B)V

    iget v14, v0, Lan1;->g0:I

    add-int/2addr v14, v15

    iput v14, v0, Lan1;->g0:I

    iput-boolean v10, v0, Lan1;->o0:Z

    if-ne v6, v8, :cond_6

    goto :goto_1

    :cond_6
    move v12, v5

    :goto_1
    or-int/2addr v12, v15

    iget-object v14, v11, Lzb3;->a:[B

    int-to-byte v12, v12

    aput-byte v12, v14, v5

    invoke-virtual {v11, v5}, Lzb3;->D(I)V

    invoke-interface {v4, v11, v10, v10}, Llk1;->f(Lzb3;II)V

    iget v12, v0, Lan1;->h0:I

    add-int/2addr v12, v10

    iput v12, v0, Lan1;->h0:I

    invoke-virtual {v13, v5}, Lzb3;->D(I)V

    invoke-interface {v4, v13, v15, v10}, Llk1;->f(Lzb3;II)V

    iget v12, v0, Lan1;->h0:I

    add-int/2addr v12, v15

    iput v12, v0, Lan1;->h0:I

    :cond_7
    if-ne v6, v8, :cond_e

    iget-boolean v6, v0, Lan1;->l0:Z

    if-nez v6, :cond_8

    iget-object v6, v11, Lzb3;->a:[B

    invoke-interface {v1, v5, v10, v6}, Llj1;->B(II[B)V

    iget v6, v0, Lan1;->g0:I

    add-int/2addr v6, v10

    iput v6, v0, Lan1;->g0:I

    invoke-virtual {v11, v5}, Lzb3;->D(I)V

    invoke-virtual {v11}, Lzb3;->I()I

    move-result v6

    iput v6, v0, Lan1;->m0:I

    iput-boolean v10, v0, Lan1;->l0:Z

    :cond_8
    iget v6, v0, Lan1;->m0:I

    mul-int/2addr v6, v9

    invoke-virtual {v11, v6}, Lzb3;->y(I)V

    iget-object v12, v11, Lzb3;->a:[B

    invoke-interface {v1, v5, v6, v12}, Llj1;->B(II[B)V

    iget v12, v0, Lan1;->g0:I

    add-int/2addr v12, v6

    iput v12, v0, Lan1;->g0:I

    iget v6, v0, Lan1;->m0:I

    shr-int/2addr v6, v10

    add-int/2addr v6, v10

    mul-int/lit8 v12, v6, 0x6

    add-int/2addr v12, v8

    iget-object v13, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    if-eqz v13, :cond_9

    invoke-virtual {v13}, Ljava/nio/Buffer;->capacity()I

    move-result v13

    if-ge v13, v12, :cond_a

    :cond_9
    invoke-static {v12}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v13

    iput-object v13, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    :cond_a
    int-to-short v6, v6

    iget-object v13, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    invoke-virtual {v13, v5}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget-object v13, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    invoke-virtual {v13, v6}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    move v6, v5

    move v13, v6

    :goto_2
    iget v14, v0, Lan1;->m0:I

    if-ge v6, v14, :cond_c

    invoke-virtual {v11}, Lzb3;->h()I

    move-result v14

    sub-int v13, v14, v13

    rem-int/lit8 v15, v6, 0x2

    move/from16 v16, v8

    iget-object v8, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    if-nez v15, :cond_b

    int-to-short v13, v13

    invoke-virtual {v8, v13}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    goto :goto_3

    :cond_b
    invoke-virtual {v8, v13}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    :goto_3
    add-int/lit8 v6, v6, 0x1

    move v13, v14

    move/from16 v8, v16

    goto :goto_2

    :cond_c
    move/from16 v16, v8

    iget v6, v0, Lan1;->g0:I

    sub-int v6, v3, v6

    sub-int/2addr v6, v13

    and-int/lit8 v8, v14, 0x1

    iget-object v13, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    if-ne v8, v10, :cond_d

    invoke-virtual {v13, v6}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    goto :goto_4

    :cond_d
    int-to-short v6, v6

    invoke-virtual {v13, v6}, Ljava/nio/ByteBuffer;->putShort(S)Ljava/nio/ByteBuffer;

    iget-object v6, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    invoke-virtual {v6, v5}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    :goto_4
    iget-object v6, v0, Lan1;->r:Ljava/nio/ByteBuffer;

    invoke-virtual {v6}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    iget-object v8, v0, Lan1;->p:Lzb3;

    invoke-virtual {v8, v12, v6}, Lzb3;->z(I[B)V

    invoke-interface {v4, v8, v12, v10}, Llk1;->f(Lzb3;II)V

    iget v6, v0, Lan1;->h0:I

    add-int/2addr v6, v12

    iput v6, v0, Lan1;->h0:I

    goto :goto_5

    :cond_e
    move/from16 v16, v8

    goto :goto_5

    :cond_f
    move/from16 v16, v8

    iget-object v6, v2, Lum1;->k:[B

    if-eqz v6, :cond_10

    array-length v8, v6

    invoke-virtual {v7, v8, v6}, Lzb3;->z(I[B)V

    :cond_10
    :goto_5
    iget-object v6, v2, Lum1;->c:Ljava/lang/String;

    const-string v8, "A_OPUS"

    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_11

    if-eqz p4, :cond_12

    goto :goto_6

    :cond_11
    iget v6, v2, Lum1;->h:I

    if-lez v6, :cond_12

    :goto_6
    iget v6, v0, Lan1;->c0:I

    const/high16 v8, 0x10000000

    or-int/2addr v6, v8

    iput v6, v0, Lan1;->c0:I

    iget-object v6, v0, Lan1;->q:Lzb3;

    invoke-virtual {v6, v5}, Lzb3;->y(I)V

    iget v6, v7, Lzb3;->c:I

    add-int/2addr v6, v3

    iget v8, v0, Lan1;->g0:I

    sub-int/2addr v6, v8

    invoke-virtual {v11, v9}, Lzb3;->y(I)V

    shr-int/lit8 v8, v6, 0x18

    iget-object v12, v11, Lzb3;->a:[B

    and-int/lit16 v8, v8, 0xff

    int-to-byte v8, v8

    aput-byte v8, v12, v5

    shr-int/lit8 v8, v6, 0x10

    and-int/lit16 v8, v8, 0xff

    int-to-byte v8, v8

    aput-byte v8, v12, v10

    shr-int/lit8 v8, v6, 0x8

    and-int/lit16 v8, v8, 0xff

    int-to-byte v8, v8

    aput-byte v8, v12, v16

    and-int/lit16 v6, v6, 0xff

    int-to-byte v6, v6

    const/4 v8, 0x3

    aput-byte v6, v12, v8

    move/from16 v6, v16

    invoke-interface {v4, v11, v9, v6}, Llk1;->f(Lzb3;II)V

    iget v6, v0, Lan1;->h0:I

    add-int/2addr v6, v9

    iput v6, v0, Lan1;->h0:I

    :cond_12
    iput-boolean v10, v0, Lan1;->j0:Z

    :cond_13
    iget v6, v7, Lzb3;->c:I

    add-int/2addr v3, v6

    iget-object v6, v2, Lum1;->c:Ljava/lang/String;

    const-string v8, "V_MPEG4/ISO/AVC"

    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_18

    const-string v8, "V_MPEGH/ISO/HEVC"

    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_14

    goto :goto_a

    :cond_14
    iget-object v6, v2, Lum1;->W:Lmk1;

    if-nez v6, :cond_15

    goto :goto_8

    :cond_15
    iget v6, v7, Lzb3;->c:I

    if-nez v6, :cond_16

    goto :goto_7

    :cond_16
    move v10, v5

    :goto_7
    invoke-static {v10}, La60;->D(Z)V

    iget-object v6, v2, Lum1;->W:Lmk1;

    invoke-virtual {v6, v1}, Lmk1;->a(Llj1;)V

    :goto_8
    iget v6, v0, Lan1;->g0:I

    if-ge v6, v3, :cond_1c

    sub-int v6, v3, v6

    invoke-virtual {v7}, Lzb3;->B()I

    move-result v8

    if-lez v8, :cond_17

    invoke-static {v6, v8}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-interface {v4, v6, v7}, Llk1;->a(ILzb3;)V

    goto :goto_9

    :cond_17
    invoke-interface {v4, v1, v6, v5}, Llk1;->b(Ltl4;IZ)I

    move-result v6

    :goto_9
    iget v8, v0, Lan1;->g0:I

    add-int/2addr v8, v6

    iput v8, v0, Lan1;->g0:I

    iget v8, v0, Lan1;->h0:I

    add-int/2addr v8, v6

    iput v8, v0, Lan1;->h0:I

    goto :goto_8

    :cond_18
    :goto_a
    iget-object v6, v0, Lan1;->i:Lzb3;

    iget-object v8, v6, Lzb3;->a:[B

    aput-byte v5, v8, v5

    aput-byte v5, v8, v10

    const/16 v16, 0x2

    aput-byte v5, v8, v16

    iget v10, v2, Lum1;->f0:I

    rsub-int/lit8 v11, v10, 0x4

    :goto_b
    iget v12, v0, Lan1;->g0:I

    if-ge v12, v3, :cond_1c

    iget v12, v0, Lan1;->i0:I

    if-nez v12, :cond_1a

    invoke-virtual {v7}, Lzb3;->B()I

    move-result v12

    invoke-static {v10, v12}, Ljava/lang/Math;->min(II)I

    move-result v12

    add-int v13, v11, v12

    sub-int v14, v10, v12

    invoke-interface {v1, v13, v14, v8}, Llj1;->B(II[B)V

    if-lez v12, :cond_19

    invoke-virtual {v7, v11, v12, v8}, Lzb3;->F(II[B)V

    :cond_19
    iget v12, v0, Lan1;->g0:I

    add-int/2addr v12, v10

    iput v12, v0, Lan1;->g0:I

    invoke-virtual {v6, v5}, Lzb3;->D(I)V

    invoke-virtual {v6}, Lzb3;->h()I

    move-result v12

    iput v12, v0, Lan1;->i0:I

    iget-object v12, v0, Lan1;->h:Lzb3;

    invoke-virtual {v12, v5}, Lzb3;->D(I)V

    invoke-interface {v4, v9, v12}, Llk1;->a(ILzb3;)V

    iget v12, v0, Lan1;->h0:I

    add-int/2addr v12, v9

    iput v12, v0, Lan1;->h0:I

    goto :goto_b

    :cond_1a
    invoke-virtual {v7}, Lzb3;->B()I

    move-result v13

    if-lez v13, :cond_1b

    invoke-static {v12, v13}, Ljava/lang/Math;->min(II)I

    move-result v12

    invoke-interface {v4, v12, v7}, Llk1;->a(ILzb3;)V

    goto :goto_c

    :cond_1b
    invoke-interface {v4, v1, v12, v5}, Llk1;->b(Ltl4;IZ)I

    move-result v12

    :goto_c
    iget v13, v0, Lan1;->g0:I

    add-int/2addr v13, v12

    iput v13, v0, Lan1;->g0:I

    iget v13, v0, Lan1;->h0:I

    add-int/2addr v13, v12

    iput v13, v0, Lan1;->h0:I

    iget v13, v0, Lan1;->i0:I

    sub-int/2addr v13, v12

    iput v13, v0, Lan1;->i0:I

    goto :goto_b

    :cond_1c
    iget-object v1, v2, Lum1;->c:Ljava/lang/String;

    const-string v2, "A_VORBIS"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    iget-object v1, v0, Lan1;->k:Lzb3;

    invoke-virtual {v1, v5}, Lzb3;->D(I)V

    invoke-interface {v4, v9, v1}, Llk1;->a(ILzb3;)V

    iget v1, v0, Lan1;->h0:I

    add-int/2addr v1, v9

    iput v1, v0, Lan1;->h0:I

    :cond_1d
    iget v1, v0, Lan1;->h0:I

    invoke-virtual {v0}, Lan1;->q()V

    return v1

    :cond_1e
    :goto_d
    sget-object v2, Lan1;->t0:[B

    invoke-virtual {v0, v1, v2, v3}, Lan1;->r(Llj1;[BI)V

    iget v1, v0, Lan1;->h0:I

    invoke-virtual {v0}, Lan1;->q()V

    return v1
.end method

.method public final q()V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lan1;->g0:I

    iput v0, p0, Lan1;->h0:I

    iput v0, p0, Lan1;->i0:I

    iput-boolean v0, p0, Lan1;->j0:Z

    iput-boolean v0, p0, Lan1;->k0:Z

    iput-boolean v0, p0, Lan1;->l0:Z

    iput v0, p0, Lan1;->m0:I

    iput-byte v0, p0, Lan1;->n0:B

    iput-boolean v0, p0, Lan1;->o0:Z

    iget-object p0, p0, Lan1;->m:Lzb3;

    invoke-virtual {p0, v0}, Lzb3;->y(I)V

    return-void
.end method

.method public final r(Llj1;[BI)V
    .locals 5

    array-length v0, p2

    add-int v1, v0, p3

    iget-object p0, p0, Lan1;->n:Lzb3;

    iget-object v2, p0, Lzb3;->a:[B

    array-length v3, v2

    const/4 v4, 0x0

    if-ge v3, v1, :cond_0

    add-int v2, v1, p3

    invoke-static {p2, v2}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p2

    array-length v2, p2

    invoke-virtual {p0, v2, p2}, Lzb3;->z(I[B)V

    goto :goto_0

    :cond_0
    invoke-static {p2, v4, v2, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_0
    iget-object p2, p0, Lzb3;->a:[B

    invoke-interface {p1, v0, p3, p2}, Llj1;->B(II[B)V

    invoke-virtual {p0, v4}, Lzb3;->D(I)V

    invoke-virtual {p0, v1}, Lzb3;->C(I)V

    return-void
.end method
