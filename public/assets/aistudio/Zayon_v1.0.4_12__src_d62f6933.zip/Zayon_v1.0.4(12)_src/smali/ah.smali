.class public final synthetic Lah;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnh;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, Lah;->h:I

    iput-object p2, p0, Lah;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final k(Log;)Ljava/lang/Object;
    .locals 0

    iget p1, p0, Lah;->h:I

    iget-object p0, p0, Lah;->i:Ljava/lang/Object;

    return-object p0
.end method
