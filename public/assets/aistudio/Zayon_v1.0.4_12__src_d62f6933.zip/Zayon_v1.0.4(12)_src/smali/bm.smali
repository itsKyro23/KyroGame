.class public final Lbm;
.super Ly;


# instance fields
.field public final synthetic j:I

.field public k:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 49
    iput p1, p0, Lbm;->j:I

    invoke-direct {p0}, Ly;-><init>()V

    return-void
.end method

.method public constructor <init>(Lh;Lh;)V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, Lbm;->j:I

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    .line 43
    new-array v1, v1, [Lh;

    aput-object p1, v1, v0

    const/4 p1, 0x1

    aput-object p2, v1, p1

    iput-object v1, p0, Ly;->h:[Lh;

    const/4 p1, -0x1

    .line 44
    iput p1, p0, Lbm;->k:I

    return-void

    .line 45
    :cond_0
    const-string p0, "\'element2\' cannot be null"

    invoke-static {p0}, Ls40;->l(Ljava/lang/String;)V

    throw v1

    :cond_1
    const-string p0, "\'element1\' cannot be null"

    invoke-static {p0}, Ls40;->l(Ljava/lang/String;)V

    throw v1
.end method

.method public synthetic constructor <init>(Li;I)V
    .locals 0

    .line 46
    iput p2, p0, Lbm;->j:I

    invoke-direct {p0, p1}, Ly;-><init>(Li;)V

    return-void
.end method

.method public synthetic constructor <init>(Lv;I)V
    .locals 0

    .line 47
    iput p2, p0, Lbm;->j:I

    invoke-direct {p0, p1}, Ly;-><init>(Lv;)V

    return-void
.end method

.method public synthetic constructor <init>(Z[Lh;)V
    .locals 0

    .line 48
    const/4 p1, 0x0

    iput p1, p0, Lbm;->j:I

    invoke-direct {p0, p2}, Ly;-><init>([Lh;)V

    return-void
.end method

.method public constructor <init>([Lh;I)V
    .locals 2

    iput p2, p0, Lbm;->j:I

    packed-switch p2, :pswitch_data_0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_1

    array-length p2, p1

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p2, :cond_0

    aget-object v1, p1, v0

    if-eqz v1, :cond_1

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-static {p1}, Li;->e([Lh;)[Lh;

    move-result-object p1

    iput-object p1, p0, Ly;->h:[Lh;

    const/4 p1, -0x1

    iput p1, p0, Lbm;->k:I

    return-void

    :cond_1
    const-string p0, "\'elements\' cannot be null, or contain null"

    invoke-static {p0}, Ls40;->l(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :pswitch_0
    invoke-direct {p0, p1}, Ly;-><init>([Lh;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public A()I
    .locals 5

    iget v0, p0, Lbm;->k:I

    if-gez v0, :cond_1

    iget-object v0, p0, Ly;->h:[Lh;

    array-length v0, v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v3, p0, Ly;->h:[Lh;

    aget-object v3, v3, v1

    invoke-interface {v3}, Lh;->c()Lv;

    move-result-object v3

    invoke-virtual {v3}, Lv;->q()Lv;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Lv;->n(Z)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iput v2, p0, Lbm;->k:I

    return v2

    :cond_1
    return v0
.end method

.method public B()I
    .locals 5

    iget v0, p0, Lbm;->k:I

    if-gez v0, :cond_1

    iget-object v0, p0, Ly;->h:[Lh;

    array-length v0, v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_0

    iget-object v3, p0, Ly;->h:[Lh;

    aget-object v3, v3, v1

    invoke-interface {v3}, Lh;->c()Lv;

    move-result-object v3

    invoke-virtual {v3}, Lv;->r()Lv;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Lv;->n(Z)I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iput v2, p0, Lbm;->k:I

    return v2

    :cond_1
    return v0
.end method

.method public final k(Lbu0;Z)V
    .locals 7

    iget v0, p0, Lbm;->j:I

    const/16 v1, 0x10

    const/16 v2, 0x30

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p1, v2, p2}, Lbu0;->H(IZ)V

    invoke-virtual {p1}, Lbu0;->l()Lmm;

    move-result-object p2

    iget-object v0, p0, Ly;->h:[Lh;

    array-length v0, v0

    iget v2, p0, Lbm;->k:I

    if-gez v2, :cond_2

    if-le v0, v1, :cond_0

    goto :goto_2

    :cond_0
    new-array v1, v0, [Lv;

    move v2, v4

    move v5, v2

    :goto_0
    if-ge v2, v0, :cond_1

    iget-object v6, p0, Ly;->h:[Lh;

    aget-object v6, v6, v2

    invoke-interface {v6}, Lh;->c()Lv;

    move-result-object v6

    invoke-virtual {v6}, Lv;->r()Lv;

    move-result-object v6

    aput-object v6, v1, v2

    invoke-virtual {v6, v3}, Lv;->n(Z)I

    move-result v6

    add-int/2addr v5, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iput v5, p0, Lbm;->k:I

    invoke-virtual {p1, v5}, Lbu0;->z(I)V

    :goto_1
    if-ge v4, v0, :cond_3

    aget-object p0, v1, v4

    invoke-virtual {p2, p0}, Lmm;->I(Lv;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    invoke-virtual {p0}, Lbm;->B()I

    move-result v1

    invoke-virtual {p1, v1}, Lbu0;->z(I)V

    :goto_3
    if-ge v4, v0, :cond_3

    iget-object p1, p0, Ly;->h:[Lh;

    aget-object p1, p1, v4

    invoke-interface {p1}, Lh;->c()Lv;

    move-result-object p1

    invoke-virtual {p2, p1}, Lmm;->I(Lv;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_3
    return-void

    :pswitch_0
    invoke-virtual {p1, v2, p2}, Lbu0;->H(IZ)V

    invoke-virtual {p1}, Lbu0;->k()Lzl;

    move-result-object p2

    iget-object v0, p0, Ly;->h:[Lh;

    array-length v0, v0

    iget v2, p0, Lbm;->k:I

    if-gez v2, :cond_6

    if-le v0, v1, :cond_4

    goto :goto_6

    :cond_4
    new-array v1, v0, [Lv;

    move v2, v4

    move v5, v2

    :goto_4
    if-ge v2, v0, :cond_5

    iget-object v6, p0, Ly;->h:[Lh;

    aget-object v6, v6, v2

    invoke-interface {v6}, Lh;->c()Lv;

    move-result-object v6

    invoke-virtual {v6}, Lv;->q()Lv;

    move-result-object v6

    aput-object v6, v1, v2

    invoke-virtual {v6, v3}, Lv;->n(Z)I

    move-result v6

    add-int/2addr v5, v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_5
    iput v5, p0, Lbm;->k:I

    invoke-virtual {p1, v5}, Lbu0;->z(I)V

    :goto_5
    if-ge v4, v0, :cond_7

    aget-object p0, v1, v4

    invoke-virtual {p0, p2, v3}, Lv;->k(Lbu0;Z)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_5

    :cond_6
    :goto_6
    invoke-virtual {p0}, Lbm;->A()I

    move-result v1

    invoke-virtual {p1, v1}, Lbu0;->z(I)V

    :goto_7
    if-ge v4, v0, :cond_7

    iget-object p1, p0, Ly;->h:[Lh;

    aget-object p1, p1, v4

    invoke-interface {p1}, Lh;->c()Lv;

    move-result-object p1

    invoke-virtual {p1}, Lv;->q()Lv;

    move-result-object p1

    invoke-virtual {p1, p2, v3}, Lv;->k(Lbu0;Z)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_7

    :cond_7
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final n(Z)I
    .locals 1

    iget v0, p0, Lbm;->j:I

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p0}, Lbm;->B()I

    move-result p0

    invoke-static {p0, p1}, Lbu0;->r(IZ)I

    move-result p0

    return p0

    :pswitch_0
    invoke-virtual {p0}, Lbm;->A()I

    move-result p0

    invoke-static {p0, p1}, Lbu0;->r(IZ)I

    move-result p0

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public q()Lv;
    .locals 1

    iget v0, p0, Lbm;->j:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ly;->q()Lv;

    move-result-object p0

    :pswitch_0
    return-object p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final r()Lv;
    .locals 1

    iget v0, p0, Lbm;->j:I

    return-object p0
.end method

.method public final x()Ld;
    .locals 3

    iget v0, p0, Lbm;->j:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lql;

    invoke-virtual {p0}, Ly;->s()[Ld;

    move-result-object p0

    invoke-static {p0}, Lmb;->u([Ld;)[B

    move-result-object p0

    const/4 v2, 0x1

    invoke-direct {v0, p0, v2, v1}, Lql;-><init>([BIB)V

    return-object v0

    :pswitch_0
    new-instance v0, Lql;

    invoke-virtual {p0}, Ly;->s()[Ld;

    move-result-object p0

    invoke-static {p0}, Lmb;->u([Ld;)[B

    move-result-object p0

    invoke-direct {v0, p0, v1, v1}, Lql;-><init>([BIB)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final y()Ls;
    .locals 1

    iget v0, p0, Lbm;->j:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lyl;

    invoke-virtual {p0}, Ly;->t()[Ls;

    move-result-object p0

    invoke-static {p0}, Lpb;->t([Ls;)[B

    move-result-object p0

    invoke-direct {v0, p0}, Ls;-><init>([B)V

    return-object v0

    :pswitch_0
    new-instance v0, Lyl;

    invoke-virtual {p0}, Ly;->t()[Ls;

    move-result-object p0

    invoke-static {p0}, Lpb;->t([Ls;)[B

    move-result-object p0

    invoke-direct {v0, p0}, Ls;-><init>([B)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final z()Lz;
    .locals 2

    iget v0, p0, Lbm;->j:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lcm;

    iget-object p0, p0, Ly;->h:[Lh;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcm;-><init>([Lh;I)V

    return-object v0

    :pswitch_0
    new-instance v0, Lcm;

    iget-object p0, p0, Ly;->h:[Lh;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lcm;-><init>([Lh;I)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
