.class public final Lbt3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lys3;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lnk4;

.field public final c:Lit3;

.field public final d:Lju3;

.field public final e:Ljava/util/concurrent/ExecutorService;

.field public final f:Los3;

.field public final g:Lcm3;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lnk4;Lit3;Lju3;Ljava/util/concurrent/ExecutorService;Los3;Lcm3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbt3;->a:Landroid/content/Context;

    iput-object p2, p0, Lbt3;->b:Lnk4;

    iput-object p3, p0, Lbt3;->c:Lit3;

    iput-object p4, p0, Lbt3;->d:Lju3;

    iput-object p5, p0, Lbt3;->e:Ljava/util/concurrent/ExecutorService;

    iput-object p6, p0, Lbt3;->f:Los3;

    iput-object p7, p0, Lbt3;->g:Lcm3;

    return-void
.end method

.method public static b(I)Lgq3;
    .locals 1

    invoke-static {}, Lgq3;->B()Lfq3;

    move-result-object v0

    invoke-virtual {v0, p0}, Lfq3;->g(I)V

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object p0

    check-cast p0, Lgq3;

    return-object p0
.end method


# virtual methods
.method public final a()Lna0;
    .locals 5

    iget-object v0, p0, Lbt3;->b:Lnk4;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lae3;

    const/16 v2, 0x8

    invoke-direct {v1, v2, v0}, Lae3;-><init>(ILjava/lang/Object;)V

    iget-object v0, p0, Lbt3;->e:Ljava/util/concurrent/ExecutorService;

    invoke-static {v1, v0}, Ln50;->w(Ljava/util/concurrent/Callable;Ljava/util/concurrent/Executor;)Lu14;

    move-result-object v1

    invoke-static {v1}, Lb14;->s(Lna0;)Lb14;

    move-result-object v1

    new-instance v2, Lat3;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v3}, Lat3;-><init>(Lbt3;I)V

    sget-object v3, Lz04;->h:Lz04;

    invoke-static {v1, v2, v3}, Ln50;->L(Lna0;Lnv3;Ljava/util/concurrent/Executor;)Ln04;

    move-result-object v1

    new-instance v2, Lia2;

    const/16 v4, 0x10

    invoke-direct {v2, v4, p0}, Lia2;-><init>(ILjava/lang/Object;)V

    invoke-static {v1, v2, v3}, Ln50;->J(Lna0;Lu04;Ljava/util/concurrent/Executor;)Lm04;

    move-result-object v1

    new-instance v2, Lat3;

    const/4 v4, 0x0

    invoke-direct {v2, p0, v4}, Lat3;-><init>(Lbt3;I)V

    invoke-static {v1, v2, v0}, Ln50;->L(Lna0;Lnv3;Ljava/util/concurrent/Executor;)Ln04;

    move-result-object v0

    const-class v1, Lzs3;

    sget-object v2, Lfs3;->i:Lfs3;

    invoke-static {v0, v1, v2, v3}, Ln50;->C(Lna0;Ljava/lang/Class;Lnv3;Ljava/util/concurrent/Executor;)Lyz3;

    move-result-object v0

    iget-object p0, p0, Lbt3;->d:Lju3;

    const/16 v1, 0x3b62

    invoke-virtual {p0, v1, v0}, Lju3;->e(ILb14;)V

    return-object v0
.end method
