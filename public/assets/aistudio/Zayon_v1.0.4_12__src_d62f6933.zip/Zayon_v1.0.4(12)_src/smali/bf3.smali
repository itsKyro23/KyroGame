.class public final Lbf3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lih3;

.field public final b:Ljg2;

.field public final c:Lhh3;


# direct methods
.method public constructor <init>(Lih3;Ljg2;Lhh3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbf3;->a:Lih3;

    iput-object p2, p0, Lbf3;->b:Ljg2;

    iput-object p3, p0, Lbf3;->c:Lhh3;

    return-void
.end method
