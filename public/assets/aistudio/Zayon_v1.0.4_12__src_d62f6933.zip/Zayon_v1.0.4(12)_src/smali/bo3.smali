.class public final Lbo3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltw0;


# static fields
.field public static final h:Lbo3;

.field public static final i:Lao3;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lbo3;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lbo3;->h:Lbo3;

    invoke-static {}, Lao3;->B()Lao3;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sput-object v0, Lbo3;->i:Lao3;

    return-void
.end method


# virtual methods
.method public final synthetic a()Ljava/lang/Object;
    .locals 0

    sget-object p0, Lbo3;->i:Lao3;

    return-object p0
.end method

.method public final synthetic b(Ljava/lang/Object;Lsx0;)V
    .locals 0

    check-cast p1, Lao3;

    invoke-virtual {p1, p2}, Lqf4;->c(Ljava/io/OutputStream;)V

    return-void
.end method

.method public final e(Ljava/io/FileInputStream;)Ljava/lang/Object;
    .locals 0

    :try_start_0
    invoke-static {p1}, Lao3;->A(Ljava/io/FileInputStream;)Lao3;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    sget-object p0, Lbo3;->i:Lao3;

    return-object p0
.end method
