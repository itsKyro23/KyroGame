.class public final Lbb1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Lsm;

.field public f:Lsm;

.field public g:J

.field public h:J

.field public i:J

.field public j:Lui;

.field public k:I

.field public l:I

.field public m:J

.field public n:J

.field public o:J

.field public p:J

.field public q:Z

.field public r:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "WorkSpec"

    invoke-static {v0}, Llb0;->f(Ljava/lang/String;)Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lbb1;->b:I

    sget-object v1, Lsm;->b:Lsm;

    iput-object v1, p0, Lbb1;->e:Lsm;

    iput-object v1, p0, Lbb1;->f:Lsm;

    sget-object v1, Lui;->i:Lui;

    iput-object v1, p0, Lbb1;->j:Lui;

    iput v0, p0, Lbb1;->l:I

    const-wide/16 v1, 0x7530

    iput-wide v1, p0, Lbb1;->m:J

    const-wide/16 v1, -0x1

    iput-wide v1, p0, Lbb1;->p:J

    iput v0, p0, Lbb1;->r:I

    iput-object p1, p0, Lbb1;->a:Ljava/lang/String;

    iput-object p2, p0, Lbb1;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()J
    .locals 9

    iget v0, p0, Lbb1;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    iget v0, p0, Lbb1;->k:I

    if-lez v0, :cond_1

    iget v2, p0, Lbb1;->l:I

    iget-wide v3, p0, Lbb1;->m:J

    const/4 v5, 0x2

    if-ne v2, v5, :cond_0

    int-to-long v0, v0

    mul-long/2addr v3, v0

    goto :goto_0

    :cond_0
    long-to-float v2, v3

    sub-int/2addr v0, v1

    invoke-static {v2, v0}, Ljava/lang/Math;->scalb(FI)F

    move-result v0

    float-to-long v3, v0

    :goto_0
    iget-wide v0, p0, Lbb1;->n:J

    const-wide/32 v5, 0x112a880

    invoke-static {v5, v6, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    add-long/2addr v2, v0

    return-wide v2

    :cond_1
    invoke-virtual {p0}, Lbb1;->c()Z

    move-result v0

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-wide v5, p0, Lbb1;->n:J

    cmp-long v0, v5, v1

    if-nez v0, :cond_2

    iget-wide v5, p0, Lbb1;->g:J

    add-long/2addr v5, v3

    :cond_2
    iget-wide v3, p0, Lbb1;->i:J

    iget-wide v7, p0, Lbb1;->h:J

    cmp-long p0, v3, v7

    if-eqz p0, :cond_4

    if-nez v0, :cond_3

    const-wide/16 v0, -0x1

    mul-long v1, v3, v0

    :cond_3
    add-long/2addr v5, v7

    add-long/2addr v5, v1

    return-wide v5

    :cond_4
    if-nez v0, :cond_5

    goto :goto_1

    :cond_5
    move-wide v1, v7

    :goto_1
    add-long/2addr v5, v1

    return-wide v5

    :cond_6
    iget-wide v3, p0, Lbb1;->n:J

    cmp-long v0, v3, v1

    if-nez v0, :cond_7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    :cond_7
    iget-wide v0, p0, Lbb1;->g:J

    add-long/2addr v3, v0

    return-wide v3
.end method

.method public final b()Z
    .locals 1

    sget-object v0, Lui;->i:Lui;

    iget-object p0, p0, Lbb1;->j:Lui;

    invoke-virtual {v0, p0}, Lui;->equals(Ljava/lang/Object;)Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public final c()Z
    .locals 4

    iget-wide v0, p0, Lbb1;->h:J

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 4

    if-ne p0, p1, :cond_0

    goto/16 :goto_0

    :cond_0
    if-eqz p1, :cond_14

    const-class v0, Lbb1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_1

    goto/16 :goto_1

    :cond_1
    check-cast p1, Lbb1;

    iget-wide v0, p0, Lbb1;->g:J

    iget-wide v2, p1, Lbb1;->g:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_2

    goto/16 :goto_1

    :cond_2
    iget-wide v0, p0, Lbb1;->h:J

    iget-wide v2, p1, Lbb1;->h:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_3

    goto/16 :goto_1

    :cond_3
    iget-wide v0, p0, Lbb1;->i:J

    iget-wide v2, p1, Lbb1;->i:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_4

    goto/16 :goto_1

    :cond_4
    iget v0, p0, Lbb1;->k:I

    iget v1, p1, Lbb1;->k:I

    if-eq v0, v1, :cond_5

    goto/16 :goto_1

    :cond_5
    iget-wide v0, p0, Lbb1;->m:J

    iget-wide v2, p1, Lbb1;->m:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_6

    goto/16 :goto_1

    :cond_6
    iget-wide v0, p0, Lbb1;->n:J

    iget-wide v2, p1, Lbb1;->n:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_7

    goto/16 :goto_1

    :cond_7
    iget-wide v0, p0, Lbb1;->o:J

    iget-wide v2, p1, Lbb1;->o:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_8

    goto/16 :goto_1

    :cond_8
    iget-wide v0, p0, Lbb1;->p:J

    iget-wide v2, p1, Lbb1;->p:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_9

    goto/16 :goto_1

    :cond_9
    iget-boolean v0, p0, Lbb1;->q:Z

    iget-boolean v1, p1, Lbb1;->q:Z

    if-eq v0, v1, :cond_a

    goto :goto_1

    :cond_a
    iget-object v0, p0, Lbb1;->a:Ljava/lang/String;

    iget-object v1, p1, Lbb1;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_1

    :cond_b
    iget v0, p0, Lbb1;->b:I

    iget v1, p1, Lbb1;->b:I

    if-eq v0, v1, :cond_c

    goto :goto_1

    :cond_c
    iget-object v0, p0, Lbb1;->c:Ljava/lang/String;

    iget-object v1, p1, Lbb1;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d

    goto :goto_1

    :cond_d
    iget-object v0, p0, Lbb1;->d:Ljava/lang/String;

    iget-object v1, p1, Lbb1;->d:Ljava/lang/String;

    if-eqz v0, :cond_e

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    goto :goto_1

    :cond_e
    if-eqz v1, :cond_f

    goto :goto_1

    :cond_f
    iget-object v0, p0, Lbb1;->e:Lsm;

    iget-object v1, p1, Lbb1;->e:Lsm;

    invoke-virtual {v0, v1}, Lsm;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_10

    goto :goto_1

    :cond_10
    iget-object v0, p0, Lbb1;->f:Lsm;

    iget-object v1, p1, Lbb1;->f:Lsm;

    invoke-virtual {v0, v1}, Lsm;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_11

    goto :goto_1

    :cond_11
    iget-object v0, p0, Lbb1;->j:Lui;

    iget-object v1, p1, Lbb1;->j:Lui;

    invoke-virtual {v0, v1}, Lui;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    goto :goto_1

    :cond_12
    iget v0, p0, Lbb1;->l:I

    iget v1, p1, Lbb1;->l:I

    if-eq v0, v1, :cond_13

    goto :goto_1

    :cond_13
    iget p0, p0, Lbb1;->r:I

    iget p1, p1, Lbb1;->r:I

    if-ne p0, p1, :cond_14

    :goto_0
    const/4 p0, 0x1

    return p0

    :cond_14
    :goto_1
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .locals 6

    iget-object v0, p0, Lbb1;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lbb1;->b:I

    invoke-static {v1}, Loj;->x(I)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Lbb1;->c:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lbb1;->d:Ljava/lang/String;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lbb1;->e:Lsm;

    invoke-virtual {v1}, Lsm;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Lbb1;->f:Lsm;

    invoke-virtual {v0}, Lsm;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->g:J

    const/16 v3, 0x20

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->h:J

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->i:J

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lbb1;->j:Lui;

    invoke-virtual {v1}, Lui;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget v0, p0, Lbb1;->k:I

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget v0, p0, Lbb1;->l:I

    invoke-static {v0}, Loj;->x(I)I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->m:J

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->n:J

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->o:J

    ushr-long v4, v1, v3

    xor-long/2addr v1, v4

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-wide v1, p0, Lbb1;->p:J

    ushr-long v3, v1, v3

    xor-long/2addr v1, v3

    long-to-int v1, v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lbb1;->q:Z

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Lbb1;->r:I

    invoke-static {p0}, Loj;->x(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "{WorkSpec: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lbb1;->a:Ljava/lang/String;

    const-string v1, "}"

    invoke-static {v0, p0, v1}, Loj;->o(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
