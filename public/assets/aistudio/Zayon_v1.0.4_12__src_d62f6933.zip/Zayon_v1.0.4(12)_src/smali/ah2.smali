.class public abstract Lah2;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lbh2;


# static fields
.field public static final synthetic h:I


# direct methods
.method public constructor <init>()V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.rewarded.client.IRewardedAd"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string v2, "com.google.android.gms.ads.internal.rewarded.client.IRewardedAdLoadCallback"

    const/4 v3, 0x0

    const/4 v4, 0x0

    packed-switch p3, :pswitch_data_0

    return v3

    :pswitch_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, v2, v3}, Lbh2;->x0(J)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_1
    invoke-interface {p0}, Lbh2;->p()J

    move-result-wide p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0, p1}, Landroid/os/Parcel;->writeLong(J)V

    return v1

    :pswitch_2
    invoke-interface {p0}, Lbh2;->n()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1

    :pswitch_3
    invoke-static {p1}, Lg12;->a(Landroid/os/Parcel;)Z

    move-result p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lbh2;->Q2(Z)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_4
    sget-object p3, Ltp4;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Ltp4;

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {v0, v2}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v2

    instance-of v3, v2, Lih2;

    if-eqz v3, :cond_1

    move-object v4, v2

    check-cast v4, Lih2;

    goto :goto_0

    :cond_1
    new-instance v4, Lgh2;

    invoke-direct {v4, v0}, Lgh2;-><init>(Landroid/os/IBinder;)V

    :goto_0
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3, v4}, Lbh2;->O1(Ltp4;Lih2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_5
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Ldh3;->P3(Landroid/os/IBinder;)Lsx2;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lbh2;->v2(Lsx2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_6
    invoke-interface {p0}, Lbh2;->j()Lc13;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    return v1

    :pswitch_7
    invoke-interface {p0}, Lbh2;->i()Lyg2;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    return v1

    :pswitch_8
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    sget-object v0, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    if-eqz v0, :cond_2

    move v3, v1

    :cond_2
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3, v3}, Lbh2;->p2(Ll50;Z)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_9
    invoke-interface {p0}, Lbh2;->c()Landroid/os/Bundle;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->d(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    return v1

    :pswitch_a
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_3

    goto :goto_1

    :cond_3
    const-string v2, "com.google.android.gms.ads.internal.client.IOnAdMetadataChangedListener"

    invoke-interface {p3, v2}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v3

    instance-of v4, v3, Lbw2;

    if-eqz v4, :cond_4

    move-object v4, v3

    check-cast v4, Lbw2;

    goto :goto_1

    :cond_4
    new-instance v4, Lbw2;

    invoke-direct {v4, p3, v2, v0}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    :goto_1
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, v4}, Lbh2;->H3(Lbw2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_b
    sget-object p3, Lmh2;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Lmh2;

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lbh2;->M2(Lmh2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_c
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_5

    goto :goto_2

    :cond_5
    const-string v2, "com.google.android.gms.ads.internal.rewarded.client.IRewardedAdSkuListener"

    invoke-interface {p3, v2}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v3

    instance-of v4, v3, Ljh2;

    if-eqz v4, :cond_6

    move-object v4, v3

    check-cast v4, Ljh2;

    goto :goto_2

    :cond_6
    new-instance v4, Ljh2;

    invoke-direct {v4, p3, v2, v0}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    :goto_2
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, v4}, Lbh2;->L2(Ljh2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_d
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lbh2;->Q1(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_e
    invoke-interface {p0}, Lbh2;->l()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1

    :pswitch_f
    invoke-interface {p0}, Lbh2;->g()Z

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    sget-object p1, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeInt(I)V

    return v1

    :pswitch_10
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_7

    goto :goto_3

    :cond_7
    const-string v2, "com.google.android.gms.ads.internal.rewarded.client.IRewardedAdCallback"

    invoke-interface {p3, v2}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v3

    instance-of v4, v3, Leh2;

    if-eqz v4, :cond_8

    move-object v4, v3

    check-cast v4, Leh2;

    goto :goto_3

    :cond_8
    new-instance v4, Lch2;

    invoke-direct {v4, p3, v2, v0}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    :goto_3
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, v4}, Lbh2;->a1(Leh2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_11
    sget-object p3, Ltp4;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Ltp4;

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    if-nez v0, :cond_9

    goto :goto_4

    :cond_9
    invoke-interface {v0, v2}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v2

    instance-of v3, v2, Lih2;

    if-eqz v3, :cond_a

    move-object v4, v2

    check-cast v4, Lih2;

    goto :goto_4

    :cond_a
    new-instance v4, Lgh2;

    invoke-direct {v4, v0}, Lgh2;-><init>(Landroid/os/IBinder;)V

    :goto_4
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3, v4}, Lbh2;->E2(Ltp4;Lih2;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
