.class public final La22;
.super Ljava/lang/Thread;
.source "SourceFile"


# instance fields
.field public h:Z

.field public i:Z

.field public final j:Ljava/lang/Object;

.field public final k:Lht1;

.field public final l:I

.field public final m:I

.field public final n:I

.field public final o:I

.field public final p:I

.field public final q:I

.field public final r:I

.field public final s:I

.field public final t:Ljava/lang/String;

.field public final u:Z

.field public final v:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    new-instance v0, Lht1;

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lht1;-><init>(IZ)V

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    iput-boolean v2, p0, La22;->h:Z

    iput-boolean v2, p0, La22;->i:Z

    iput-object v0, p0, La22;->k:Lht1;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La22;->j:Ljava/lang/Object;

    sget-object v0, Lj62;->d:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    iput v0, p0, La22;->m:I

    sget-object v0, Lj62;->a:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    iput v0, p0, La22;->n:I

    sget-object v0, Lj62;->e:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    iput v0, p0, La22;->o:I

    sget-object v0, Lj62;->c:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    iput v0, p0, La22;->p:I

    sget-object v0, Lk52;->E0:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, La22;->q:I

    sget-object v0, Lk52;->F0:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, La22;->r:I

    sget-object v0, Lk52;->G0:Lg52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, La22;->s:I

    sget-object v0, Lj62;->f:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    iput v0, p0, La22;->l:I

    sget-object v0, Lk52;->I0:Lg52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iput-object v0, p0, La22;->t:Ljava/lang/String;

    sget-object v0, Lk52;->J0:Lg52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, p0, La22;->u:Z

    sget-object v0, Lk52;->K0:Lg52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iput-boolean v0, p0, La22;->v:Z

    sget-object v0, Lk52;->L0:Lg52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "ContentFetchTask"

    invoke-virtual {p0, v0}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Lw12;)Lch0;
    .locals 10

    const/4 v0, 0x0

    if-nez p1, :cond_0

    new-instance p1, Lch0;

    invoke-direct {p1, p0, v0, v0}, Lch0;-><init>(La22;II)V

    return-object p1

    :cond_0
    new-instance v1, Landroid/graphics/Rect;

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p1, v1}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v4

    instance-of v1, p1, Landroid/widget/TextView;

    const/4 v9, 0x1

    if-eqz v1, :cond_2

    instance-of v1, p1, Landroid/widget/EditText;

    if-nez v1, :cond_2

    move-object v1, p1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Landroid/view/View;->getX()F

    move-result v5

    invoke-virtual {p1}, Landroid/view/View;->getY()F

    move-result v6

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v7, v1

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    int-to-float v8, p1

    move-object v2, p2

    invoke-virtual/range {v2 .. v8}, Lw12;->c(Ljava/lang/String;ZFFFF)V

    new-instance p1, Lch0;

    invoke-direct {p1, p0, v9, v0}, Lch0;-><init>(La22;II)V

    return-object p1

    :cond_1
    new-instance p1, Lch0;

    invoke-direct {p1, p0, v0, v0}, Lch0;-><init>(La22;II)V

    return-object p1

    :cond_2
    move-object v2, p2

    instance-of p2, p1, Landroid/webkit/WebView;

    if-eqz p2, :cond_3

    instance-of p2, p1, Lsl2;

    if-nez p2, :cond_3

    check-cast p1, Landroid/webkit/WebView;

    iget-object p2, v2, Lw12;->g:Ljava/lang/Object;

    monitor-enter p2

    :try_start_0
    iget v1, v2, Lw12;->m:I

    add-int/2addr v1, v9

    iput v1, v2, Lw12;->m:I

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    new-instance p2, Lsi;

    invoke-direct {p2, p0, v2, p1, v4}, Lsi;-><init>(La22;Lw12;Landroid/webkit/WebView;Z)V

    invoke-virtual {p1, p2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    new-instance p1, Lch0;

    invoke-direct {p1, p0, v0, v9}, Lch0;-><init>(La22;II)V

    return-object p1

    :catchall_0
    move-exception v0

    move-object p0, v0

    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_3
    instance-of p2, p1, Landroid/view/ViewGroup;

    if-eqz p2, :cond_5

    check-cast p1, Landroid/view/ViewGroup;

    move p2, v0

    move v1, p2

    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v0, v3, :cond_4

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {p0, v3, v2}, La22;->a(Landroid/view/View;Lw12;)Lch0;

    move-result-object v3

    iget v4, v3, Lch0;->a:I

    add-int/2addr p2, v4

    iget v3, v3, Lch0;->b:I

    add-int/2addr v1, v3

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_4
    new-instance p1, Lch0;

    invoke-direct {p1, p0, p2, v1}, Lch0;-><init>(La22;II)V

    return-object p1

    :cond_5
    new-instance p1, Lch0;

    invoke-direct {p1, p0, v0, v0}, Lch0;-><init>(La22;II)V

    return-object p1
.end method

.method public final b()V
    .locals 3

    const-string v0, "ContentFetchThread: paused, pause = true"

    iget-object v1, p0, La22;->j:Ljava/lang/Object;

    monitor-enter v1

    const/4 v2, 0x1

    :try_start_0
    iput-boolean v2, p0, La22;->i:Z

    new-instance p0, Ljava/lang/StringBuilder;

    const/16 v2, 0x28

    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    sget v0, Lj23;->b:I

    invoke-static {p0}, Lj23;->c(Ljava/lang/String;)V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public final run()V
    .locals 7

    :goto_0
    :try_start_0
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->g:Lyy;

    iget-object v1, v0, Lyy;->i:Ljava/lang/Object;

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v0, v0, Lyy;->j:Ljava/lang/Object;

    check-cast v0, Lx12;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    iget-object v0, v0, Lx12;->i:Landroid/app/Application;

    monitor-exit v1

    goto :goto_1

    :catchall_0
    move-exception v0

    goto/16 :goto_3

    :cond_0
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v0, v2

    :goto_1
    if-nez v0, :cond_1

    goto/16 :goto_5

    :cond_1
    :try_start_2
    const-string v1, "activity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/ActivityManager;

    const-string v3, "keyguard"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/KeyguardManager;

    if-eqz v1, :cond_5

    if-eqz v3, :cond_5

    invoke-virtual {v1}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_5

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/ActivityManager$RunningAppProcessInfo;

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v5

    iget v6, v4, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    if-ne v5, v6, :cond_2

    iget v1, v4, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/16 v4, 0x64

    if-ne v1, v4, :cond_5

    invoke-virtual {v3}, Landroid/app/KeyguardManager;->inKeyguardRestrictedInputMode()Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "power"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/PowerManager;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Landroid/os/PowerManager;->isScreenOn()Z

    move-result v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz v0, :cond_5

    :try_start_3
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->g:Lyy;

    invoke-virtual {v0}, Lyy;->o()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_3

    const-string v0, "ContentFetchThread: no activity. Sleeping."

    sget v1, Lj23;->b:I

    invoke-static {v0}, Lj23;->c(Ljava/lang/String;)V

    invoke-virtual {p0}, La22;->b()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_6

    :catch_0
    move-exception v0

    goto :goto_7

    :cond_3
    :try_start_4
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_4

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_4

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const v1, 0x1020002

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1

    goto :goto_2

    :catch_1
    move-exception v0

    :try_start_5
    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v1, v1, Lcw4;->h:Lui2;

    const-string v3, "ContentFetchTask.extractContent"

    invoke-virtual {v1, v3, v0}, Lui2;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    const-string v0, "Failed getting root view of activity. Content not extracted."

    sget v1, Lj23;->b:I

    invoke-static {v0}, Lj23;->c(Ljava/lang/String;)V

    :cond_4
    :goto_2
    if-eqz v2, :cond_6

    new-instance v0, Lvt2;

    const/16 v1, 0x14

    const/4 v3, 0x0

    invoke-direct {v0, v1, p0, v2, v3}, Lvt2;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    invoke-virtual {v2, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    goto :goto_6

    :catchall_1
    move-exception v0

    goto :goto_4

    :goto_3
    :try_start_6
    monitor-exit v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :try_start_7
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_4
    :try_start_8
    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v1, v1, Lcw4;->h:Lui2;

    const-string v2, "ContentFetchTask.isInForeground"

    invoke-virtual {v1, v2, v0}, Lui2;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_5
    :goto_5
    const-string v0, "ContentFetchTask: sleeping"

    sget v1, Lj23;->b:I

    invoke-static {v0}, Lj23;->c(Ljava/lang/String;)V

    invoke-virtual {p0}, La22;->b()V

    :cond_6
    :goto_6
    iget v0, p0, La22;->l:I

    mul-int/lit16 v0, v0, 0x3e8

    int-to-long v0, v0

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_8
    .catch Ljava/lang/InterruptedException; {:try_start_8 .. :try_end_8} :catch_2
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    goto :goto_8

    :goto_7
    sget v1, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    const-string v1, "ContentFetchTask.run"

    sget-object v2, Lcw4;->B:Lcw4;

    iget-object v2, v2, Lcw4;->h:Lui2;

    invoke-virtual {v2, v1, v0}, Lui2;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_8

    :catch_2
    sget v0, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :goto_8
    iget-object v0, p0, La22;->j:Ljava/lang/Object;

    monitor-enter v0

    :catch_3
    :goto_9
    :try_start_9
    iget-boolean v1, p0, La22;->i:Z
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    if-eqz v1, :cond_7

    :try_start_a
    const-string v1, "ContentFetchTask: waiting"

    sget v2, Lj23;->b:I

    invoke-static {v1}, Lj23;->c(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Object;->wait()V
    :try_end_a
    .catch Ljava/lang/InterruptedException; {:try_start_a .. :try_end_a} :catch_3
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    goto :goto_9

    :catchall_2
    move-exception p0

    goto :goto_a

    :cond_7
    :try_start_b
    monitor-exit v0

    goto/16 :goto_0

    :goto_a
    monitor-exit v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    throw p0
.end method
