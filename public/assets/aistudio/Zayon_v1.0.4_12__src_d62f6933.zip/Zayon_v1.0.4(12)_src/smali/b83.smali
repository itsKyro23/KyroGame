.class public final Lb83;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final synthetic a:I

.field public final b:Lsk4;

.field public final c:Lxk4;

.field public final d:Luk4;


# direct methods
.method public synthetic constructor <init>(Lsk4;Luk4;Lxk4;I)V
    .locals 0

    iput p4, p0, Lb83;->a:I

    iput-object p1, p0, Lb83;->b:Lsk4;

    iput-object p2, p0, Lb83;->d:Luk4;

    iput-object p3, p0, Lb83;->c:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lsk4;Lxk4;Luk4;I)V
    .locals 0

    .line 12
    iput p4, p0, Lb83;->a:I

    iput-object p1, p0, Lb83;->b:Lsk4;

    iput-object p2, p0, Lb83;->c:Lxk4;

    iput-object p3, p0, Lb83;->d:Luk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final d()Ljava/lang/Object;
    .locals 4

    iget v0, p0, Lb83;->a:I

    const/4 v1, 0x1

    iget-object v2, p0, Lb83;->d:Luk4;

    iget-object v3, p0, Lb83;->c:Lxk4;

    iget-object p0, p0, Lb83;->b:Lsk4;

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Executor;

    iget-object v2, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v2, Lio2;

    new-instance v3, Lf93;

    invoke-direct {v3, p0, v0, v2, v1}, Lf93;-><init>(Landroid/content/Context;Ljava/util/concurrent/Executor;Lio2;I)V

    return-object v3

    :pswitch_0
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/Executor;

    iget-object v1, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v1, Lio2;

    new-instance v2, Lf93;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v0, v1, v3}, Lf93;-><init>(Landroid/content/Context;Ljava/util/concurrent/Executor;Lio2;I)V

    return-object v2

    :pswitch_1
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    iget-object v0, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v0, Lrn2;

    check-cast v3, Lmn2;

    invoke-virtual {v3}, Lmn2;->a()Lw61;

    move-result-object v1

    new-instance v2, Ld83;

    invoke-direct {v2, p0, v0, v1}, Ld83;-><init>(Landroid/content/Context;Lrn2;Lw61;)V

    return-object v2

    :pswitch_2
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    iget-object v0, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v0, Lrn2;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/concurrent/Executor;

    new-instance v2, Lw73;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v0, v1, v3}, Lw73;-><init>(Landroid/content/Context;Ljava/lang/Object;Ljava/util/concurrent/Executor;I)V

    return-object v2

    :pswitch_3
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    check-cast v3, Lmn2;

    invoke-virtual {v3}, Lmn2;->a()Lw61;

    move-result-object v0

    iget-object v1, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v1, Lbo2;

    sget-object v2, Laj2;->a:Lzi2;

    invoke-static {v2}, Lms2;->q(Ljava/lang/Object;)V

    new-instance v3, Ld83;

    invoke-direct {v3, p0, v0, v1, v2}, Ld83;-><init>(Landroid/content/Context;Lw61;Lbo2;Lzi2;)V

    return-object v3

    :pswitch_4
    invoke-virtual {p0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Context;

    iget-object v0, v2, Luk4;->a:Ljava/lang/Object;

    check-cast v0, Lyn2;

    invoke-interface {v3}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/concurrent/Executor;

    new-instance v3, Lw73;

    invoke-direct {v3, p0, v0, v2, v1}, Lw73;-><init>(Landroid/content/Context;Ljava/lang/Object;Ljava/util/concurrent/Executor;I)V

    return-object v3

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
