.class public final Lar2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final synthetic a:I

.field public final b:Lxk4;

.field public final c:Lxk4;


# direct methods
.method public synthetic constructor <init>(Lxk4;Lxk4;I)V
    .locals 0

    iput p3, p0, Lar2;->a:I

    iput-object p1, p0, Lar2;->b:Lxk4;

    iput-object p2, p0, Lar2;->c:Lxk4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final d()Ljava/lang/Object;
    .locals 4

    iget v0, p0, Lar2;->a:I

    iget-object v1, p0, Lar2;->c:Lxk4;

    iget-object p0, p0, Lar2;->b:Lxk4;

    packed-switch v0, :pswitch_data_0

    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lju3;

    new-instance v1, Lqt3;

    invoke-direct {v1, p0, v0}, Lqt3;-><init>(Ljava/util/concurrent/ExecutorService;Lju3;)V

    return-object v1

    :pswitch_0
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lmi3;

    new-instance v1, Lei3;

    invoke-direct {v1, p0, v0}, Lei3;-><init>(Landroid/content/Context;Lmi3;)V

    return-object v1

    :pswitch_1
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    check-cast v1, Lnn2;

    invoke-virtual {v1}, Lnn2;->a()Lwi2;

    move-result-object v0

    new-instance v1, Lzg3;

    invoke-direct {v1, p0, v0}, Lzg3;-><init>(Landroid/content/Context;Lwi2;)V

    return-object v1

    :pswitch_2
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/concurrent/ScheduledExecutorService;

    check-cast v1, Lfn2;

    invoke-virtual {v1}, Lfn2;->a()Landroid/content/Context;

    new-instance v0, Lva3;

    const/4 v1, 0x7

    invoke-direct {v0, v1, p0}, Lva3;-><init>(ILjava/lang/Object;)V

    return-object v0

    :pswitch_3
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lbi2;

    sget-object v0, Laj2;->a:Lzi2;

    invoke-static {v0}, Lms2;->q(Ljava/lang/Object;)V

    check-cast v1, Lfn2;

    invoke-virtual {v1}, Lfn2;->a()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Lgb3;

    const/4 v3, 0x3

    invoke-direct {v2, v3, p0, v0, v1}, Lgb3;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v2

    :pswitch_4
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfc3;

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lab3;

    sget-object v2, Lk52;->Id:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-long v2, v2

    invoke-direct {v1, p0, v2, v3, v0}, Lab3;-><init>(Lud3;JLjava/util/concurrent/ScheduledExecutorService;)V

    return-object v1

    :pswitch_5
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lfc3;

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v1, Lab3;

    sget-object v2, Lk52;->Vd:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    int-to-long v2, v2

    invoke-direct {v1, p0, v2, v3, v0}, Lab3;-><init>(Lud3;JLjava/util/concurrent/ScheduledExecutorService;)V

    return-object v1

    :pswitch_6
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbi2;

    new-instance v1, Lq53;

    invoke-direct {v1, p0, v0}, Lq53;-><init>(Landroid/content/Context;Lbi2;)V

    return-object v1

    :pswitch_7
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lu23;

    new-instance v1, Ly43;

    invoke-direct {v1, p0, v0}, Ly43;-><init>(Landroid/content/Context;Lu23;)V

    return-object v1

    :pswitch_8
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lc33;

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltn2;

    new-instance v1, Le33;

    invoke-direct {v1, p0, v0}, Le33;-><init>(Lc33;Ltn2;)V

    return-object v1

    :pswitch_9
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lb62;

    invoke-interface {v1}, Lxk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Leo;

    sget-object v1, Laj2;->a:Lzi2;

    invoke-static {v1}, Lms2;->q(Ljava/lang/Object;)V

    new-instance v2, Lnz2;

    invoke-direct {v2, p0, v0, v1}, Lnz2;-><init>(Lb62;Leo;Lzi2;)V

    return-object v2

    :pswitch_a
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    check-cast v1, Ltt2;

    invoke-virtual {v1}, Ltt2;->a()Log3;

    move-result-object v0

    iget-object v0, v0, Log3;->g:Ljava/lang/String;

    new-instance v1, Lai2;

    invoke-direct {v1, p0, v0}, Lai2;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    return-object v1

    :pswitch_b
    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lxs2;

    check-cast v1, Ltt2;

    invoke-virtual {v1}, Ltt2;->a()Log3;

    move-result-object v0

    new-instance v1, Lus2;

    invoke-direct {v1, p0, v0}, Lus2;-><init>(Lxs2;Log3;)V

    return-object v1

    :pswitch_c
    check-cast p0, Lfn2;

    invoke-virtual {p0}, Lfn2;->a()Landroid/content/Context;

    move-result-object p0

    check-cast v1, Ltt2;

    invoke-virtual {v1}, Ltt2;->a()Log3;

    move-result-object v0

    iget-object v0, v0, Log3;->g:Ljava/lang/String;

    new-instance v1, Lai2;

    invoke-direct {v1, p0, v0}, Lai2;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    return-object v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
