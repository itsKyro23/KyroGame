.class public final Lbn2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lry1;


# instance fields
.field public final h:Landroid/content/Context;

.field public final i:Ls93;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lw61;)V
    .locals 11

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbn2;->h:Landroid/content/Context;

    sget-object v0, Lk52;->C3:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v0, v5, :cond_1

    if-eq v0, v4, :cond_0

    move v0, v4

    goto :goto_0

    :cond_0
    move v0, v2

    goto :goto_0

    :cond_1
    move v0, v3

    :goto_0
    invoke-static {}, Lhp3;->C()Lgp3;

    move-result-object v6

    sget-object v7, Lk52;->J3:Lg52;

    iget-object v8, v1, Lvx1;->c:Li52;

    invoke-virtual {v8, v7}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Float;

    invoke-virtual {v7}, Ljava/lang/Float;->floatValue()F

    move-result v7

    invoke-virtual {v6}, Lkg4;->c()V

    iget-object v8, v6, Lkg4;->i:Lng4;

    check-cast v8, Lhp3;

    invoke-virtual {v8, v7}, Lhp3;->E(F)V

    invoke-virtual {v6}, Lkg4;->d()Lng4;

    move-result-object v6

    check-cast v6, Lhp3;

    invoke-static {}, Ljp3;->F()Lip3;

    move-result-object v7

    sget-object v8, Lk52;->K3:Lg52;

    iget-object v9, v1, Lvx1;->c:Li52;

    invoke-virtual {v9, v8}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Boolean;

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    invoke-virtual {v7}, Lkg4;->c()V

    iget-object v9, v7, Lkg4;->i:Lng4;

    check-cast v9, Ljp3;

    invoke-virtual {v9, v8}, Ljp3;->H(Z)V

    sget-object v8, Lk52;->M3:Lg52;

    iget-object v9, v1, Lvx1;->c:Li52;

    invoke-virtual {v9, v8}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Long;

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-virtual {v7}, Lkg4;->c()V

    iget-object v10, v7, Lkg4;->i:Lng4;

    check-cast v10, Ljp3;

    invoke-virtual {v10, v8, v9}, Ljp3;->I(J)V

    invoke-virtual {v7}, Lkg4;->d()Lng4;

    move-result-object v7

    check-cast v7, Ljp3;

    invoke-static {}, Lcp3;->o0()Lbp3;

    move-result-object v8

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v9, v8, Lkg4;->i:Lng4;

    check-cast v9, Lcp3;

    invoke-virtual {v9, v0}, Lcp3;->N(I)V

    sget-object v0, Lk52;->D3:Lg52;

    iget-object v9, v1, Lvx1;->c:Li52;

    invoke-virtual {v9, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-eq v0, v5, :cond_2

    if-eq v0, v4, :cond_3

    move v2, v4

    goto :goto_1

    :cond_2
    move v2, v3

    :cond_3
    :goto_1
    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, v2}, Lcp3;->O(I)V

    iget-object p2, p2, Lw61;->h:Ljava/lang/String;

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->B(Ljava/lang/String;)V

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2}, Lcp3;->P()V

    sget-object p2, Lk52;->j3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->y(Z)V

    sget-object p2, Lk52;->N3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->z(Z)V

    sget-object p2, Lk52;->O3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->A(Z)V

    sget-object p2, Lk52;->P3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->J(Z)V

    sget-object p2, Lk52;->z3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v0, -0x1

    if-ne p2, v0, :cond_4

    goto :goto_2

    :cond_4
    const/4 v5, 0x0

    :goto_2
    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v5}, Lcp3;->H(Z)V

    sget-object p2, Lk52;->B3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    int-to-long v4, p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v4, v5}, Lcp3;->G(J)V

    sget-object p2, Lk52;->L3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Long;

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v4, v5}, Lcp3;->E(J)V

    sget-object p2, Lk52;->A3:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    int-to-long v4, p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v4, v5}, Lcp3;->D(J)V

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v6}, Lcp3;->C(Lhp3;)V

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object p2, v8, Lkg4;->i:Lng4;

    check-cast p2, Lcp3;

    invoke-virtual {p2, v7}, Lcp3;->F(Ljp3;)V

    sget-object p2, Lk52;->s4:Lg52;

    iget-object v0, v1, Lvx1;->c:Li52;

    invoke-virtual {v0, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    invoke-virtual {v8}, Lkg4;->c()V

    iget-object v0, v8, Lkg4;->i:Lng4;

    check-cast v0, Lcp3;

    invoke-virtual {v0, p2}, Lcp3;->I(Z)V

    invoke-virtual {v8}, Lkg4;->d()Lng4;

    move-result-object p2

    check-cast p2, Lcp3;

    sget-object v0, Laj2;->a:Lzi2;

    sget-object v1, Ls93;->j:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    sget-object v2, Ls93;->k:Ls93;

    if-nez v2, :cond_5

    new-instance v2, Ls93;

    invoke-direct {v2, p1, v0, p2}, Ls93;-><init>(Landroid/content/Context;Lzi2;Lcp3;)V

    sput-object v2, Ls93;->k:Ls93;

    goto :goto_3

    :catchall_0
    move-exception p0

    goto/16 :goto_7

    :cond_5
    :goto_3
    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iput-object v2, p0, Lbn2;->i:Ls93;

    iget-object p0, v2, Ls93;->i:Ljava/lang/Object;

    check-cast p0, Lap3;

    iget-object p0, p0, Lap3;->a:Lbq3;

    monitor-enter p0

    :try_start_1
    iget-object p1, p0, Lbq3;->e:Ln04;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz p1, :cond_6

    monitor-exit p0

    return-void

    :cond_6
    :try_start_2
    iget-object p1, p0, Lbq3;->b:Lnk4;

    invoke-interface {p1}, Lnk4;->d()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Set;

    new-instance p2, Ljava/util/ArrayList;

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result v0

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lyp3;

    invoke-interface {v0}, Lyp3;->a()Lna0;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :catchall_1
    move-exception p1

    goto :goto_6

    :cond_7
    iget-object p1, p0, Lbq3;->d:Lnk4;

    invoke-interface {p1}, Lnk4;->d()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lju3;

    invoke-static {p2}, Ln50;->O(Ljava/util/ArrayList;)Lv04;

    move-result-object p2

    iget-object v0, p0, Lbq3;->c:Ljava/util/concurrent/ExecutorService;

    sget-object v1, Lwm1;->x:Lwm1;

    invoke-static {p2, v1, v0}, Ln50;->L(Lna0;Lnv3;Ljava/util/concurrent/Executor;)Ln04;

    move-result-object p2

    invoke-virtual {p1, v3, p2}, Lju3;->e(ILb14;)V

    iput-object p2, p0, Lbq3;->e:Ln04;

    iget-object p1, p0, Lbq3;->a:Lnk4;

    invoke-interface {p1}, Lnk4;->d()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_5
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_8

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lyp3;

    invoke-interface {p2}, Lyp3;->a()Lna0;

    goto :goto_5

    :cond_8
    iget-object p1, p0, Lbq3;->e:Ln04;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz p1, :cond_9

    monitor-exit p0

    return-void

    :cond_9
    const/4 p1, 0x0

    :try_start_3
    throw p1

    :goto_6
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p1

    :goto_7
    :try_start_4
    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p0
.end method


# virtual methods
.method public final a(III)V
    .locals 20

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    sget-object v3, Lwv1;->g:Lwv1;

    iget-object v3, v3, Lwv1;->a:Lsc3;

    iget-object v3, v0, Lbn2;->h:Landroid/content/Context;

    invoke-static {v3, v1}, Lsc3;->b(Landroid/content/Context;I)I

    move-result v4

    int-to-float v10, v4

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    invoke-static {v4, v2}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v4

    int-to-float v11, v4

    move/from16 v4, p3

    int-to-long v14, v4

    const/4 v9, 0x0

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    move-wide v7, v14

    invoke-static/range {v5 .. v12}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v4

    iget-object v0, v0, Lbn2;->i:Ls93;

    invoke-virtual {v0, v4}, Ls93;->B(Landroid/view/MotionEvent;)V

    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    invoke-static {v4, v1}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    invoke-static {v5, v2}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v5

    int-to-float v5, v5

    const/16 v19, 0x0

    const-wide/16 v12, 0x0

    const/16 v16, 0x2

    move/from16 v17, v4

    move/from16 v18, v5

    invoke-static/range {v12 .. v19}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v4

    invoke-virtual {v0, v4}, Ls93;->B(Landroid/view/MotionEvent;)V

    invoke-virtual {v4}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    invoke-static {v4, v1}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    invoke-static {v3, v2}, Lsc3;->p(Landroid/util/DisplayMetrics;I)I

    move-result v2

    int-to-float v2, v2

    const/16 v16, 0x1

    move/from16 v17, v1

    move/from16 v18, v2

    invoke-static/range {v12 .. v19}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v1

    invoke-virtual {v0, v1}, Ls93;->B(Landroid/view/MotionEvent;)V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    return-void
.end method

.method public final b(Landroid/content/Context;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-virtual {p0, p1}, Ls93;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final c([Ljava/lang/StackTraceElement;)V
    .locals 1

    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    iget-object p0, p0, Ls93;->i:Ljava/lang/Object;

    check-cast p0, Lap3;

    iget-object p0, p0, Lap3;->c:Lvt3;

    iget-object p0, p0, Lvt3;->b:Ldu3;

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Ldu3;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final d(Landroid/content/Context;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-virtual {p0, p1}, Ls93;->z(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final e(Landroid/view/View;)V
    .locals 0

    return-void
.end method

.method public final f(Landroid/view/MotionEvent;)V
    .locals 0

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-virtual {p0, p1}, Ls93;->B(Landroid/view/MotionEvent;)V

    return-void
.end method

.method public final g(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-virtual {p0, p1, p2, p3}, Ls93;->A(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final h(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;Landroid/app/Activity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lbn2;->i:Ls93;

    invoke-virtual {p0, p1, p2, p3}, Ls93;->A(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final i(Landroid/content/Context;Landroid/view/View;Landroid/app/Activity;)Ljava/lang/String;
    .locals 10

    iget-object p0, p0, Lbn2;->i:Ls93;

    iget-object p0, p0, Ls93;->i:Ljava/lang/Object;

    move-object v1, p0

    check-cast v1, Lap3;

    iget-object p0, v1, Lap3;->e:Lqp3;

    iget-object v6, v1, Lap3;->d:Lju3;

    const/4 v0, 0x4

    invoke-virtual {v6, v0}, Lju3;->a(I)Liu3;

    move-result-object v7

    iget-boolean v8, v1, Lap3;->l:Z

    iget-object v0, v1, Lap3;->a:Lbq3;

    if-eqz v8, :cond_0

    invoke-virtual {v0}, Lbq3;->a()Lna0;

    move-result-object v0

    invoke-static {v0}, Ln50;->Q(Lna0;)Lna0;

    move-result-object v0

    :goto_0
    move-object v9, v0

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Lbq3;->a()Lna0;

    move-result-object v0

    goto :goto_0

    :goto_1
    new-instance v0, Lxb2;

    const/4 v5, 0x7

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v5}, Lxb2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object p1, Lz04;->h:Lz04;

    invoke-static {v9, v0, p1}, Ln50;->J(Lna0;Lu04;Ljava/util/concurrent/Executor;)Lm04;

    move-result-object p1

    :try_start_0
    invoke-virtual {v7}, Liu3;->a()V

    iget-wide p2, v1, Lap3;->f:J

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p1, p2, p3, v0}, Lg04;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;
    :try_end_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_5

    :catchall_0
    move-exception v0

    move-object p1, v0

    goto :goto_2

    :catch_0
    move-exception v0

    move-object p1, v0

    goto :goto_3

    :catch_1
    move-exception v0

    move-object p1, v0

    goto :goto_4

    :goto_2
    :try_start_1
    invoke-virtual {v7, p1}, Liu3;->b(Ljava/lang/Throwable;)V

    throw p1

    :catchall_1
    move-exception v0

    move-object p1, v0

    goto :goto_6

    :goto_3
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Thread;->interrupt()V

    invoke-virtual {v7, p1}, Liu3;->b(Ljava/lang/Throwable;)V

    const-string p2, ""

    goto :goto_5

    :goto_4
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p2

    if-eqz p2, :cond_1

    move-object p1, p2

    :cond_1
    invoke-virtual {v7, p1}, Liu3;->b(Ljava/lang/Throwable;)V

    const/4 p1, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    goto :goto_5

    :catch_2
    if-eqz v8, :cond_2

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Lg04;->cancel(Z)Z

    :cond_2
    const/16 p1, 0x39

    invoke-virtual {v6, p1}, Lju3;->b(I)V

    const/16 p1, 0x11

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_5
    invoke-virtual {v7}, Liu3;->c()V

    invoke-interface {p0}, Lqp3;->d()V

    return-object p2

    :goto_6
    invoke-virtual {v7}, Liu3;->c()V

    invoke-interface {p0}, Lqp3;->d()V

    throw p1
.end method
