.class public final La03;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/concurrent/Executor;

.field public final b:Liq2;

.field public final c:Lnw2;

.field public final d:Lkp2;

.field public final e:Lit2;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Executor;Liq2;Lnw2;Lkp2;Lit2;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La03;->a:Ljava/util/concurrent/Executor;

    iput-object p3, p0, La03;->c:Lnw2;

    iput-object p2, p0, La03;->b:Liq2;

    iput-object p4, p0, La03;->d:Lkp2;

    iput-object p5, p0, La03;->e:Lit2;

    return-void
.end method
