.class public final Lb73;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lie2;


# static fields
.field public static final synthetic o:I


# instance fields
.field public final h:Ljava/util/HashMap;

.field public final i:Landroid/content/Context;

.field public final j:Lu23;

.field public final k:Ltw4;

.field public final l:Lv63;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lv63;Ltw4;Lu23;)V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.offline.IOfflineUtils"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lb73;->h:Ljava/util/HashMap;

    iput-object p1, p0, Lb73;->i:Landroid/content/Context;

    iput-object p4, p0, Lb73;->j:Lu23;

    iput-object p3, p0, Lb73;->k:Ltw4;

    iput-object p2, p0, Lb73;->l:Lv63;

    return-void
.end method

.method public static Q3(Landroid/content/Context;Lu23;Lv63;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 6

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->h:Lui2;

    invoke-virtual {v0, p0}, Lui2;->i(Landroid/content/Context;)Z

    move-result p0

    const/4 v0, 0x1

    if-eq v0, p0, :cond_0

    const-string p0, "offline"

    goto :goto_0

    :cond_0
    const-string p0, "online"

    :goto_0
    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lu23;->a()Lry2;

    move-result-object p1

    const-string v0, "gqi"

    invoke-virtual {p1, v0, p3}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "action"

    invoke-virtual {p1, v0, p4}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    const-string p4, "device_connectivity"

    invoke-virtual {p1, p4, p0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    const-string p4, "event_timestamp"

    invoke-virtual {p1, p4, p0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {p5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/util/Map$Entry;

    invoke-interface {p4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Ljava/lang/String;

    invoke-interface {p4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    invoke-virtual {p1, p5, p4}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_1
    iget-object p0, p1, Lry2;->j:Ljava/lang/Object;

    check-cast p0, Lu23;

    iget-object p0, p0, Lu23;->a:La33;

    iget-object p1, p1, Lry2;->i:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/ConcurrentHashMap;

    iget-object p0, p0, La33;->f:Lh34;

    invoke-virtual {p0, p1}, Lh34;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p0

    :goto_2
    move-object v4, p0

    goto :goto_3

    :cond_2
    const-string p0, ""

    goto :goto_2

    :goto_3
    new-instance v0, Llt1;

    sget-object p0, Lcw4;->B:Lcw4;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v5, 0x2

    move-object v3, p3

    invoke-direct/range {v0 .. v5}, Llt1;-><init>(JLjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lzy2;

    const/4 p1, 0x4

    invoke-direct {p0, p2, p1, v0}, Lzy2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {p2, p0}, Lv63;->a(Lsh3;)V

    return-void
.end method

.method public static final R3(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/app/PendingIntent;
    .locals 2

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "offline_notification_action"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "gws_query_id"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "uri"

    invoke-virtual {v0, v1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-instance p3, Landroid/net/Uri$Builder;

    invoke-direct {p3}, Landroid/net/Uri$Builder;-><init>()V

    const-string v1, "offline"

    invoke-virtual {p3, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p2

    invoke-virtual {p2}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p3, 0x1d

    const/4 v1, 0x0

    if-lt p2, p3, :cond_0

    const-string p2, "offline_notification_clicked"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const-string p1, "com.google.android.gms.ads.NotificationHandlerActivity"

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 p1, 0xc000000

    invoke-static {v0, p1}, Lku3;->a(Landroid/content/Intent;I)Landroid/content/Intent;

    move-result-object p2

    invoke-static {p0, v1, p2, p1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    return-object p0

    :cond_0
    const-string p1, "com.google.android.gms.ads.AdService"

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 p1, 0x44000000    # 512.0f

    invoke-static {v0, p1}, Lku3;->a(Landroid/content/Intent;I)Landroid/content/Intent;

    move-result-object p2

    invoke-static {p0, v1, p2, p1}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p0

    return-object p0
.end method

.method public static W3(ILjava/lang/String;)Ljava/lang/String;
    .locals 1

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->h:Lui2;

    invoke-virtual {v0}, Lui2;->c()Landroid/content/res/Resources;

    move-result-object v0

    if-nez v0, :cond_0

    return-object p1

    :cond_0
    :try_start_0
    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    return-object p1
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    packed-switch p3, :pswitch_data_0

    const/4 p0, 0x0

    return p0

    :pswitch_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    sget-object v0, Ldf1;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, v0}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    check-cast v0, Ldf1;

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p0, p3, v0}, Lb73;->u0(Ll50;Ldf1;)V

    goto :goto_0

    :pswitch_1
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    invoke-static {v1}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object v1

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p0, p3, v0, v1}, Lb73;->i3([Ljava/lang/String;[ILl50;)V

    goto :goto_0

    :pswitch_2
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p0, p3}, Lb73;->S(Ll50;)V

    goto :goto_0

    :pswitch_3
    invoke-virtual {p0}, Lb73;->e()V

    goto :goto_0

    :pswitch_4
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    new-instance p1, Ldf1;

    const-string v2, ""

    invoke-direct {p1, v0, v1, v2}, Ldf1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, p3, p1}, Lb73;->u0(Ll50;Ldf1;)V

    goto :goto_0

    :pswitch_5
    sget-object p3, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Landroid/content/Intent;

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p0, p3}, Lb73;->m0(Landroid/content/Intent;)V

    :goto_0
    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    const/4 p0, 0x1

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final P3(Ljava/lang/String;Liy2;)V
    .locals 4

    const-string v0, ""

    invoke-virtual {p2}, Liy2;->f()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2}, Liy2;->a()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_0

    goto :goto_0

    :cond_0
    if-eqz v2, :cond_1

    move-object v1, v2

    goto :goto_0

    :cond_1
    move-object v1, v0

    :goto_0
    invoke-virtual {p2}, Liy2;->b()Ly72;

    move-result-object v2

    if-nez v2, :cond_2

    goto :goto_1

    :cond_2
    :try_start_0
    invoke-interface {v2}, Ly72;->d()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_1
    monitor-enter p2

    :try_start_1
    iget-object v2, p2, Liy2;->s:Ly72;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit p2

    const/4 p2, 0x0

    if-nez v2, :cond_3

    goto :goto_2

    :cond_3
    :try_start_2
    invoke-interface {v2}, Ly72;->a()Ll50;

    move-result-object v2

    if-eqz v2, :cond_4

    invoke-static {v2}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/drawable/Drawable;
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1

    move-object p2, v2

    :catch_1
    :cond_4
    :goto_2
    new-instance v2, Lt63;

    invoke-direct {v2, v1, v0, p2}, Lt63;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Lb73;->h:Ljava/util/HashMap;

    invoke-virtual {p0, p1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :catchall_0
    move-exception p0

    :try_start_3
    monitor-exit p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p0
.end method

.method public final S(Ll50;)V
    .locals 6

    invoke-static {p1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lu63;

    iget-object v0, p1, Lu63;->a:Landroid/app/Activity;

    iget-object v1, p1, Lu63;->b:Lbj1;

    iget-object v2, p1, Lu63;->c:Ljava/lang/String;

    iput-object v2, p0, Lb73;->m:Ljava/lang/String;

    iget-object p1, p1, Lu63;->d:Ljava/lang/String;

    iput-object p1, p0, Lb73;->n:Ljava/lang/String;

    sget-object p1, Lk52;->M9:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p1, p0, Lb73;->m:Ljava/lang/String;

    const-string v2, "dialog_impression"

    sget-object v3, Lwy3;->k:Lwy3;

    invoke-virtual {p0, p1, v2, v3}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    sget-object p1, Lcw4;->B:Lcw4;

    iget-object p1, p1, Lcw4;->c:Lzu4;

    invoke-static {v0}, Lzu4;->k(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const v2, 0x7f0f02f7

    const-string v3, "Open ad when you\'re back online."

    invoke-static {v2, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const v3, 0x7f0f02f6

    const-string v4, "We\'ll send you a notification with a link to the advertiser site."

    invoke-static {v3, v4}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const v3, 0x7f0f02f4

    const-string v4, "OK"

    invoke-static {v3, v4}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lz63;

    const/4 v5, 0x1

    invoke-direct {v4, p0, v0, v1, v5}, Lz63;-><init>(Lb73;Landroid/app/Activity;Lbj1;I)V

    invoke-virtual {v2, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v2, 0x7f0f02f5

    const-string v3, "No thanks"

    invoke-static {v2, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lx63;

    const/4 v4, 0x0

    invoke-direct {v3, p0, v1, v4}, Lx63;-><init>(Lb73;Lbj1;I)V

    invoke-virtual {v0, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v2, Ly63;

    invoke-direct {v2, p0, v1, v4}, Ly63;-><init>(Lb73;Lbj1;I)V

    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void

    :cond_0
    invoke-virtual {p0, v0, v1}, Lb73;->S3(Landroid/app/Activity;Lbj1;)V

    return-void
.end method

.method public final S3(Landroid/app/Activity;Lbj1;)V
    .locals 6

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->c:Lzu4;

    new-instance v0, Lpi0;

    invoke-direct {v0, p1}, Lpi0;-><init>(Landroid/content/Context;)V

    iget-object v0, v0, Lpi0;->b:Landroid/app/NotificationManager;

    invoke-virtual {v0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result v0

    if-nez v0, :cond_1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    sget-object v2, Lwy3;->k:Lwy3;

    if-ge v0, v1, :cond_0

    invoke-static {p1}, Lzu4;->k(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const v1, 0x7f0f02db

    const-string v3, "Allow app to send you notifications?"

    invoke-static {v1, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const v3, 0x7f0f02d9

    const-string v4, "Allow"

    invoke-static {v3, v4}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lz63;

    const/4 v5, 0x0

    invoke-direct {v4, p0, p1, p2, v5}, Lz63;-><init>(Lb73;Landroid/app/Activity;Lbj1;I)V

    invoke-virtual {v1, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const v1, 0x7f0f02da

    const-string v3, "Don\'t allow"

    invoke-static {v1, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Lx63;

    const/4 v4, 0x1

    invoke-direct {v3, p0, p2, v4}, Lx63;-><init>(Lb73;Lbj1;I)V

    invoke-virtual {p1, v1, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    new-instance v1, Ly63;

    invoke-direct {v1, p0, p2, v4}, Ly63;-><init>(Lb73;Lbj1;I)V

    invoke-virtual {p1, v1}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    iget-object p1, p0, Lb73;->m:Ljava/lang/String;

    const-string p2, "rtsdi"

    invoke-virtual {p0, p1, p2, v2}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    return-void

    :cond_0
    const-string p2, "android.permission.POST_NOTIFICATIONS"

    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x3039

    invoke-virtual {p1, p2, v0}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    iget-object p1, p0, Lb73;->m:Ljava/lang/String;

    const-string p2, "asnpdi"

    invoke-virtual {p0, p1, p2, v2}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    return-void

    :cond_1
    invoke-virtual {p0}, Lb73;->T3()V

    invoke-virtual {p0, p1, p2}, Lb73;->U3(Landroid/app/Activity;Lbj1;)V

    return-void
.end method

.method public final T3()V
    .locals 7

    :try_start_0
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->c:Lzu4;

    iget-object v0, p0, Lb73;->i:Landroid/content/Context;

    invoke-static {v0}, Lzu4;->b(Landroid/content/Context;)Lk82;

    move-result-object v1

    new-instance v2, Lui0;

    invoke-direct {v2, v0}, Lui0;-><init>(Ljava/lang/Object;)V

    new-instance v3, Ldf1;

    iget-object v4, p0, Lb73;->n:Ljava/lang/String;

    iget-object v5, p0, Lb73;->m:Ljava/lang/String;

    iget-object v6, p0, Lb73;->h:Ljava/util/HashMap;

    invoke-virtual {v6, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lt63;

    if-nez v6, :cond_0

    const-string v6, ""

    goto :goto_0

    :cond_0
    iget-object v6, v6, Lt63;->b:Ljava/lang/String;

    :goto_0
    invoke-direct {v3, v4, v5, v6}, Ldf1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v1, v2, v3}, Lk82;->zzg(Ll50;Ldf1;)Z

    move-result v2
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v2, :cond_1

    :try_start_1
    new-instance v3, Lui0;

    invoke-direct {v3, v0}, Lui0;-><init>(Ljava/lang/Object;)V

    iget-object v0, p0, Lb73;->n:Ljava/lang/String;

    iget-object v4, p0, Lb73;->m:Ljava/lang/String;

    invoke-interface {v1, v3, v0, v4}, Lk82;->zze(Ll50;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x1

    goto :goto_1

    :catch_0
    const/4 v2, 0x0

    :catch_1
    sget v0, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    move v0, v2

    :goto_1
    if-nez v0, :cond_2

    iget-object v0, p0, Lb73;->l:Lv63;

    iget-object v1, p0, Lb73;->m:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lv63;->b(Ljava/lang/String;)V

    iget-object v0, p0, Lb73;->m:Ljava/lang/String;

    const-string v1, "offline_notification_worker_not_scheduled"

    sget-object v2, Lwy3;->k:Lwy3;

    invoke-virtual {p0, v0, v1, v2}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    return-void
.end method

.method public final U3(Landroid/app/Activity;Lbj1;)V
    .locals 6

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v1, v0, Lcw4;->c:Lzu4;

    invoke-static {p1}, Lzu4;->k(Landroid/content/Context;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lmq;

    const/4 v3, 0x4

    invoke-direct {v2, v3, p2}, Lmq;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    iget-object v0, v0, Lcw4;->h:Lui2;

    invoke-virtual {v0}, Lui2;->c()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    :catch_0
    move-object v0, v2

    goto :goto_0

    :cond_0
    const v3, 0x7f0c004f

    :try_start_0
    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getLayout(I)Landroid/content/res/XmlResourceParser;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    const-string v3, "Thanks for your interest.\nWe will share more once you\'re back online."

    const v4, 0x7f0f02f1

    if-nez v0, :cond_1

    invoke-static {v4, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    goto :goto_3

    :cond_1
    :try_start_1
    invoke-virtual {p1}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object p1

    invoke-virtual {p1, v0, v2}, Landroid/view/LayoutInflater;->inflate(Lorg/xmlpull/v1/XmlPullParser;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    invoke-virtual {v1, p1}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    iget-object v0, p0, Lb73;->m:Ljava/lang/String;

    iget-object v3, p0, Lb73;->h:Ljava/util/HashMap;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lt63;

    if-nez v0, :cond_2

    const-string v0, ""

    goto :goto_1

    :cond_2
    iget-object v0, v0, Lt63;->a:Ljava/lang/String;

    :goto_1
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v5, 0x0

    if-nez v4, :cond_3

    const v4, 0x7f0901b9

    invoke-virtual {p1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_3
    iget-object v0, p0, Lb73;->m:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lt63;

    if-nez v0, :cond_4

    goto :goto_2

    :cond_4
    iget-object v2, v0, Lt63;->c:Landroid/graphics/drawable/Drawable;

    :goto_2
    if-eqz v2, :cond_5

    const v0, 0x7f0901ba

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_5
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v1, v5}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_3

    :catch_1
    invoke-static {v4, v3}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    :goto_3
    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    new-instance v0, Ljava/util/Timer;

    invoke-direct {v0}, Ljava/util/Timer;-><init>()V

    new-instance v1, Lw63;

    invoke-direct {v1, p0, p1, v0, p2}, Lw63;-><init>(Lb73;Landroid/app/AlertDialog;Ljava/util/Timer;Lbj1;)V

    const-wide/16 p0, 0xbb8

    invoke-virtual {v0, v1, p0, p1}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    return-void
.end method

.method public final V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .locals 6

    iget-object v1, p0, Lb73;->j:Lu23;

    iget-object v2, p0, Lb73;->l:Lv63;

    iget-object v0, p0, Lb73;->i:Landroid/content/Context;

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    invoke-static/range {v0 .. v5}, Lb73;->Q3(Landroid/content/Context;Lu23;Lv63;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    return-void
.end method

.method public final e()V
    .locals 3

    new-instance v0, Lf53;

    iget-object v1, p0, Lb73;->k:Ltw4;

    const/4 v2, 0x2

    invoke-direct {v0, v2, v1}, Lf53;-><init>(ILjava/lang/Object;)V

    iget-object p0, p0, Lb73;->l:Lv63;

    invoke-virtual {p0, v0}, Lv63;->a(Lsh3;)V

    return-void
.end method

.method public final i3([Ljava/lang/String;[ILl50;)V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    array-length v1, p1

    if-ge v0, v1, :cond_3

    aget-object v1, p1, v0

    const-string v2, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    invoke-static {p3}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lu63;

    iget-object p3, p1, Lu63;->a:Landroid/app/Activity;

    iget-object p1, p1, Lu63;->b:Lbj1;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    aget p2, p2, v0

    const-string v0, "dialog_action"

    if-nez p2, :cond_1

    const-string p2, "confirm"

    invoke-virtual {v1, v0, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lb73;->T3()V

    invoke-virtual {p0, p3, p1}, Lb73;->U3(Landroid/app/Activity;Lbj1;)V

    goto :goto_1

    :cond_1
    const-string p2, "dismiss"

    invoke-virtual {v1, v0, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lbj1;->q()V

    :cond_2
    :goto_1
    iget-object p1, p0, Lb73;->m:Ljava/lang/String;

    const-string p2, "asnpdc"

    invoke-virtual {p0, p1, p2, v1}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    :cond_3
    return-void
.end method

.method public final m0(Landroid/content/Intent;)V
    .locals 12

    iget-object v0, p0, Lb73;->l:Lv63;

    const-string v1, "olaa"

    const-string v2, "offline_notification_action"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_5

    const-string v4, "offline_notification_clicked"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string v6, "offline_notification_dismissed"

    if-nez v5, :cond_0

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    goto/16 :goto_2

    :cond_0
    const-string v5, "gws_query_id"

    invoke-virtual {p1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "uri"

    invoke-virtual {p1, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sget-object v7, Lcw4;->B:Lcw4;

    iget-object v7, v7, Lcw4;->h:Lui2;

    iget-object v8, p0, Lb73;->i:Landroid/content/Context;

    invoke-virtual {v7, v8}, Lui2;->i(Landroid/content/Context;)Z

    move-result v7

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v3, :cond_3

    invoke-virtual {v9, v2, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eq v11, v7, :cond_1

    goto :goto_0

    :cond_1
    move v10, v11

    :goto_0
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "obvs"

    invoke-virtual {v9, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "http"

    invoke-virtual {p1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v3

    const-string v4, "olaih"

    invoke-virtual {v9, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v3, p1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    if-nez v3, :cond_2

    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.intent.action.VIEW"

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {v3, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    :cond_2
    const/high16 p1, 0x10000000

    invoke-virtual {v3, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v8, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const-string p1, "olas"

    invoke-virtual {v9, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string p1, "olaf"

    invoke-virtual {v9, v1, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_3
    invoke-virtual {v9, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    invoke-virtual {p0, v5, v2, v9}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    :try_start_1
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p1
    :try_end_1
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_1 .. :try_end_1} :catch_1

    if-ne v10, v11, :cond_4

    new-instance v1, Lsi;

    const/16 v2, 0x12

    iget-object p0, p0, Lb73;->k:Ltw4;

    invoke-direct {v1, v2, p1, v5, p0}, Lsi;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p0, v0, Lv63;->i:Lzi2;

    invoke-interface {p0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :cond_4
    const/4 p0, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    filled-new-array {v5, p0}, [Ljava/lang/String;

    move-result-object p0

    const-string v0, "offline_buffered_pings"

    const-string v1, "gws_query_id = ? AND event_state = ?"

    invoke-virtual {p1, v0, v1, p0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    return-void

    :catch_1
    move-exception p0

    const-string p1, "Failed to get writable offline buffering database: "

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget p1, Lj23;->b:I

    invoke-static {p0}, Lj23;->d(Ljava/lang/String;)V

    :cond_5
    :goto_2
    return-void
.end method

.method public final u0(Ll50;Ldf1;)V
    .locals 8

    invoke-static {p1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/Context;

    iget-object v0, p2, Ldf1;->h:Ljava/lang/String;

    iget-object v1, p2, Ldf1;->i:Ljava/lang/String;

    iget-object p2, p2, Ldf1;->j:Ljava/lang/String;

    iget-object v2, p0, Lb73;->h:Ljava/util/HashMap;

    iget-object v3, p0, Lb73;->m:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lt63;

    if-nez v2, :cond_0

    const-string v2, ""

    goto :goto_0

    :cond_0
    iget-object v2, v2, Lt63;->a:Ljava/lang/String;

    :goto_0
    sget-object v3, Lcw4;->B:Lcw4;

    iget-object v3, v3, Lcw4;->f:Lne4;

    new-instance v3, Landroid/app/NotificationChannel;

    sget-object v4, Lk52;->O9:Lg52;

    sget-object v5, Lvx1;->e:Lvx1;

    iget-object v6, v5, Lvx1;->c:Li52;

    iget-object v5, v5, Lvx1;->c:Li52;

    invoke-virtual {v6, v4}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const-string v6, "AdMob Offline Notifications"

    const-string v7, "offline_notification_channel"

    invoke-direct {v3, v7, v6, v4}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    const-class v4, Landroid/app/NotificationManager;

    invoke-virtual {p1, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/NotificationManager;

    invoke-virtual {v4, v3}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    const-string v3, "offline_notification_clicked"

    invoke-static {p1, v3, v1, v0}, Lb73;->R3(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/app/PendingIntent;

    move-result-object v3

    const-string v4, "offline_notification_dismissed"

    invoke-static {p1, v4, v1, v0}, Lb73;->R3(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/app/PendingIntent;

    move-result-object v0

    new-instance v4, Lii0;

    invoke-direct {v4, p1, v7}, Lii0;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_1

    const v6, 0x7f0f02f3

    const-string v7, "You are back online! Continue learning about %s"

    invoke-static {v6, v7}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v6

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v6, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lii0;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    iput-object v2, v4, Lii0;->e:Ljava/lang/CharSequence;

    goto :goto_1

    :cond_1
    const v2, 0x7f0f02f2

    const-string v6, "You are back online! Let\'s pick up where we left off"

    invoke-static {v2, v6}, Lb73;->W3(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lii0;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    iput-object v2, v4, Lii0;->e:Ljava/lang/CharSequence;

    :goto_1
    const/16 v2, 0x10

    const/4 v6, 0x1

    invoke-virtual {v4, v2, v6}, Lii0;->d(IZ)V

    iget-object v2, v4, Lii0;->u:Landroid/app/Notification;

    iput-object v0, v2, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    iput-object v3, v4, Lii0;->g:Landroid/app/PendingIntent;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->icon:I

    iput v0, v2, Landroid/app/Notification;->icon:I

    sget-object v0, Lk52;->N9:Lg52;

    invoke-virtual {v5, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, v4, Lii0;->j:I

    sget-object v0, Lk52;->P9:Lg52;

    invoke-virtual {v5, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    :try_start_0
    new-instance v0, Ljava/net/URL;

    invoke-direct {v0, p2}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p2

    invoke-virtual {p2}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p2

    invoke-static {p2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object p2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    :cond_2
    move-object p2, v2

    :goto_2
    if-eqz p2, :cond_3

    :try_start_1
    invoke-virtual {v4, p2}, Lii0;->e(Landroid/graphics/Bitmap;)V

    new-instance v0, Lgi0;

    invoke-direct {v0}, Lji0;-><init>()V

    new-instance v3, Landroidx/core/graphics/drawable/IconCompat;

    invoke-direct {v3, v6}, Landroidx/core/graphics/drawable/IconCompat;-><init>(I)V

    iput-object p2, v3, Landroidx/core/graphics/drawable/IconCompat;->b:Ljava/lang/Object;

    iput-object v3, v0, Lgi0;->d:Landroidx/core/graphics/drawable/IconCompat;

    iput-object v2, v0, Lgi0;->e:Landroidx/core/graphics/drawable/IconCompat;

    iput-boolean v6, v0, Lgi0;->f:Z

    invoke-virtual {v4, v0}, Lii0;->f(Lji0;)V
    :try_end_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_3
    const-string p2, "notification"

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/app/NotificationManager;

    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    :try_start_2
    invoke-virtual {v4}, Lii0;->b()Landroid/app/Notification;

    move-result-object v0

    const v2, 0xd431

    invoke-virtual {p1, v1, v2, v0}, Landroid/app/NotificationManager;->notify(Ljava/lang/String;ILandroid/app/Notification;)V
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    const-string p1, "offline_notification_impression"

    goto :goto_3

    :catch_2
    move-exception p1

    const-string v0, "notification_not_shown_reason"

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "offline_notification_failed"

    :goto_3
    invoke-virtual {p0, v1, p1, p2}, Lb73;->V3(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    return-void
.end method
