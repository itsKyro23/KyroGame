.class public final Lau4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltw2;


# instance fields
.field public final h:Ls23;

.field public final i:Lxs4;

.field public final j:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ls23;Lxs4;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lau4;->h:Ls23;

    iput-object p2, p0, Lau4;->i:Lxs4;

    iput-object p3, p0, Lau4;->j:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public final d(Lbz1;)V
    .locals 5

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lau4;->i:Lxs4;

    iget-object v1, p0, Lau4;->j:Ljava/lang/String;

    iget-object p0, p0, Lau4;->h:Ls23;

    iget-object p1, p1, Lbz1;->b:Ljava/lang/String;

    monitor-enter v0

    :try_start_0
    new-instance v2, Lwr4;

    sget-object v3, Lcw4;->B:Lcw4;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    new-instance v4, Ljava/util/HashSet;

    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    invoke-direct {v2, v3, p1, v4}, Lwr4;-><init>(Ljava/lang/Long;Ljava/lang/String;Ljava/util/HashSet;)V

    iget-object p1, v0, Lxs4;->e:Ljava/util/Map;

    invoke-interface {p1, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, Lxs4;->b()V

    invoke-virtual {v0, p0}, Lxs4;->c(Ls23;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method
