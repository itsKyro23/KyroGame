.class public final synthetic Lb4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Loi;
.implements Lni;


# instance fields
.field public final synthetic a:Landroid/app/Activity;

.field public final synthetic b:Lml4;

.field public final synthetic c:La4;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;Lml4;La4;)V
    .locals 0

    iput-object p1, p0, Lb4;->a:Landroid/app/Activity;

    iput-object p2, p0, Lb4;->b:Lml4;

    iput-object p3, p0, Lb4;->c:La4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    iget-object v0, p0, Lb4;->b:Lml4;

    iget-object v1, p0, Lb4;->c:La4;

    iget-object p0, p0, Lb4;->a:Landroid/app/Activity;

    invoke-static {p0, v0, v1}, Ln50;->c(Landroid/app/Activity;Lml4;Lf4;)V

    return-void
.end method

.method public b()V
    .locals 15

    const/4 v0, 0x1

    sput-boolean v0, Ln50;->n:Z

    iget-object v1, p0, Lb4;->a:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    iget-object v3, p0, Lb4;->b:Lml4;

    iget-object p0, p0, Lb4;->c:La4;

    if-nez v2, :cond_4

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_0

    goto/16 :goto_0

    :cond_0
    new-instance v2, Lc4;

    invoke-direct {v2, v1, v3, p0}, Lc4;-><init>(Landroid/app/Activity;Lml4;La4;)V

    invoke-static {v1}, Lsj1;->p(Landroid/content/Context;)Lsj1;

    move-result-object p0

    iget-object v3, p0, Lsj1;->h:Ljava/lang/Object;

    check-cast v3, Lgw4;

    invoke-virtual {v3}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lml4;

    invoke-virtual {v3}, Lml4;->a()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-virtual {v2}, Lc4;->a()V

    return-void

    :cond_1
    iget-object v3, p0, Lsj1;->g:Ljava/lang/Object;

    check-cast v3, Lgw4;

    invoke-virtual {v3}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Leo2;

    iget-object v3, v3, Leo2;->i:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Queue;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    iget-object p0, p0, Lsj1;->e:Ljava/lang/Object;

    check-cast p0, Lgw4;

    invoke-virtual {p0}, Lgw4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lh92;

    invoke-static {}, Lpr2;->a()V

    new-instance v3, Llx2;

    const/16 v4, 0x17

    invoke-direct {v3, v1, v4, v2}, Llx2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    new-instance v1, Lo81;

    const/16 v4, 0x13

    invoke-direct {v1, v4, v2}, Lo81;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lpr2;->a()V

    iget-object v2, p0, Lh92;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lca2;

    if-nez v2, :cond_2

    new-instance p0, Lfm3;

    const/4 v0, 0x3

    const-string v2, "No available form can be built."

    invoke-direct {p0, v0, v2}, Lfm3;-><init>(ILjava/lang/String;)V

    invoke-virtual {p0}, Lfm3;->a()Ld34;

    move-result-object p0

    invoke-virtual {v1, p0}, Lo81;->i(Ld34;)V

    return-void

    :cond_2
    iget-object p0, p0, Lh92;->a:Lo81;

    invoke-virtual {p0}, Lo81;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lbu0;

    iget-object p0, p0, Lbu0;->h:Ljava/lang/Object;

    check-cast p0, Lsj1;

    iget-object v4, p0, Lsj1;->b:Ljava/lang/Object;

    check-cast v4, Ls53;

    new-instance v5, Lxy1;

    const/16 v6, 0x16

    invoke-direct {v5, v6, v4}, Lxy1;-><init>(ILjava/lang/Object;)V

    invoke-static {v5}, Lgw4;->a(Liw4;)Lgw4;

    move-result-object v9

    new-instance v4, Ls53;

    const/16 v5, 0x11

    invoke-direct {v4, v5, v2}, Ls53;-><init>(ILjava/lang/Object;)V

    new-instance v12, Ls43;

    invoke-direct {v12}, Ls43;-><init>()V

    iget-object v2, p0, Lsj1;->b:Ljava/lang/Object;

    move-object v8, v2

    check-cast v8, Ls53;

    iget-object v2, p0, Lsj1;->f:Ljava/lang/Object;

    move-object v10, v2

    check-cast v10, Lgw4;

    iget-object v2, p0, Lsj1;->i:Ljava/lang/Object;

    move-object v11, v2

    check-cast v11, Lsp1;

    iget-object v2, p0, Lsj1;->c:Ljava/lang/Object;

    move-object v13, v2

    check-cast v13, Lgw4;

    new-instance v7, Lfu1;

    invoke-direct/range {v7 .. v13}, Lfu1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    move-object v2, v12

    move-object v11, v13

    new-instance v13, Lsf2;

    const/16 v5, 0x18

    invoke-direct {v13, v9, v5, v7}, Lsf2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-object v5, p0, Lsj1;->d:Ljava/lang/Object;

    check-cast v5, Lgw4;

    iget-object p0, p0, Lsj1;->g:Ljava/lang/Object;

    move-object v14, p0

    check-cast v14, Lgw4;

    new-instance v7, Lqh;

    move-object v12, v4

    move-object v10, v9

    move-object v9, v5

    invoke-direct/range {v7 .. v14}, Lqh;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v7}, Lgw4;->a(Liw4;)Lgw4;

    move-result-object p0

    iget-object v4, v2, Ls43;->i:Ljava/lang/Object;

    check-cast v4, Lgw4;

    if-nez v4, :cond_3

    iput-object p0, v2, Ls43;->i:Ljava/lang/Object;

    invoke-virtual {v2}, Ls43;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lh02;

    iput-boolean v0, p0, Lh02;->n:Z

    invoke-virtual {p0, v3, v1}, Lh02;->b(Lj61;Li61;)V

    return-void

    :cond_3
    invoke-static {}, Lb;->a()V

    return-void

    :cond_4
    :goto_0
    invoke-static {v1, v3, p0}, Ln50;->c(Landroid/app/Activity;Lml4;Lf4;)V

    return-void
.end method
