.class public final synthetic Lb10;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Landroid/app/Activity;

.field public final synthetic j:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(ILandroid/app/Activity;Ljava/lang/String;)V
    .locals 0

    .line 11
    iput p1, p0, Lb10;->h:I

    iput-object p2, p0, Lb10;->i:Landroid/app/Activity;

    iput-object p3, p0, Lb10;->j:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, Lb10;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lb10;->j:Ljava/lang/String;

    iput-object p1, p0, Lb10;->i:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lb10;->h:I

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v3, p0, Lb10;->j:Ljava/lang/String;

    iget-object p0, p0, Lb10;->i:Landroid/app/Activity;

    packed-switch v0, :pswitch_data_0

    invoke-static {p0, v3}, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->E(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_0
    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    if-nez v3, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    move-object v0, v3

    :goto_0
    invoke-static {v2, v0}, Lcom/zayon/optimize/core/ZyCore;->featureOpen(ILjava/lang/String;)I

    move-result v0

    new-instance v2, Lb5;

    invoke-direct {v2, p0, v0, v3, v1}, Lb5;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :pswitch_1
    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    const/4 v0, 0x1

    sput-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lb10;

    invoke-direct {v1, p0, v3}, Lb10;-><init>(Landroid/app/Activity;Ljava/lang/String;)V

    const-string p0, "zayon-space"

    invoke-direct {v0, v1, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :goto_1
    return-void

    :pswitch_2
    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    invoke-static {v2}, Lcom/zayon/optimize/core/ZyCore;->refreshBalance(Z)I

    invoke-static {v2}, Lcom/zayon/optimize/core/ZyCore;->featureInfo(I)[I

    move-result-object v0

    new-instance v2, Lz4;

    invoke-direct {v2, v1, p0, v0, v3}, Lz4;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :pswitch_3
    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    if-eqz v3, :cond_2

    const-string v1, "com.zayon.optimize.GAME_ID"

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_2
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
