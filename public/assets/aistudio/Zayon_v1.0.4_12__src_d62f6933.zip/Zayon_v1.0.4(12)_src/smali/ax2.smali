.class public final Lax2;
.super Ljd1;
.source "SourceFile"

# interfaces
.implements Lsx2;


# direct methods
.method public constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const-string v0, "com.google.android.gms.ads.internal.client.IOnPaidEventListener"

    const/4 v1, 0x4

    invoke-direct {p0, p1, v0, v1}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final V1(Lxv4;)V
    .locals 1

    invoke-virtual {p0}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, p1}, Lg12;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 p1, 0x1

    invoke-virtual {p0, v0, p1}, Ljd1;->R0(Landroid/os/Parcel;I)V

    return-void
.end method

.method public final c()Z
    .locals 2

    const/4 v0, 0x2

    invoke-virtual {p0}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v1

    invoke-virtual {p0, v1, v0}, Ljd1;->M0(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object p0

    sget-object v0, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/os/Parcel;->recycle()V

    return v0
.end method
