.class public final La90;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lie;
.implements Liw4;
.implements Lfs2;
.implements Le14;
.implements Lwh3;


# static fields
.field public static m:La90;

.field public static final n:Lnl0;


# instance fields
.field public final synthetic h:I

.field public i:Ljava/lang/Object;

.field public j:Ljava/lang/Object;

.field public k:Ljava/lang/Object;

.field public l:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lnl0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La90;->n:Lnl0;

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    iput p1, p0, La90;->h:I

    const/4 v0, 0x0

    sparse-switch p1, :sswitch_data_0

    .line 1314
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    return-void

    .line 1315
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    iput-object v0, p0, La90;->j:Ljava/lang/Object;

    iput-object v0, p0, La90;->k:Ljava/lang/Object;

    sget-object p1, Ld34;->r:Ld34;

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    return-void

    .line 1316
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 1317
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 1318
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, La90;->k:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 1319
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    return-void

    .line 1320
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    iput-object v0, p0, La90;->j:Ljava/lang/Object;

    iput-object v0, p0, La90;->k:Ljava/lang/Object;

    sget-object p1, Lh34;->e:Lh34;

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    return-void

    .line 1321
    :sswitch_3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void

    :sswitch_data_0
    .sparse-switch
        0xe -> :sswitch_3
        0x1a -> :sswitch_2
        0x1b -> :sswitch_1
        0x1c -> :sswitch_0
    .end sparse-switch
.end method

.method public constructor <init>(Lak;Lvn;Lwm;)V
    .locals 2

    const/4 v0, 0x6

    iput v0, p0, La90;->h:I

    .line 1287
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1288
    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    .line 1289
    iput-object p3, p0, La90;->j:Ljava/lang/Object;

    const p3, 0x7fffffff

    const/4 v1, 0x0

    .line 1290
    invoke-static {p3, v1, v0}, Lb64;->a(ILid;I)Lkd;

    move-result-object p3

    iput-object p3, p0, La90;->k:Ljava/lang/Object;

    .line 1291
    new-instance p3, Lbu0;

    const/4 v0, 0x4

    invoke-direct {p3, v0}, Lbu0;-><init>(I)V

    iput-object p3, p0, La90;->l:Ljava/lang/Object;

    .line 1292
    invoke-interface {p1}, Lak;->a()Lsj;

    move-result-object p1

    sget-object p3, Lq24;->j:Lq24;

    invoke-interface {p1, p3}, Lsj;->h(Lrj;)Lqj;

    move-result-object p1

    check-cast p1, Le80;

    if-eqz p1, :cond_0

    new-instance p3, Lpj;

    const/4 v0, 0x1

    invoke-direct {p3, p2, v0, p0}, Lpj;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1293
    new-instance p0, Lv60;

    invoke-direct {p0, p3}, Lv60;-><init>(Lkz;)V

    .line 1294
    invoke-virtual {p1, v0, p0}, Le80;->E(ZLa80;)Lzq;

    :cond_0
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v0, 0x0

    iput v0, p0, La90;->h:I

    .line 1306
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1307
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, La90;->j:Ljava/lang/Object;

    .line 1308
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, La90;->k:Ljava/lang/Object;

    .line 1309
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v2, "zayon_library"

    invoke-virtual {p1, v2, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    .line 1310
    const-string v0, "lib"

    const-string v2, ""

    invoke-interface {p1, v0, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 1311
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    const-string v2, ","

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    .line 1312
    :cond_0
    const-string v0, "hero"

    const/4 v2, 0x0

    invoke-interface {p1, v0, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    if-eqz p1, :cond_2

    .line 1313
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_2

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    add-int/lit8 p1, p1, -0x1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    move-object v2, p1

    check-cast v2, Ljava/lang/String;

    :goto_0
    iput-object v2, p0, La90;->l:Ljava/lang/Object;

    :cond_2
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 8

    const/16 v0, 0xc

    iput v0, p0, La90;->h:I

    .line 1178
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    iput-object p2, p0, La90;->k:Ljava/lang/Object;

    sget-object p2, Ly91;->l:Lht1;

    invoke-virtual {p2}, Lht1;->v()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    iput-object p2, p0, La90;->l:Ljava/lang/Object;

    new-instance p2, Ljava/util/LinkedHashMap;

    .line 1179
    invoke-direct {p2}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p2, p0, La90;->i:Ljava/lang/Object;

    const-string v0, "s"

    const-string v1, "gmob_sdk"

    .line 1180
    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "v"

    const-string v1, "3"

    .line 1181
    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "os"

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    .line 1182
    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "api_v"

    sget-object v1, Landroid/os/Build$VERSION;->SDK:Ljava/lang/String;

    .line 1183
    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1184
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v1, v0, Lcw4;->c:Lzu4;

    .line 1185
    const-string v1, "device"

    invoke-static {}, Lzu4;->N()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1186
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 1187
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    .line 1188
    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    .line 1189
    :goto_0
    const-string v2, "app"

    .line 1190
    invoke-interface {p2, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1191
    invoke-static {p1}, Lzu4;->f(Landroid/content/Context;)Z

    move-result v1

    const-string v2, "1"

    const-string v3, "0"

    const/4 v4, 0x1

    if-eq v4, v1, :cond_1

    move-object v1, v3

    goto :goto_1

    :cond_1
    move-object v1, v2

    :goto_1
    const-string v5, "is_lite_sdk"

    .line 1192
    invoke-interface {p2, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1193
    iget-object v1, v0, Lcw4;->o:Lso3;

    .line 1194
    sget-object v5, Laj2;->a:Lzi2;

    new-instance v6, Ldy1;

    const/4 v7, 0x3

    invoke-direct {v6, v1, v7, p1}, Ldy1;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v5, v6}, Lzi2;->b(Ljava/util/concurrent/Callable;)Lna0;

    move-result-object v1

    .line 1195
    :try_start_0
    const-string v5, "network_coarse"

    .line 1196
    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lmg2;

    iget v6, v6, Lmg2;->j:I

    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    .line 1197
    invoke-interface {p2, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "network_fine"

    .line 1198
    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lmg2;

    iget v1, v1, Lmg2;->k:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    .line 1199
    invoke-interface {p2, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p2

    .line 1200
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v1, v0, Lcw4;->h:Lui2;

    .line 1201
    const-string v5, "CsiConfiguration.CsiConfiguration"

    invoke-virtual {v1, v5, p2}, Lui2;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 1202
    :goto_2
    iget-object p2, v0, Lcw4;->h:Lui2;

    sget-object v0, Lk52;->Uc:Lg52;

    .line 1203
    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v5, v1, Lvx1;->c:Li52;

    iget-object v1, v1, Lvx1;->c:Li52;

    .line 1204
    invoke-virtual {v5, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    .line 1205
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    .line 1206
    invoke-static {p1}, Lzu4;->d(Landroid/content/Context;)Z

    move-result p1

    if-eq v4, p1, :cond_2

    move-object v2, v3

    :cond_2
    const-string p1, "is_bstar"

    invoke-interface {v0, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    sget-object p1, Lk52;->Sa:Lg52;

    .line 1207
    invoke-virtual {v1, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    .line 1208
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_4

    sget-object p1, Lk52;->f3:Lg52;

    .line 1209
    invoke-virtual {v1, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    .line 1210
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_4

    .line 1211
    iget-object p1, p2, Lui2;->g:Ljava/lang/String;

    .line 1212
    invoke-static {p1}, Ln50;->p(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_4

    .line 1213
    iget-object p0, p0, La90;->i:Ljava/lang/Object;

    check-cast p0, Ljava/util/LinkedHashMap;

    .line 1214
    iget-object p1, p2, Lui2;->g:Ljava/lang/String;

    .line 1215
    const-string p2, "plugin"

    invoke-interface {p0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lu02;)V
    .locals 3

    const/16 v0, 0x18

    iput v0, p0, La90;->h:I

    .line 1216
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "pcvmspf"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    const-string v0, "pccache"

    .line 1217
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object v0

    .line 1218
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-nez v2, :cond_0

    .line 1219
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    :cond_0
    iput-object v0, p0, La90;->j:Ljava/lang/Object;

    const-string v0, "tmppccache"

    .line 1220
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p1

    .line 1221
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-nez v0, :cond_1

    .line 1222
    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    .line 1223
    :cond_1
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v0

    if-nez v0, :cond_2

    .line 1224
    invoke-virtual {p1}, Ljava/io/File;->mkdirs()Z

    .line 1225
    :cond_2
    iput-object p1, p0, La90;->k:Ljava/lang/Object;

    iput-object p2, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/util/JsonReader;Landroid/os/Bundle;)V
    .locals 8

    const/16 v0, 0x16

    iput v0, p0, La90;->h:I

    .line 1226
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La90;->l:Ljava/lang/Object;

    sget-object v0, Lk52;->M2:Lg52;

    .line 1227
    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    .line 1228
    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    .line 1229
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    if-eqz p2, :cond_0

    .line 1230
    sget-object v0, Lcw4;->B:Lcw4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1231
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 1232
    const-string v2, "server-response-parse-start"

    invoke-virtual {p2, v2, v0, v1}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 1233
    :cond_0
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    new-instance v1, Ljava/util/ArrayList;

    .line 1234
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1235
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginObject()V

    const/4 v2, 0x0

    move-object v3, v2

    .line 1236
    :cond_1
    :goto_0
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_d

    .line 1237
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "responses"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_7

    .line 1238
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginArray()V

    .line 1239
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginObject()V

    .line 1240
    :cond_2
    :goto_1
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    .line 1241
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    move-result-object v4

    const-string v5, "ad_configs"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    new-instance v0, Ljava/util/ArrayList;

    .line 1242
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1243
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginArray()V

    .line 1244
    :goto_2
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    new-instance v4, Lbg3;

    .line 1245
    invoke-direct {v4, p1}, Lbg3;-><init>(Landroid/util/JsonReader;)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    .line 1246
    :cond_3
    invoke-virtual {p1}, Landroid/util/JsonReader;->endArray()V

    goto :goto_1

    :cond_4
    const-string v5, "common"

    .line 1247
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    new-instance v3, Ldg3;

    .line 1248
    invoke-direct {v3, p1}, Ldg3;-><init>(Landroid/util/JsonReader;)V

    sget-object v4, Lk52;->N2:Lg52;

    .line 1249
    sget-object v5, Lvx1;->e:Lvx1;

    iget-object v5, v5, Lvx1;->c:Li52;

    .line 1250
    invoke-virtual {v5, v4}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v4

    .line 1251
    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_2

    if-eqz p2, :cond_2

    .line 1252
    const-string v4, "normalize-ad-response-start"

    .line 1253
    iget-wide v5, v3, Ldg3;->s:J

    invoke-virtual {p2, v4, v5, v6}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 1254
    const-string v4, "normalize-ad-response-end"

    .line 1255
    iget-wide v5, v3, Ldg3;->t:J

    .line 1256
    invoke-virtual {p2, v4, v5, v6}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    goto :goto_1

    .line 1257
    :cond_5
    invoke-virtual {p1}, Landroid/util/JsonReader;->skipValue()V

    goto :goto_1

    .line 1258
    :cond_6
    invoke-virtual {p1}, Landroid/util/JsonReader;->endObject()V

    .line 1259
    invoke-virtual {p1}, Landroid/util/JsonReader;->endArray()V

    goto :goto_0

    :cond_7
    const-string v5, "actions"

    .line 1260
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 1261
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginArray()V

    .line 1262
    :goto_3
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c

    .line 1263
    invoke-virtual {p1}, Landroid/util/JsonReader;->beginObject()V

    move-object v4, v2

    move-object v5, v4

    .line 1264
    :goto_4
    invoke-virtual {p1}, Landroid/util/JsonReader;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_a

    .line 1265
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextName()Ljava/lang/String;

    move-result-object v6

    const-string v7, "name"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_8

    .line 1266
    invoke-virtual {p1}, Landroid/util/JsonReader;->nextString()Ljava/lang/String;

    move-result-object v4

    goto :goto_4

    :cond_8
    const-string v7, "info"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_9

    .line 1267
    invoke-static {p1}, Lgd;->x(Landroid/util/JsonReader;)Lorg/json/JSONObject;

    move-result-object v5

    goto :goto_4

    .line 1268
    :cond_9
    invoke-virtual {p1}, Landroid/util/JsonReader;->skipValue()V

    goto :goto_4

    :cond_a
    if-eqz v4, :cond_b

    new-instance v6, Lgg3;

    invoke-direct {v6, v4, v5}, Lgg3;-><init>(Ljava/lang/String;Lorg/json/JSONObject;)V

    .line 1269
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1270
    :cond_b
    invoke-virtual {p1}, Landroid/util/JsonReader;->endObject()V

    goto :goto_3

    .line 1271
    :cond_c
    invoke-virtual {p1}, Landroid/util/JsonReader;->endArray()V

    goto/16 :goto_0

    :cond_d
    iput-object v1, p0, La90;->j:Ljava/lang/Object;

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    if-nez v3, :cond_e

    new-instance v3, Ldg3;

    new-instance p1, Landroid/util/JsonReader;

    .line 1272
    new-instance p2, Ljava/io/StringReader;

    const-string v0, "{}"

    invoke-direct {p2, v0}, Ljava/io/StringReader;-><init>(Ljava/lang/String;)V

    invoke-direct {p1, p2}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V

    invoke-direct {v3, p1}, Ldg3;-><init>(Landroid/util/JsonReader;)V

    :cond_e
    iput-object v3, p0, La90;->k:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroidx/work/impl/WorkDatabase_Impl;)V
    .locals 2

    const/16 v0, 0x8

    iput v0, p0, La90;->h:I

    .line 1295
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1296
    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    .line 1297
    new-instance v0, Lcq;

    const/4 v1, 0x4

    .line 1298
    invoke-direct {v0, p1, v1}, Lcq;-><init>(Landroidx/work/impl/WorkDatabase_Impl;I)V

    .line 1299
    iput-object v0, p0, La90;->j:Ljava/lang/Object;

    .line 1300
    new-instance v0, Lr11;

    const/4 v1, 0x1

    .line 1301
    invoke-direct {v0, p1, v1}, Lr11;-><init>(Landroidx/work/impl/WorkDatabase_Impl;I)V

    .line 1302
    iput-object v0, p0, La90;->k:Ljava/lang/Object;

    .line 1303
    new-instance v0, Lr11;

    const/4 v1, 0x2

    .line 1304
    invoke-direct {v0, p1, v1}, Lr11;-><init>(Landroidx/work/impl/WorkDatabase_Impl;I)V

    .line 1305
    iput-object v0, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lii0;)V
    .locals 25

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x5

    iput v2, v0, La90;->h:I

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    iput-object v2, v0, La90;->l:Ljava/lang/Object;

    iput-object v1, v0, La90;->k:Ljava/lang/Object;

    iget-object v2, v1, Lii0;->a:Landroid/content/Context;

    iget-object v3, v1, Lii0;->w:Ljava/util/ArrayList;

    iget-object v4, v1, Lii0;->c:Ljava/util/ArrayList;

    iget-object v5, v1, Lii0;->d:Ljava/util/ArrayList;

    iput-object v2, v0, La90;->i:Ljava/lang/Object;

    iget-object v6, v1, Lii0;->r:Ljava/lang/String;

    new-instance v7, Landroid/app/Notification$Builder;

    invoke-direct {v7, v2, v6}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object v7, v0, La90;->j:Ljava/lang/Object;

    iget-object v6, v1, Lii0;->u:Landroid/app/Notification;

    iget-wide v8, v6, Landroid/app/Notification;->when:J

    invoke-virtual {v7, v8, v9}, Landroid/app/Notification$Builder;->setWhen(J)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->icon:I

    iget v10, v6, Landroid/app/Notification;->iconLevel:I

    invoke-virtual {v8, v9, v10}, Landroid/app/Notification$Builder;->setSmallIcon(II)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContent(Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    const/4 v10, 0x0

    invoke-virtual {v8, v9, v10}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->vibrate:[J

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->ledARGB:I

    iget v11, v6, Landroid/app/Notification;->ledOnMS:I

    iget v12, v6, Landroid/app/Notification;->ledOffMS:I

    invoke-virtual {v8, v9, v11, v12}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x2

    const/4 v11, 0x0

    if-eqz v9, :cond_0

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    move v9, v11

    :goto_0
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x8

    if-eqz v9, :cond_1

    const/4 v9, 0x1

    goto :goto_1

    :cond_1
    move v9, v11

    :goto_1
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setOnlyAlertOnce(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x10

    if-eqz v9, :cond_2

    const/4 v9, 0x1

    goto :goto_2

    :cond_2
    move v9, v11

    :goto_2
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->defaults:I

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lii0;->e:Ljava/lang/CharSequence;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lii0;->f:Ljava/lang/CharSequence;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    invoke-virtual {v8, v10}, Landroid/app/Notification$Builder;->setContentInfo(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lii0;->g:Landroid/app/PendingIntent;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setDeleteIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit16 v9, v9, 0x80

    if-eqz v9, :cond_3

    const/4 v9, 0x1

    goto :goto_3

    :cond_3
    move v9, v11

    :goto_3
    invoke-virtual {v8, v10, v9}, Landroid/app/Notification$Builder;->setFullScreenIntent(Landroid/app/PendingIntent;Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v1, Lii0;->i:I

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setNumber(I)Landroid/app/Notification$Builder;

    move-result-object v8

    invoke-virtual {v8, v11, v11, v11}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;

    iget-object v8, v1, Lii0;->h:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v8, :cond_4

    move-object v2, v10

    goto :goto_4

    :cond_4
    invoke-static {v8, v2}, Ls9;->i(Landroidx/core/graphics/drawable/IconCompat;Landroid/content/Context;)Landroid/graphics/drawable/Icon;

    move-result-object v2

    :goto_4
    invoke-virtual {v7, v2}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    invoke-virtual {v7, v10}, Landroid/app/Notification$Builder;->setSubText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v11}, Landroid/app/Notification$Builder;->setUsesChronometer(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    iget v7, v1, Lii0;->j:I

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    iget-object v2, v1, Lii0;->b:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    move v8, v11

    :goto_5
    const-string v9, "android.support.allowGeneratedReplies"

    const-string v13, "code"

    if-ge v8, v7, :cond_f

    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v16

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v15, v16

    check-cast v15, Lei0;

    iget-object v11, v15, Lei0;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v11, :cond_5

    iget v14, v15, Lei0;->f:I

    if-eqz v14, :cond_5

    invoke-static {v14}, Landroidx/core/graphics/drawable/IconCompat;->a(I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v11

    iput-object v11, v15, Lei0;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_5
    iget-boolean v14, v15, Lei0;->d:Z

    iget-object v12, v15, Lei0;->a:Landroid/os/Bundle;

    move-object/from16 v17, v2

    new-instance v2, Landroid/app/Notification$Action$Builder;

    if-eqz v11, :cond_6

    invoke-static {v11, v10}, Ls9;->i(Landroidx/core/graphics/drawable/IconCompat;Landroid/content/Context;)Landroid/graphics/drawable/Icon;

    move-result-object v11

    goto :goto_6

    :cond_6
    move-object v11, v10

    :goto_6
    iget-object v10, v15, Lei0;->g:Ljava/lang/CharSequence;

    move-object/from16 v19, v4

    iget-object v4, v15, Lei0;->h:Landroid/app/PendingIntent;

    invoke-direct {v2, v11, v10, v4}, Landroid/app/Notification$Action$Builder;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    iget-object v4, v15, Lei0;->c:[Lcs0;

    if-eqz v4, :cond_a

    array-length v10, v4

    new-array v11, v10, [Landroid/app/RemoteInput;

    move/from16 v20, v7

    move/from16 v21, v8

    const/4 v7, 0x0

    :goto_7
    array-length v8, v4

    if-ge v7, v8, :cond_9

    aget-object v8, v4, v7

    move-object/from16 v22, v4

    new-instance v4, Landroid/app/RemoteInput$Builder;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v4, v13}, Landroid/app/RemoteInput$Builder;-><init>(Ljava/lang/String;)V

    move/from16 v23, v7

    iget-object v7, v8, Lcs0;->a:Ljava/lang/CharSequence;

    invoke-virtual {v4, v7}, Landroid/app/RemoteInput$Builder;->setLabel(Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v4

    const/4 v7, 0x0

    invoke-virtual {v4, v7}, Landroid/app/RemoteInput$Builder;->setChoices([Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v4

    const/4 v7, 0x1

    invoke-virtual {v4, v7}, Landroid/app/RemoteInput$Builder;->setAllowFreeFormInput(Z)Landroid/app/RemoteInput$Builder;

    move-result-object v4

    iget-object v7, v8, Lcs0;->b:Landroid/os/Bundle;

    invoke-virtual {v4, v7}, Landroid/app/RemoteInput$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/RemoteInput$Builder;

    move-result-object v4

    iget-object v7, v8, Lcs0;->c:Ljava/util/HashSet;

    invoke-virtual {v7}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_8
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    move-object/from16 v24, v7

    const/4 v7, 0x1

    invoke-virtual {v4, v8, v7}, Landroid/app/RemoteInput$Builder;->setAllowDataType(Ljava/lang/String;Z)Landroid/app/RemoteInput$Builder;

    move-object/from16 v7, v24

    goto :goto_8

    :cond_7
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1d

    if-lt v7, v8, :cond_8

    invoke-static {v4}, Le9;->g(Landroid/app/RemoteInput$Builder;)V

    :cond_8
    invoke-virtual {v4}, Landroid/app/RemoteInput$Builder;->build()Landroid/app/RemoteInput;

    move-result-object v4

    aput-object v4, v11, v23

    add-int/lit8 v7, v23, 0x1

    move-object/from16 v4, v22

    goto :goto_7

    :cond_9
    const/4 v4, 0x0

    :goto_9
    if-ge v4, v10, :cond_b

    aget-object v7, v11, v4

    invoke-virtual {v2, v7}, Landroid/app/Notification$Action$Builder;->addRemoteInput(Landroid/app/RemoteInput;)Landroid/app/Notification$Action$Builder;

    add-int/lit8 v4, v4, 0x1

    goto :goto_9

    :cond_a
    move/from16 v20, v7

    move/from16 v21, v8

    :cond_b
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4, v12}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    invoke-virtual {v4, v9, v14}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v2, v14}, Landroid/app/Notification$Action$Builder;->setAllowGeneratedReplies(Z)Landroid/app/Notification$Action$Builder;

    const-string v7, "android.support.action.semanticAction"

    const/4 v8, 0x0

    invoke-virtual {v4, v7, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1c

    if-lt v7, v8, :cond_c

    invoke-static {v2}, Lhp;->o(Landroid/app/Notification$Action$Builder;)V

    :cond_c
    const/16 v8, 0x1d

    if-lt v7, v8, :cond_d

    invoke-static {v2}, Le9;->f(Landroid/app/Notification$Action$Builder;)V

    :cond_d
    const/16 v8, 0x1f

    if-lt v7, v8, :cond_e

    invoke-static {v2}, Lki0;->a(Landroid/app/Notification$Action$Builder;)V

    :cond_e
    const-string v7, "android.support.action.showsUserInterface"

    iget-boolean v8, v15, Lei0;->e:Z

    invoke-virtual {v4, v7, v8}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v2, v4}, Landroid/app/Notification$Action$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/Notification$Action$Builder;

    iget-object v4, v0, La90;->j:Ljava/lang/Object;

    check-cast v4, Landroid/app/Notification$Builder;

    invoke-virtual {v2}, Landroid/app/Notification$Action$Builder;->build()Landroid/app/Notification$Action;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/app/Notification$Builder;->addAction(Landroid/app/Notification$Action;)Landroid/app/Notification$Builder;

    move-object/from16 v2, v17

    move-object/from16 v4, v19

    move/from16 v7, v20

    move/from16 v8, v21

    const/4 v10, 0x0

    const/4 v11, 0x0

    goto/16 :goto_5

    :cond_f
    move-object/from16 v19, v4

    iget-object v2, v1, Lii0;->o:Landroid/os/Bundle;

    if-eqz v2, :cond_10

    iget-object v4, v0, La90;->l:Ljava/lang/Object;

    check-cast v4, Landroid/os/Bundle;

    invoke-virtual {v4, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    :cond_10
    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-boolean v4, v1, Lii0;->k:Z

    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-boolean v4, v1, Lii0;->m:Z

    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setLocalOnly(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setSortKey(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v8, 0x0

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setGroupSummary(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v4, v1, Lii0;->n:Ljava/lang/String;

    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget v4, v1, Lii0;->p:I

    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget v4, v1, Lii0;->q:I

    invoke-virtual {v2, v4}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setPublicVersion(Landroid/app/Notification;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v4, v6, Landroid/app/Notification;->sound:Landroid/net/Uri;

    iget-object v7, v6, Landroid/app/Notification;->audioAttributes:Landroid/media/AudioAttributes;

    invoke-virtual {v2, v4, v7}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)Landroid/app/Notification$Builder;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1c

    if-ge v2, v8, :cond_15

    if-nez v19, :cond_11

    const/4 v2, 0x0

    goto :goto_a

    :cond_11
    new-instance v2, Ljava/util/ArrayList;

    invoke-virtual/range {v19 .. v19}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-direct {v2, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual/range {v19 .. v19}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_14

    :goto_a
    if-nez v2, :cond_12

    goto :goto_b

    :cond_12
    if-nez v3, :cond_13

    move-object v3, v2

    goto :goto_b

    :cond_13
    new-instance v4, Lq9;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v7

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v8

    add-int/2addr v8, v7

    invoke-direct {v4, v8}, Lq9;-><init>(I)V

    invoke-virtual {v4, v2}, Lq9;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v4, v3}, Lq9;->addAll(Ljava/util/Collection;)Z

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    goto :goto_b

    :cond_14
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lnu0;->f()V

    const/16 v18, 0x0

    throw v18

    :cond_15
    :goto_b
    if-eqz v3, :cond_16

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_16

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v4, 0x0

    :goto_c
    if-ge v4, v2, :cond_16

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v4, v4, 0x1

    check-cast v7, Ljava/lang/String;

    iget-object v8, v0, La90;->j:Ljava/lang/Object;

    check-cast v8, Landroid/app/Notification$Builder;

    invoke-virtual {v8, v7}, Landroid/app/Notification$Builder;->addPerson(Ljava/lang/String;)Landroid/app/Notification$Builder;

    goto :goto_c

    :cond_16
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_21

    iget-object v2, v1, Lii0;->o:Landroid/os/Bundle;

    if-nez v2, :cond_17

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    iput-object v2, v1, Lii0;->o:Landroid/os/Bundle;

    :cond_17
    const-string v3, "android.car.EXTENSIONS"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    if-nez v2, :cond_18

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    :cond_18
    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4, v2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x0

    :goto_d
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v8, v10, :cond_1f

    invoke-static {v8}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lei0;

    new-instance v12, Landroid/os/Bundle;

    invoke-direct {v12}, Landroid/os/Bundle;-><init>()V

    iget-object v14, v11, Lei0;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v14, :cond_19

    iget v15, v11, Lei0;->f:I

    if-eqz v15, :cond_19

    invoke-static {v15}, Landroidx/core/graphics/drawable/IconCompat;->a(I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v14

    iput-object v14, v11, Lei0;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_19
    iget-object v15, v11, Lei0;->a:Landroid/os/Bundle;

    if-eqz v14, :cond_1a

    invoke-virtual {v14}, Landroidx/core/graphics/drawable/IconCompat;->b()I

    move-result v14

    :goto_e
    move-object/from16 v17, v5

    goto :goto_f

    :cond_1a
    const/4 v14, 0x0

    goto :goto_e

    :goto_f
    const-string v5, "icon"

    invoke-virtual {v12, v5, v14}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string v5, "title"

    iget-object v14, v11, Lei0;->g:Ljava/lang/CharSequence;

    invoke-virtual {v12, v5, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const-string v5, "actionIntent"

    iget-object v14, v11, Lei0;->h:Landroid/app/PendingIntent;

    invoke-virtual {v12, v5, v14}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5, v15}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    iget-boolean v14, v11, Lei0;->d:Z

    invoke-virtual {v5, v9, v14}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v14, "extras"

    invoke-virtual {v12, v14, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v5, v11, Lei0;->c:[Lcs0;

    if-nez v5, :cond_1c

    move/from16 v20, v8

    move-object/from16 v21, v9

    const/4 v15, 0x0

    :cond_1b
    move-object/from16 v24, v13

    goto :goto_12

    :cond_1c
    array-length v15, v5

    new-array v15, v15, [Landroid/os/Bundle;

    move/from16 v20, v8

    move-object/from16 v21, v9

    const/4 v8, 0x0

    :goto_10
    array-length v9, v5

    if-ge v8, v9, :cond_1b

    aget-object v9, v5, v8

    move-object/from16 v22, v5

    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move/from16 v23, v8

    const-string v8, "resultKey"

    invoke-virtual {v5, v8, v13}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v8, "label"

    move-object/from16 v24, v13

    iget-object v13, v9, Lcs0;->a:Ljava/lang/CharSequence;

    invoke-virtual {v5, v8, v13}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const-string v8, "choices"

    const/4 v13, 0x0

    invoke-virtual {v5, v8, v13}, Landroid/os/Bundle;->putCharSequenceArray(Ljava/lang/String;[Ljava/lang/CharSequence;)V

    const-string v8, "allowFreeFormInput"

    const/4 v13, 0x1

    invoke-virtual {v5, v8, v13}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    iget-object v8, v9, Lcs0;->b:Landroid/os/Bundle;

    invoke-virtual {v5, v14, v8}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v8, v9, Lcs0;->c:Ljava/util/HashSet;

    invoke-virtual {v8}, Ljava/util/HashSet;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_1e

    new-instance v9, Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/HashSet;->size()I

    move-result v13

    invoke-direct {v9, v13}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v8}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_11
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1d

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_11

    :cond_1d
    const-string v8, "allowedDataTypes"

    invoke-virtual {v5, v8, v9}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_1e
    aput-object v5, v15, v23

    add-int/lit8 v8, v23, 0x1

    move-object/from16 v5, v22

    move-object/from16 v13, v24

    goto :goto_10

    :goto_12
    const-string v5, "remoteInputs"

    invoke-virtual {v12, v5, v15}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const-string v5, "showsUserInterface"

    iget-boolean v8, v11, Lei0;->e:Z

    invoke-virtual {v12, v5, v8}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v5, "semanticAction"

    const/4 v8, 0x0

    invoke-virtual {v12, v5, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v7, v10, v12}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    add-int/lit8 v8, v20, 0x1

    move-object/from16 v5, v17

    move-object/from16 v9, v21

    move-object/from16 v13, v24

    goto/16 :goto_d

    :cond_1f
    const-string v5, "invisible_actions"

    invoke-virtual {v2, v5, v7}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual {v4, v5, v7}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v5, v1, Lii0;->o:Landroid/os/Bundle;

    if-nez v5, :cond_20

    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    iput-object v5, v1, Lii0;->o:Landroid/os/Bundle;

    :cond_20
    invoke-virtual {v5, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v2, v0, La90;->l:Ljava/lang/Object;

    check-cast v2, Landroid/os/Bundle;

    invoke-virtual {v2, v3, v4}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_21
    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v3, v1, Lii0;->o:Landroid/os/Bundle;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setExtras(Landroid/os/Bundle;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setRemoteInputHistory([Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v8, 0x0

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setBadgeIconType(I)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setSettingsText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setShortcutId(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-wide v3, v1, Lii0;->s:J

    invoke-virtual {v2, v3, v4}, Landroid/app/Notification$Builder;->setTimeoutAfter(J)Landroid/app/Notification$Builder;

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v8, 0x0

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setGroupAlertBehavior(I)Landroid/app/Notification$Builder;

    iget-object v2, v1, Lii0;->r:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_22

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v8, v8, v8}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v2

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    :cond_22
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1c

    if-lt v2, v8, :cond_23

    invoke-virtual/range {v19 .. v19}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_24

    :cond_23
    const/16 v8, 0x1d

    goto :goto_13

    :cond_24
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lnu0;->f()V

    const/16 v18, 0x0

    throw v18

    :goto_13
    if-lt v2, v8, :cond_25

    iget-object v3, v0, La90;->j:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    iget-boolean v4, v1, Lii0;->t:Z

    invoke-static {v3, v4}, Le9;->d(Landroid/app/Notification$Builder;Z)V

    iget-object v3, v0, La90;->j:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Le9;->e(Landroid/app/Notification$Builder;)V

    :cond_25
    const/16 v3, 0x24

    if-lt v2, v3, :cond_26

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-static {v2}, Lh2;->e(Landroid/app/Notification$Builder;)V

    :cond_26
    iget-boolean v1, v1, Lii0;->v:Z

    if-eqz v1, :cond_28

    iget-object v1, v0, La90;->k:Ljava/lang/Object;

    check-cast v1, Lii0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v0, La90;->j:Ljava/lang/Object;

    check-cast v1, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    invoke-virtual {v1, v7}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    iget-object v1, v0, La90;->j:Ljava/lang/Object;

    check-cast v1, Landroid/app/Notification$Builder;

    invoke-virtual {v1, v7}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;)Landroid/app/Notification$Builder;

    iget v1, v6, Landroid/app/Notification;->defaults:I

    and-int/lit8 v1, v1, -0x4

    iput v1, v6, Landroid/app/Notification;->defaults:I

    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v2, v1}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    iget-object v1, v0, La90;->k:Ljava/lang/Object;

    check-cast v1, Lii0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_27

    iget-object v1, v0, La90;->j:Ljava/lang/Object;

    check-cast v1, Landroid/app/Notification$Builder;

    const-string v2, "silent"

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_27
    iget-object v0, v0, La90;->j:Ljava/lang/Object;

    check-cast v0, Landroid/app/Notification$Builder;

    const/4 v7, 0x1

    invoke-virtual {v0, v7}, Landroid/app/Notification$Builder;->setGroupAlertBehavior(I)Landroid/app/Notification$Builder;

    :cond_28
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1176
    iput p5, p0, La90;->h:I

    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    iput-object p2, p0, La90;->j:Ljava/lang/Object;

    iput-object p3, p0, La90;->k:Ljava/lang/Object;

    iput-object p4, p0, La90;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V
    .locals 0

    .line 1177
    iput p5, p0, La90;->h:I

    iput-object p2, p0, La90;->i:Ljava/lang/Object;

    iput-object p3, p0, La90;->j:Ljava/lang/Object;

    iput-object p4, p0, La90;->k:Ljava/lang/Object;

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/util/ArrayList;)V
    .locals 5

    const/4 p2, 0x1

    iput p2, p0, La90;->h:I

    .line 1327
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1328
    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    .line 1329
    new-instance p2, Landroid/util/SparseBooleanArray;

    invoke-direct {p2}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object p2, p0, La90;->k:Ljava/lang/Object;

    .line 1330
    new-instance p2, Lp9;

    const/4 v0, 0x0

    .line 1331
    invoke-direct {p2, v0}, Ltx0;-><init>(I)V

    .line 1332
    iput-object p2, p0, La90;->j:Ljava/lang/Object;

    .line 1333
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/high16 v1, -0x80000000

    const/4 v2, 0x0

    :goto_0
    if-ge v0, p2, :cond_1

    .line 1334
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lol0;

    .line 1335
    iget v4, v3, Lol0;->e:I

    if-le v4, v1, :cond_0

    move-object v2, v3

    move v1, v4

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 1336
    :cond_1
    iput-object v2, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lkp2;Lsj3;Ljava/lang/String;Lco2;)V
    .locals 1

    const/16 v0, 0xf

    iput v0, p0, La90;->h:I

    .line 1274
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La90;->i:Ljava/lang/Object;

    iput-object p3, p0, La90;->l:Ljava/lang/Object;

    iput-object p4, p0, La90;->j:Ljava/lang/Object;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, La90;->k:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lp20;I[Ljava/lang/String;[Ljava/lang/String;ZIF[ZLh20;)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    const/4 v3, 0x4

    iput v3, v0, La90;->h:I

    .line 1337
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v1, v0, La90;->l:Ljava/lang/Object;

    .line 1338
    iget-object v3, v1, Lp20;->h:Landroid/view/View;

    iget v4, v1, Lp20;->d:F

    move/from16 v5, p2

    invoke-virtual {v3, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    .line 1339
    invoke-virtual {v3}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1340
    array-length v5, v2

    .line 1341
    new-array v6, v5, [Lcom/zayon/optimize/ui/ZyBox;

    iput-object v6, v0, La90;->i:Ljava/lang/Object;

    .line 1342
    new-array v6, v5, [Landroid/widget/TextView;

    iput-object v6, v0, La90;->j:Ljava/lang/Object;

    if-eqz p8, :cond_0

    move-object/from16 v6, p8

    goto :goto_0

    .line 1343
    :cond_0
    new-array v6, v5, [Z

    :goto_0
    iput-object v6, v0, La90;->k:Ljava/lang/Object;

    const/4 v6, 0x0

    move v7, v6

    :goto_1
    if-ge v7, v5, :cond_4

    .line 1344
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    const/high16 v10, 0x41000000    # 8.0f

    const/4 v11, 0x0

    invoke-static {v9, v10, v6, v11}, Lcom/zayon/optimize/ui/ZyBox;->c(Landroid/content/Context;FZF)Lcom/zayon/optimize/ui/ZyBox;

    move-result-object v9

    .line 1345
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move/from16 v11, p6

    int-to-float v12, v11

    mul-float/2addr v12, v4

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v10, v6, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v7, :cond_1

    const/high16 v12, 0x40400000    # 3.0f

    mul-float/2addr v12, v4

    .line 1346
    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    invoke-virtual {v10, v12}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    .line 1347
    :cond_1
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    invoke-direct {v12, v13}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v13, 0x1

    .line 1348
    invoke-virtual {v12, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v13, 0x11

    .line 1349
    invoke-virtual {v12, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1350
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    aget-object v14, v2, v7

    if-eqz p5, :cond_2

    const v15, 0x7f080004

    :goto_2
    move/from16 v6, p7

    goto :goto_3

    :cond_2
    const v15, 0x7f080003

    goto :goto_2

    :goto_3
    invoke-static {v13, v14, v6, v15}, Lp20;->l(Landroid/content/Context;Ljava/lang/String;FI)Lcom/zayon/optimize/ui/ZyTextView;

    move-result-object v13

    .line 1351
    invoke-virtual {v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    if-eqz p4, :cond_3

    .line 1352
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v14

    aget-object v15, p4, v7

    const/high16 v8, 0x41100000    # 9.0f

    const v2, 0x7f080002

    invoke-static {v14, v15, v8, v2}, Lp20;->l(Landroid/content/Context;Ljava/lang/String;FI)Lcom/zayon/optimize/ui/ZyTextView;

    move-result-object v2

    const v8, 0x3d75c28f    # 0.06f

    .line 1353
    invoke-virtual {v2, v8}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1354
    iget v8, v1, Lp20;->m0:I

    invoke-virtual {v2, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1355
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    invoke-direct {v8, v14, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1356
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v14

    iput v14, v8, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1357
    invoke-virtual {v12, v2, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1358
    :cond_3
    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/4 v8, -0x1

    invoke-direct {v2, v8, v8}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v12, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1359
    new-instance v2, Lo20;

    move-object/from16 v8, p9

    const/4 v12, 0x0

    invoke-direct {v2, v0, v7, v8, v12}, Lo20;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v9, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1360
    invoke-virtual {v3, v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1361
    iget-object v2, v0, La90;->i:Ljava/lang/Object;

    check-cast v2, [Lcom/zayon/optimize/ui/ZyBox;

    aput-object v9, v2, v7

    .line 1362
    iget-object v2, v0, La90;->j:Ljava/lang/Object;

    check-cast v2, [Landroid/widget/TextView;

    aput-object v13, v2, v7

    add-int/lit8 v7, v7, 0x1

    move-object/from16 v2, p3

    move v6, v12

    goto/16 :goto_1

    :cond_4
    const/4 v2, -0x1

    .line 1363
    invoke-virtual {v0, v2}, La90;->i(I)V

    return-void
.end method

.method public constructor <init>(Lqy3;Lzy2;Ley2;Lry2;)V
    .locals 1

    const/16 v0, 0x19

    iput v0, p0, La90;->h:I

    .line 1275
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_0

    invoke-static {p1}, Lmx3;->n(Ljava/util/Collection;)Lmx3;

    move-result-object p1

    goto :goto_0

    :cond_0
    sget-object p1, Lmx3;->i:Lix3;

    .line 1276
    sget-object p1, Lqy3;->l:Lqy3;

    .line 1277
    :goto_0
    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    iput-object p2, p0, La90;->j:Ljava/lang/Object;

    iput-object p3, p0, La90;->k:Ljava/lang/Object;

    iput-object p4, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lrs1;Ljava/util/concurrent/PriorityBlockingQueue;Ls93;)V
    .locals 1

    const/16 v0, 0xb

    iput v0, p0, La90;->h:I

    .line 1273
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    iput-object p3, p0, La90;->l:Ljava/lang/Object;

    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    iput-object p2, p0, La90;->k:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ly64;)V
    .locals 2

    const/16 v0, 0x1b

    iput v0, p0, La90;->h:I

    .line 1278
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    .line 1279
    iget-object v1, p1, Ly64;->a:Ljava/util/HashMap;

    .line 1280
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    .line 1281
    iget-object v1, p1, Ly64;->b:Ljava/util/HashMap;

    .line 1282
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, La90;->j:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    .line 1283
    iget-object v1, p1, Ly64;->c:Ljava/util/HashMap;

    .line 1284
    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, La90;->k:Ljava/lang/Object;

    new-instance v0, Ljava/util/HashMap;

    .line 1285
    iget-object p1, p1, Ly64;->d:Ljava/util/HashMap;

    .line 1286
    invoke-direct {v0, p1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    iput-object v0, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lz40;Lfl;Landroid/content/ComponentName;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, La90;->h:I

    .line 1322
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1323
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, La90;->i:Ljava/lang/Object;

    .line 1324
    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    .line 1325
    iput-object p2, p0, La90;->k:Ljava/lang/Object;

    .line 1326
    iput-object p3, p0, La90;->l:Ljava/lang/Object;

    return-void
.end method

.method public static final B(Landroid/content/Context;)Z
    .locals 1

    sget-object v0, Lw62;->c:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    move-object p0, v0

    :goto_0
    invoke-static {p0}, Lzu4;->H(Landroid/content/Context;)Ldw2;

    move-result-object p0

    iget-object p0, p0, Ldw2;->i:Ljava/lang/String;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "ru"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public static declared-synchronized c(Landroid/content/Context;)La90;
    .locals 2

    const-class v0, La90;

    monitor-enter v0

    :try_start_0
    sget-object v1, La90;->m:La90;

    if-nez v1, :cond_0

    new-instance v1, La90;

    invoke-direct {v1, p0}, La90;-><init>(Landroid/content/Context;)V

    sput-object v1, La90;->m:La90;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0

    return-object v1

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static k(Ljava/io/Reader;Landroid/os/Bundle;)La90;
    .locals 2

    :try_start_0
    new-instance v0, La90;

    new-instance v1, Landroid/util/JsonReader;

    invoke-direct {v1, p0}, Landroid/util/JsonReader;-><init>(Ljava/io/Reader;)V

    invoke-direct {v0, v1, p1}, La90;-><init>(Landroid/util/JsonReader;Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/AssertionError; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {p0}, Lgx1;->d(Ljava/io/Closeable;)V

    return-object v0

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_0

    :catch_1
    move-exception p1

    goto :goto_0

    :catch_2
    move-exception p1

    goto :goto_0

    :catch_3
    move-exception p1

    goto :goto_0

    :catch_4
    move-exception p1

    :goto_0
    :try_start_1
    new-instance v0, Leg3;

    const-string v1, "unable to parse ServerResponse"

    invoke-direct {v0, v1, p1}, Lx43;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    invoke-static {p0}, Lgx1;->d(Ljava/io/Closeable;)V

    throw p1
.end method

.method private final p(Ljava/lang/Throwable;)V
    .locals 0

    return-void
.end method


# virtual methods
.method public A()Lec4;
    .locals 6

    sget-object v0, Lm24;->m:Lm24;

    iget-object v1, p0, La90;->i:Ljava/lang/Object;

    check-cast v1, Lc34;

    const/4 v2, 0x0

    if-eqz v1, :cond_8

    iget-object v3, p0, La90;->j:Ljava/lang/Object;

    check-cast v3, Ldc4;

    if-eqz v3, :cond_7

    iget-object v4, p0, La90;->k:Ljava/lang/Object;

    check-cast v4, Lm24;

    if-eqz v4, :cond_6

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Ld34;

    sget-object v5, Ldc4;->c:Ldc4;

    if-ne v3, v5, :cond_1

    sget-object v5, Lm24;->k:Lm24;

    if-ne v4, v5, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "NIST_P256 requires SHA256"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2

    :cond_1
    :goto_0
    sget-object v5, Ldc4;->d:Ldc4;

    if-ne v3, v5, :cond_3

    sget-object v5, Lm24;->l:Lm24;

    if-eq v4, v5, :cond_3

    if-ne v4, v0, :cond_2

    goto :goto_1

    :cond_2
    const-string p0, "NIST_P384 requires SHA384 or SHA512"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2

    :cond_3
    :goto_1
    sget-object v5, Ldc4;->e:Ldc4;

    if-ne v3, v5, :cond_5

    if-ne v4, v0, :cond_4

    goto :goto_2

    :cond_4
    const-string p0, "NIST_P521 requires SHA512"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2

    :cond_5
    :goto_2
    new-instance v0, Lec4;

    invoke-direct {v0, v1, v3, v4, p0}, Lec4;-><init>(Lc34;Ldc4;Lm24;Ld34;)V

    return-object v0

    :cond_6
    const-string p0, "hash type is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2

    :cond_7
    const-string p0, "EC curve type is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2

    :cond_8
    const-string p0, "signature encoding is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v2
.end method

.method public C()Ljava/lang/String;
    .locals 2

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lu02;

    iget p0, p0, Lu02;->h:I

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x6

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "LATMTD"

    invoke-static {p0, v0, v1}, Loj;->i(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public D(Ljava/lang/Throwable;)V
    .locals 11

    iget v0, p0, La90;->h:I

    const/4 v1, 0x0

    sparse-switch v0, :sswitch_data_0

    iget-object p1, p0, La90;->i:Ljava/lang/Object;

    check-cast p1, Lji3;

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {p1, v1}, Lji3;->b(Z)Lji3;

    iget-object v0, p0, La90;->j:Ljava/lang/Object;

    check-cast v0, Lmi3;

    if-nez v0, :cond_1

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lsj3;

    invoke-interface {p1}, Lji3;->n()Lli3;

    move-result-object p1

    iget-object p0, p0, Lsj3;->f:Lni3;

    invoke-virtual {p0, p1}, Lni3;->b(Lli3;)V

    goto :goto_0

    :cond_1
    invoke-virtual {v0, p1}, Lmi3;->a(Lji3;)V

    invoke-virtual {v0}, Lmi3;->h()V

    :goto_0
    return-void

    :sswitch_0
    sget-object v0, Lk52;->P6:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {}, Lj23;->b()Z

    :cond_2
    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lye3;

    monitor-enter v2

    :try_start_0
    iget-object v0, p0, La90;->k:Ljava/lang/Object;

    check-cast v0, Lyn2;

    iget-object v3, v0, Lyn2;->t:Lsk4;

    invoke-virtual {v3}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lps2;

    iget-object v3, v3, Lps2;->l:Lp73;

    invoke-static {p1, v3}, Lic1;->s(Ljava/lang/Throwable;Lp73;)Lh23;

    move-result-object v3

    iput-object v3, v2, Lye3;->n:Lh23;

    iget-object v0, v0, Lyn2;->m:Lsk4;

    invoke-virtual {v0}, Lsk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lau2;

    invoke-virtual {v0, v3}, Lau2;->X0(Lh23;)V

    iget v0, v3, Lh23;->h:I

    const-string v4, "BannerAdLoader.onFailure"

    invoke-static {v0, p1, v4}, Ltb1;->q(ILjava/lang/Throwable;Ljava/lang/String;)V

    iget-boolean v0, v2, Lye3;->m:Z

    if-eqz v0, :cond_3

    invoke-virtual {v2}, Lye3;->e()V

    iget-object v0, v2, Lye3;->h:Lcv2;

    iget-object v4, v2, Lye3;->j:Lpv2;

    monitor-enter v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget v5, v4, Lpv2;->h:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    monitor-exit v4

    invoke-virtual {v0, v5}, Lcv2;->X1(I)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_3

    :catchall_1
    move-exception v0

    move-object p0, v0

    :try_start_3
    monitor-exit v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    throw p0

    :cond_3
    :goto_1
    sget-object v0, Ll62;->c:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lmi3;

    if-eqz v0, :cond_4

    invoke-virtual {v0, v3}, Lmi3;->f(Lh23;)V

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Lji3;

    invoke-interface {p0, p1}, Lji3;->g(Ljava/lang/Throwable;)Lji3;

    invoke-interface {p0, v1}, Lji3;->b(Z)Lji3;

    invoke-virtual {v0, p0}, Lmi3;->a(Lji3;)V

    invoke-virtual {v0}, Lmi3;->h()V

    goto :goto_2

    :cond_4
    iget-object v0, v2, Lye3;->i:Lni3;

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Lji3;

    invoke-interface {p0, v3}, Lji3;->h(Lh23;)Lji3;

    invoke-interface {p0, p1}, Lji3;->g(Ljava/lang/Throwable;)Lji3;

    invoke-interface {p0, v1}, Lji3;->b(Z)Lji3;

    invoke-interface {p0}, Lji3;->n()Lli3;

    move-result-object p0

    invoke-virtual {v0, p0}, Lni3;->b(Lli3;)V

    :goto_2
    monitor-exit v2

    return-void

    :goto_3
    monitor-exit v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p0

    :sswitch_1
    return-void

    :sswitch_2
    new-instance v3, Lra1;

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    move-object v6, v0

    check-cast v6, Lsj3;

    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    move-object v7, v0

    check-cast v7, Ljava/lang/String;

    iget-object v0, p0, La90;->j:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Lco2;

    const/4 v9, 0x3

    const/4 v10, 0x0

    move-object v4, p0

    move-object v5, p1

    invoke-direct/range {v3 .. v10}, Lra1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    iget-object p0, v4, La90;->k:Ljava/lang/Object;

    check-cast p0, Lkp2;

    iget-object p0, p0, Lkp2;->e:Lzi2;

    invoke-virtual {p0, v3}, Lzi2;->a(Ljava/lang/Runnable;)Lna0;

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0xf -> :sswitch_2
        0x11 -> :sswitch_1
        0x15 -> :sswitch_0
    .end sparse-switch
.end method

.method public a()Ljava/util/concurrent/Executor;
    .locals 0

    .line 24
    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Ljava/util/concurrent/Executor;

    return-object p0
.end method

.method public synthetic a()V
    .locals 3

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lp93;

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Lkg3;

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, Lbg3;

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Ln73;

    iget-object v0, v0, Lp93;->e:Ljava/lang/Object;

    check-cast v0, Lq73;

    invoke-interface {v0, v1, v2, p0}, Lq73;->a(Lkg3;Lbg3;Ln73;)V

    return-void
.end method

.method public b(Ljava/lang/String;Lorg/json/JSONObject;)Z
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    iget-object v3, v0, La90;->j:Ljava/lang/Object;

    check-cast v3, Lrq1;

    iget-object v4, v0, La90;->i:Ljava/lang/Object;

    check-cast v4, Landroid/app/Application;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v5

    const v6, 0x5a5b64d

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v5, v6, :cond_23

    const v6, 0x6c257df

    if-eq v5, v6, :cond_0

    goto/16 :goto_14

    :cond_0
    const-string v5, "write"

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    new-instance v1, Lwp2;

    invoke-direct {v1, v4}, Lwp2;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    iget-object v6, v1, Lwp2;->c:Ljava/util/HashMap;

    iget-object v9, v1, Lwp2;->a:Ljava/util/HashMap;

    if-eqz v5, :cond_a

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    iget-object v11, v1, Lwp2;->b:Landroid/content/Context;

    invoke-static {v11, v5}, Lgx1;->t(Landroid/content/Context;Ljava/lang/String;)Lxt3;

    move-result-object v12

    if-nez v12, :cond_1

    goto/16 :goto_2

    :cond_1
    iget-object v13, v12, Lxt3;->i:Ljava/lang/Object;

    check-cast v13, Ljava/lang/String;

    iget-object v12, v12, Lxt3;->h:Ljava/lang/Object;

    check-cast v12, Ljava/lang/String;

    invoke-virtual {v6, v12}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_2

    invoke-virtual {v11, v12, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-virtual {v6, v12, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    invoke-virtual {v6, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/SharedPreferences$Editor;

    instance-of v11, v10, Ljava/lang/Integer;

    if-eqz v11, :cond_3

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-interface {v6, v13, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    sget-object v6, Lwp2;->d:Ln03;

    invoke-virtual {v6, v13}, Lac1;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_8

    invoke-virtual {v9, v13, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_3
    instance-of v9, v10, Ljava/lang/Long;

    if-eqz v9, :cond_4

    check-cast v10, Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    invoke-interface {v6, v13, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    goto :goto_1

    :cond_4
    instance-of v9, v10, Ljava/lang/Double;

    if-eqz v9, :cond_5

    check-cast v10, Ljava/lang/Double;

    invoke-virtual {v10}, Ljava/lang/Double;->floatValue()F

    move-result v9

    invoke-interface {v6, v13, v9}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    goto :goto_1

    :cond_5
    instance-of v9, v10, Ljava/lang/Float;

    if-eqz v9, :cond_6

    check-cast v10, Ljava/lang/Float;

    invoke-virtual {v10}, Ljava/lang/Float;->floatValue()F

    move-result v9

    invoke-interface {v6, v13, v9}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    goto :goto_1

    :cond_6
    instance-of v9, v10, Ljava/lang/Boolean;

    if-eqz v9, :cond_7

    check-cast v10, Ljava/lang/Boolean;

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    invoke-interface {v6, v13, v9}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    goto :goto_1

    :cond_7
    instance-of v9, v10, Ljava/lang/String;

    if-eqz v9, :cond_9

    check-cast v10, Ljava/lang/String;

    invoke-interface {v6, v13, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :cond_8
    :goto_1
    iget-object v6, v3, Lrq1;->c:Ljava/util/HashSet;

    invoke-virtual {v6, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_9
    :goto_2
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "Failed writing key: "

    invoke-virtual {v6, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    goto/16 :goto_0

    :cond_a
    iget-object v1, v3, Lrq1;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "written_values"

    iget-object v3, v3, Lrq1;->c:Ljava/util/HashSet;

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    invoke-virtual {v6}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_b

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences$Editor;

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_3

    :cond_b
    invoke-virtual {v9}, Ljava/util/HashMap;->size()I

    move-result v1

    if-le v1, v8, :cond_22

    iget-object v0, v0, La90;->k:Ljava/lang/Object;

    check-cast v0, Lko4;

    iget-object v1, v0, Lko4;->a:Lqn1;

    const-string v2, "valueOf"

    iget-object v3, v1, Lqn1;->g:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v4, v1, Lqn1;->f:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v5, v1, Lqn1;->e:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v6, v1, Lqn1;->d:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v10, v1, Lqn1;->c:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v11, v1, Lqn1;->b:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v12

    const/4 v13, 0x0

    if-eqz v12, :cond_c

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    goto :goto_4

    :cond_c
    iget-object v1, v1, Lqn1;->a:Landroid/content/Context;

    if-nez v1, :cond_d

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    goto :goto_4

    :cond_d
    :try_start_0
    const-string v12, "com.google.firebase.analytics.FirebaseAnalytics"

    invoke-static {v12}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v12

    const-string v14, "getInstance"

    const-class v15, Landroid/content/Context;

    filled-new-array {v15}, [Ljava/lang/Class;

    move-result-object v15

    invoke-virtual {v12, v14, v15}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v14

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v14, v13, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v11, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const-string v1, "setConsent"

    const-class v14, Ljava/util/Map;

    filled-new-array {v14}, [Ljava/lang/Class;

    move-result-object v14

    invoke-virtual {v12, v1, v14}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    invoke-virtual {v10, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const-string v1, "com.google.firebase.analytics.FirebaseAnalytics$ConsentStatus"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const-string v12, "com.google.firebase.analytics.FirebaseAnalytics$ConsentType"

    invoke-static {v12}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v12

    const-class v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/Class;

    move-result-object v15

    invoke-virtual {v1, v2, v15}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    filled-new-array {v14}, [Ljava/lang/Class;

    move-result-object v14

    invoke-virtual {v12, v2, v14}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    invoke-virtual {v6, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-virtual {v5, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v3, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    move v7, v8

    goto :goto_4

    :catch_0
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :goto_4
    if-nez v7, :cond_e

    goto/16 :goto_d

    :cond_e
    iget-object v0, v0, Lko4;->b:Landroid/content/Context;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_f

    :try_start_1
    invoke-static {v0}, Ljb1;->a(Landroid/content/Context;)Lgl0;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x80

    invoke-virtual {v1, v2, v0}, Lgl0;->a(ILjava/lang/String;)Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_f
    const-string v0, "IABTCF_gdprApplies"

    invoke-virtual {v9, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v9}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_10
    :goto_5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_1e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_10

    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    move-result v12

    const-string v14, "AD_PERSONALIZATION"

    const-string v15, "AD_USER_DATA"

    sparse-switch v12, :sswitch_data_0

    :cond_11
    move-object/from16 p1, v0

    move-object/from16 p2, v1

    goto :goto_8

    :sswitch_0
    const-string v12, "UMP_CoMoAdUserDataPurposeConsentStatus"

    invoke-virtual {v7, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_11

    const-string v12, "google_analytics_default_allow_ad_user_data"

    move-object v13, v15

    goto :goto_7

    :sswitch_1
    const-string v12, "UMP_CoMoAdStoragePurposeConsentStatus"

    invoke-virtual {v7, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_11

    const-string v12, "google_analytics_default_allow_ad_storage"

    const-string v16, "AD_STORAGE"

    :goto_6
    move-object/from16 v13, v16

    goto :goto_7

    :sswitch_2
    const-string v12, "UMP_CoMoAnalyticsStoragePurposeConsentStatus"

    invoke-virtual {v7, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_11

    const-string v12, "google_analytics_default_allow_analytics_storage"

    const-string v16, "ANALYTICS_STORAGE"

    goto :goto_6

    :sswitch_3
    const-string v12, "UMP_CoMoAdPersonalizationPurposeConsentStatus"

    invoke-virtual {v7, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_11

    const-string v12, "google_analytics_default_allow_ad_personalization_signals"

    move-object v13, v14

    :goto_7
    invoke-virtual {v9, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    move-object/from16 p1, v0

    const-string v0, "GRANTED"

    if-eq v7, v8, :cond_1d

    const/4 v8, 0x2

    move-object/from16 p2, v1

    const-string v1, "DENIED"

    if-eq v7, v8, :cond_1c

    const/4 v8, 0x5

    if-eq v7, v8, :cond_13

    :cond_12
    :goto_8
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    :goto_9
    const/4 v8, 0x1

    const/4 v13, 0x0

    goto :goto_5

    :cond_13
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v7

    if-nez v7, :cond_14

    goto :goto_a

    :cond_14
    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/os/Bundle;

    invoke-virtual {v7, v12}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_16

    instance-of v8, v7, Ljava/lang/Boolean;

    if-eqz v8, :cond_15

    check-cast v7, Ljava/lang/Boolean;

    goto :goto_b

    :cond_15
    instance-of v8, v7, Ljava/lang/String;

    if-eqz v8, :cond_16

    check-cast v7, Ljava/lang/String;

    goto :goto_b

    :cond_16
    :goto_a
    const/4 v7, 0x0

    :goto_b
    if-nez v7, :cond_17

    goto :goto_8

    :cond_17
    instance-of v8, v7, Ljava/lang/Boolean;

    if-eqz v8, :cond_19

    check-cast v7, Ljava/lang/Boolean;

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    const/4 v8, 0x1

    if-eq v8, v7, :cond_18

    move-object v0, v1

    :cond_18
    invoke-virtual {v2, v13, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_8

    :cond_19
    instance-of v8, v7, Ljava/lang/String;

    if-eqz v8, :cond_12

    const-string v8, "eu_consent_policy"

    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_12

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_1a

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_12

    :cond_1a
    if-eqz p2, :cond_12

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const/4 v8, 0x1

    if-ne v7, v8, :cond_1b

    move-object v0, v1

    :cond_1b
    invoke-virtual {v2, v13, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_8

    :cond_1c
    invoke-virtual {v2, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_8

    :cond_1d
    move-object/from16 p2, v1

    invoke-virtual {v2, v13, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v0, p1

    goto :goto_9

    :cond_1e
    const-string v0, "Update Firebase: "

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v2}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :catch_2
    :goto_c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    :try_start_2
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/reflect/Method;

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v7
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    const/4 v8, 0x0

    :try_start_3
    invoke-virtual {v4, v8, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :try_start_4
    check-cast v4, Ljava/lang/Enum;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/reflect/Method;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    const/4 v8, 0x0

    :try_start_5
    invoke-virtual {v7, v8, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Enum;

    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    goto :goto_c

    :catch_3
    const/4 v8, 0x0

    goto :goto_c

    :cond_1f
    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_21

    invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_20

    goto :goto_d

    :cond_20
    :try_start_6
    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/reflect/Method;

    invoke-virtual {v11}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v1, v2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    :catch_4
    :cond_21
    :goto_d
    invoke-virtual {v9}, Ljava/util/HashMap;->clear()V

    const/16 v16, 0x1

    return v16

    :cond_22
    move/from16 v16, v8

    goto/16 :goto_12

    :cond_23
    const-string v0, "clear"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2c

    const-string v0, "keys"

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    if-eqz v0, :cond_24

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-nez v1, :cond_25

    :cond_24
    const/16 v16, 0x1

    goto/16 :goto_13

    :cond_25
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    move v3, v7

    :goto_e
    if-ge v3, v2, :cond_27

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->optString(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_26

    goto :goto_f

    :cond_26
    invoke-virtual {v1, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :goto_f
    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    :cond_27
    new-instance v0, Lwp2;

    invoke-direct {v0, v4}, Lwp2;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    iget-object v3, v0, Lwp2;->c:Ljava/util/HashMap;

    if-eqz v2, :cond_2a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v4, v2}, Lgx1;->t(Landroid/content/Context;Ljava/lang/String;)Lxt3;

    move-result-object v5

    if-nez v5, :cond_28

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "clearKeys: unable to process key: "

    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    goto :goto_10

    :cond_28
    iget-object v2, v5, Lxt3;->h:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_29

    iget-object v6, v0, Lwp2;->b:Landroid/content/Context;

    invoke-virtual {v6, v2, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-virtual {v3, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_29
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences$Editor;

    iget-object v3, v5, Lxt3;->i:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_10

    :cond_2a
    invoke-virtual {v3}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2b

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/SharedPreferences$Editor;

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_11

    :cond_2b
    const/16 v16, 0x1

    :goto_12
    return v16

    :goto_13
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "Action[clear]: wrong args."

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    return v16

    :cond_2c
    :goto_14
    return v7

    :sswitch_data_0
    .sparse-switch
        -0x72d36826 -> :sswitch_3
        -0x883f808 -> :sswitch_2
        0x3fb31ab1 -> :sswitch_1
        0x582c6f7b -> :sswitch_0
    .end sparse-switch
.end method

.method public bridge synthetic d()Ljava/lang/Object;
    .locals 4

    iget v0, p0, La90;->h:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lgw4;

    invoke-virtual {v0}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lrq1;

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Lyn0;

    invoke-virtual {v1}, Lyn0;->c()Lsj1;

    move-result-object v1

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, Lgw4;

    invoke-virtual {v2}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lh92;

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lgw4;

    invoke-virtual {p0}, Lgw4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Leo2;

    new-instance v3, Lml4;

    invoke-direct {v3, v0, v1, v2, p0}, Lml4;-><init>(Lrq1;Lsj1;Lh92;Leo2;)V

    return-object v3

    :pswitch_0
    invoke-virtual {p0}, La90;->m()Lgv4;

    move-result-object p0

    return-object p0

    :pswitch_data_0
    .packed-switch 0x9
        :pswitch_0
    .end packed-switch
.end method

.method public e(Z)V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    iget-object p0, p0, La90;->k:Ljava/lang/Object;

    check-cast p0, Ljava/util/ArrayList;

    invoke-direct {v0, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p0, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    check-cast v2, Lz80;

    invoke-interface {v2, p1}, Lz80;->a(Z)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public f(Ljava/lang/String;)V
    .locals 3

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, La90;->i:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v2, p0, La90;->j:Ljava/lang/Object;

    check-cast v2, Lz40;

    iget-object p0, p0, La90;->k:Ljava/lang/Object;

    check-cast p0, Lfl;

    check-cast v2, Lx40;

    invoke-virtual {v2, p0, p1, v0}, Lx40;->W(Lfl;Ljava/lang/String;Landroid/os/Bundle;)I
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    monitor-exit v1

    return-void

    :catchall_0
    move-exception p0

    goto :goto_0

    :catch_0
    monitor-exit v1

    return-void

    :goto_0
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public g(Lj00;)V
    .locals 5

    iget-object v0, p0, La90;->j:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    :goto_0
    if-ltz v1, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {p1, v4}, Lj00;->a(Ljava/lang/String;)Ld00;

    move-result-object v4

    if-nez v4, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move v3, v2

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_1
    iget-object p1, p0, La90;->l:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2

    const/4 p1, 0x0

    goto :goto_1

    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    :goto_1
    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    move v3, v2

    :cond_3
    if-eqz v3, :cond_4

    invoke-virtual {p0}, La90;->h()V

    invoke-virtual {p0, v2}, La90;->e(Z)V

    :cond_4
    return-void
.end method

.method public h()V
    .locals 3

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    const-string v2, ","

    invoke-static {v2, v1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "lib"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v1, "hero"

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public i(I)V
    .locals 8

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, [Lcom/zayon/optimize/ui/ZyBox;

    iget-object v1, p0, La90;->l:Ljava/lang/Object;

    check-cast v1, Lp20;

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, [Z

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    array-length v5, v0

    if-ge v4, v5, :cond_5

    if-ne v4, p1, :cond_0

    aget-boolean v5, v2, v4

    if-nez v5, :cond_0

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    move v5, v3

    :goto_1
    aget-object v6, v0, v4

    if-eqz v5, :cond_1

    iget v7, v1, Lp20;->b0:I

    goto :goto_2

    :cond_1
    move v7, v3

    :goto_2
    invoke-virtual {v6, v7}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    aget-object v6, v0, v4

    aget-boolean v7, v2, v4

    if-eqz v7, :cond_2

    const v7, 0x3ecccccd    # 0.4f

    goto :goto_3

    :cond_2
    const/high16 v7, 0x3f800000    # 1.0f

    :goto_3
    invoke-virtual {v6, v7}, Landroid/view/View;->setAlpha(F)V

    iget-object v6, p0, La90;->j:Ljava/lang/Object;

    check-cast v6, [Landroid/widget/TextView;

    aget-object v6, v6, v4

    aget-boolean v7, v2, v4

    if-eqz v7, :cond_3

    iget v5, v1, Lp20;->f0:I

    goto :goto_4

    :cond_3
    if-eqz v5, :cond_4

    iget v5, v1, Lp20;->a0:I

    goto :goto_4

    :cond_4
    iget v5, v1, Lp20;->e0:I

    :goto_4
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setTextColor(I)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_5
    return-void
.end method

.method public j(Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v4, 0xa

    if-lt v3, v4, :cond_0

    return-void

    :cond_0
    if-eqz v2, :cond_2

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v2, p0, La90;->l:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    add-int/lit8 p1, p1, -0x1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    :goto_0
    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    goto :goto_1

    :cond_2
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iput-object p1, p0, La90;->l:Ljava/lang/Object;

    :cond_3
    :goto_1
    invoke-virtual {p0}, La90;->h()V

    iget-object p1, p0, La90;->l:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    invoke-virtual {p0, p1}, La90;->e(Z)V

    return-void
.end method

.method public l(Landroid/content/Context;Lw61;Lni3;)Lvb2;
    .locals 4

    iget-object v0, p0, La90;->j:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La90;->l:Ljava/lang/Object;

    check-cast v1, Lvb2;

    if-nez v1, :cond_2

    new-instance v1, Lvb2;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    if-nez v2, :cond_0

    move-object v2, p1

    :cond_0
    invoke-static {p1}, La90;->B(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_1

    sget-object p1, Lk52;->c:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v3, v3, Lvx1;->c:Li52;

    invoke-virtual {v3, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    sget-object p1, Lb64;->h:Lht1;

    invoke-virtual {p1}, Lht1;->v()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    :goto_0
    invoke-direct {v1, v2, p2, p1, p3}, Lvb2;-><init>(Landroid/content/Context;Lw61;Ljava/lang/String;Lni3;)V

    iput-object v1, p0, La90;->l:Ljava/lang/Object;

    :cond_2
    monitor-exit v0

    return-object v1

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public m()Lgv4;
    .locals 4

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lgw4;

    invoke-virtual {v0}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ld23;

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Lsp1;

    invoke-virtual {v1}, Lsp1;->a()La90;

    move-result-object v1

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, Lgw4;

    invoke-virtual {v2}, Lgw4;->d()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lrq1;

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lgw4;

    invoke-virtual {p0}, Lgw4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Leo2;

    new-instance v3, Lgv4;

    invoke-direct {v3, v0, v1, v2, p0}, Lgv4;-><init>(Ld23;La90;Lrq1;Leo2;)V

    return-object v3
.end method

.method public n(I)V
    .locals 1

    const/16 v0, 0x10

    if-eq p1, v0, :cond_1

    const/16 v0, 0x18

    if-eq p1, v0, :cond_1

    const/16 v0, 0x20

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/security/InvalidAlgorithmParameterException;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Invalid key size %d; only 16-byte, 24-byte and 32-byte AES keys are supported"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, La90;->i:Ljava/lang/Object;

    return-void
.end method

.method public o(Lv02;Ljs;)Z
    .locals 8

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1}, Lv02;->z()Lyf4;

    move-result-object v1

    invoke-virtual {v1}, Lyf4;->b()[B

    move-result-object v1

    invoke-virtual {p1}, Lv02;->A()Lyf4;

    move-result-object v2

    invoke-virtual {v2}, Lyf4;->b()[B

    move-result-object v2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v4, 0x0

    if-nez v3, :cond_b

    array-length v3, v2

    if-nez v3, :cond_0

    goto/16 :goto_4

    :cond_0
    iget-object v3, p0, La90;->k:Ljava/lang/Object;

    check-cast v3, Ljava/io/File;

    invoke-static {v3}, Ly91;->V(Ljava/io/File;)Z

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    invoke-static {v3, v0}, Ly91;->R(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    move-result-object v5

    invoke-virtual {v5}, Ljava/io/File;->mkdirs()Z

    const-string v5, "pcam.jar"

    invoke-static {v0, v5, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v6

    array-length v7, v1

    if-lez v7, :cond_1

    invoke-static {v6, v1}, Ly91;->Q(Ljava/io/File;[B)Z

    move-result v1

    if-eqz v1, :cond_b

    :cond_1
    const-string v1, "pcbc"

    invoke-static {v0, v1, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    invoke-static {v0, v2}, Ly91;->Q(Ljava/io/File;[B)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v5, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_2

    if-eqz p2, :cond_2

    :try_start_0
    invoke-static {v0}, Lbm3;->a(Ljava/io/File;)Z

    move-result p2
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move p2, v4

    :goto_0
    if-nez p2, :cond_2

    goto/16 :goto_4

    :cond_2
    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object p2

    invoke-virtual {p2}, Ld12;->y()Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_4

    :cond_3
    :goto_1
    move p1, v4

    goto/16 :goto_2

    :cond_4
    invoke-static {p2, v5, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v0

    invoke-static {p2, v1, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v3

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v6

    invoke-static {p2, v5, v6}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v5

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v6

    invoke-static {p2, v1, v6}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object p2

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-virtual {v0, v5}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_1

    :cond_5
    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v3, p2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p2

    if-eqz p2, :cond_3

    invoke-static {}, Ld12;->F()Lc12;

    move-result-object p2

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lkg4;->c()V

    iget-object v1, p2, Lkg4;->i:Lng4;

    check-cast v1, Ld12;

    invoke-virtual {v1, v0}, Ld12;->H(Ljava/lang/String;)V

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->z()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lkg4;->c()V

    iget-object v1, p2, Lkg4;->i:Lng4;

    check-cast v1, Ld12;

    invoke-virtual {v1, v0}, Ld12;->I(Ljava/lang/String;)V

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->B()J

    move-result-wide v0

    invoke-virtual {p2}, Lkg4;->c()V

    iget-object v3, p2, Lkg4;->i:Lng4;

    check-cast v3, Ld12;

    invoke-virtual {v3, v0, v1}, Ld12;->K(J)V

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object v0

    invoke-virtual {v0}, Ld12;->C()J

    move-result-wide v0

    invoke-virtual {p2}, Lkg4;->c()V

    iget-object v3, p2, Lkg4;->i:Lng4;

    check-cast v3, Ld12;

    invoke-virtual {v3, v0, v1}, Ld12;->L(J)V

    invoke-virtual {p1}, Lv02;->y()Ld12;

    move-result-object p1

    invoke-virtual {p1}, Ld12;->A()J

    move-result-wide v0

    invoke-virtual {p2}, Lkg4;->c()V

    iget-object p1, p2, Lkg4;->i:Lng4;

    check-cast p1, Ld12;

    invoke-virtual {p1, v0, v1}, Ld12;->J(J)V

    invoke-virtual {p2}, Lkg4;->d()Lng4;

    move-result-object p1

    check-cast p1, Ld12;

    invoke-virtual {p0, v2}, La90;->u(I)Ld12;

    move-result-object p2

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    if-eqz p2, :cond_6

    invoke-virtual {p1}, Ld12;->y()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2}, Ld12;->y()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {p0}, La90;->y()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2}, Lqf4;->b()[B

    move-result-object p2

    invoke-static {p2}, Lgx1;->b([B)Ljava/lang/String;

    move-result-object p2

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :cond_6
    invoke-virtual {p0}, La90;->C()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, Lqf4;->b()[B

    move-result-object p1

    invoke-static {p1}, Lgx1;->b([B)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result p1

    if-eqz p1, :cond_3

    move p1, v2

    :goto_2
    new-instance p2, Ljava/util/HashSet;

    invoke-direct {p2}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v2}, La90;->u(I)Ld12;

    move-result-object v0

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_7
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, La90;->u(I)Ld12;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_8
    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    array-length v1, v0

    :goto_3
    if-ge v4, v1, :cond_a

    aget-object v2, v0, v4

    invoke-virtual {v2}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v3

    invoke-static {v3, v2}, Ly91;->R(Ljava/io/File;Ljava/lang/String;)Ljava/io/File;

    move-result-object v2

    invoke-static {v2}, Ly91;->V(Ljava/io/File;)Z

    :cond_9
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_a
    return p1

    :cond_b
    :goto_4
    return v4
.end method

.method public onCancel()V
    .locals 2

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    iget-object v1, p0, La90;->j:Ljava/lang/Object;

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    iget-object v0, p0, La90;->k:Ljava/lang/Object;

    check-cast v0, Ldp;

    invoke-virtual {v0}, Lg7;->e()V

    const/4 v0, 0x2

    invoke-static {v0}, Lhy;->F(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lfz0;

    invoke-static {p0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    :cond_0
    return-void
.end method

.method public q(Ljava/lang/Object;)V
    .locals 13

    iget v0, p0, La90;->h:I

    const/4 v1, 0x1

    sparse-switch v0, :sswitch_data_0

    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    check-cast v0, Lsj3;

    iget-object v2, p0, La90;->i:Ljava/lang/Object;

    check-cast v2, Lji3;

    check-cast p1, Lyv4;

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    sget-object v4, Lyv4;->h:Lyv4;

    if-ne p1, v4, :cond_0

    move p1, v1

    goto :goto_0

    :cond_0
    move p1, v3

    :goto_0
    invoke-interface {v2, p1}, Lji3;->b(Z)Lji3;

    iget-object p1, p0, La90;->j:Ljava/lang/Object;

    check-cast p1, Lmi3;

    if-nez p1, :cond_1

    invoke-interface {v2}, Lji3;->n()Lli3;

    move-result-object p1

    iget-object v2, v0, Lsj3;->f:Lni3;

    invoke-virtual {v2, p1}, Lni3;->b(Lli3;)V

    goto :goto_1

    :cond_1
    invoke-virtual {p1, v2}, Lmi3;->a(Lji3;)V

    invoke-virtual {p1}, Lmi3;->h()V

    :cond_2
    :goto_1
    iget-object p0, p0, La90;->k:Ljava/lang/Object;

    check-cast p0, Lxu2;

    if-eqz p0, :cond_e

    iget-object p1, v0, Lsj3;->d:Ltw4;

    iget-object p1, p1, Ltw4;->j:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto/16 :goto_8

    :cond_3
    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "type"

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v2, "precision"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "currency"

    invoke-virtual {v0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v4, "value"

    const-wide/16 v5, 0x0

    invoke-virtual {v0, v4, v5, v6}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const v6, 0x10576

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eq v0, v6, :cond_6

    const v6, 0x10580

    if-eq v0, v6, :cond_5

    const v6, 0x506e232d

    if-eq v0, v6, :cond_4

    goto :goto_2

    :cond_4
    const-string v0, "ONE_PIXEL"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    const-wide/16 v11, 0x3e8

    :try_start_1
    div-long/2addr v4, v11
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    move v6, v7

    goto :goto_3

    :cond_5
    const-string v0, "CPM"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    move v6, v1

    goto :goto_3

    :cond_6
    const-string v0, "CPC"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    move v6, v8

    goto :goto_3

    :cond_7
    :goto_2
    move v6, v3

    :goto_3
    :try_start_2
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result p1
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_0

    const v0, -0x7f136fe4

    if-eq p1, v0, :cond_a

    const v0, 0x17cbce3b

    if-eq p1, v0, :cond_9

    const v0, 0x4bc5cce6    # 2.5926092E7f

    if-eq p1, v0, :cond_8

    goto :goto_5

    :cond_8
    const-string p1, "PUBLISHER_PROVIDED"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b

    move v7, v8

    :goto_4
    move-wide v8, v4

    goto :goto_6

    :cond_9
    const-string p1, "PRECISE"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b

    goto :goto_4

    :cond_a
    const-string p1, "ESTIMATED"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b

    move v7, v1

    goto :goto_4

    :cond_b
    :goto_5
    move v7, v3

    goto :goto_4

    :goto_6
    :try_start_3
    new-instance v5, Lxv4;

    invoke-direct/range {v5 .. v10}, Lxv4;-><init>(IIJLjava/lang/String;)V

    iget-object p1, p0, Lxu2;->l:Lkg3;

    iget-object p1, p1, Lkg3;->a:Lf53;

    iget-object p1, p1, Lf53;->i:Ljava/lang/Object;

    check-cast p1, Log3;

    invoke-static {p1}, Li60;->D(Log3;)I

    move-result p1

    if-eq p1, v1, :cond_c

    move p1, v1

    goto :goto_7

    :cond_c
    move p1, v3

    :goto_7
    if-eqz p1, :cond_e

    iget-object p1, p0, Lxu2;->j:Lbg3;

    iget-boolean p1, p1, Lbg3;->B0:Z

    if-eqz p1, :cond_e

    iget-object p1, p0, Lxu2;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v3, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    if-nez p1, :cond_d

    goto :goto_8

    :cond_d
    new-instance p1, Lo81;

    const/16 v0, 0x19

    invoke-direct {p1, v0, v5}, Lo81;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p0, p1}, Lfg4;->S1(Luv2;)V
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_8

    :catch_0
    move-exception v0

    move-object p0, v0

    const-string p1, "UrlPinger.pingUrl"

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->h:Lui2;

    invoke-virtual {v0, p1, p0}, Lui2;->d(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_e
    :goto_8
    return-void

    :sswitch_0
    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lye3;

    check-cast p1, Lqq2;

    monitor-enter v2

    if-eqz p1, :cond_f

    :try_start_4
    invoke-virtual {p1}, Lor2;->b()V

    goto :goto_9

    :catchall_0
    move-exception v0

    move-object p0, v0

    goto :goto_b

    :cond_f
    :goto_9
    iget-boolean v0, v2, Lye3;->m:Z

    if-eqz v0, :cond_10

    invoke-virtual {v2}, Lye3;->c()V

    :cond_10
    sget-object v0, Ll62;->c:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_11

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lmi3;

    if-eqz v0, :cond_11

    iget-object v3, p1, Lor2;->a:Lkg3;

    iget-object v3, v3, Lkg3;->b:La90;

    invoke-virtual {v0, v3}, Lmi3;->e(La90;)V

    iget-object p1, p1, Lor2;->f:Lut2;

    iget-object p1, p1, Lut2;->h:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lmi3;->g(Ljava/lang/String;)V

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Lji3;

    invoke-interface {p0, v1}, Lji3;->b(Z)Lji3;

    invoke-virtual {v0, p0}, Lmi3;->a(Lji3;)V

    invoke-virtual {v0}, Lmi3;->h()V

    goto :goto_a

    :cond_11
    iget-object v0, v2, Lye3;->i:Lni3;

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Lji3;

    iget-object v3, p1, Lor2;->a:Lkg3;

    iget-object v3, v3, Lkg3;->b:La90;

    invoke-interface {p0, v3}, Lji3;->k(La90;)Lji3;

    iget-object p1, p1, Lor2;->f:Lut2;

    iget-object p1, p1, Lut2;->h:Ljava/lang/String;

    invoke-interface {p0, p1}, Lji3;->m(Ljava/lang/String;)Lji3;

    invoke-interface {p0, v1}, Lji3;->b(Z)Lji3;

    invoke-interface {p0}, Lji3;->n()Lli3;

    move-result-object p0

    invoke-virtual {v0, p0}, Lni3;->b(Lli3;)V

    :goto_a
    monitor-exit v2

    return-void

    :goto_b
    monitor-exit v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw p0

    :sswitch_1
    check-cast p1, Lsl2;

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lbg3;

    iget-object v2, p0, La90;->j:Ljava/lang/Object;

    check-cast v2, Ldg3;

    invoke-interface {p1, v0, v2}, Lsl2;->g0(Lbg3;Ldg3;)V

    invoke-interface {p1}, Lsl2;->b0()Lmm2;

    move-result-object p1

    sget-object v2, Lk52;->Gb:Lg52;

    sget-object v3, Lvx1;->e:Lvx1;

    iget-object v4, v3, Lvx1;->c:Li52;

    invoke-virtual {v4, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_12

    if-eqz p1, :cond_12

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, Lkp2;

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Ls03;

    iget-object v4, p0, Ls03;->i:Lv63;

    iget-object v5, p0, Ls03;->j:Lsj3;

    invoke-virtual {p1, v2, v4, v5}, Lmm2;->I(Lkp2;Lv63;Lsj3;)V

    iget-object p0, p0, Ls03;->d:Lu23;

    invoke-virtual {p1, v2, v4, p0}, Lmm2;->J(Lkp2;Lv63;Lu23;)V

    :cond_12
    sget-object p0, Lk52;->Re:Lg52;

    iget-object v2, v3, Lvx1;->c:Li52;

    invoke-virtual {v2, p0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_13

    if-eqz p1, :cond_13

    const-string p0, "/logScionEvent"

    iget-object v2, p1, Lmm2;->h:Ldm2;

    sget-object v3, Lcw4;->B:Lcw4;

    iget-object v3, v3, Lcw4;->x:Lbi2;

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v3, v4}, Lbi2;->a(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_13

    invoke-virtual {p1, p0}, Lmm2;->c(Ljava/lang/String;)V

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iget-object v0, v0, Lbg3;->w0:Ljava/util/HashMap;

    new-instance v3, Lk92;

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v3, v2, v1, v0}, Lk92;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {p1, p0, v3}, Lmm2;->b(Ljava/lang/String;Ln92;)V

    :cond_13
    return-void

    :sswitch_2
    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Lsj3;

    check-cast p1, Ljava/lang/String;

    new-instance v1, Lsi;

    iget-object v2, p0, La90;->j:Ljava/lang/Object;

    check-cast v2, Lco2;

    const/16 v3, 0x10

    invoke-direct {v1, v3, v0, p1, v2}, Lsi;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p0, p0, La90;->k:Ljava/lang/Object;

    check-cast p0, Lkp2;

    iget-object p0, p0, Lkp2;->e:Lzi2;

    invoke-virtual {p0, v1}, Lzi2;->a(Ljava/lang/Runnable;)Lna0;

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0xf -> :sswitch_2
        0x11 -> :sswitch_1
        0x15 -> :sswitch_0
    .end sparse-switch
.end method

.method public r(Landroid/content/Context;Lw61;Lni3;)Lvb2;
    .locals 4

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La90;->k:Ljava/lang/Object;

    check-cast v1, Lvb2;

    if-nez v1, :cond_3

    invoke-static {p1}, La90;->B(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lk52;->c:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    sget-object v1, Lw62;->h:Lht1;

    invoke-virtual {v1}, Lht1;->v()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    sget-object v1, Lk52;->a:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    :cond_1
    sget-object v1, Lk52;->b:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    :goto_0
    new-instance v2, Lvb2;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    if-nez v3, :cond_2

    goto :goto_1

    :cond_2
    move-object p1, v3

    :goto_1
    invoke-direct {v2, p1, p2, v1, p3}, Lvb2;-><init>(Landroid/content/Context;Lw61;Ljava/lang/String;Lni3;)V

    iput-object v2, p0, La90;->k:Ljava/lang/Object;

    move-object v1, v2

    :cond_3
    monitor-exit v0

    return-object v1

    :goto_2
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public s(I)V
    .locals 1

    const/16 v0, 0xc

    if-eq p1, v0, :cond_1

    const/16 v0, 0x10

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Invalid IV size in bytes %d; acceptable values have 12 or 16 bytes"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, La90;->j:Ljava/lang/Object;

    return-void
.end method

.method public declared-synchronized t(Lbt1;)V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {p1}, Lbt1;->d()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    if-eqz v1, :cond_1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1

    sget-boolean v2, Lgt1;->a:Z

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2, p1}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "%d waiting requests for cacheKey=%s; resend to network"

    invoke-static {v3, v2}, Lgt1;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lbt1;

    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, v2, Lbt1;->l:Ljava/lang/Object;

    monitor-enter p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iput-object p0, v2, Lbt1;->r:La90;

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    iget-object p1, p0, La90;->k:Ljava/lang/Object;

    check-cast p1, Ljava/util/concurrent/PriorityBlockingQueue;

    invoke-virtual {p1, v2}, Ljava/util/concurrent/PriorityBlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    return-void

    :catch_0
    move-exception p1

    :try_start_3
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Couldn\'t add request to queue. %s"

    invoke-static {v0, p1}, Lgt1;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    iget-object p1, p0, La90;->j:Ljava/lang/Object;

    check-cast p1, Lrs1;

    const/4 v0, 0x1

    iput-boolean v0, p1, Lrs1;->k:Z

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    monitor-exit p0

    return-void

    :catchall_1
    move-exception v0

    :try_start_4
    monitor-exit p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    throw v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :cond_1
    monitor-exit p0

    return-void

    :goto_1
    :try_start_6
    monitor-exit p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    throw p1
.end method

.method public u(I)Ld12;
    .locals 4

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v2, :cond_0

    invoke-virtual {p0}, La90;->C()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, La90;->y()Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    :try_start_0
    invoke-static {p1}, Lgx1;->o(Ljava/lang/String;)[B

    move-result-object p1

    array-length v0, p1

    const/4 v2, 0x0

    invoke-static {v2, v0, p1}, Lyf4;->t(II[B)Lwf4;

    move-result-object p1

    invoke-static {p1}, Ld12;->D(Lwf4;)Ld12;

    move-result-object p1

    invoke-virtual {p1}, Ld12;->y()Ljava/lang/String;

    move-result-object v0

    const-string v2, "pcam.jar"

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v3

    invoke-static {v0, v2, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_2

    const-string v2, "pcam"

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object v3

    invoke-static {v0, v2, v3}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v2

    :cond_2
    const-string v3, "pcbc"

    invoke-virtual {p0}, La90;->x()Ljava/io/File;

    move-result-object p0

    invoke-static {v0, v3, p0}, Ly91;->K(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object p0

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result p0
    :try_end_0
    .catch Lyg4; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p0, :cond_3

    return-object p1

    :catch_0
    :cond_3
    :goto_1
    return-object v1
.end method

.method public v()V
    .locals 1

    const/16 v0, 0x10

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p0, La90;->k:Ljava/lang/Object;

    return-void
.end method

.method public declared-synchronized w(Lbt1;)Z
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    invoke-virtual {p1}, Lbt1;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    if-nez v2, :cond_0

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_0
    :goto_0
    const-string v3, "waiting-for-response"

    invoke-virtual {p1, v3}, Lbt1;->a(Ljava/lang/String;)V

    invoke-interface {v2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-boolean p1, Lgt1;->a:Z

    if-eqz p1, :cond_1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Request for cacheKey=%s is in flight, putting on hold."

    invoke-static {v0, p1}, Lgt1;->b(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    monitor-exit p0

    const/4 p0, 0x1

    return p0

    :cond_2
    const/4 v2, 0x0

    :try_start_1
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p1, Lbt1;->l:Ljava/lang/Object;

    monitor-enter v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    iput-object p0, p1, Lbt1;->r:La90;

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    sget-boolean p1, Lgt1;->a:Z

    if-eqz p1, :cond_3

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "new request, sending to network %s"

    invoke-static {v0, p1}, Lgt1;->b(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :cond_3
    monitor-exit p0

    const/4 p0, 0x0

    return p0

    :catchall_1
    move-exception p1

    :try_start_4
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    throw p1

    :goto_1
    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    throw p1
.end method

.method public x()Ljava/io/File;
    .locals 2

    iget-object v0, p0, La90;->l:Ljava/lang/Object;

    check-cast v0, Lu02;

    new-instance v1, Ljava/io/File;

    iget v0, v0, Lu02;->h:I

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    iget-object p0, p0, La90;->j:Ljava/lang/Object;

    check-cast p0, Ljava/io/File;

    invoke-direct {v1, p0, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p0

    if-nez p0, :cond_0

    invoke-virtual {v1}, Ljava/io/File;->mkdir()Z

    :cond_0
    return-object v1
.end method

.method public y()Ljava/lang/String;
    .locals 2

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lu02;

    iget p0, p0, Lu02;->h:I

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x6

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "FBAMTD"

    invoke-static {p0, v0, v1}, Loj;->i(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public z()Li34;
    .locals 4

    iget-object v0, p0, La90;->i:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v2, p0, La90;->j:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_1

    iget-object v2, p0, La90;->k:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_0

    new-instance v1, Li34;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v2, p0, La90;->j:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v3, p0, La90;->k:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, La90;->l:Ljava/lang/Object;

    check-cast p0, Lh34;

    invoke-direct {v1, v0, v2, p0}, Li34;-><init>(IILh34;)V

    return-object v1

    :cond_0
    const-string p0, "Tag size is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v1

    :cond_1
    const-string p0, "IV size is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v1

    :cond_2
    const-string p0, "Key size is not set"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-object v1
.end method
