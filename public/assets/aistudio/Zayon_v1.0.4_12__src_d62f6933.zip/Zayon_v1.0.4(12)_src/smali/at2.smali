.class public final Lat2;
.super Ljava/lang/Object;
.source "SourceFile"
