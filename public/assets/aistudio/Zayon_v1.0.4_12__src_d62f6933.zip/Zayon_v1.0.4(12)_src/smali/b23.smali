.class public abstract Lb23;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Loc3;
.implements Landroid/os/IInterface;


# static fields
.field public static final synthetic h:I
