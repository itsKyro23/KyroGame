.class public final Lbe;
.super Lde;
.source "SourceFile"


# instance fields
.field public final synthetic i:Lta1;

.field public final synthetic j:Ljava/util/UUID;


# direct methods
.method public constructor <init>(Lta1;Ljava/util/UUID;)V
    .locals 0

    iput-object p1, p0, Lbe;->i:Lta1;

    iput-object p2, p0, Lbe;->j:Ljava/util/UUID;

    invoke-direct {p0}, Lde;-><init>()V

    return-void
.end method


# virtual methods
.method public final b()V
    .locals 2

    iget-object v0, p0, Lbe;->i:Lta1;

    iget-object v1, v0, Lta1;->c:Landroidx/work/impl/WorkDatabase;

    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->c()V

    :try_start_0
    iget-object p0, p0, Lbe;->j:Ljava/util/UUID;

    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0, p0}, Lde;->a(Lta1;Ljava/lang/String;)V

    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->j()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->g()V

    iget-object p0, v0, Lta1;->b:Lvh;

    iget-object v1, v0, Lta1;->c:Landroidx/work/impl/WorkDatabase;

    iget-object v0, v0, Lta1;->e:Ljava/util/List;

    invoke-static {p0, v1, v0}, Lov0;->a(Lvh;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    return-void

    :catchall_0
    move-exception p0

    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->g()V

    throw p0
.end method
