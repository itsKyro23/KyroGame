.class public final synthetic Lab2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ldb2;

.field public final synthetic j:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ldb2;Ljava/lang/String;I)V
    .locals 0

    iput p3, p0, Lab2;->h:I

    iput-object p1, p0, Lab2;->i:Ldb2;

    iput-object p2, p0, Lab2;->j:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic run()V
    .locals 3

    iget v0, p0, Lab2;->h:I

    iget-object v1, p0, Lab2;->j:Ljava/lang/String;

    iget-object p0, p0, Lab2;->i:Ldb2;

    packed-switch v0, :pswitch_data_0

    iget-object p0, p0, Ldb2;->h:Lsl2;

    if-eqz p0, :cond_0

    invoke-interface {p0, v1}, Leb2;->r(Ljava/lang/String;)V

    :cond_0
    return-void

    :pswitch_0
    iget-object p0, p0, Ldb2;->h:Lsl2;

    if-eqz p0, :cond_1

    invoke-interface {p0, v1}, Lsl2;->loadUrl(Ljava/lang/String;)V

    :cond_1
    return-void

    :pswitch_1
    iget-object p0, p0, Ldb2;->h:Lsl2;

    if-eqz p0, :cond_2

    const-string v0, "text/html"

    const-string v2, "UTF-8"

    invoke-interface {p0, v1, v0, v2}, Lsl2;->loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
