.class public abstract Lb74;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lq64;

.field public static final b:Lq64;

.field public static final c:Lx54;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget-object v0, Lw34;->v:Lw34;

    new-instance v1, Lq64;

    const-class v2, La74;

    const-class v3, Lp74;

    invoke-direct {v1, v2, v3, v0}, Lq64;-><init>(Ljava/lang/Class;Ljava/lang/Class;Ls64;)V

    sput-object v1, Lb74;->a:Lq64;

    sget-object v0, La44;->w:La44;

    new-instance v1, Lq64;

    const-class v3, Lj24;

    invoke-direct {v1, v2, v3, v0}, Lq64;-><init>(Ljava/lang/Class;Ljava/lang/Class;Ls64;)V

    sput-object v1, Lb74;->b:Lq64;

    sget v0, Lz74;->zza:I

    const-class v0, Lz74;

    invoke-static {v0}, Lng4;->q(Ljava/lang/Class;)Llg4;

    new-instance v0, Lx54;

    const/4 v1, 0x3

    const-string v2, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    invoke-direct {v0, v1, v3, v2}, Lx54;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    sput-object v0, Lb74;->c:Lx54;

    return-void
.end method
