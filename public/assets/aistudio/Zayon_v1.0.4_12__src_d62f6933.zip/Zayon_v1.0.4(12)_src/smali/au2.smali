.class public final Lau2;
.super Lfg4;
.source "SourceFile"

# interfaces
.implements Lbu2;


# virtual methods
.method public final X0(Lh23;)V
    .locals 2

    new-instance v0, Lco2;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p1}, Lco2;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p0, v0}, Lfg4;->S1(Luv2;)V

    return-void
.end method
