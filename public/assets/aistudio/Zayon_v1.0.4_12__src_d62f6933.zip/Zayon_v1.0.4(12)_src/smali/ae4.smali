.class public final Lae4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp24;


# static fields
.field public static final g:[B

.field public static final h:[B


# instance fields
.field public final a:Ljava/security/interfaces/RSAPublicKey;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/security/spec/PSSParameterSpec;

.field public final d:[B

.field public final e:[B

.field public final f:Ljava/security/Provider;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x0

    new-array v1, v0, [B

    sput-object v1, Lae4;->g:[B

    const/4 v1, 0x1

    new-array v1, v1, [B

    aput-byte v0, v1, v0

    sput-object v1, Lae4;->h:[B

    return-void
.end method

.method public constructor <init>(Ljava/security/interfaces/RSAPublicKey;Lyc4;Lyc4;I[B[BLjava/security/Provider;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    invoke-static {v0}, Ls9;->n(I)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {p2, p3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    invoke-static {v0}, Lbo;->A(I)V

    invoke-interface {p1}, Ljava/security/interfaces/RSAPublicKey;->getPublicExponent()Ljava/math/BigInteger;

    move-result-object v0

    invoke-static {v0}, Lbo;->E(Ljava/math/BigInteger;)V

    iput-object p1, p0, Lae4;->a:Ljava/security/interfaces/RSAPublicKey;

    invoke-static {p2}, Lae4;->a(Lyc4;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lae4;->b:Ljava/lang/String;

    invoke-static {p2, p3, p4}, Lae4;->c(Lyc4;Lyc4;I)Ljava/security/spec/PSSParameterSpec;

    move-result-object p1

    iput-object p1, p0, Lae4;->c:Ljava/security/spec/PSSParameterSpec;

    iput-object p5, p0, Lae4;->d:[B

    iput-object p6, p0, Lae4;->e:[B

    iput-object p7, p0, Lae4;->f:Ljava/security/Provider;

    return-void

    :cond_0
    const-string p0, "sigHash and mgf1Hash must be the same"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    throw v1

    :cond_1
    const-string p0, "Cannot use RSA SSA PSS in FIPS-mode, as BoringCrypto module is not available."

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    throw v1
.end method

.method public static a(Lyc4;)Ljava/lang/String;
    .locals 1

    sget-object v0, Lyc4;->b:Lyc4;

    if-ne p0, v0, :cond_0

    const-string p0, "SHA256withRSA/PSS"

    return-object p0

    :cond_0
    sget-object v0, Lyc4;->c:Lyc4;

    if-ne p0, v0, :cond_1

    const-string p0, "SHA384withRSA/PSS"

    return-object p0

    :cond_1
    sget-object v0, Lyc4;->d:Lyc4;

    if-ne p0, v0, :cond_2

    const-string p0, "SHA512withRSA/PSS"

    return-object p0

    :cond_2
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Unsupported hash: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static c(Lyc4;Lyc4;I)Ljava/security/spec/PSSParameterSpec;
    .locals 6

    new-instance v0, Ljava/security/spec/PSSParameterSpec;

    const/4 v1, 0x0

    sget-object v2, Lyc4;->d:Lyc4;

    sget-object v3, Lyc4;->c:Lyc4;

    sget-object v4, Lyc4;->b:Lyc4;

    if-ne p0, v4, :cond_0

    const-string p0, "SHA-256"

    goto :goto_0

    :cond_0
    if-ne p0, v3, :cond_1

    const-string p0, "SHA-384"

    goto :goto_0

    :cond_1
    if-ne p0, v2, :cond_5

    const-string p0, "SHA-512"

    :goto_0
    if-ne p1, v4, :cond_2

    sget-object p1, Ljava/security/spec/MGF1ParameterSpec;->SHA256:Ljava/security/spec/MGF1ParameterSpec;

    :goto_1
    move-object v3, p1

    goto :goto_2

    :cond_2
    if-ne p1, v3, :cond_3

    sget-object p1, Ljava/security/spec/MGF1ParameterSpec;->SHA384:Ljava/security/spec/MGF1ParameterSpec;

    goto :goto_1

    :cond_3
    if-ne p1, v2, :cond_4

    sget-object p1, Ljava/security/spec/MGF1ParameterSpec;->SHA512:Ljava/security/spec/MGF1ParameterSpec;

    goto :goto_1

    :goto_2
    const-string v2, "MGF1"

    const/4 v5, 0x1

    move-object v1, p0

    move v4, p2

    invoke-direct/range {v0 .. v5}, Ljava/security/spec/PSSParameterSpec;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/security/spec/AlgorithmParameterSpec;II)V

    return-object v0

    :cond_4
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Unsupported MGF1 hash: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-object v1

    :cond_5
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Unsupported MD hash: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-object v1
.end method

.method public static d(Lbd4;)Lae4;
    .locals 9

    sget v0, Lz64;->a:I

    const-string v0, "java.vendor"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "The Android Project"

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    :goto_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_1
    invoke-static {}, Ls9;->k()Ljava/security/Provider;

    move-result-object v8

    if-eqz v8, :cond_3

    const-string v0, "RSA"

    invoke-static {v0, v8}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyFactory;

    move-result-object v0

    new-instance v1, Ljava/security/spec/RSAPublicKeySpec;

    iget-object v2, p0, Lbd4;->p:Ljava/math/BigInteger;

    iget-object v3, p0, Lbd4;->o:Lzc4;

    iget-object v4, v3, Lzc4;->b:Ljava/math/BigInteger;

    invoke-direct {v1, v2, v4}, Ljava/security/spec/RSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/security/interfaces/RSAPublicKey;

    new-instance v1, Lae4;

    move-object v0, v3

    iget-object v3, v0, Lzc4;->d:Lyc4;

    iget-object v4, v0, Lzc4;->e:Lyc4;

    iget v5, v0, Lzc4;->f:I

    iget-object p0, p0, Lbd4;->q:Lxe4;

    invoke-virtual {p0}, Lxe4;->b()[B

    move-result-object v6

    iget-object p0, v0, Lzc4;->c:Lf24;

    sget-object v0, Lf24;->v:Lf24;

    if-eq p0, v0, :cond_2

    sget-object p0, Lae4;->g:[B

    :goto_1
    move-object v7, p0

    goto :goto_2

    :cond_2
    sget-object p0, Lae4;->h:[B

    goto :goto_1

    :goto_2
    invoke-direct/range {v1 .. v8}, Lae4;-><init>(Ljava/security/interfaces/RSAPublicKey;Lyc4;Lyc4;I[B[BLjava/security/Provider;)V

    return-object v1

    :cond_3
    new-instance p0, Ljava/security/NoSuchProviderException;

    const-string v0, "RSA SSA PSS using Conscrypt is not supported."

    invoke-direct {p0, v0}, Ljava/security/NoSuchProviderException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final b([B[B)V
    .locals 3

    iget-object v0, p0, Lae4;->d:[B

    invoke-static {v0, p1}, Lz64;->a([B[B)Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, p0, Lae4;->b:Ljava/lang/String;

    iget-object v2, p0, Lae4;->f:Ljava/security/Provider;

    invoke-static {v1, v2}, Ljava/security/Signature;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/Signature;

    move-result-object v1

    iget-object v2, p0, Lae4;->a:Ljava/security/interfaces/RSAPublicKey;

    invoke-virtual {v1, v2}, Ljava/security/Signature;->initVerify(Ljava/security/PublicKey;)V

    iget-object v2, p0, Lae4;->c:Ljava/security/spec/PSSParameterSpec;

    invoke-virtual {v1, v2}, Ljava/security/Signature;->setParameter(Ljava/security/spec/AlgorithmParameterSpec;)V

    invoke-virtual {v1, p2}, Ljava/security/Signature;->update([B)V

    iget-object p0, p0, Lae4;->e:[B

    array-length p2, p0

    if-lez p2, :cond_0

    invoke-virtual {v1, p0}, Ljava/security/Signature;->update([B)V

    :cond_0
    array-length p0, p1

    array-length p2, v0

    sub-int/2addr p0, p2

    invoke-virtual {v1, p1, p2, p0}, Ljava/security/Signature;->verify([BII)Z

    move-result p0

    if-eqz p0, :cond_1

    return-void

    :cond_1
    const-string p0, "signature verification failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-void

    :cond_2
    const-string p0, "Invalid signature (output prefix mismatch)"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    return-void
.end method
