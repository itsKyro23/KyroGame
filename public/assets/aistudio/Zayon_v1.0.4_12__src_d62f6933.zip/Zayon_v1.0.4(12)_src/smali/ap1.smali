.class public interface abstract Lap1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()I
.end method

.method public abstract b(J)Ljava/util/ArrayList;
.end method

.method public abstract y(I)J
.end method
