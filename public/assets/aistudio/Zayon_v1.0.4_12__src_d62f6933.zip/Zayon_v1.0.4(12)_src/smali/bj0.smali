.class public interface abstract Lbj0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract i(Lg21;)V
.end method
