.class public final Lbb4;
.super Lng4;
.source "SourceFile"


# static fields
.field public static final synthetic zza:I

.field private static final zzd:Lbb4;


# instance fields
.field private zzb:Ljava/lang/String;

.field private zzc:Lug4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lbb4;

    invoke-direct {v0}, Lbb4;-><init>()V

    sput-object v0, Lbb4;->zzd:Lbb4;

    const-class v1, Lbb4;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lbb4;->zzb:Ljava/lang/String;

    sget-object v0, Lkh4;->l:Lkh4;

    iput-object v0, p0, Lbb4;->zzc:Lug4;

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lab4;

    sget-object p1, Lbb4;->zzd:Lbb4;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lbb4;

    invoke-direct {p0}, Lbb4;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zzc"

    const-class p1, Lha4;

    const-string p2, "zzb"

    filled-new-array {p2, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lbb4;->zzd:Lbb4;

    new-instance p2, Llh4;

    const-string v0, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u0208\u0002\u001b"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method
