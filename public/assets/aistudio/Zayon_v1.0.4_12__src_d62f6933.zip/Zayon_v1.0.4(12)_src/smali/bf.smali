.class public final synthetic Lbf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, Lbf;->h:I

    iput-object p2, p0, Lbf;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 2

    iget p1, p0, Lbf;->h:I

    const/4 v0, 0x0

    iget-object p0, p0, Lbf;->i:Ljava/lang/Object;

    packed-switch p1, :pswitch_data_0

    check-cast p0, Ltt0;

    sput-boolean v0, Ltt0;->H:Z

    iget-object p0, p0, Ltt0;->F:Landroid/animation/ValueAnimator;

    invoke-static {p0}, Li60;->b(Landroid/animation/ValueAnimator;)V

    return-void

    :pswitch_0
    check-cast p0, Ldc0;

    const/4 p1, 0x1

    iput-boolean p1, p0, Ldc0;->H:Z

    iget-object p1, p0, Ldc0;->r:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-virtual {p0}, Ldc0;->z()V

    iget-object p1, p0, Ldc0;->v:Lac0;

    iput-boolean v0, p1, Lac0;->m:Z

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    iget-object p1, p0, Ldc0;->w:Lcc0;

    iput-boolean v0, p1, Lcc0;->n:Z

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    sget-object p1, Ldc0;->Z:Ljava/lang/ref/WeakReference;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, p0, :cond_0

    sput-object v1, Ldc0;->Z:Ljava/lang/ref/WeakReference;

    :cond_0
    return-void

    :pswitch_1
    check-cast p0, Ldf;

    iget-object p1, p0, Ldf;->G:Lcf;

    iget-object p0, p0, Ldf;->a0:Laf;

    invoke-virtual {p1, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
