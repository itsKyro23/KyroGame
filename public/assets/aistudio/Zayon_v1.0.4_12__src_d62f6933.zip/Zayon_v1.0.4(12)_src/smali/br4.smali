.class public interface abstract Lbr4;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e()V
.end method

.method public abstract f()V
.end method
