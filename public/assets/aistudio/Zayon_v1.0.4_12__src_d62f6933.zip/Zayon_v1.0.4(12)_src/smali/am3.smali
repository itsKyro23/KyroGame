.class public final Lam3;
.super Ljava/lang/ref/WeakReference;
.source "SourceFile"
