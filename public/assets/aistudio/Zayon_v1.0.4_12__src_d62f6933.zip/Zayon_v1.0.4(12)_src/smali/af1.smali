.class public final Laf1;
.super Landroid/widget/RelativeLayout;
.source "SourceFile"
