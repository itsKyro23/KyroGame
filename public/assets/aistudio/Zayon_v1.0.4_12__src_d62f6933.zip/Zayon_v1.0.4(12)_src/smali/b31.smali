.class public final synthetic Lb31;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Le31;


# direct methods
.method public synthetic constructor <init>(Le31;I)V
    .locals 0

    iput p2, p0, Lb31;->a:I

    iput-object p1, p0, Lb31;->b:Le31;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 0

    iget p1, p0, Lb31;->a:I

    iget-object p0, p0, Lb31;->b:Le31;

    packed-switch p1, :pswitch_data_0

    invoke-virtual {p0}, Le31;->h()V

    return-void

    :pswitch_0
    sub-int/2addr p4, p2

    int-to-float p1, p4

    const/high16 p2, 0x40800000    # 4.0f

    div-float/2addr p1, p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    iget-object p2, p0, Le31;->p:Landroid/view/View;

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p3

    iget p4, p3, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-eq p4, p1, :cond_0

    iput p1, p3, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p2, p3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    iget p3, p0, Le31;->a0:I

    if-ltz p3, :cond_2

    const/4 p4, 0x3

    if-gt p3, p4, :cond_2

    iget-object p3, p0, Le31;->g0:Landroid/animation/ValueAnimator;

    if-eqz p3, :cond_1

    invoke-virtual {p3}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result p3

    if-nez p3, :cond_2

    :cond_1
    iget p0, p0, Le31;->a0:I

    mul-int/2addr p0, p1

    int-to-float p0, p0

    invoke-virtual {p2, p0}, Landroid/view/View;->setTranslationX(F)V

    :cond_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
