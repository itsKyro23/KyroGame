.class public final Lbo1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lkj1;


# static fields
.field public static final synthetic G:I


# instance fields
.field public A:I

.field public B:J

.field public C:Lmj1;

.field public D:[Lao1;

.field public E:[[J

.field public F:I

.field public final a:Lcp1;

.field public final b:I

.field public final c:Lzb3;

.field public final d:Lzb3;

.field public final e:Lzb3;

.field public final f:Lzb3;

.field public final g:Ljava/util/ArrayDeque;

.field public final h:Lio1;

.field public final i:Ljava/util/ArrayList;

.field public final j:Ljava/util/ArrayList;

.field public final k:Ljava/util/ArrayList;

.field public l:Lqy3;

.field public m:I

.field public n:I

.field public o:J

.field public p:I

.field public q:Lzb3;

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:Z

.field public w:Z

.field public x:Z

.field public y:Z

.field public z:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Lsl3;->o:I

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 96
    sget-object v0, Lcp1;->f:Ljs;

    const/16 v1, 0x10

    invoke-direct {p0, v0, v1}, Lbo1;-><init>(Lcp1;I)V

    return-void
.end method

.method public constructor <init>(Lcp1;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbo1;->a:Lcp1;

    iput p2, p0, Lbo1;->b:I

    sget-object p1, Lmx3;->i:Lix3;

    sget-object p1, Lqy3;->l:Lqy3;

    iput-object p1, p0, Lbo1;->l:Lqy3;

    const/4 p1, 0x0

    iput p1, p0, Lbo1;->m:I

    new-instance p2, Lio1;

    invoke-direct {p2}, Lio1;-><init>()V

    iput-object p2, p0, Lbo1;->h:Lio1;

    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Lbo1;->i:Ljava/util/ArrayList;

    new-instance p2, Lzb3;

    const/16 v0, 0x10

    invoke-direct {p2, v0}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lbo1;->f:Lzb3;

    new-instance p2, Ljava/util/ArrayDeque;

    invoke-direct {p2}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p2, p0, Lbo1;->g:Ljava/util/ArrayDeque;

    new-instance p2, Lzb3;

    sget-object v0, Lic1;->o:[B

    invoke-direct {p2, v0}, Lzb3;-><init>([B)V

    iput-object p2, p0, Lbo1;->c:Lzb3;

    new-instance p2, Lzb3;

    const/4 v0, 0x6

    invoke-direct {p2, v0}, Lzb3;-><init>(I)V

    iput-object p2, p0, Lbo1;->d:Lzb3;

    new-instance p2, Lzb3;

    invoke-direct {p2}, Lzb3;-><init>()V

    iput-object p2, p0, Lbo1;->e:Lzb3;

    const/4 p2, -0x1

    iput p2, p0, Lbo1;->r:I

    sget-object p2, Lmj1;->e:Lpt;

    iput-object p2, p0, Lbo1;->C:Lmj1;

    new-array p1, p1, [Lao1;

    iput-object p1, p0, Lbo1;->D:[Lao1;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lbo1;->j:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lbo1;->k:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final a(J)V
    .locals 44

    move-object/from16 v0, p0

    :cond_0
    :goto_0
    iget-object v1, v0, Lbo1;->g:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v2, :cond_3c

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lun3;

    iget-wide v6, v2, Lun3;->b:J

    cmp-long v2, v6, p1

    if-nez v2, :cond_3c

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->pop()Ljava/lang/Object;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lun3;

    iget v2, v6, Lto3;->a:I

    const v7, 0x6d6f6f76

    if-ne v2, v7, :cond_3b

    const v2, 0x6d657461

    invoke-virtual {v6, v2}, Lun3;->c(I)Lun3;

    move-result-object v2

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x3

    const/16 v16, 0x0

    const/4 v9, 0x1

    if-eqz v2, :cond_e

    invoke-static {v2}, Lsn1;->d(Lun3;)Lrp1;

    move-result-object v2

    iget-boolean v10, v0, Lbo1;->y:Z

    if-eqz v10, :cond_d

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v2, Lrp1;->a:[Lyo1;

    array-length v10, v7

    move v11, v5

    :goto_1
    const-class v12, Lbn3;

    if-ge v11, v10, :cond_3

    aget-object v13, v7, v11

    const-wide/16 v17, 0x0

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v14

    if-eqz v14, :cond_1

    invoke-virtual {v12, v13}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lyo1;

    move-object v14, v13

    check-cast v14, Lbn3;

    iget-object v14, v14, Lbn3;->a:Ljava/lang/String;

    const-string v15, "auxiliary.tracks.interleaved"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_1

    goto :goto_2

    :cond_1
    move-object/from16 v13, v16

    :goto_2
    if-eqz v13, :cond_2

    goto :goto_3

    :cond_2
    add-int/lit8 v11, v11, 0x1

    goto :goto_1

    :cond_3
    const-wide/16 v17, 0x0

    move-object/from16 v13, v16

    :goto_3
    check-cast v13, Lbn3;

    if-eqz v13, :cond_4

    iget-object v10, v13, Lbn3;->b:[B

    aget-byte v10, v10, v5

    if-nez v10, :cond_4

    const-wide/16 v10, 0x10

    add-long v14, v17, v10

    iput-wide v14, v0, Lbo1;->B:J

    :cond_4
    array-length v10, v7

    move v11, v5

    :goto_4
    if-ge v11, v10, :cond_7

    aget-object v13, v7, v11

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v14

    if-eqz v14, :cond_5

    invoke-virtual {v12, v13}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lyo1;

    move-object v14, v13

    check-cast v14, Lbn3;

    iget-object v14, v14, Lbn3;->a:Ljava/lang/String;

    const-string v15, "auxiliary.tracks.map"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_5

    goto :goto_5

    :cond_5
    move-object/from16 v13, v16

    :goto_5
    if-eqz v13, :cond_6

    goto :goto_6

    :cond_6
    add-int/lit8 v11, v11, 0x1

    goto :goto_4

    :cond_7
    move-object/from16 v13, v16

    :goto_6
    check-cast v13, Lbn3;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v13}, Lbn3;->b()Ljava/util/ArrayList;

    move-result-object v7

    new-instance v10, Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v11

    invoke-direct {v10, v11}, Ljava/util/ArrayList;-><init>(I)V

    move v11, v5

    :goto_7
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v12

    if-ge v11, v12, :cond_c

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-eqz v12, :cond_b

    if-eq v12, v9, :cond_a

    if-eq v12, v4, :cond_9

    if-eq v12, v8, :cond_8

    move v12, v5

    goto :goto_8

    :cond_8
    const/4 v12, 0x4

    goto :goto_8

    :cond_9
    move v12, v8

    goto :goto_8

    :cond_a
    move v12, v4

    goto :goto_8

    :cond_b
    move v12, v9

    :goto_8
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v10, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    goto :goto_7

    :cond_c
    move-object v14, v10

    goto :goto_9

    :cond_d
    const-wide/16 v17, 0x0

    move-object v14, v7

    goto :goto_9

    :cond_e
    const-wide/16 v17, 0x0

    move-object v14, v7

    move-object/from16 v2, v16

    :goto_9
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    iget v7, v0, Lbo1;->F:I

    new-instance v10, Lwj1;

    invoke-direct {v10}, Lwj1;-><init>()V

    const v11, 0x75647461

    invoke-virtual {v6, v11}, Lun3;->b(I)Leo3;

    move-result-object v11

    if-eqz v11, :cond_f

    invoke-static {v11}, Lsn1;->b(Leo3;)Lrp1;

    move-result-object v11

    invoke-virtual {v10, v11}, Lwj1;->a(Lrp1;)V

    goto :goto_a

    :cond_f
    move-object/from16 v11, v16

    :goto_a
    new-instance v12, Lrp1;

    const v13, 0x6d766864

    invoke-virtual {v6, v13}, Lun3;->b(I)Leo3;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eq v9, v7, :cond_10

    move v7, v5

    goto :goto_b

    :cond_10
    move v7, v9

    :goto_b
    iget-object v13, v13, Leo3;->b:Lzb3;

    invoke-static {v13}, Lsn1;->c(Lzb3;)Lmp3;

    move-result-object v13

    new-array v3, v9, [Lyo1;

    aput-object v13, v3, v5

    invoke-direct {v12, v3}, Lrp1;-><init>([Lyo1;)V

    new-instance v13, Lwm1;

    invoke-direct {v13, v8}, Lwm1;-><init>(I)V

    move v3, v9

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    move-object/from16 v19, v12

    move v12, v7

    move-object v7, v10

    const/4 v10, 0x0

    move-object/from16 v20, v11

    const/4 v11, 0x0

    move-object/from16 v21, v19

    move/from16 v19, v5

    move-object/from16 v5, v20

    invoke-static/range {v6 .. v13}, Lsn1;->a(Lun3;Lwj1;JLat4;ZZLnv3;)Ljava/util/ArrayList;

    move-result-object v6

    iget-boolean v8, v0, Lbo1;->y:Z

    if-eqz v8, :cond_12

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ne v8, v9, :cond_11

    move v9, v3

    goto :goto_c

    :cond_11
    move/from16 v9, v19

    :goto_c
    sget-object v8, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v10

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "The number of auxiliary track types from metadata ("

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, ") is not same as the number of auxiliary tracks ("

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, ")"

    invoke-virtual {v11, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v9}, La60;->E(Ljava/lang/String;Z)V

    :cond_12
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v9

    move/from16 v10, v19

    :cond_13
    :goto_d
    const/4 v11, -0x1

    if-ge v10, v9, :cond_14

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    add-int/lit8 v10, v10, 0x1

    check-cast v12, Lno1;

    iget-object v12, v12, Lno1;->a:Lko1;

    iget v12, v12, Lko1;->l:I

    if-eq v12, v11, :cond_13

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_13

    invoke-virtual {v8, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_d

    :cond_14
    iget-object v9, v0, Lbo1;->j:Ljava/util/ArrayList;

    invoke-virtual {v9}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v10

    move/from16 v12, v19

    :goto_e
    if-ge v12, v10, :cond_16

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    add-int/lit8 v12, v12, 0x1

    check-cast v13, Lno1;

    iget-object v3, v13, Lno1;->a:Lko1;

    iget v3, v3, Lko1;->a:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_15

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_15
    const/4 v3, 0x1

    goto :goto_e

    :cond_16
    invoke-static {v6}, Lw93;->k(Ljava/util/ArrayList;)Ljava/lang/String;

    move-result-object v3

    move/from16 v24, v11

    move/from16 v8, v19

    move v10, v8

    const-wide v12, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v22, -0x7fffffffffffffffL    # -4.9E-324

    :goto_f
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v8, v11, :cond_34

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lno1;

    iget v4, v11, Lno1;->b:I

    move-object/from16 v25, v1

    iget-object v1, v11, Lno1;->f:[J

    move/from16 v26, v4

    iget-object v4, v11, Lno1;->h:[I

    if-nez v26, :cond_17

    move-object/from16 v27, v6

    move-object/from16 v28, v15

    goto :goto_10

    :cond_17
    move-object/from16 v27, v6

    iget-object v6, v11, Lno1;->a:Lko1;

    move-object/from16 v28, v15

    iget-boolean v15, v6, Lko1;->m:Z

    if-nez v15, :cond_18

    :goto_10
    move-object v1, v3

    move-object/from16 v39, v14

    move/from16 v15, v24

    move-object/from16 v4, v28

    const/4 v3, -0x1

    move/from16 v24, v8

    move-object v14, v9

    move-object/from16 v8, v21

    goto/16 :goto_2c

    :cond_18
    new-instance v15, Lao1;

    move-object/from16 v29, v9

    iget-object v9, v0, Lbo1;->C:Lmj1;

    add-int/lit8 v30, v10, 0x1

    move-object/from16 v31, v3

    iget v3, v6, Lko1;->b:I

    invoke-interface {v9, v10, v3}, Lmj1;->c(II)Llk1;

    move-result-object v9

    invoke-direct {v15, v6, v11, v9}, Lao1;-><init>(Lko1;Lno1;Llk1;)V

    move-object/from16 v32, v9

    iget-wide v9, v6, Lko1;->e:J

    cmp-long v33, v9, v22

    if-nez v33, :cond_19

    iget-wide v9, v11, Lno1;->i:J

    :cond_19
    invoke-virtual/range {v32 .. v32}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v12, v13, v9, v10}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v12

    move-wide/from16 v33, v12

    iget-object v12, v6, Lko1;->g:Lfx4;

    iget-object v13, v12, Lfx4;->o:Ljava/lang/String;

    move-object/from16 v35, v15

    const-string v15, "audio/true-hd"

    invoke-virtual {v15, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    move/from16 v36, v15

    iget v15, v11, Lno1;->e:I

    if-eqz v36, :cond_1a

    mul-int/lit8 v15, v15, 0x10

    :goto_11
    move-object/from16 v36, v6

    goto :goto_12

    :cond_1a
    add-int/lit8 v15, v15, 0x1e

    goto :goto_11

    :goto_12
    new-instance v6, Law4;

    invoke-direct {v6, v12}, Law4;-><init>(Lfx4;)V

    iput v15, v6, Law4;->o:I

    const/4 v15, 0x2

    if-ne v3, v15, :cond_1e

    iget v3, v12, Lfx4;->f:I

    iget v15, v0, Lbo1;->b:I

    and-int/lit8 v15, v15, 0x8

    if-eqz v15, :cond_1c

    move/from16 v15, v24

    move/from16 v24, v3

    const/4 v3, -0x1

    if-ne v15, v3, :cond_1b

    const/4 v3, 0x1

    goto :goto_13

    :cond_1b
    const/4 v3, 0x2

    :goto_13
    or-int v3, v24, v3

    :goto_14
    move/from16 v24, v3

    goto :goto_15

    :cond_1c
    move/from16 v15, v24

    goto :goto_14

    :goto_15
    iget-boolean v3, v0, Lbo1;->y:Z

    if-eqz v3, :cond_1d

    const v3, 0x8000

    or-int v3, v24, v3

    invoke-interface {v14, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v24

    check-cast v24, Ljava/lang/Integer;

    move/from16 v37, v3

    invoke-virtual/range {v24 .. v24}, Ljava/lang/Integer;->intValue()I

    move-result v3

    iput v3, v6, Law4;->g:I

    move/from16 v3, v37

    goto :goto_16

    :cond_1d
    move/from16 v3, v24

    :goto_16
    iput v3, v6, Law4;->f:I

    const/4 v3, 0x2

    goto :goto_17

    :cond_1e
    move/from16 v15, v24

    :goto_17
    invoke-static {v13}, Lxr1;->b(Ljava/lang/String;)Z

    move-result v24

    if-eqz v24, :cond_28

    move/from16 v24, v8

    array-length v8, v1

    if-lez v8, :cond_27

    iget-boolean v8, v11, Lno1;->j:Z

    move-object/from16 v37, v1

    if-nez v8, :cond_1f

    array-length v1, v4

    goto :goto_18

    :cond_1f
    move/from16 v1, v26

    :goto_18
    cmp-long v26, v9, v22

    move-object/from16 v38, v4

    const/16 v4, 0x14

    invoke-static {v1, v4}, Ljava/lang/Math;->min(II)I

    move-result v1

    if-eqz v26, :cond_20

    const/4 v4, 0x1

    goto :goto_19

    :cond_20
    move/from16 v4, v19

    :goto_19
    invoke-static {v4}, La60;->D(Z)V

    move-object v4, v14

    move/from16 v26, v15

    const-wide/32 v14, 0x989680

    invoke-static {v9, v10, v14, v15}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v9

    move-object/from16 v39, v4

    move/from16 v14, v19

    move v15, v14

    const/4 v4, -0x1

    :goto_1a
    if-ge v14, v1, :cond_22

    if-eqz v8, :cond_21

    move/from16 v40, v14

    goto :goto_1b

    :cond_21
    aget v40, v38, v14

    :goto_1b
    aget-wide v41, v37, v40

    cmp-long v43, v41, v9

    if-lez v43, :cond_23

    :cond_22
    const/4 v1, -0x1

    goto :goto_1d

    :cond_23
    cmp-long v41, v41, v17

    if-ltz v41, :cond_24

    move/from16 v41, v1

    iget-object v1, v11, Lno1;->d:[I

    aget v1, v1, v40

    if-le v1, v15, :cond_25

    move v15, v1

    move/from16 v4, v40

    goto :goto_1c

    :cond_24
    move/from16 v41, v1

    :cond_25
    :goto_1c
    add-int/lit8 v14, v14, 0x1

    move/from16 v1, v41

    goto :goto_1a

    :goto_1d
    if-ne v4, v1, :cond_26

    :goto_1e
    move-wide/from16 v8, v22

    goto :goto_20

    :cond_26
    aget-wide v8, v37, v4

    goto :goto_20

    :cond_27
    :goto_1f
    move-object/from16 v39, v14

    move/from16 v26, v15

    goto :goto_1e

    :cond_28
    move/from16 v24, v8

    goto :goto_1f

    :goto_20
    cmp-long v1, v8, v22

    if-eqz v1, :cond_29

    new-instance v1, Lrp1;

    new-instance v4, Lrl1;

    invoke-direct {v4, v8, v9}, Lrl1;-><init>(J)V

    const/4 v8, 0x1

    new-array v9, v8, [Lyo1;

    aput-object v4, v9, v19

    invoke-direct {v1, v9}, Lrp1;-><init>([Lyo1;)V

    goto :goto_21

    :cond_29
    const/4 v8, 0x1

    move-object/from16 v1, v16

    :goto_21
    if-ne v3, v8, :cond_2a

    iget v4, v7, Lwj1;->a:I

    const/4 v8, -0x1

    if-eq v4, v8, :cond_2a

    iget v9, v7, Lwj1;->b:I

    if-eq v9, v8, :cond_2a

    iput v4, v6, Law4;->K:I

    iput v9, v6, Law4;->L:I

    :cond_2a
    iget-object v4, v12, Lfx4;->l:Lrp1;

    iget-object v8, v0, Lbo1;->i:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_2b

    move-object/from16 v9, v16

    :goto_22
    move-object/from16 v8, v21

    goto :goto_23

    :cond_2b
    new-instance v9, Lrp1;

    invoke-direct {v9, v8}, Lrp1;-><init>(Ljava/util/List;)V

    goto :goto_22

    :goto_23
    filled-new-array {v9, v5, v8, v1}, [Lrp1;

    move-result-object v1

    invoke-static {v3, v2, v6, v4, v1}, Lfv2;->k(ILrp1;Law4;Lrp1;[Lrp1;)V

    move-object/from16 v1, v31

    invoke-virtual {v6, v1}, Law4;->c(Ljava/lang/String;)V

    new-instance v4, Lfx4;

    invoke-direct {v4, v6}, Lfx4;-><init>(Law4;)V

    const-string v6, "audio/mpeg"

    invoke-static {v13, v6}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2c

    invoke-static {v13}, Ls9;->p(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2d

    :cond_2c
    move-object/from16 v6, v36

    const/4 v9, 0x1

    goto :goto_24

    :cond_2d
    move/from16 v9, v19

    move-object/from16 v6, v36

    :goto_24
    iget v6, v6, Lko1;->l:I

    const/4 v10, -0x1

    if-eq v6, v10, :cond_2f

    invoke-virtual/range {v29 .. v29}, Ljava/util/ArrayList;->size()I

    move-result v10

    move/from16 v11, v19

    :goto_25
    if-ge v11, v10, :cond_2f

    move-object/from16 v14, v29

    invoke-virtual {v14, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    add-int/lit8 v11, v11, 0x1

    check-cast v12, Lno1;

    iget-object v12, v12, Lno1;->a:Lko1;

    iget v12, v12, Lko1;->a:I

    if-ne v12, v6, :cond_2e

    const/4 v6, 0x1

    goto :goto_26

    :cond_2e
    move-object/from16 v29, v14

    goto :goto_25

    :cond_2f
    move-object/from16 v14, v29

    move/from16 v6, v19

    :goto_26
    if-nez v9, :cond_30

    if-eqz v6, :cond_31

    :cond_30
    move-object/from16 v6, v35

    goto :goto_28

    :cond_31
    move-object/from16 v6, v32

    invoke-interface {v6, v4}, Llk1;->c(Lfx4;)V

    move-object/from16 v6, v35

    :goto_27
    const/4 v15, 0x2

    goto :goto_29

    :goto_28
    iput-object v4, v6, Lao1;->h:Lfx4;

    goto :goto_27

    :goto_29
    if-ne v3, v15, :cond_33

    move/from16 v15, v26

    const/4 v3, -0x1

    if-ne v15, v3, :cond_32

    invoke-virtual/range {v28 .. v28}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v15, v4

    :cond_32
    :goto_2a
    move-object/from16 v4, v28

    goto :goto_2b

    :cond_33
    move/from16 v15, v26

    const/4 v3, -0x1

    goto :goto_2a

    :goto_2b
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v10, v30

    move-wide/from16 v12, v33

    :goto_2c
    add-int/lit8 v6, v24, 0x1

    move-object v3, v1

    move-object/from16 v21, v8

    move-object v9, v14

    move/from16 v24, v15

    move-object/from16 v1, v25

    move-object/from16 v14, v39

    move-object v15, v4

    move v8, v6

    move-object/from16 v6, v27

    const/4 v4, 0x2

    goto/16 :goto_f

    :cond_34
    move-object/from16 v25, v1

    move-object v14, v9

    move-object v4, v15

    move/from16 v6, v19

    move/from16 v15, v24

    const/4 v3, -0x1

    new-array v1, v6, [Lao1;

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lao1;

    iput-object v1, v0, Lbo1;->D:[Lao1;

    array-length v2, v1

    new-array v4, v2, [[J

    new-array v5, v2, [I

    new-array v6, v2, [J

    new-array v2, v2, [Z

    const/4 v7, 0x0

    :goto_2d
    array-length v8, v1

    if-ge v7, v8, :cond_35

    aget-object v8, v1, v7

    iget-object v8, v8, Lao1;->b:Lno1;

    iget v8, v8, Lno1;->b:I

    new-array v8, v8, [J

    aput-object v8, v4, v7

    aget-object v8, v1, v7

    iget-object v8, v8, Lao1;->b:Lno1;

    iget-object v8, v8, Lno1;->f:[J

    const/16 v19, 0x0

    aget-wide v9, v8, v19

    aput-wide v9, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_2d

    :cond_35
    const/4 v7, 0x0

    :goto_2e
    array-length v8, v1

    if-ge v7, v8, :cond_39

    const-wide v8, 0x7fffffffffffffffL

    move-wide v10, v8

    const/4 v9, 0x0

    move v8, v3

    :goto_2f
    array-length v3, v1

    if-ge v9, v3, :cond_37

    aget-boolean v3, v2, v9

    if-nez v3, :cond_36

    aget-wide v21, v6, v9

    cmp-long v3, v21, v10

    if-gtz v3, :cond_36

    move v8, v9

    move-wide/from16 v10, v21

    :cond_36
    add-int/lit8 v9, v9, 0x1

    goto :goto_2f

    :cond_37
    aget v3, v5, v8

    aget-object v9, v4, v8

    aput-wide v17, v9, v3

    aget-object v10, v1, v8

    iget-object v10, v10, Lao1;->b:Lno1;

    iget-object v11, v10, Lno1;->d:[I

    aget v11, v11, v3

    move-object/from16 v16, v1

    move-object/from16 v21, v2

    int-to-long v1, v11

    add-long v17, v17, v1

    const/16 v20, 0x1

    add-int/lit8 v3, v3, 0x1

    aput v3, v5, v8

    array-length v1, v9

    if-ge v3, v1, :cond_38

    iget-object v1, v10, Lno1;->f:[J

    aget-wide v2, v1, v3

    aput-wide v2, v6, v8

    :goto_30
    move-object/from16 v1, v16

    move-object/from16 v2, v21

    const/4 v3, -0x1

    goto :goto_2e

    :cond_38
    aput-boolean v20, v21, v8

    add-int/lit8 v7, v7, 0x1

    goto :goto_30

    :cond_39
    iput-object v4, v0, Lbo1;->E:[[J

    iget-object v1, v0, Lbo1;->C:Lmj1;

    invoke-interface {v1}, Lmj1;->e0()V

    iget-object v1, v0, Lbo1;->C:Lmj1;

    new-instance v2, Lzn1;

    iget-object v3, v0, Lbo1;->D:[Lao1;

    invoke-direct {v2, v12, v13, v3, v15}, Lzn1;-><init>(J[Lao1;I)V

    invoke-interface {v1, v2}, Lmj1;->f0(Lbk1;)V

    invoke-virtual/range {v25 .. v25}, Ljava/util/ArrayDeque;->clear()V

    iget-boolean v1, v0, Lbo1;->x:Z

    if-nez v1, :cond_0

    invoke-virtual {v14}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v3, 0x1

    if-eq v3, v1, :cond_3a

    const/4 v3, 0x4

    goto :goto_31

    :cond_3a
    const/4 v3, 0x2

    :goto_31
    iput v3, v0, Lbo1;->m:I

    goto/16 :goto_0

    :cond_3b
    move-object/from16 v25, v1

    invoke-virtual/range {v25 .. v25}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual/range {v25 .. v25}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lun3;

    iget-object v1, v1, Lun3;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_3c
    iget v1, v0, Lbo1;->m:I

    const/4 v2, 0x4

    if-eq v1, v2, :cond_3d

    const/4 v15, 0x2

    if-eq v1, v15, :cond_3d

    const/4 v6, 0x0

    iput v6, v0, Lbo1;->m:I

    iput v6, v0, Lbo1;->p:I

    :cond_3d
    return-void
.end method

.method public final b(Llj1;)Z
    .locals 2

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lms2;->v(Llj1;Z)Lfk1;

    move-result-object p1

    if-eqz p1, :cond_0

    invoke-static {p1}, Lmx3;->j(Ljava/lang/Object;)Lqy3;

    move-result-object v1

    goto :goto_0

    :cond_0
    sget-object v1, Lmx3;->i:Lix3;

    sget-object v1, Lqy3;->l:Lqy3;

    :goto_0
    iput-object v1, p0, Lbo1;->l:Lqy3;

    if-nez p1, :cond_1

    const/4 p0, 0x1

    return p0

    :cond_1
    return v0
.end method

.method public final c()V
    .locals 0

    return-void
.end method

.method public final synthetic d()Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lbo1;->l:Lqy3;

    return-object p0
.end method

.method public final e(Lmj1;)V
    .locals 2

    iget v0, p0, Lbo1;->b:I

    and-int/lit8 v0, v0, 0x10

    if-nez v0, :cond_0

    new-instance v0, Ljl;

    iget-object v1, p0, Lbo1;->a:Lcp1;

    invoke-direct {v0, p1, v1}, Ljl;-><init>(Lmj1;Lcp1;)V

    move-object p1, v0

    :cond_0
    iput-object p1, p0, Lbo1;->C:Lmj1;

    return-void
.end method

.method public final f(JJ)V
    .locals 5

    iget-object v0, p0, Lbo1;->g:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const/4 v0, 0x0

    iput v0, p0, Lbo1;->p:I

    const/4 v1, -0x1

    iput v1, p0, Lbo1;->r:I

    iput v0, p0, Lbo1;->s:I

    iput v0, p0, Lbo1;->t:I

    iput v0, p0, Lbo1;->u:I

    iput-boolean v0, p0, Lbo1;->v:Z

    iput v0, p0, Lbo1;->z:I

    iput v0, p0, Lbo1;->A:I

    iget-object v2, p0, Lbo1;->j:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iget-object v2, p0, Lbo1;->k:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const-wide/16 v2, 0x0

    cmp-long p1, p1, v2

    if-nez p1, :cond_1

    iget p1, p0, Lbo1;->m:I

    const/4 p2, 0x3

    if-eq p1, p2, :cond_0

    iput v0, p0, Lbo1;->m:I

    iput v0, p0, Lbo1;->p:I

    return-void

    :cond_0
    iget-object p1, p0, Lbo1;->h:Lio1;

    iget-object p2, p1, Lio1;->a:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->clear()V

    iput v0, p1, Lio1;->b:I

    iget-object p0, p0, Lbo1;->i:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void

    :cond_1
    iget-object p0, p0, Lbo1;->D:[Lao1;

    array-length p1, p0

    move p2, v0

    :goto_0
    if-ge p2, p1, :cond_4

    aget-object v2, p0, p2

    iget-object v3, v2, Lao1;->b:Lno1;

    invoke-virtual {v3, p3, p4}, Lno1;->a(J)I

    move-result v4

    if-ne v4, v1, :cond_2

    invoke-virtual {v3, p3, p4}, Lno1;->b(J)I

    move-result v4

    :cond_2
    iput v4, v2, Lao1;->g:I

    iget-object v2, v2, Lao1;->d:Lmk1;

    if-eqz v2, :cond_3

    iput-boolean v0, v2, Lmk1;->b:Z

    iput v0, v2, Lmk1;->c:I

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_4
    return-void
.end method

.method public final g(Llj1;Loj1;)I
    .locals 42

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    :cond_0
    :goto_0
    iget v3, v0, Lbo1;->m:I

    const v4, 0x66747970

    iget-object v5, v0, Lbo1;->g:Ljava/util/ArrayDeque;

    iget-object v8, v0, Lbo1;->e:Lzb3;

    const/4 v11, 0x0

    const/4 v14, 0x1

    const/4 v15, 0x0

    if-eqz v3, :cond_4b

    const-wide/32 v16, 0x40000

    const-wide/16 v18, -0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eq v3, v14, :cond_41

    const-wide/16 v20, 0x8

    const-string v4, "audio/mpeg"

    if-eq v3, v6, :cond_1d

    const/4 v5, 0x3

    if-eq v3, v5, :cond_a

    iget v3, v0, Lbo1;->z:I

    iget-object v5, v0, Lbo1;->j:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lno1;

    iget v7, v0, Lbo1;->A:I

    iget v9, v3, Lno1;->b:I

    iget-object v10, v0, Lbo1;->k:Ljava/util/ArrayList;

    if-ge v7, v9, :cond_3

    iget-object v4, v3, Lno1;->c:[J

    aget-wide v5, v4, v7

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v12

    cmp-long v4, v12, v5

    if-eqz v4, :cond_1

    iput-wide v5, v2, Loj1;->h:J

    return v14

    :cond_1
    iget-object v2, v3, Lno1;->d:[I

    iget v4, v0, Lbo1;->A:I

    aget v2, v2, v4

    invoke-virtual {v8, v2}, Lzb3;->y(I)V

    iget-object v4, v8, Lzb3;->a:[B

    invoke-interface {v1, v15, v2, v4}, Llj1;->B(II[B)V

    invoke-virtual {v8}, Lzb3;->J()I

    move-result v1

    invoke-virtual {v8}, Lzb3;->B()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v8, v1, v2}, Lzb3;->k(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v3, Lno1;->f:[J

    iget v4, v0, Lbo1;->A:I

    aget-wide v4, v2, v4

    invoke-static {v4, v5}, Lvh3;->t(J)J

    move-result-wide v17

    iget v4, v0, Lbo1;->A:I

    add-int/2addr v4, v14

    if-ge v4, v9, :cond_2

    aget-wide v3, v2, v4

    invoke-static {v3, v4}, Lvh3;->t(J)J

    move-result-wide v2

    :goto_1
    move-wide/from16 v19, v2

    goto :goto_2

    :cond_2
    iget-wide v2, v3, Lno1;->i:J

    invoke-static {v2, v3}, Lvh3;->t(J)J

    move-result-wide v2

    goto :goto_1

    :goto_2
    new-instance v2, Liy4;

    invoke-direct {v2, v11, v1}, Liy4;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v16, Lpl1;

    const/16 v21, 0x0

    move-object/from16 v22, v2

    invoke-direct/range {v16 .. v22}, Lpl1;-><init>(JJZLiy4;)V

    move-object/from16 v1, v16

    invoke-virtual {v10, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v1, v0, Lbo1;->A:I

    add-int/2addr v1, v14

    iput v1, v0, Lbo1;->A:I

    return v15

    :cond_3
    iget-object v1, v0, Lbo1;->D:[Lao1;

    array-length v2, v1

    move v7, v15

    :goto_3
    if-ge v7, v2, :cond_8

    aget-object v8, v1, v7

    iget-object v9, v8, Lao1;->a:Lko1;

    iget v9, v9, Lko1;->l:I

    iget-object v12, v3, Lno1;->a:Lko1;

    iget v12, v12, Lko1;->a:I

    if-ne v9, v12, :cond_7

    iget-object v9, v8, Lao1;->h:Lfx4;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v9, Lfx4;->l:Lrp1;

    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    move/from16 v22, v14

    if-eqz v12, :cond_4

    const-class v14, Lyo1;

    sget-object v6, Lvj1;->k:Lvj1;

    invoke-virtual {v12, v14, v6}, Lrp1;->a(Ljava/lang/Class;Lqv3;)Lqy3;

    move-result-object v6

    invoke-virtual {v13, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_4
    invoke-virtual {v13, v10}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    new-instance v6, Law4;

    invoke-direct {v6, v9}, Law4;-><init>(Lfx4;)V

    new-instance v9, Lrp1;

    invoke-direct {v9, v13}, Lrp1;-><init>(Ljava/util/List;)V

    iput-object v9, v6, Law4;->k:Lrp1;

    new-instance v9, Lfx4;

    invoke-direct {v9, v6}, Lfx4;-><init>(Law4;)V

    iget-object v6, v9, Lfx4;->o:Ljava/lang/String;

    invoke-static {v6, v4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_6

    invoke-static {v6}, Ls9;->p(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_5

    goto :goto_4

    :cond_5
    iget-object v6, v8, Lao1;->c:Llk1;

    invoke-interface {v6, v9}, Llk1;->c(Lfx4;)V

    iput-object v11, v8, Lao1;->h:Lfx4;

    goto :goto_5

    :cond_6
    :goto_4
    iput-object v9, v8, Lao1;->h:Lfx4;

    goto :goto_5

    :cond_7
    move/from16 v22, v14

    :goto_5
    add-int/lit8 v7, v7, 0x1

    move/from16 v14, v22

    const/4 v6, 0x2

    goto :goto_3

    :cond_8
    move/from16 v22, v14

    iget v1, v0, Lbo1;->z:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lbo1;->z:I

    iput v15, v0, Lbo1;->A:I

    invoke-virtual {v10}, Ljava/util/ArrayList;->clear()V

    iget v1, v0, Lbo1;->z:I

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-eq v1, v2, :cond_9

    return v15

    :cond_9
    const/4 v1, 0x2

    iput v1, v0, Lbo1;->m:I

    return v15

    :cond_a
    move/from16 v22, v14

    iget-object v3, v0, Lbo1;->h:Lio1;

    iget-object v4, v3, Lio1;->a:Ljava/util/ArrayList;

    iget v6, v3, Lio1;->b:I

    if-eqz v6, :cond_19

    move/from16 v8, v22

    if-eq v6, v8, :cond_17

    const/16 v8, 0x890

    const/16 v14, 0xb03

    const/16 v24, -0x1

    const/16 v12, 0xb00

    const/16 v25, 0x8

    const/16 v13, 0xb04

    const/16 v9, 0xb01

    const/4 v10, 0x2

    if-eq v6, v10, :cond_12

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v16

    invoke-interface {v1}, Llj1;->s()J

    move-result-wide v18

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v20

    sub-long v18, v18, v20

    iget v3, v3, Lio1;->c:I

    int-to-long v5, v3

    new-instance v3, Lzb3;

    sub-long v5, v18, v5

    long-to-int v5, v5

    invoke-direct {v3, v5}, Lzb3;-><init>(I)V

    iget-object v6, v3, Lzb3;->a:[B

    invoke-interface {v1, v15, v5, v6}, Llj1;->B(II[B)V

    move v1, v15

    :goto_6
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v1, v5, :cond_11

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lho1;

    iget-wide v10, v5, Lho1;->a:J

    sub-long v10, v10, v16

    long-to-int v10, v10

    invoke-virtual {v3, v10}, Lzb3;->D(I)V

    invoke-virtual {v3, v7}, Lzb3;->E(I)V

    invoke-virtual {v3}, Lzb3;->c()I

    move-result v10

    sget-object v11, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v3, v10, v11}, Lzb3;->k(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->hashCode()I

    move-result v19

    sparse-switch v19, :sswitch_data_0

    goto/16 :goto_a

    :sswitch_0
    const-string v7, "Super_SlowMotion_BGM"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    move v6, v9

    goto :goto_7

    :sswitch_1
    const-string v7, "Super_SlowMotion_Deflickering_On"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    move v6, v13

    goto :goto_7

    :sswitch_2
    const-string v7, "Super_SlowMotion_Data"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    move v6, v12

    goto :goto_7

    :sswitch_3
    const-string v7, "Super_SlowMotion_Edit_Data"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    move v6, v14

    goto :goto_7

    :sswitch_4
    const-string v7, "SlowMotion_Data"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    move v6, v8

    :goto_7
    iget v5, v5, Lho1;->b:I

    add-int/lit8 v10, v10, 0x8

    sub-int/2addr v5, v10

    if-eq v6, v8, :cond_c

    if-eq v6, v12, :cond_f

    if-eq v6, v9, :cond_f

    if-eq v6, v14, :cond_f

    if-ne v6, v13, :cond_b

    goto/16 :goto_9

    :cond_b
    invoke-static {}, Lb;->a()V

    return v15

    :cond_c
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v3, v5, v11}, Lzb3;->k(ILjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object v5

    sget-object v6, Lio1;->e:Lyy;

    invoke-virtual {v6, v5}, Lyy;->t(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v5

    move v6, v15

    :goto_8
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v10

    if-ge v6, v10, :cond_e

    sget-object v10, Lio1;->d:Lyy;

    invoke-interface {v5, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    invoke-virtual {v10, v11}, Lyy;->t(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v10

    const/4 v13, 0x3

    if-ne v10, v13, :cond_d

    :try_start_0
    invoke-interface {v11, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v30

    const/4 v13, 0x1

    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    invoke-static/range {v18 .. v18}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v32

    const/4 v13, 0x2

    invoke-interface {v11, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    add-int/lit8 v11, v11, -0x1

    const/16 v22, 0x1

    shl-int v29, v22, v11

    new-instance v28, Llm1;

    invoke-direct/range {v28 .. v33}, Llm1;-><init>(IJJ)V

    move-object/from16 v11, v28

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v6, v6, 0x1

    const/16 v13, 0xb04

    goto :goto_8

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    invoke-static {v0, v6}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_d
    const/4 v6, 0x0

    invoke-static {v6, v6}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_e
    new-instance v5, Lmm1;

    invoke-direct {v5, v7}, Lmm1;-><init>(Ljava/util/ArrayList;)V

    iget-object v7, v0, Lbo1;->i:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_f
    :goto_9
    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v11, 0x0

    const/16 v13, 0xb04

    goto/16 :goto_6

    :cond_10
    :goto_a
    const-string v0, "Invalid SEF name"

    const/4 v6, 0x0

    invoke-static {v6, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_11
    const-wide/16 v3, 0x0

    iput-wide v3, v2, Loj1;->h:J

    :goto_b
    const-wide/16 v5, 0x0

    const/4 v13, 0x1

    const-wide/16 v26, 0x0

    goto/16 :goto_10

    :cond_12
    invoke-interface {v1}, Llj1;->s()J

    move-result-wide v5

    iget v7, v3, Lio1;->c:I

    add-int/lit8 v7, v7, -0x14

    new-instance v11, Lzb3;

    invoke-direct {v11, v7}, Lzb3;-><init>(I)V

    iget-object v13, v11, Lzb3;->a:[B

    invoke-interface {v1, v15, v7, v13}, Llj1;->B(II[B)V

    move v1, v15

    :goto_c
    div-int/lit8 v13, v7, 0xc

    if-ge v1, v13, :cond_15

    const/4 v13, 0x2

    invoke-virtual {v11, v13}, Lzb3;->E(I)V

    sget-object v10, Lwm1;->m:Lwm1;

    invoke-virtual {v11, v13, v10}, Lzb3;->v(ILnv3;)V

    iget-object v10, v11, Lzb3;->a:[B

    move/from16 v23, v13

    iget v13, v11, Lzb3;->b:I

    add-int/lit8 v15, v13, 0x1

    iput v15, v11, Lzb3;->b:I

    aget-byte v14, v10, v13

    and-int/lit16 v14, v14, 0xff

    add-int/lit8 v13, v13, 0x2

    iput v13, v11, Lzb3;->b:I

    aget-byte v10, v10, v15

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x8

    or-int/2addr v10, v14

    int-to-short v10, v10

    if-eq v10, v8, :cond_13

    if-eq v10, v12, :cond_13

    if-eq v10, v9, :cond_13

    const/16 v13, 0xb03

    const/16 v14, 0xb04

    if-eq v10, v13, :cond_14

    if-eq v10, v14, :cond_14

    move/from16 v10, v25

    invoke-virtual {v11, v10}, Lzb3;->E(I)V

    goto :goto_d

    :cond_13
    const/16 v13, 0xb03

    const/16 v14, 0xb04

    :cond_14
    iget v10, v3, Lio1;->c:I

    int-to-long v8, v10

    sub-long v8, v5, v8

    invoke-virtual {v11}, Lzb3;->c()I

    move-result v10

    int-to-long v12, v10

    invoke-virtual {v11}, Lzb3;->c()I

    move-result v10

    new-instance v14, Lho1;

    sub-long/2addr v8, v12

    invoke-direct {v14, v8, v9, v10}, Lho1;-><init>(JI)V

    invoke-virtual {v4, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_d
    add-int/lit8 v1, v1, 0x1

    const/16 v8, 0x890

    const/16 v9, 0xb01

    const/16 v12, 0xb00

    const/16 v14, 0xb03

    const/4 v15, 0x0

    const/16 v25, 0x8

    goto :goto_c

    :cond_15
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_16

    const-wide/16 v5, 0x0

    iput-wide v5, v2, Loj1;->h:J

    goto/16 :goto_b

    :cond_16
    const/4 v10, 0x3

    iput v10, v3, Lio1;->b:I

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lho1;

    iget-wide v3, v1, Lho1;->a:J

    iput-wide v3, v2, Loj1;->h:J

    move-wide/from16 v26, v3

    :goto_e
    const-wide/16 v5, 0x0

    const/4 v13, 0x1

    goto :goto_10

    :cond_17
    move v5, v15

    new-instance v4, Lzb3;

    const/16 v10, 0x8

    invoke-direct {v4, v10}, Lzb3;-><init>(I)V

    iget-object v6, v4, Lzb3;->a:[B

    invoke-interface {v1, v5, v10, v6}, Llj1;->B(II[B)V

    invoke-virtual {v4}, Lzb3;->c()I

    move-result v5

    add-int/2addr v5, v10

    iput v5, v3, Lio1;->c:I

    invoke-virtual {v4}, Lzb3;->b()I

    move-result v4

    const v5, 0x53454654

    if-eq v4, v5, :cond_18

    const-wide/16 v5, 0x0

    iput-wide v5, v2, Loj1;->h:J

    goto/16 :goto_b

    :cond_18
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v4

    iget v1, v3, Lio1;->c:I

    add-int/lit8 v1, v1, -0xc

    int-to-long v6, v1

    sub-long/2addr v4, v6

    iput-wide v4, v2, Loj1;->h:J

    const/4 v13, 0x2

    iput v13, v3, Lio1;->b:I

    move-wide/from16 v26, v4

    goto :goto_e

    :cond_19
    invoke-interface {v1}, Llj1;->s()J

    move-result-wide v4

    cmp-long v1, v4, v18

    if-eqz v1, :cond_1a

    cmp-long v1, v4, v20

    if-gez v1, :cond_1b

    :cond_1a
    const-wide/16 v4, 0x0

    goto :goto_f

    :cond_1b
    const-wide/16 v6, -0x8

    add-long/2addr v4, v6

    :goto_f
    iput-wide v4, v2, Loj1;->h:J

    const/4 v13, 0x1

    iput v13, v3, Lio1;->b:I

    move-wide/from16 v26, v4

    const-wide/16 v5, 0x0

    :goto_10
    cmp-long v1, v26, v5

    if-eqz v1, :cond_1c

    goto/16 :goto_27

    :cond_1c
    const/4 v5, 0x0

    iput v5, v0, Lbo1;->m:I

    iput v5, v0, Lbo1;->p:I

    return v13

    :cond_1d
    const/16 v24, -0x1

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v9

    iget v3, v0, Lbo1;->r:I

    move/from16 v5, v24

    if-ne v3, v5, :cond_2a

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v7, -0x1

    const-wide v11, 0x7fffffffffffffffL

    const/4 v13, -0x1

    const/4 v14, -0x1

    const/4 v15, 0x0

    const-wide v18, 0x7fffffffffffffffL

    const-wide v29, 0x7fffffffffffffffL

    const-wide v31, 0x7fffffffffffffffL

    const-wide v33, 0x7fffffffffffffffL

    const-wide v35, 0x7fffffffffffffffL

    :goto_11
    iget-object v6, v0, Lbo1;->D:[Lao1;

    move/from16 v37, v3

    array-length v3, v6

    if-ge v15, v3, :cond_27

    aget-object v3, v6, v15

    iget v6, v3, Lao1;->g:I

    move/from16 v38, v5

    iget-object v5, v3, Lao1;->b:Lno1;

    move-wide/from16 v39, v9

    iget v9, v5, Lno1;->b:I

    if-ne v6, v9, :cond_1e

    move/from16 v3, v37

    move/from16 v5, v38

    goto/16 :goto_16

    :cond_1e
    iget-object v9, v5, Lno1;->f:[J

    move v10, v13

    move/from16 v41, v14

    aget-wide v13, v9, v6

    iget-boolean v9, v3, Lao1;->e:Z

    if-eqz v9, :cond_1f

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v11

    goto :goto_12

    :cond_1f
    iget-boolean v3, v3, Lao1;->f:Z

    if-eqz v3, :cond_20

    cmp-long v3, v13, v31

    if-gez v3, :cond_20

    move-wide/from16 v31, v13

    move v7, v15

    :cond_20
    :goto_12
    iget-object v3, v5, Lno1;->c:[J

    aget-wide v13, v3, v6

    iget-object v3, v0, Lbo1;->E:[[J

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    aget-object v3, v3, v15

    aget-wide v5, v3, v6

    sub-long v13, v13, v39

    const-wide/16 v26, 0x0

    cmp-long v3, v13, v26

    if-ltz v3, :cond_21

    cmp-long v3, v13, v16

    if-ltz v3, :cond_22

    :cond_21
    const/4 v3, 0x1

    goto :goto_13

    :cond_22
    const/4 v3, 0x0

    :goto_13
    if-nez v3, :cond_23

    if-nez v38, :cond_24

    const/4 v9, 0x0

    goto :goto_14

    :cond_23
    move/from16 v9, v38

    :goto_14
    if-ne v3, v9, :cond_25

    cmp-long v38, v13, v35

    if-gez v38, :cond_25

    :cond_24
    move v9, v3

    move-wide/from16 v33, v5

    move-wide/from16 v35, v13

    move v14, v15

    goto :goto_15

    :cond_25
    move/from16 v14, v41

    :goto_15
    cmp-long v13, v5, v29

    if-gez v13, :cond_26

    move-wide/from16 v29, v5

    move v5, v9

    move v13, v15

    goto :goto_16

    :cond_26
    move v5, v9

    move v13, v10

    move/from16 v3, v37

    :goto_16
    add-int/lit8 v15, v15, 0x1

    move-wide/from16 v9, v39

    goto :goto_11

    :cond_27
    move-wide/from16 v39, v9

    move v10, v13

    move/from16 v41, v14

    cmp-long v3, v11, v18

    if-eqz v3, :cond_28

    const/4 v5, -0x1

    if-eq v7, v5, :cond_28

    cmp-long v3, v31, v11

    if-gtz v3, :cond_28

    move v3, v7

    goto :goto_17

    :cond_28
    cmp-long v3, v29, v18

    if-eqz v3, :cond_29

    if-eqz v37, :cond_29

    const-wide/32 v5, 0xa00000

    add-long v29, v29, v5

    cmp-long v3, v33, v29

    if-ltz v3, :cond_29

    move v3, v10

    goto :goto_17

    :cond_29
    move/from16 v3, v41

    :goto_17
    iput v3, v0, Lbo1;->r:I

    const/4 v5, -0x1

    if-ne v3, v5, :cond_2b

    move/from16 v24, v5

    goto/16 :goto_28

    :cond_2a
    move-wide/from16 v39, v9

    :cond_2b
    iget-object v5, v0, Lbo1;->D:[Lao1;

    aget-object v3, v5, v3

    iget-object v9, v3, Lao1;->c:Llk1;

    iget v5, v3, Lao1;->g:I

    iget-object v7, v3, Lao1;->b:Lno1;

    iget-object v6, v7, Lno1;->c:[J

    aget-wide v10, v6, v5

    iget-wide v12, v0, Lbo1;->B:J

    add-long/2addr v10, v12

    iget-object v12, v7, Lno1;->d:[I

    aget v6, v12, v5

    iget-object v13, v3, Lao1;->d:Lmk1;

    sub-long v14, v10, v39

    move/from16 v18, v5

    iget v5, v0, Lbo1;->s:I

    move/from16 v19, v6

    int-to-long v5, v5

    add-long/2addr v14, v5

    const-wide/16 v26, 0x0

    cmp-long v5, v14, v26

    if-ltz v5, :cond_2c

    cmp-long v5, v14, v16

    if-ltz v5, :cond_2d

    :cond_2c
    const/16 v22, 0x1

    goto/16 :goto_21

    :cond_2d
    iget-object v2, v3, Lao1;->a:Lko1;

    iget v5, v2, Lko1;->h:I

    const/4 v6, 0x1

    if-ne v5, v6, :cond_2e

    add-long v14, v14, v20

    add-int/lit8 v6, v19, -0x8

    move v5, v6

    goto :goto_18

    :cond_2e
    move/from16 v5, v19

    :goto_18
    long-to-int v6, v14

    invoke-interface {v1, v6}, Llj1;->w(I)V

    iget-object v10, v2, Lko1;->g:Lfx4;

    iget-object v11, v10, Lfx4;->o:Ljava/lang/String;

    const-string v6, "video/avc"

    invoke-static {v11, v6}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    iget v14, v0, Lbo1;->b:I

    if-eqz v6, :cond_30

    and-int/lit8 v6, v14, 0x20

    if-nez v6, :cond_2f

    :goto_19
    const/4 v6, 0x1

    goto :goto_1a

    :cond_2f
    const/4 v6, 0x1

    goto :goto_1b

    :cond_30
    const-string v6, "video/hevc"

    invoke-static {v11, v6}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_31

    and-int/lit16 v6, v14, 0x80

    if-nez v6, :cond_2f

    goto :goto_19

    :cond_31
    const-string v6, "video/apv"

    invoke-static {v11, v6}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2f

    goto :goto_19

    :goto_1a
    iput-boolean v6, v0, Lbo1;->v:Z

    :goto_1b
    iget v2, v2, Lko1;->k:I

    if-eqz v2, :cond_37

    iget-object v4, v0, Lbo1;->d:Lzb3;

    iget-object v8, v4, Lzb3;->a:[B

    const/16 v28, 0x0

    aput-byte v28, v8, v28

    aput-byte v28, v8, v6

    const/16 v23, 0x2

    aput-byte v28, v8, v23

    rsub-int/lit8 v11, v2, 0x4

    add-int/2addr v5, v11

    :cond_32
    :goto_1c
    iget v6, v0, Lbo1;->t:I

    if-ge v6, v5, :cond_36

    iget v14, v0, Lbo1;->u:I

    if-nez v14, :cond_35

    iget-boolean v6, v0, Lbo1;->v:Z

    if-nez v6, :cond_33

    invoke-static {v10}, Lic1;->v(Lfx4;)I

    move-result v6

    add-int/2addr v6, v2

    aget v14, v12, v18

    iget v15, v0, Lbo1;->s:I

    sub-int/2addr v14, v15

    if-gt v6, v14, :cond_33

    invoke-static {v10}, Lic1;->v(Lfx4;)I

    move-result v6

    add-int v14, v2, v6

    goto :goto_1d

    :cond_33
    move v14, v2

    const/4 v6, 0x0

    :goto_1d
    invoke-interface {v1, v11, v14, v8}, Llj1;->B(II[B)V

    iget v15, v0, Lbo1;->s:I

    add-int/2addr v15, v14

    iput v15, v0, Lbo1;->s:I

    const/4 v14, 0x0

    invoke-virtual {v4, v14}, Lzb3;->D(I)V

    invoke-virtual {v4}, Lzb3;->b()I

    move-result v15

    if-ltz v15, :cond_34

    sub-int/2addr v15, v6

    iput v15, v0, Lbo1;->u:I

    iget-object v15, v0, Lbo1;->c:Lzb3;

    invoke-virtual {v15, v14}, Lzb3;->D(I)V

    const/4 v14, 0x4

    invoke-interface {v9, v14, v15}, Llk1;->a(ILzb3;)V

    iget v15, v0, Lbo1;->t:I

    add-int/2addr v15, v14

    iput v15, v0, Lbo1;->t:I

    if-lez v6, :cond_32

    invoke-interface {v9, v6, v4}, Llk1;->a(ILzb3;)V

    iget v14, v0, Lbo1;->t:I

    add-int/2addr v14, v6

    iput v14, v0, Lbo1;->t:I

    invoke-static {v8, v6, v10}, Lic1;->D([BILfx4;)Z

    move-result v6

    if-eqz v6, :cond_32

    const/4 v6, 0x1

    iput-boolean v6, v0, Lbo1;->v:Z

    goto :goto_1c

    :cond_34
    const-string v0, "Invalid NAL length"

    const/4 v6, 0x0

    invoke-static {v6, v0}, Lis1;->a(Ljava/lang/RuntimeException;Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_35
    const/4 v15, 0x0

    invoke-interface {v9, v1, v14, v15}, Llk1;->b(Ltl4;IZ)I

    move-result v14

    iget v15, v0, Lbo1;->s:I

    add-int/2addr v15, v14

    iput v15, v0, Lbo1;->s:I

    iget v15, v0, Lbo1;->t:I

    add-int/2addr v15, v14

    iput v15, v0, Lbo1;->t:I

    iget v15, v0, Lbo1;->u:I

    sub-int/2addr v15, v14

    iput v15, v0, Lbo1;->u:I

    goto :goto_1c

    :cond_36
    move/from16 v34, v5

    goto/16 :goto_1f

    :cond_37
    iget-object v2, v3, Lao1;->h:Lfx4;

    const-string v10, "audio/ac4"

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_39

    iget v2, v0, Lbo1;->t:I

    if-nez v2, :cond_38

    invoke-static {v5, v8}, Lgx1;->y(ILzb3;)V

    const/4 v2, 0x7

    invoke-interface {v9, v2, v8}, Llk1;->a(ILzb3;)V

    iget v4, v0, Lbo1;->t:I

    add-int/2addr v4, v2

    iput v4, v0, Lbo1;->t:I

    :cond_38
    add-int/lit8 v5, v5, 0x7

    goto :goto_1e

    :cond_39
    if-eqz v2, :cond_3b

    invoke-static {v11, v4}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3b

    const/4 v14, 0x4

    invoke-virtual {v8, v14}, Lzb3;->y(I)V

    iget-object v4, v8, Lzb3;->a:[B

    const/4 v15, 0x0

    invoke-interface {v1, v15, v14, v4}, Llj1;->v(II[B)V

    invoke-interface {v1}, Llj1;->j()V

    new-instance v4, Lzj1;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v8}, Lzb3;->b()I

    move-result v8

    invoke-virtual {v4, v8}, Lzj1;->a(I)Z

    move-result v8

    if-eqz v8, :cond_3a

    iget-object v8, v2, Lfx4;->o:Ljava/lang/String;

    iget-object v10, v4, Lzj1;->g:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    invoke-static {v8, v10}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3a

    new-instance v8, Law4;

    invoke-direct {v8, v2}, Law4;-><init>(Lfx4;)V

    iget-object v2, v4, Lzj1;->g:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8, v2}, Law4;->d(Ljava/lang/String;)V

    new-instance v2, Lfx4;

    invoke-direct {v2, v8}, Lfx4;-><init>(Law4;)V

    :cond_3a
    invoke-interface {v9, v2}, Llk1;->c(Lfx4;)V

    const/4 v6, 0x0

    iput-object v6, v3, Lao1;->h:Lfx4;

    goto :goto_1e

    :cond_3b
    const/4 v6, 0x0

    if-eqz v2, :cond_3c

    invoke-static {v11}, Ls9;->p(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3c

    invoke-static {v1, v5, v2}, Ls9;->x(Llj1;ILfx4;)Lfx4;

    move-result-object v2

    invoke-interface {v9, v2}, Llk1;->c(Lfx4;)V

    iput-object v6, v3, Lao1;->h:Lfx4;

    goto :goto_1e

    :cond_3c
    if-eqz v13, :cond_3d

    invoke-virtual {v13, v1}, Lmk1;->a(Llj1;)V

    :cond_3d
    :goto_1e
    iget v2, v0, Lbo1;->t:I

    if-ge v2, v5, :cond_36

    sub-int v2, v5, v2

    const/4 v15, 0x0

    invoke-interface {v9, v1, v2, v15}, Llk1;->b(Ltl4;IZ)I

    move-result v2

    iget v4, v0, Lbo1;->s:I

    add-int/2addr v4, v2

    iput v4, v0, Lbo1;->s:I

    iget v4, v0, Lbo1;->t:I

    add-int/2addr v4, v2

    iput v4, v0, Lbo1;->t:I

    iget v4, v0, Lbo1;->u:I

    sub-int/2addr v4, v2

    iput v4, v0, Lbo1;->u:I

    goto :goto_1e

    :goto_1f
    iget-object v1, v7, Lno1;->f:[J

    aget-wide v31, v1, v18

    iget-object v1, v7, Lno1;->g:[I

    aget v1, v1, v18

    iget-boolean v2, v0, Lbo1;->v:Z

    if-nez v2, :cond_3e

    const/high16 v2, 0x4000000

    or-int/2addr v1, v2

    :cond_3e
    move/from16 v33, v1

    if-eqz v13, :cond_3f

    const/16 v35, 0x0

    const/16 v36, 0x0

    move-object/from16 v30, v9

    move-object/from16 v29, v13

    invoke-virtual/range {v29 .. v36}, Lmk1;->b(Llk1;JIIILhk1;)V

    move-object/from16 v1, v29

    const/16 v22, 0x1

    add-int/lit8 v5, v18, 0x1

    iget v2, v7, Lno1;->b:I

    if-ne v5, v2, :cond_40

    const/4 v6, 0x0

    invoke-virtual {v1, v9, v6}, Lmk1;->c(Llk1;Lhk1;)V

    goto :goto_20

    :cond_3f
    move/from16 v13, v34

    const/16 v22, 0x1

    const/4 v14, 0x0

    const/4 v15, 0x0

    move-wide/from16 v10, v31

    move/from16 v12, v33

    invoke-interface/range {v9 .. v15}, Llk1;->d(JIIILhk1;)V

    :cond_40
    :goto_20
    iget v1, v3, Lao1;->g:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v3, Lao1;->g:I

    const/4 v5, -0x1

    iput v5, v0, Lbo1;->r:I

    const/4 v15, 0x0

    iput v15, v0, Lbo1;->s:I

    iput v15, v0, Lbo1;->t:I

    iput v15, v0, Lbo1;->u:I

    iput-boolean v15, v0, Lbo1;->v:Z

    return v15

    :goto_21
    iput-wide v10, v2, Loj1;->h:J

    return v22

    :cond_41
    iget-wide v6, v0, Lbo1;->o:J

    iget v3, v0, Lbo1;->p:I

    int-to-long v8, v3

    sub-long/2addr v6, v8

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v8

    add-long/2addr v8, v6

    iget-object v3, v0, Lbo1;->q:Lzb3;

    if-eqz v3, :cond_46

    iget-object v10, v3, Lzb3;->a:[B

    iget v11, v0, Lbo1;->p:I

    long-to-int v6, v6

    invoke-interface {v1, v11, v6, v10}, Llj1;->B(II[B)V

    iget v6, v0, Lbo1;->n:I

    if-ne v6, v4, :cond_45

    const/4 v6, 0x1

    iput-boolean v6, v0, Lbo1;->w:Z

    const/16 v10, 0x8

    invoke-virtual {v3, v10}, Lzb3;->D(I)V

    invoke-virtual {v3}, Lzb3;->b()I

    move-result v4

    const v5, 0x71742020

    if-eq v4, v5, :cond_42

    const/4 v14, 0x4

    invoke-virtual {v3, v14}, Lzb3;->E(I)V

    :goto_22
    invoke-virtual {v3}, Lzb3;->B()I

    move-result v4

    if-lez v4, :cond_43

    invoke-virtual {v3}, Lzb3;->b()I

    move-result v4

    if-eq v4, v5, :cond_42

    goto :goto_22

    :cond_42
    const/4 v3, 0x1

    goto :goto_23

    :cond_43
    const/4 v3, 0x0

    :goto_23
    iput v3, v0, Lbo1;->F:I

    :cond_44
    :goto_24
    const/4 v3, 0x0

    goto :goto_25

    :cond_45
    invoke-virtual {v5}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_44

    invoke-virtual {v5}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lun3;

    new-instance v5, Leo3;

    iget v6, v0, Lbo1;->n:I

    invoke-direct {v5, v6, v3}, Leo3;-><init>(ILzb3;)V

    iget-object v3, v4, Lun3;->c:Ljava/util/ArrayList;

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_24

    :cond_46
    iget-boolean v3, v0, Lbo1;->w:Z

    if-nez v3, :cond_47

    iget v3, v0, Lbo1;->n:I

    const v4, 0x6d646174

    if-ne v3, v4, :cond_47

    const/4 v13, 0x1

    iput v13, v0, Lbo1;->F:I

    :cond_47
    cmp-long v3, v6, v16

    if-gez v3, :cond_48

    long-to-int v3, v6

    invoke-interface {v1, v3}, Llj1;->w(I)V

    goto :goto_24

    :cond_48
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v3

    add-long/2addr v3, v6

    iput-wide v3, v2, Loj1;->h:J

    const/4 v3, 0x1

    :goto_25
    invoke-virtual {v0, v8, v9}, Lbo1;->a(J)V

    iget-boolean v4, v0, Lbo1;->x:Z

    const/4 v13, 0x1

    if-eqz v4, :cond_49

    iput-boolean v13, v0, Lbo1;->y:Z

    const-wide/16 v5, 0x0

    iput-wide v5, v2, Loj1;->h:J

    const/4 v15, 0x0

    iput-boolean v15, v0, Lbo1;->x:Z

    goto :goto_26

    :cond_49
    if-nez v3, :cond_4a

    goto/16 :goto_0

    :cond_4a
    :goto_26
    iget v3, v0, Lbo1;->m:I

    const/4 v10, 0x2

    if-eq v3, v10, :cond_0

    :goto_27
    return v13

    :cond_4b
    move v13, v14

    const-wide/16 v18, -0x1

    iget v3, v0, Lbo1;->p:I

    iget-object v7, v0, Lbo1;->f:Lzb3;

    if-nez v3, :cond_4d

    iget-object v3, v7, Lzb3;->a:[B

    const/16 v10, 0x8

    const/4 v15, 0x0

    invoke-interface {v1, v3, v15, v10, v13}, Llj1;->x([BIIZ)Z

    move-result v3

    if-nez v3, :cond_4c

    const/16 v24, -0x1

    :goto_28
    return v24

    :cond_4c
    iput v10, v0, Lbo1;->p:I

    invoke-virtual {v7, v15}, Lzb3;->D(I)V

    invoke-virtual {v7}, Lzb3;->N()J

    move-result-wide v9

    iput-wide v9, v0, Lbo1;->o:J

    invoke-virtual {v7}, Lzb3;->b()I

    move-result v3

    iput v3, v0, Lbo1;->n:I

    :cond_4d
    iget-wide v9, v0, Lbo1;->o:J

    const-wide/16 v11, 0x1

    cmp-long v3, v9, v11

    if-nez v3, :cond_4e

    iget-object v3, v7, Lzb3;->a:[B

    const/16 v10, 0x8

    invoke-interface {v1, v10, v10, v3}, Llj1;->B(II[B)V

    iget v3, v0, Lbo1;->p:I

    add-int/2addr v3, v10

    iput v3, v0, Lbo1;->p:I

    invoke-virtual {v7}, Lzb3;->j()J

    move-result-wide v9

    iput-wide v9, v0, Lbo1;->o:J

    goto :goto_2a

    :cond_4e
    const-wide/16 v26, 0x0

    cmp-long v3, v9, v26

    if-nez v3, :cond_51

    invoke-interface {v1}, Llj1;->s()J

    move-result-wide v9

    cmp-long v3, v9, v18

    if-nez v3, :cond_50

    invoke-virtual {v5}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lun3;

    if-eqz v3, :cond_4f

    iget-wide v9, v3, Lun3;->b:J

    goto :goto_29

    :cond_4f
    move-wide/from16 v9, v18

    :cond_50
    :goto_29
    cmp-long v3, v9, v18

    if-eqz v3, :cond_51

    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v11

    sub-long/2addr v9, v11

    iget v3, v0, Lbo1;->p:I

    int-to-long v11, v3

    add-long/2addr v9, v11

    iput-wide v9, v0, Lbo1;->o:J

    :cond_51
    :goto_2a
    iget-wide v9, v0, Lbo1;->o:J

    iget v3, v0, Lbo1;->p:I

    int-to-long v11, v3

    cmp-long v9, v9, v11

    if-gez v9, :cond_53

    iget v9, v0, Lbo1;->n:I

    const v10, 0x66726565

    if-ne v9, v10, :cond_52

    const/16 v10, 0x8

    if-ne v3, v10, :cond_52

    iput-wide v11, v0, Lbo1;->o:J

    const/16 v3, 0x8

    goto :goto_2b

    :cond_52
    const-string v0, "Atom size less than header length (unsupported)."

    invoke-static {v0}, Lis1;->b(Ljava/lang/String;)Lis1;

    move-result-object v0

    throw v0

    :cond_53
    :goto_2b
    iget v9, v0, Lbo1;->n:I

    const v10, 0x6d6f6f76

    const v11, 0x6d657461

    if-eq v9, v10, :cond_59

    const v10, 0x7472616b

    if-eq v9, v10, :cond_59

    const v10, 0x6d646961

    if-eq v9, v10, :cond_59

    const v10, 0x6d696e66

    if-eq v9, v10, :cond_59

    const v10, 0x7374626c

    if-eq v9, v10, :cond_59

    const v10, 0x65647473

    if-eq v9, v10, :cond_59

    if-eq v9, v11, :cond_59

    const v10, 0x61787465

    if-eq v9, v10, :cond_59

    const v10, 0x74726566

    if-ne v9, v10, :cond_54

    goto/16 :goto_30

    :cond_54
    const v5, 0x6d646864

    if-eq v9, v5, :cond_55

    const v5, 0x6d766864

    if-eq v9, v5, :cond_55

    const v5, 0x68646c72    # 4.3148E24f

    if-eq v9, v5, :cond_55

    const v5, 0x73747364

    if-eq v9, v5, :cond_55

    const v5, 0x73747473

    if-eq v9, v5, :cond_55

    const v5, 0x73747373

    if-eq v9, v5, :cond_55

    const v5, 0x63747473

    if-eq v9, v5, :cond_55

    const v5, 0x656c7374

    if-eq v9, v5, :cond_55

    const v5, 0x73747363

    if-eq v9, v5, :cond_55

    const v5, 0x7374737a

    if-eq v9, v5, :cond_55

    const v5, 0x73747a32

    if-eq v9, v5, :cond_55

    const v5, 0x7374636f

    if-eq v9, v5, :cond_55

    const v5, 0x636f3634

    if-eq v9, v5, :cond_55

    const v5, 0x746b6864

    if-eq v9, v5, :cond_55

    if-eq v9, v4, :cond_55

    const v4, 0x75647461

    if-eq v9, v4, :cond_55

    const v4, 0x6b657973

    if-eq v9, v4, :cond_55

    const v4, 0x696c7374

    if-eq v9, v4, :cond_55

    const v4, 0x63686170

    if-ne v9, v4, :cond_56

    :cond_55
    const/16 v10, 0x8

    goto :goto_2d

    :cond_56
    const/4 v6, 0x0

    iput-object v6, v0, Lbo1;->q:Lzb3;

    :goto_2c
    const/4 v13, 0x1

    iput v13, v0, Lbo1;->m:I

    goto/16 :goto_0

    :goto_2d
    if-ne v3, v10, :cond_57

    const/4 v8, 0x1

    goto :goto_2e

    :cond_57
    const/4 v8, 0x0

    :goto_2e
    invoke-static {v8}, La60;->D(Z)V

    iget-wide v3, v0, Lbo1;->o:J

    const-wide/32 v5, 0x7fffffff

    cmp-long v3, v3, v5

    if-gtz v3, :cond_58

    const/4 v8, 0x1

    goto :goto_2f

    :cond_58
    const/4 v8, 0x0

    :goto_2f
    invoke-static {v8}, La60;->D(Z)V

    new-instance v3, Lzb3;

    iget-wide v4, v0, Lbo1;->o:J

    long-to-int v4, v4

    invoke-direct {v3, v4}, Lzb3;-><init>(I)V

    iget-object v4, v7, Lzb3;->a:[B

    iget-object v5, v3, Lzb3;->a:[B

    const/16 v10, 0x8

    const/4 v15, 0x0

    invoke-static {v4, v15, v5, v15, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v3, v0, Lbo1;->q:Lzb3;

    goto :goto_2c

    :cond_59
    :goto_30
    invoke-interface {v1}, Llj1;->o()J

    move-result-wide v3

    iget-wide v6, v0, Lbo1;->o:J

    add-long/2addr v3, v6

    iget v9, v0, Lbo1;->p:I

    int-to-long v9, v9

    cmp-long v6, v6, v9

    if-eqz v6, :cond_5a

    iget v6, v0, Lbo1;->n:I

    if-ne v6, v11, :cond_5a

    const/16 v6, 0x8

    invoke-virtual {v8, v6}, Lzb3;->y(I)V

    iget-object v7, v8, Lzb3;->a:[B

    const/4 v15, 0x0

    invoke-interface {v1, v15, v6, v7}, Llj1;->v(II[B)V

    invoke-static {v8}, Lsn1;->e(Lzb3;)V

    iget v6, v8, Lzb3;->b:I

    invoke-interface {v1, v6}, Llj1;->w(I)V

    invoke-interface {v1}, Llj1;->j()V

    :cond_5a
    sub-long/2addr v3, v9

    new-instance v6, Lun3;

    iget v7, v0, Lbo1;->n:I

    invoke-direct {v6, v7, v3, v4}, Lun3;-><init>(IJ)V

    invoke-virtual {v5, v6}, Ljava/util/ArrayDeque;->push(Ljava/lang/Object;)V

    iget-wide v5, v0, Lbo1;->o:J

    iget v7, v0, Lbo1;->p:I

    int-to-long v7, v7

    cmp-long v5, v5, v7

    if-nez v5, :cond_5b

    invoke-virtual {v0, v3, v4}, Lbo1;->a(J)V

    goto/16 :goto_0

    :cond_5b
    const/4 v15, 0x0

    iput v15, v0, Lbo1;->m:I

    iput v15, v0, Lbo1;->p:I

    goto/16 :goto_0

    :sswitch_data_0
    .sparse-switch
        -0x6604662e -> :sswitch_4
        -0x4f6659e5 -> :sswitch_3
        -0x4a96a712 -> :sswitch_2
        -0x3182f331 -> :sswitch_1
        0x68f2d704 -> :sswitch_0
    .end sparse-switch
.end method
