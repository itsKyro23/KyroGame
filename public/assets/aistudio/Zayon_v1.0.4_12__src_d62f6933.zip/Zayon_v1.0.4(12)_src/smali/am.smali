.class public final Lam;
.super Lv;

# interfaces
.implements La0;


# instance fields
.field public final h:[B


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lk01;->b(Ljava/lang/String;)[B

    move-result-object p1

    iput-object p1, p0, Lam;->h:[B

    return-void
.end method

.method public constructor <init>([B)V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput-object p1, p0, Lam;->h:[B

    return-void
.end method


# virtual methods
.method public final d()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lam;->h:[B

    invoke-static {p0}, Lk01;->a([B)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final hashCode()I
    .locals 0

    iget-object p0, p0, Lam;->h:[B

    invoke-static {p0}, Lgx1;->j([B)I

    move-result p0

    return p0
.end method

.method public final j(Lv;)Z
    .locals 1

    instance-of v0, p1, Lam;

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    check-cast p1, Lam;

    iget-object p0, p0, Lam;->h:[B

    iget-object p1, p1, Lam;->h:[B

    invoke-static {p0, p1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result p0

    return p0
.end method

.method public final k(Lbu0;Z)V
    .locals 1

    const/16 v0, 0x13

    iget-object p0, p0, Lam;->h:[B

    invoke-virtual {p1, v0, p2, p0}, Lbu0;->C(IZ[B)V

    return-void
.end method

.method public final l()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public final n(Z)I
    .locals 0

    iget-object p0, p0, Lam;->h:[B

    array-length p0, p0

    invoke-static {p0, p1}, Lbu0;->r(IZ)I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lam;->h:[B

    invoke-static {p0}, Lk01;->a([B)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
