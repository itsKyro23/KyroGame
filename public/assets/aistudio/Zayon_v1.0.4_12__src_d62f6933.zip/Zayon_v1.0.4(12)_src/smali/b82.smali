.class public abstract Lb82;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lc82;


# static fields
.field public static final synthetic h:I


# direct methods
.method public constructor <init>()V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.formats.client.INativeAdViewDelegate"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 3

    packed-switch p3, :pswitch_data_0

    const/4 p0, 0x0

    return p0

    :pswitch_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->v3(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_1

    :pswitch_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_0

    const/4 p3, 0x0

    goto :goto_0

    :cond_0
    const-string v0, "com.google.android.gms.ads.internal.formats.client.IMediaContent"

    invoke-interface {p3, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v1

    instance-of v2, v1, Lw72;

    if-eqz v2, :cond_1

    move-object p3, v1

    check-cast p3, Lw72;

    goto :goto_0

    :cond_1
    new-instance v1, Lv72;

    const/4 v2, 0x4

    invoke-direct {v1, p3, v0, v2}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    move-object p3, v1

    :goto_0
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->v0(Lw72;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto/16 :goto_1

    :pswitch_2
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->p3(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto :goto_1

    :pswitch_3
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->W0(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto :goto_1

    :pswitch_4
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p0

    invoke-static {p0}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto :goto_1

    :pswitch_5
    invoke-interface {p0}, Lc82;->k()V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto :goto_1

    :pswitch_6
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->u3(Ll50;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    goto :goto_1

    :pswitch_7
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lc82;->A(Ljava/lang/String;)Ll50;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p2, p0}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    goto :goto_1

    :pswitch_8
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    invoke-static {v0}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object v0

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, v0, p3}, Lc82;->D3(Ll50;Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    :goto_1
    const/4 p0, 0x1

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
