.class public final Lba;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lsi0;


# static fields
.field public static final a:Lba;

.field public static final b:Lju;

.field public static final c:Lju;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Lba;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lba;->a:Lba;

    const-string v0, "networkType"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Lba;->b:Lju;

    const-string v0, "mobileSubtype"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Lba;->c:Lju;

    return-void
.end method


# virtual methods
.method public final encode(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    check-cast p1, Lrh0;

    check-cast p2, Lti0;

    move-object p0, p1

    check-cast p0, Lab;

    iget-object p0, p0, Lab;->a:Lqh0;

    sget-object v0, Lba;->b:Lju;

    invoke-interface {p2, v0, p0}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    check-cast p1, Lab;

    iget-object p0, p1, Lab;->b:Lph0;

    sget-object p1, Lba;->c:Lju;

    invoke-interface {p2, p1, p0}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    return-void
.end method
