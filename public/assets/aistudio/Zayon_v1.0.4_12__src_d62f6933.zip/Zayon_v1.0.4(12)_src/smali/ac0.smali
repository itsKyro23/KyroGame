.class public final Lac0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final h:Landroid/graphics/Paint;

.field public final i:Landroid/graphics/RectF;

.field public final j:I

.field public final k:I

.field public final l:Z

.field public m:Z

.field public n:Z

.field public final o:J

.field public final synthetic p:Ldc0;


# direct methods
.method public constructor <init>(Ldc0;Landroid/app/Activity;)V
    .locals 4

    iget-object v0, p1, Ldc0;->c:Landroid/content/Context;

    iput-object p1, p0, Lac0;->p:Ldc0;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p2, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {p2, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p2, p0, Lac0;->h:Landroid/graphics/Paint;

    new-instance p2, Landroid/graphics/RectF;

    invoke-direct {p2}, Landroid/graphics/RectF;-><init>()V

    iput-object p2, p0, Lac0;->i:Landroid/graphics/RectF;

    const/4 p2, 0x0

    :try_start_0
    iget-object p1, p1, Ldc0;->b:Landroid/app/Activity;

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const-string v2, "animator_duration_scale"

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {p1, v2, v3}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    move-result p1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x0

    cmpl-float p1, p1, v2

    if-nez p1, :cond_0

    goto :goto_0

    :catch_0
    :cond_0
    move v1, p2

    :goto_0
    iput-boolean v1, p0, Lac0;->l:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Lac0;->o:J

    const p1, 0x7f050231

    invoke-virtual {v0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p1

    iput p1, p0, Lac0;->j:I

    const p1, 0x7f050071

    invoke-virtual {v0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p1

    iput p1, p0, Lac0;->k:I

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 10

    iget-object v0, p0, Lac0;->p:Ldc0;

    iget v0, v0, Ldc0;->d:F

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iget-wide v3, p0, Lac0;->o:J

    sub-long/2addr v1, v3

    long-to-float v1, v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    const/4 v4, 0x0

    :goto_0
    const/16 v5, 0xb

    iget-boolean v6, p0, Lac0;->l:Z

    if-ge v4, v5, :cond_3

    iget-boolean v5, p0, Lac0;->n:Z

    const/high16 v7, 0x41400000    # 12.0f

    if-eqz v5, :cond_0

    goto :goto_1

    :cond_0
    if-eqz v6, :cond_1

    const/high16 v7, 0x41c00000    # 24.0f

    goto :goto_1

    :cond_1
    const/high16 v5, 0x43a00000    # 320.0f

    div-float v5, v1, v5

    int-to-float v6, v4

    const v8, 0x3f1eb852    # 0.62f

    mul-float/2addr v8, v6

    add-float/2addr v8, v5

    float-to-double v8, v8

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v5, v8

    invoke-static {v5}, Ljava/lang/Math;->abs(F)F

    move-result v5

    const/high16 v8, 0x42600000    # 56.0f

    mul-float/2addr v5, v8

    const v8, 0x3f666666    # 0.9f

    mul-float/2addr v6, v8

    const/high16 v8, 0x3f800000    # 1.0f

    add-float/2addr v6, v8

    float-to-double v8, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v6, v8

    const v8, 0x3ee66666    # 0.45f

    mul-float/2addr v6, v8

    const v8, 0x3f0ccccd    # 0.55f

    add-float/2addr v6, v8

    mul-float/2addr v6, v5

    add-float/2addr v6, v7

    const/high16 v5, 0x41000000    # 8.0f

    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v7

    :goto_1
    mul-int/lit8 v5, v4, 0xd

    int-to-float v5, v5

    mul-float/2addr v5, v0

    mul-float/2addr v7, v0

    div-float/2addr v7, v3

    sub-float v6, v2, v7

    const/high16 v8, 0x40c00000    # 6.0f

    mul-float/2addr v8, v0

    add-float/2addr v8, v5

    add-float/2addr v7, v2

    iget-object v9, p0, Lac0;->i:Landroid/graphics/RectF;

    invoke-virtual {v9, v5, v6, v8, v7}, Landroid/graphics/RectF;->set(FFFF)V

    rem-int/lit8 v5, v4, 0x3

    const/4 v6, 0x1

    if-ne v5, v6, :cond_2

    iget v5, p0, Lac0;->j:I

    goto :goto_2

    :cond_2
    iget v5, p0, Lac0;->k:I

    :goto_2
    iget-object v6, p0, Lac0;->h:Landroid/graphics/Paint;

    invoke-virtual {v6, v5}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v5, 0x40400000    # 3.0f

    mul-float/2addr v5, v0

    invoke-virtual {p1, v9, v5, v5, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    iget-boolean p1, p0, Lac0;->m:Z

    if-eqz p1, :cond_4

    iget-boolean p1, p0, Lac0;->n:Z

    if-nez p1, :cond_4

    if-nez v6, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_4
    return-void
.end method
