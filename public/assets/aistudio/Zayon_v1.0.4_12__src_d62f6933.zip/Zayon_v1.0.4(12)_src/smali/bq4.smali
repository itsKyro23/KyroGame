.class public final Lbq4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lnt4;

.field public final b:Ly02;

.field public final c:Lwy4;

.field public final d:J

.field public final e:F

.field public final f:Z

.field public final g:J


# direct methods
.method public constructor <init>(Lnt4;Ly02;Lwy4;JFZJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbq4;->a:Lnt4;

    iput-object p2, p0, Lbq4;->b:Ly02;

    iput-object p3, p0, Lbq4;->c:Lwy4;

    iput-wide p4, p0, Lbq4;->d:J

    iput p6, p0, Lbq4;->e:F

    iput-boolean p7, p0, Lbq4;->f:Z

    iput-wide p8, p0, Lbq4;->g:J

    return-void
.end method
