.class public final synthetic Lax0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Lcx0;

.field public final synthetic j:I


# direct methods
.method public synthetic constructor <init>(Lcx0;II)V
    .locals 0

    iput p3, p0, Lax0;->h:I

    iput-object p1, p0, Lax0;->i:Lcx0;

    iput p2, p0, Lax0;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget p1, p0, Lax0;->h:I

    const/4 v0, 0x1

    iget v1, p0, Lax0;->j:I

    iget-object p0, p0, Lax0;->i:Lcx0;

    packed-switch p1, :pswitch_data_0

    iget-boolean p1, p0, Lcx0;->M:Z

    if-nez p1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lyf1;->e(Landroid/content/Context;)I

    move-result p1

    if-ne v1, p1, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean v0, p0, Lcx0;->M:Z

    invoke-virtual {p0, v1, v0}, Lcx0;->d(IZ)V

    new-instance p1, Ln00;

    const/16 v0, 0x8

    invoke-direct {p1, p0, v1, v0}, Ln00;-><init>(Ljava/lang/Object;II)V

    const-wide/16 v0, 0x104

    invoke-virtual {p0, p1, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-boolean p1, p0, Lcx0;->M:Z

    if-nez p1, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lsl3;->c(Landroid/content/Context;)I

    move-result p1

    if-ne v1, p1, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v2, "zayon_overlay"

    const/4 v3, 0x0

    invoke-virtual {p1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    if-ltz v1, :cond_3

    const/4 v2, 0x5

    if-ge v1, v2, :cond_3

    move v3, v1

    :cond_3
    const-string v2, "overlay_color"

    invoke-interface {p1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0, v1, v0}, Lcx0;->b(IZ)V

    :cond_4
    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
