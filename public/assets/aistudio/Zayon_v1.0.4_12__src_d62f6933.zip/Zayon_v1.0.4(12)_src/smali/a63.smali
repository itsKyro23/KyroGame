.class public final synthetic La63;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Le63;

.field public final synthetic b:Lxh3;

.field public final synthetic c:Lxh3;

.field public final synthetic d:Ljg2;

.field public final synthetic e:Lji3;


# direct methods
.method public synthetic constructor <init>(Le63;Lxh3;Lxh3;Ljg2;Lji3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La63;->a:Le63;

    iput-object p2, p0, La63;->b:Lxh3;

    iput-object p3, p0, La63;->c:Lxh3;

    iput-object p4, p0, La63;->d:Ljg2;

    iput-object p5, p0, La63;->e:Lji3;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 6

    iget-object v0, p0, La63;->a:Le63;

    iget-object v1, p0, La63;->b:Lxh3;

    iget-object v2, p0, La63;->c:Lxh3;

    iget-object v3, p0, La63;->d:Ljg2;

    iget-object p0, p0, La63;->e:Lji3;

    iget-object v4, v1, Lxh3;->j:Lna0;

    invoke-interface {v4}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkg2;

    iget-object v4, v4, Lkg2;->i:Ljava/lang/String;

    iget-object v2, v2, Lxh3;->j:Lna0;

    invoke-interface {v2}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/json/JSONObject;

    iget-object v3, v3, Ljg2;->o:Ljava/lang/String;

    new-instance v5, Lb63;

    iget-object v1, v1, Lxh3;->j:Lna0;

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkg2;

    invoke-direct {v5, v1, v2, v3, p0}, Lb63;-><init>(Lkg2;Lorg/json/JSONObject;Ljava/lang/String;Lji3;)V

    monitor-enter v0

    :try_start_0
    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object p0, Lx62;->b:Lht1;

    invoke-virtual {p0}, Lht1;->v()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->intValue()I

    move-result p0

    :goto_0
    iget-object v1, v0, Le63;->l:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->size()I

    move-result v2

    if-lt v2, p0, :cond_0

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :try_start_2
    monitor-exit v0

    iget-object p0, v0, Le63;->l:Ljava/util/ArrayDeque;

    invoke-virtual {p0, v5}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v0

    new-instance p0, Ljava/io/ByteArrayInputStream;

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v4, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    return-object p0

    :catchall_1
    move-exception p0

    goto :goto_2

    :goto_1
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw p0

    :goto_2
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p0
.end method
