.class public final La42;
.super Lkg4;
.source "SourceFile"
