.class public final Lbl2;
.super Ll54;
.source "SourceFile"


# instance fields
.field public A:Lna0;

.field public final B:Ljava/util/concurrent/atomic/AtomicLong;

.field public final l:Landroid/content/Context;

.field public final m:Lxa4;

.field public final n:Lbu0;

.field public final o:Ljava/lang/String;

.field public final p:I

.field public final q:Z

.field public r:Ljava/io/InputStream;

.field public s:Z

.field public t:Landroid/net/Uri;

.field public volatile u:Lv22;

.field public v:Z

.field public w:Z

.field public x:Z

.field public y:Z

.field public z:J


# direct methods
.method public constructor <init>(Landroid/content/Context;Lxa4;Ljava/lang/String;ILgl4;Lbu0;)V
    .locals 1

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Ll54;-><init>(Z)V

    iput-object p1, p0, Lbl2;->l:Landroid/content/Context;

    iput-object p2, p0, Lbl2;->m:Lxa4;

    iput-object p6, p0, Lbl2;->n:Lbu0;

    iput-object p3, p0, Lbl2;->o:Ljava/lang/String;

    iput p4, p0, Lbl2;->p:I

    iput-boolean v0, p0, Lbl2;->v:Z

    iput-boolean v0, p0, Lbl2;->w:Z

    iput-boolean v0, p0, Lbl2;->x:Z

    iput-boolean v0, p0, Lbl2;->y:Z

    const-wide/16 p1, 0x0

    iput-wide p1, p0, Lbl2;->z:J

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 p2, -0x1

    invoke-direct {p1, p2, p3}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    iput-object p1, p0, Lbl2;->B:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 p1, 0x0

    iput-object p1, p0, Lbl2;->A:Lna0;

    sget-object p1, Lk52;->A2:Lg52;

    sget-object p2, Lvx1;->e:Lvx1;

    iget-object p2, p2, Lvx1;->c:Li52;

    invoke-virtual {p2, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, Lbl2;->q:Z

    invoke-virtual {p0, p5}, Ll54;->e(Lgl4;)V

    return-void
.end method


# virtual methods
.method public final b(II[B)I
    .locals 1

    iget-boolean v0, p0, Lbl2;->s:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Lbl2;->r:Ljava/io/InputStream;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p3, p1, p2}, Ljava/io/InputStream;->read([BII)I

    move-result p1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lbl2;->m:Lxa4;

    invoke-interface {v0, p1, p2, p3}, Ltl4;->b(II[B)I

    move-result p1

    :goto_0
    iget-boolean p2, p0, Lbl2;->q:Z

    if-eqz p2, :cond_2

    iget-object p2, p0, Lbl2;->r:Ljava/io/InputStream;

    if-eqz p2, :cond_1

    goto :goto_1

    :cond_1
    return p1

    :cond_2
    :goto_1
    invoke-virtual {p0, p1}, Ll54;->d(I)V

    return p1

    :cond_3
    const-string p0, "Attempt to read closed GcacheDataSource."

    invoke-static {p0}, Lb;->m(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final f()Landroid/net/Uri;
    .locals 0

    iget-object p0, p0, Lbl2;->t:Landroid/net/Uri;

    return-object p0
.end method

.method public final i()Z
    .locals 3

    iget-boolean v0, p0, Lbl2;->q:Z

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    sget-object v0, Lk52;->t5:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lbl2;->x:Z

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    sget-object v0, Lk52;->u5:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-boolean p0, p0, Lbl2;->y:Z

    if-nez p0, :cond_2

    :goto_0
    const/4 p0, 0x1

    return p0

    :cond_2
    :goto_1
    const/4 p0, 0x0

    return p0
.end method

.method public final k()V
    .locals 4

    iget-boolean v0, p0, Lbl2;->s:Z

    if-eqz v0, :cond_4

    const/4 v0, 0x0

    iput-boolean v0, p0, Lbl2;->s:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lbl2;->t:Landroid/net/Uri;

    iget-boolean v2, p0, Lbl2;->q:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_0

    iget-object v2, p0, Lbl2;->r:Ljava/io/InputStream;

    if-eqz v2, :cond_1

    :cond_0
    move v0, v3

    :cond_1
    iget-object v2, p0, Lbl2;->r:Ljava/io/InputStream;

    if-eqz v2, :cond_2

    invoke-static {v2}, Lgx1;->d(Ljava/io/Closeable;)V

    iput-object v1, p0, Lbl2;->r:Ljava/io/InputStream;

    goto :goto_0

    :cond_2
    iget-object v1, p0, Lbl2;->m:Lxa4;

    invoke-interface {v1}, Lxa4;->k()V

    :goto_0
    if-eqz v0, :cond_3

    invoke-virtual {p0}, Ll54;->g()V

    :cond_3
    return-void

    :cond_4
    const-string p0, "Attempt to close an already closed GcacheDataSource."

    invoke-static {p0}, Lb;->m(Ljava/lang/String;)V

    return-void
.end method

.method public final p(Ljd4;)J
    .locals 14

    const-string v0, ""

    const-string v1, "ms"

    const-string v2, "Cache connection took "

    iget-boolean v3, p0, Lbl2;->s:Z

    if-nez v3, :cond_10

    const/4 v3, 0x1

    iput-boolean v3, p0, Lbl2;->s:Z

    iget-object v4, p1, Ljd4;->a:Landroid/net/Uri;

    iput-object v4, p0, Lbl2;->t:Landroid/net/Uri;

    iget-boolean v5, p0, Lbl2;->q:Z

    if-nez v5, :cond_0

    invoke-virtual {p0, p1}, Ll54;->c(Ljd4;)V

    :cond_0
    invoke-static {v4}, Lv22;->a(Landroid/net/Uri;)Lv22;

    move-result-object v4

    iput-object v4, p0, Lbl2;->u:Lv22;

    sget-object v4, Lk52;->q5:Lg52;

    sget-object v6, Lvx1;->e:Lvx1;

    iget-object v7, v6, Lvx1;->c:Li52;

    invoke-virtual {v7, v4}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    iget-object v7, p0, Lbl2;->u:Lv22;

    const-wide/16 v8, -0x1

    const/4 v10, 0x0

    if-eqz v4, :cond_a

    if-eqz v7, :cond_e

    iget-object v4, p0, Lbl2;->u:Lv22;

    iget-wide v11, p1, Ljd4;->c:J

    iput-wide v11, v4, Lv22;->o:J

    iget-object v4, p0, Lbl2;->u:Lv22;

    iget-object v7, p0, Lbl2;->o:Ljava/lang/String;

    if-nez v7, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, v7

    :goto_0
    iput-object v0, v4, Lv22;->p:Ljava/lang/String;

    iget-object v0, p0, Lbl2;->u:Lv22;

    iget v4, p0, Lbl2;->p:I

    iput v4, v0, Lv22;->q:I

    iget-object v0, p0, Lbl2;->u:Lv22;

    iget-boolean v0, v0, Lv22;->n:Z

    if-eqz v0, :cond_2

    sget-object v0, Lk52;->s5:Lg52;

    iget-object v4, v6, Lvx1;->c:Li52;

    invoke-virtual {v4, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    goto :goto_1

    :cond_2
    sget-object v0, Lk52;->r5:Lg52;

    iget-object v4, v6, Lvx1;->c:Li52;

    invoke-virtual {v4, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    :goto_1
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    sget-object v0, Lcw4;->B:Lcw4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    iget-object v0, p0, Lbl2;->l:Landroid/content/Context;

    iget-object v4, p0, Lbl2;->u:Lv22;

    invoke-static {v0, v4}, Lfs;->o(Landroid/content/Context;Lv22;)Lx22;

    move-result-object v0

    :try_start_0
    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    iget-object v13, v0, Lfj2;->h:Lr14;

    invoke-virtual {v13, v6, v7, v4}, Lg04;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lz22;
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-boolean v6, v4, Lz22;->b:Z

    iput-boolean v6, p0, Lbl2;->v:Z

    iget-boolean v6, v4, Lz22;->c:Z

    iput-boolean v6, p0, Lbl2;->x:Z

    iget-boolean v6, v4, Lz22;->e:Z

    iput-boolean v6, p0, Lbl2;->y:Z

    iget-wide v6, v4, Lz22;->d:J

    iput-wide v6, p0, Lbl2;->z:J

    invoke-virtual {p0}, Lbl2;->i()Z

    move-result v6

    if-nez v6, :cond_5

    iget-object v4, v4, Lz22;->a:Ly22;

    iput-object v4, p0, Lbl2;->r:Ljava/io/InputStream;

    if-eqz v5, :cond_3

    invoke-virtual {p0, p1}, Ll54;->c(Ljd4;)V
    :try_end_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v0

    move-object p1, v0

    goto/16 :goto_8

    :cond_3
    :goto_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v11

    iget-object p1, p0, Lbl2;->n:Lbu0;

    iget-object p1, p1, Lbu0;->h:Ljava/lang/Object;

    check-cast p1, Lkl2;

    iget-object p1, p1, Lkl2;->q:Ltj2;

    if-eqz p1, :cond_4

    invoke-interface {p1, v4, v5, v3}, Ltj2;->m(JZ)V

    :cond_4
    iput-boolean v3, p0, Lbl2;->w:Z

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x18

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lj23;->a(Ljava/lang/String;)V

    return-wide v8

    :cond_5
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v11

    iget-object v0, p0, Lbl2;->n:Lbu0;

    iget-object v0, v0, Lbu0;->h:Ljava/lang/Object;

    check-cast v0, Lkl2;

    iget-object v0, v0, Lkl2;->q:Ltj2;

    if-eqz v0, :cond_6

    invoke-interface {v0, v4, v5, v3}, Ltj2;->m(JZ)V

    :cond_6
    iput-boolean v3, p0, Lbl2;->w:Z

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x18

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    :goto_3
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lj23;->a(Ljava/lang/String;)V

    goto/16 :goto_c

    :catch_0
    move v4, v3

    goto :goto_4

    :catch_1
    move v4, v3

    goto :goto_7

    :catchall_1
    move-exception v0

    move-object p1, v0

    move v3, v10

    goto/16 :goto_8

    :catch_2
    move v4, v10

    :goto_4
    :try_start_2
    invoke-virtual {v0, v3}, Lx22;->cancel(Z)Z

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    sget-object v0, Lcw4;->B:Lcw4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    sub-long/2addr v5, v11

    iget-object v0, p0, Lbl2;->n:Lbu0;

    iget-object v0, v0, Lbu0;->h:Ljava/lang/Object;

    check-cast v0, Lkl2;

    iget-object v0, v0, Lkl2;->q:Ltj2;

    if-eqz v0, :cond_7

    invoke-interface {v0, v5, v6, v4}, Ltj2;->m(JZ)V

    :cond_7
    iput-boolean v4, p0, Lbl2;->w:Z

    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x18

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    :goto_5
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    goto :goto_3

    :goto_6
    move v3, v4

    goto :goto_8

    :catch_3
    move v4, v10

    :goto_7
    :try_start_3
    invoke-virtual {v0, v3}, Lx22;->cancel(Z)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    sget-object v0, Lcw4;->B:Lcw4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    sub-long/2addr v5, v11

    iget-object v0, p0, Lbl2;->n:Lbu0;

    iget-object v0, v0, Lbu0;->h:Ljava/lang/Object;

    check-cast v0, Lkl2;

    iget-object v0, v0, Lkl2;->q:Ltj2;

    if-eqz v0, :cond_8

    invoke-interface {v0, v5, v6, v4}, Ltj2;->m(JZ)V

    :cond_8
    iput-boolean v4, p0, Lbl2;->w:Z

    invoke-static {v5, v6}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    add-int/lit8 v0, v0, 0x18

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    goto :goto_5

    :catchall_2
    move-exception v0

    move-object p1, v0

    goto :goto_6

    :goto_8
    sget-object v0, Lcw4;->B:Lcw4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v11

    iget-object v0, p0, Lbl2;->n:Lbu0;

    iget-object v0, v0, Lbu0;->h:Ljava/lang/Object;

    check-cast v0, Lkl2;

    iget-object v0, v0, Lkl2;->q:Ltj2;

    if-eqz v0, :cond_9

    invoke-interface {v0, v4, v5, v3}, Ltj2;->m(JZ)V

    :cond_9
    iput-boolean v3, p0, Lbl2;->w:Z

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    add-int/lit8 p0, p0, 0x18

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lj23;->a(Ljava/lang/String;)V

    throw p1

    :cond_a
    if-eqz v7, :cond_c

    iget-object v1, p0, Lbl2;->u:Lv22;

    iget-wide v4, p1, Ljd4;->c:J

    iput-wide v4, v1, Lv22;->o:J

    iget-object v1, p0, Lbl2;->u:Lv22;

    iget-object v2, p0, Lbl2;->o:Ljava/lang/String;

    if-nez v2, :cond_b

    goto :goto_9

    :cond_b
    move-object v0, v2

    :goto_9
    iput-object v0, v1, Lv22;->p:Ljava/lang/String;

    iget-object v0, p0, Lbl2;->u:Lv22;

    iget v1, p0, Lbl2;->p:I

    iput v1, v0, Lv22;->q:I

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->j:Lqa;

    iget-object v1, p0, Lbl2;->u:Lv22;

    invoke-virtual {v0, v1}, Lqa;->i(Lv22;)Lr22;

    move-result-object v0

    :goto_a
    move-object v1, v0

    goto :goto_b

    :cond_c
    const/4 v0, 0x0

    goto :goto_a

    :goto_b
    if-eqz v1, :cond_e

    invoke-virtual {v1}, Lr22;->a()Z

    move-result v0

    if-eqz v0, :cond_e

    monitor-enter v1

    :try_start_4
    iget-boolean v0, v1, Lr22;->i:Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    monitor-exit v1

    iput-boolean v0, p0, Lbl2;->v:Z

    invoke-virtual {v1}, Lr22;->d()Z

    move-result v0

    iput-boolean v0, p0, Lbl2;->x:Z

    invoke-virtual {v1}, Lr22;->c()Z

    move-result v0

    iput-boolean v0, p0, Lbl2;->y:Z

    monitor-enter v1

    :try_start_5
    iget-wide v4, v1, Lr22;->k:J
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    monitor-exit v1

    iput-wide v4, p0, Lbl2;->z:J

    iput-boolean v3, p0, Lbl2;->w:Z

    invoke-virtual {p0}, Lbl2;->i()Z

    move-result v0

    if-nez v0, :cond_e

    invoke-virtual {v1}, Lr22;->b()Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    move-result-object v0

    iput-object v0, p0, Lbl2;->r:Ljava/io/InputStream;

    iget-boolean v0, p0, Lbl2;->q:Z

    if-eqz v0, :cond_d

    invoke-virtual {p0, p1}, Ll54;->c(Ljd4;)V

    :cond_d
    return-wide v8

    :catchall_3
    move-exception v0

    move-object p0, v0

    :try_start_6
    monitor-exit v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    throw p0

    :catchall_4
    move-exception v0

    move-object p0, v0

    :try_start_7
    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    throw p0

    :cond_e
    :goto_c
    iput-boolean v10, p0, Lbl2;->w:Z

    iget-object v0, p0, Lbl2;->u:Lv22;

    if-eqz v0, :cond_f

    iget-object v3, p1, Ljd4;->b:Ljava/util/Map;

    iget-wide v4, p1, Ljd4;->c:J

    iget-wide v6, p1, Ljd4;->d:J

    iget v8, p1, Ljd4;->e:I

    iget-object p1, p0, Lbl2;->u:Lv22;

    iget-object p1, p1, Lv22;->h:Ljava/lang/String;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string p1, "The uri must be set."

    invoke-static {v2, p1}, La60;->F(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v1, Ljd4;

    invoke-direct/range {v1 .. v8}, Ljd4;-><init>(Landroid/net/Uri;Ljava/util/Map;JJI)V

    move-object p1, v1

    :cond_f
    iget-object p0, p0, Lbl2;->m:Lxa4;

    invoke-interface {p0, p1}, Lxa4;->p(Ljd4;)J

    move-result-wide p0

    return-wide p0

    :cond_10
    const-string p0, "Attempt to open an already open GcacheDataSource."

    invoke-static {p0}, Lb;->m(Ljava/lang/String;)V

    const-wide/16 p0, 0x0

    return-wide p0
.end method
