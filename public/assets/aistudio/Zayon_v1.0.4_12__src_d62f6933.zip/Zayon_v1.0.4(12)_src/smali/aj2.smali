.class public abstract Laj2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lzi2;

.field public static final b:Lzi2;

.field public static final c:Lzi2;

.field public static final d:Lyi2;

.field public static final e:Lo14;

.field public static final f:Lzi2;

.field public static final g:Ljava/util/concurrent/ExecutorService;

.field public static final h:Lzi2;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    sget-object v0, Lk52;->Rc:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v2

    sget-object v8, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v11, 0x1

    const-string v3, "Default"

    if-eqz v2, :cond_0

    invoke-virtual {v1, v0}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Lk52;->Sc:Lg52;

    invoke-virtual {v1, v0}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_0

    sget-object v2, Lk52;->Tc:Lg52;

    invoke-virtual {v1, v2}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_0

    move-object v4, v3

    new-instance v3, Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v1, v0}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {v1, v0}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    new-instance v9, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v9}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    new-instance v10, Lse1;

    invoke-direct {v10, v4, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    const-wide/16 v6, 0xa

    move v4, v5

    move v5, v0

    invoke-direct/range {v3 .. v10}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    invoke-virtual {v1, v2}, Li52;->b(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v3, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    goto :goto_0

    :cond_0
    move-object v4, v3

    new-instance v3, Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v9, Ljava/util/concurrent/SynchronousQueue;

    invoke-direct {v9}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    new-instance v10, Lse1;

    invoke-direct {v10, v4, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x2

    const v5, 0x7fffffff

    const-wide/16 v6, 0xa

    invoke-direct/range {v3 .. v10}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    :goto_0
    new-instance v0, Lzi2;

    invoke-direct {v0, v3}, Lzi2;-><init>(Ljava/util/concurrent/Executor;)V

    sput-object v0, Laj2;->a:Lzi2;

    new-instance v3, Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v9, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v9}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    new-instance v10, Lse1;

    const-string v0, "Loader"

    invoke-direct {v10, v0, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-wide/16 v6, 0xa

    invoke-direct/range {v3 .. v10}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    invoke-virtual {v3, v11}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    new-instance v0, Lzi2;

    invoke-direct {v0, v3}, Lzi2;-><init>(Ljava/util/concurrent/Executor;)V

    sput-object v0, Laj2;->b:Lzi2;

    new-instance v3, Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v9, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v9}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    new-instance v10, Lse1;

    const-string v0, "Activeview"

    invoke-direct {v10, v0, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct/range {v3 .. v10}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    invoke-virtual {v3, v11}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    new-instance v0, Lzi2;

    invoke-direct {v0, v3}, Lzi2;-><init>(Ljava/util/concurrent/Executor;)V

    sput-object v0, Laj2;->c:Lzi2;

    new-instance v0, Lyi2;

    new-instance v1, Lse1;

    const-string v2, "Schedule"

    invoke-direct {v1, v2, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    const/4 v2, 0x3

    invoke-direct {v0, v2, v1}, Ljava/util/concurrent/ScheduledThreadPoolExecutor;-><init>(ILjava/util/concurrent/ThreadFactory;)V

    sput-object v0, Laj2;->d:Lyi2;

    new-instance v1, Lo14;

    invoke-direct {v1, v0}, Lo14;-><init>(Ljava/util/concurrent/ScheduledExecutorService;)V

    sput-object v1, Laj2;->e:Lo14;

    new-instance v0, Lua1;

    invoke-direct {v0, v11}, Lua1;-><init>(I)V

    new-instance v1, Lzi2;

    invoke-direct {v1, v0}, Lzi2;-><init>(Ljava/util/concurrent/Executor;)V

    sput-object v1, Laj2;->f:Lzi2;

    new-instance v0, Lse1;

    const-string v1, "AdQualityMetrics"

    invoke-direct {v0, v1, v11}, Lse1;-><init>(Ljava/lang/String;I)V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Laj2;->g:Ljava/util/concurrent/ExecutorService;

    new-instance v0, Lzi2;

    sget-object v1, Lz04;->h:Lz04;

    invoke-direct {v0, v1}, Lzi2;-><init>(Ljava/util/concurrent/Executor;)V

    sput-object v0, Laj2;->h:Lzi2;

    return-void
.end method
