.class public final Lb91;
.super Lj3;
.source "SourceFile"

# interfaces
.implements Lee0;


# instance fields
.field public final j:Landroid/content/Context;

.field public final k:Lge0;

.field public l:Llx2;

.field public m:Ljava/lang/ref/WeakReference;

.field public final synthetic n:Lc91;


# direct methods
.method public constructor <init>(Lc91;Landroid/content/Context;Llx2;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb91;->n:Lc91;

    iput-object p2, p0, Lb91;->j:Landroid/content/Context;

    iput-object p3, p0, Lb91;->l:Llx2;

    new-instance p1, Lge0;

    invoke-direct {p1, p2}, Lge0;-><init>(Landroid/content/Context;)V

    const/4 p2, 0x1

    iput p2, p1, Lge0;->l:I

    iput-object p1, p0, Lb91;->k:Lge0;

    iput-object p0, p1, Lge0;->e:Lee0;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-object v0, p0, Lb91;->n:Lc91;

    iget-object v1, v0, Lc91;->i:Lb91;

    if-eq v1, p0, :cond_0

    return-void

    :cond_0
    iget-boolean v1, v0, Lc91;->p:Z

    if-eqz v1, :cond_1

    iput-object p0, v0, Lc91;->j:Lb91;

    iget-object v1, p0, Lb91;->l:Llx2;

    iput-object v1, v0, Lc91;->k:Llx2;

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lb91;->l:Llx2;

    invoke-virtual {v1, p0}, Llx2;->C(Lj3;)V

    :goto_0
    const/4 v1, 0x0

    iput-object v1, p0, Lb91;->l:Llx2;

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, Lc91;->a(Z)V

    iget-object p0, v0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    iget-object v2, p0, Landroidx/appcompat/widget/ActionBarContextView;->r:Landroid/view/View;

    if-nez v2, :cond_2

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionBarContextView;->e()V

    :cond_2
    iget-object p0, v0, Lc91;->c:Landroidx/appcompat/widget/ActionBarOverlayLayout;

    iget-boolean v2, v0, Lc91;->u:Z

    invoke-virtual {p0, v2}, Landroidx/appcompat/widget/ActionBarOverlayLayout;->setHideOnContentScrollEnabled(Z)V

    iput-object v1, v0, Lc91;->i:Lb91;

    return-void
.end method

.method public final b()Landroid/view/View;
    .locals 0

    iget-object p0, p0, Lb91;->m:Ljava/lang/ref/WeakReference;

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public final c()Lge0;
    .locals 0

    iget-object p0, p0, Lb91;->k:Lge0;

    return-object p0
.end method

.method public final d()Landroid/view/MenuInflater;
    .locals 1

    new-instance v0, Ld11;

    iget-object p0, p0, Lb91;->j:Landroid/content/Context;

    invoke-direct {v0, p0}, Ld11;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public final e()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionBarContextView;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public final f()Ljava/lang/CharSequence;
    .locals 0

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionBarContextView;->getTitle()Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public final g(Lge0;Landroid/view/MenuItem;)Z
    .locals 0

    iget-object p1, p0, Lb91;->l:Llx2;

    if-eqz p1, :cond_0

    iget-object p1, p1, Llx2;->i:Ljava/lang/Object;

    check-cast p1, Ll41;

    invoke-virtual {p1, p0, p2}, Ll41;->t(Lj3;Landroid/view/MenuItem;)Z

    move-result p0

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final h()V
    .locals 2

    iget-object v0, p0, Lb91;->n:Lc91;

    iget-object v0, v0, Lc91;->i:Lb91;

    if-eq v0, p0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lb91;->k:Lge0;

    invoke-virtual {v0}, Lge0;->w()V

    :try_start_0
    iget-object v1, p0, Lb91;->l:Llx2;

    invoke-virtual {v1, p0, v0}, Llx2;->F(Lj3;Landroid/view/Menu;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Lge0;->v()V

    return-void

    :catchall_0
    move-exception p0

    invoke-virtual {v0}, Lge0;->v()V

    throw p0
.end method

.method public final i()Z
    .locals 0

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    iget-boolean p0, p0, Landroidx/appcompat/widget/ActionBarContextView;->z:Z

    return p0
.end method

.method public final j(Landroid/view/View;)V
    .locals 1

    iget-object v0, p0, Lb91;->n:Lc91;

    iget-object v0, v0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setCustomView(Landroid/view/View;)V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lb91;->m:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public final k(I)V
    .locals 1

    iget-object v0, p0, Lb91;->n:Lc91;

    iget-object v0, v0, Lc91;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lb91;->l(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final l(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setSubtitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final m(I)V
    .locals 1

    iget-object v0, p0, Lb91;->n:Lc91;

    iget-object v0, v0, Lc91;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lb91;->n(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final n(Ljava/lang/CharSequence;)V
    .locals 0

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final o(Lge0;)V
    .locals 0

    iget-object p1, p0, Lb91;->l:Llx2;

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lb91;->h()V

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    iget-object p0, p0, Landroidx/appcompat/widget/ActionBarContextView;->k:Lf3;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Lf3;->l()Z

    :cond_1
    :goto_0
    return-void
.end method

.method public final p(Z)V
    .locals 0

    iput-boolean p1, p0, Lj3;->i:Z

    iget-object p0, p0, Lb91;->n:Lc91;

    iget-object p0, p0, Lc91;->f:Landroidx/appcompat/widget/ActionBarContextView;

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionBarContextView;->setTitleOptional(Z)V

    return-void
.end method
