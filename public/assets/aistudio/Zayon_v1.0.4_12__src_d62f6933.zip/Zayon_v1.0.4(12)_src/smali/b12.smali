.class public final Lb12;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzf:Lb12;


# instance fields
.field private zza:I

.field private zzb:Le12;

.field private zzc:Lyf4;

.field private zzd:J

.field private zze:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lb12;

    invoke-direct {v0}, Lb12;-><init>()V

    sput-object v0, Lb12;->zzf:Lb12;

    const-class v1, Lb12;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Lyf4;->i:Lwf4;

    iput-object v0, p0, Lb12;->zzc:Lyf4;

    return-void
.end method

.method public static B()Lb12;
    .locals 1

    sget-object v0, Lb12;->zzf:Lb12;

    return-object v0
.end method


# virtual methods
.method public final A()J
    .locals 2

    iget-wide v0, p0, Lb12;->zze:J

    return-wide v0
.end method

.method public final u(ILng4;)Ljava/lang/Object;
    .locals 2

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lpv1;

    sget-object p1, Lb12;->zzf:Lb12;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lb12;

    invoke-direct {p0}, Lb12;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zzd"

    const-string p1, "zze"

    const-string p2, "zza"

    const-string v0, "zzb"

    const-string v1, "zzc"

    filled-new-array {p2, v0, v1, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lb12;->zzf:Lb12;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u1009\u0000\u0002\u100a\u0001\u0003\u1002\u0002\u0004\u1002\u0003"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method

.method public final y()Le12;
    .locals 0

    iget-object p0, p0, Lb12;->zzb:Le12;

    if-nez p0, :cond_0

    invoke-static {}, Le12;->A()Le12;

    move-result-object p0

    :cond_0
    return-object p0
.end method

.method public final z()Lyf4;
    .locals 0

    iget-object p0, p0, Lb12;->zzc:Lyf4;

    return-object p0
.end method
