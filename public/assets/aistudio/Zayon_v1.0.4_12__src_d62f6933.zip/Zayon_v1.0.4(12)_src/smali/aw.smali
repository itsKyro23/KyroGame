.class public final Law;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final A:Landroid/widget/TextView;

.field public final B:Landroid/widget/TextView;

.field public final C:Landroid/widget/LinearLayout;

.field public final D:Landroid/widget/LinearLayout;

.field public final E:Landroid/widget/LinearLayout;

.field public final F:Landroid/view/View;

.field public final G:Landroid/view/View;

.field public final H:Lcom/zayon/optimize/ui/gamelab/ScoreRingView;

.field public final I:I

.field public final J:I

.field public final K:I

.field public final L:I

.field public final M:I

.field public final N:I

.field public final O:I

.field public final P:I

.field public final Q:I

.field public final R:I

.field public final S:I

.field public final T:I

.field public final U:I

.field public final V:I

.field public final W:I

.field public final X:I

.field public final Y:I

.field public final Z:I

.field public final a:Landroid/content/Context;

.field public a0:I

.field public final b:Landroid/content/Context;

.field public b0:Z

.field public final c:Lu20;

.field public c0:Z

.field public final d:F

.field public d0:Z

.field public final e:Landroid/os/Handler;

.field public e0:Z

.field public final f:Ljava/util/concurrent/ExecutorService;

.field public f0:I

.field public final g:Ljava/util/Random;

.field public g0:I

.field public final h:Lcom/zayon/optimize/ui/gamelab/StepperView;

.field public h0:I

.field public final i:Landroid/view/View;

.field public i0:I

.field public final j:Landroid/view/View;

.field public j0:I

.field public final k:Landroid/view/View;

.field public k0:J

.field public final l:Landroid/view/View;

.field public final l0:Ljava/util/ArrayList;

.field public final m:Landroid/view/View;

.field public final m0:[Ljava/lang/Long;

.field public final n:Landroid/view/View;

.field public n0:I

.field public final o:Landroid/view/View;

.field public o0:I

.field public final p:Landroid/view/View;

.field public p0:I

.field public final q:Landroid/view/View;

.field public q0:I

.field public final r:[Lcom/zayon/optimize/ui/ZyBox;

.field public r0:Lov;

.field public final s:[Landroid/widget/TextView;

.field public s0:Landroid/animation/ValueAnimator;

.field public final t:Landroid/widget/TextView;

.field public t0:Landroid/animation/ValueAnimator;

.field public final u:Landroid/widget/TextView;

.field public u0:Landroid/animation/ValueAnimator;

.field public final v:Landroid/widget/TextView;

.field public final w:Landroid/widget/TextView;

.field public final x:Landroid/widget/TextView;

.field public final y:Landroid/widget/TextView;

.field public final z:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;Lu20;)V
    .locals 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Law;->e:Landroid/os/Handler;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Law;->f:Ljava/util/concurrent/ExecutorService;

    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    iput-object v0, p0, Law;->g:Ljava/util/Random;

    const/4 v0, 0x6

    new-array v1, v0, [Lcom/zayon/optimize/ui/ZyBox;

    iput-object v1, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    new-array v1, v0, [Landroid/widget/TextView;

    iput-object v1, p0, Law;->s:[Landroid/widget/TextView;

    const/4 v1, -0x1

    iput v1, p0, Law;->f0:I

    iput v1, p0, Law;->g0:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Law;->l0:Ljava/util/ArrayList;

    new-array v1, v0, [Ljava/lang/Long;

    iput-object v1, p0, Law;->m0:[Ljava/lang/Long;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    iput-object v2, p0, Law;->a:Landroid/content/Context;

    iput-object v1, p0, Law;->b:Landroid/content/Context;

    iput-object p2, p0, Law;->c:Lu20;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    iput v2, p0, Law;->d:F

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    const v2, 0x7f050071

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    const v2, 0x7f05025f

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->I:I

    const v2, 0x7f050264

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->J:I

    const v2, 0x7f050161

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->K:I

    const v2, 0x7f0501a1

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->L:I

    const v2, 0x7f050234

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->M:I

    const v2, 0x7f050231

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->N:I

    const v2, 0x7f050230

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->O:I

    const v2, 0x7f050198

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->P:I

    const v2, 0x7f05019a

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->Q:I

    const v2, 0x7f0501a0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->R:I

    const v2, 0x7f050194

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->S:I

    const v2, 0x7f0500c1

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->T:I

    const v2, 0x7f0500db

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->U:I

    const v2, 0x7f05008a

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->Z:I

    const v2, 0x7f0500c2

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->V:I

    const v2, 0x7f0500c0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->W:I

    const v2, 0x7f0501db

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    iput v2, p0, Law;->X:I

    const v2, 0x7f050199

    invoke-virtual {v1, v2}, Landroid/content/Context;->getColor(I)I

    move-result v1

    iput v1, p0, Law;->Y:I

    const v1, 0x7f0900ad

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/zayon/optimize/ui/gamelab/StepperView;

    iput-object v1, p0, Law;->h:Lcom/zayon/optimize/ui/gamelab/StepperView;

    const v1, 0x7f09009f

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->i:Landroid/view/View;

    const v1, 0x7f09009c

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->j:Landroid/view/View;

    const v1, 0x7f0900a5

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->k:Landroid/view/View;

    const v1, 0x7f0900a6

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->l:Landroid/view/View;

    const v1, 0x7f0900ac

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->m:Landroid/view/View;

    const v1, 0x7f0900ae

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->n:Landroid/view/View;

    const v1, 0x7f09008d

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->o:Landroid/view/View;

    const v1, 0x7f090090

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->p:Landroid/view/View;

    const v1, 0x7f09009d

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->q:Landroid/view/View;

    const v1, 0x7f0900a9

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->t:Landroid/widget/TextView;

    const v1, 0x7f09009e

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->u:Landroid/widget/TextView;

    const v1, 0x7f09008f

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->v:Landroid/widget/TextView;

    const v1, 0x7f0900a1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->w:Landroid/widget/TextView;

    const v1, 0x7f0900a0

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->x:Landroid/widget/TextView;

    const v1, 0x7f090092

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->y:Landroid/widget/TextView;

    const v1, 0x7f090099

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Law;->C:Landroid/widget/LinearLayout;

    const v1, 0x7f09008c

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Law;->D:Landroid/widget/LinearLayout;

    const v1, 0x7f09009b

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    iput-object v1, p0, Law;->E:Landroid/widget/LinearLayout;

    const v1, 0x7f0900a4

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->z:Landroid/widget/TextView;

    const v1, 0x7f0900a3

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->A:Landroid/widget/TextView;

    const v1, 0x7f0900a2

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->F:Landroid/view/View;

    const v1, 0x7f0900ab

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Law;->G:Landroid/view/View;

    const v1, 0x7f0900aa

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iput-object v1, p0, Law;->B:Landroid/widget/TextView;

    const v1, 0x7f0900a8

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/zayon/optimize/ui/gamelab/ScoreRingView;

    iput-object v1, p0, Law;->H:Lcom/zayon/optimize/ui/gamelab/ScoreRingView;

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    const/4 v4, 0x0

    if-ge v3, v0, :cond_0

    iget-object v5, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget v6, v1, v3

    invoke-virtual {p1, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Lcom/zayon/optimize/ui/ZyBox;

    aput-object v6, v5, v3

    iget-object v5, p0, Law;->s:[Landroid/widget/TextView;

    iget-object v6, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget-object v6, v6, v3

    const v7, 0x7f09009a

    invoke-virtual {v6, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    aput-object v6, v5, v3

    iget-object v5, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget-object v5, v5, v3

    new-array v6, v2, [Lsb1;

    invoke-virtual {v5, v6}, Lcom/zayon/optimize/ui/ZyBox;->setShadowsA([Lsb1;)V

    iget-object v5, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget-object v5, v5, v3

    new-instance v6, Lsb1;

    iget v7, p0, Law;->U:I

    const/high16 v8, 0x41d00000    # 26.0f

    iget v9, p0, Law;->d:F

    mul-float/2addr v9, v8

    invoke-direct {v6, v4, v9, v4, v7}, Lsb1;-><init>(FFFI)V

    filled-new-array {v6}, [Lsb1;

    move-result-object v4

    invoke-virtual {v5, v4}, Lcom/zayon/optimize/ui/ZyBox;->setShadowsB([Lsb1;)V

    iget-object v4, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget-object v4, v4, v3

    new-instance v5, Lqv;

    invoke-direct {v5, p0, v3}, Lqv;-><init>(Law;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Law;->F:Landroid/view/View;

    invoke-virtual {v0, v4}, Landroid/view/View;->setPivotX(F)V

    iget-object v0, p0, Law;->m:Landroid/view/View;

    new-instance v1, Lwv;

    invoke-direct {v1, p0, v2}, Lwv;-><init>(Law;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, p0, Law;->o:Landroid/view/View;

    new-instance v1, Lwv;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lwv;-><init>(Law;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f09008e

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lwv;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lwv;-><init>(Law;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f0900a7

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lwv;

    const/4 v2, 0x3

    invoke-direct {v1, p0, v2}, Lwv;-><init>(Law;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f090091

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    new-instance v0, Ld1;

    invoke-direct {v0, v2, p2}, Ld1;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p1, p0, Law;->q:Landroid/view/View;

    new-instance p2, Lwv;

    const/4 v0, 0x4

    invoke-direct {p2, p0, v0}, Lwv;-><init>(Law;I)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Law;->f()V

    return-void

    :array_0
    .array-data 4
        0x7f090093
        0x7f090094
        0x7f090095
        0x7f090096
        0x7f090097
        0x7f090098
    .end array-data
.end method


# virtual methods
.method public final a(FFJ)V
    .locals 2

    iget-object v0, p0, Law;->s0:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_0
    const/4 v0, 0x2

    new-array v0, v0, [F

    const/4 v1, 0x0

    aput p1, v0, v1

    const/4 p1, 0x1

    aput p2, v0, p1

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p1

    iput-object p1, p0, Law;->s0:Landroid/animation/ValueAnimator;

    invoke-virtual {p1, p3, p4}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object p1, p0, Law;->s0:Landroid/animation/ValueAnimator;

    new-instance p3, Landroid/view/animation/LinearInterpolator;

    invoke-direct {p3}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {p1, p3}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object p1, p0, Law;->D:Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    iget-object p3, p0, Law;->s0:Landroid/animation/ValueAnimator;

    new-instance p4, Lxv;

    invoke-direct {p4, p0, p2, p1}, Lxv;-><init>(Law;FI)V

    invoke-virtual {p3, p4}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object p0, p0, Law;->s0:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->start()V

    return-void
.end method

.method public final b()I
    .locals 6

    iget-object p0, p0, Law;->l0:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const-wide/16 v2, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v1, v1, 0x1

    check-cast v4, Ljava/lang/Long;

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    add-long/2addr v2, v4

    goto :goto_0

    :cond_1
    long-to-float v0, v2

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    int-to-float p0, p0

    div-float/2addr v0, p0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public final c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 9

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Law;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v3, Landroid/view/View;

    invoke-direct {v3, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v4, 0x7f050262

    invoke-virtual {v1, v4}, Landroid/content/Context;->getColor(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    iget v5, p0, Law;->d:F

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v6, -0x1

    invoke-direct {v4, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x10

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v4, 0x41200000    # 10.0f

    mul-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {v2, v3, v4, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    new-instance v4, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v4, v1}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41500000    # 13.0f

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const v6, 0x7f080002

    invoke-static {v1, v6}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iget v6, p0, Law;->M:I

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, -0x2

    invoke-direct {v6, v3, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v3, v1}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const p1, 0x7f080005

    invoke-static {v1, p1}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const p1, 0x7f050232

    invoke-virtual {v1, p1}, Landroid/content/Context;->getColor(I)I

    move-result p1

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 p2, 0x41000000    # 8.0f

    mul-float/2addr p2, v5

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v2, v3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/ImageView;

    invoke-direct {p1, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v3, 0x7f070083

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v3, p0, Law;->O:I

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setColorFilter(I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x41800000    # 16.0f

    mul-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-direct {v3, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v2, p1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {p1, v1}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p3, 0x41600000    # 14.0f

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setTextSize(F)V

    const p3, 0x7f080004

    invoke-static {v1, p3}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iget p0, p0, Law;->P:I

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setTextColor(I)V

    const p0, 0x800005

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 p0, 0x42780000    # 62.0f

    mul-float/2addr v5, p0

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setMinWidth(I)V

    new-instance p0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-virtual {p0, p2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v2, p1, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method public final d()V
    .locals 3

    const/4 v0, -0x1

    iput v0, p0, Law;->f0:I

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x6

    if-ge v0, v1, :cond_0

    invoke-virtual {p0, v0}, Law;->l(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    new-instance v0, Lrv;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lrv;-><init>(Law;I)V

    iget-object v1, p0, Law;->g:Ljava/util/Random;

    const/16 v2, 0x17d

    invoke-virtual {v1, v2}, Ljava/util/Random;->nextInt(I)I

    move-result v1

    add-int/lit16 v1, v1, 0x140

    int-to-long v1, v1

    iget-object p0, p0, Law;->e:Landroid/os/Handler;

    invoke-virtual {p0, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final e()V
    .locals 4

    iget-boolean v0, p0, Law;->c0:Z

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    iget v0, p0, Law;->h0:I

    div-int/lit8 v0, v0, 0x4

    add-int/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    :goto_0
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-boolean v3, p0, Law;->c0:Z

    if-eqz v3, :cond_1

    move v1, v2

    :cond_1
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v0

    iget-object v1, p0, Law;->b:Landroid/content/Context;

    const v2, 0x7f0f00ac

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Law;->t:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-boolean v0, p0, Law;->b0:Z

    iget-object v1, p0, Law;->u:Landroid/widget/TextView;

    if-eqz v0, :cond_2

    const v0, 0x7f0f009f

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(I)V

    goto :goto_2

    :cond_2
    iget v0, p0, Law;->h0:I

    iget v2, p0, Law;->j0:I

    if-lt v0, v2, :cond_4

    if-lez v2, :cond_4

    iget-boolean v0, p0, Law;->c0:Z

    if-eqz v0, :cond_3

    const v0, 0x7f0f009e

    goto :goto_1

    :cond_3
    const v0, 0x7f0f009d

    :goto_1
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(I)V

    goto :goto_2

    :cond_4
    const v0, 0x7f0f009c

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(I)V

    :goto_2
    invoke-virtual {p0}, Law;->b()I

    move-result v0

    if-lez v0, :cond_5

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " ms"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_3

    :cond_5
    const-string v0, "\u2014"

    :goto_3
    iget-object v1, p0, Law;->v:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v0, p0, Law;->i0:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Law;->w:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v0, p0, Law;->i0:I

    if-lez v0, :cond_6

    iget p0, p0, Law;->L:I

    goto :goto_4

    :cond_6
    iget p0, p0, Law;->N:I

    :goto_4
    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method public final f()V
    .locals 4

    iget-object v0, p0, Law;->e:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v0, 0x0

    iput v0, p0, Law;->a0:I

    iput-boolean v0, p0, Law;->b0:Z

    iput-boolean v0, p0, Law;->c0:Z

    iget-object v2, p0, Law;->h:Lcom/zayon/optimize/ui/gamelab/StepperView;

    invoke-virtual {v2, v0, v0}, Lcom/zayon/optimize/ui/gamelab/StepperView;->d(IZ)V

    iget-object v2, p0, Law;->i:Landroid/view/View;

    invoke-virtual {p0, v2}, Law;->j(Landroid/view/View;)V

    iget-object v2, p0, Law;->x:Landroid/widget/TextView;

    const v3, 0x7f0f00a3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(I)V

    move v2, v0

    :goto_0
    const/4 v3, 0x6

    if-ge v2, v3, :cond_0

    iget-object v3, p0, Law;->m0:[Ljava/lang/Long;

    aput-object v1, v3, v2

    invoke-virtual {p0, v2}, Law;->l(I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Law;->l0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iput v0, p0, Law;->h0:I

    iput v0, p0, Law;->i0:I

    const/4 v1, -0x1

    iput v1, p0, Law;->f0:I

    iget-object v1, p0, Law;->m:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Law;->e()V

    return-void
.end method

.method public final g(Lov;)V
    .locals 18

    move-object/from16 v1, p0

    move-object/from16 v4, p1

    const/4 v6, 0x5

    new-array v7, v6, [[Ljava/lang/String;

    new-array v8, v6, [Z

    iget-boolean v9, v4, Lov;->a:Z

    iget-object v0, v4, Lov;->b:Ljava/util/ArrayList;

    const v2, 0x7f0f0088

    iget-object v10, v1, Law;->b:Landroid/content/Context;

    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v3, 0x7f0f0142

    invoke-virtual {v10, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    const v5, 0x7f0f008a

    invoke-virtual {v10, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-nez v9, :cond_0

    filled-new-array {v5, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v11

    goto :goto_2

    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v13

    if-eqz v13, :cond_1

    filled-new-array {v5, v3}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v11

    goto :goto_2

    :cond_1
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    move v14, v11

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-ge v14, v15, :cond_3

    if-lez v14, :cond_2

    const-string v15, ", "

    goto :goto_1

    :cond_2
    const-string v15, ""

    :goto_1
    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lpv;

    iget-object v15, v15, Lpv;->b:Ljava/lang/String;

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v14, v14, 0x1

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    filled-new-array {v0, v13}, [Ljava/lang/Object;

    move-result-object v0

    const v13, 0x7f0f0089

    invoke-virtual {v10, v13, v0}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v5, v0}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v11

    aput-boolean v12, v8, v11

    :goto_2
    const v0, 0x7f0f008f

    invoke-virtual {v10, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    if-nez v9, :cond_4

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v12

    goto :goto_5

    :cond_4
    invoke-virtual {v4}, Lov;->a()Z

    move-result v5

    if-eqz v5, :cond_7

    iget v5, v4, Lov;->c:I

    if-lez v5, :cond_5

    goto :goto_3

    :cond_5
    const/16 v5, 0x190

    :goto_3
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v13, v4, Lov;->d:I

    if-lez v13, :cond_6

    goto :goto_4

    :cond_6
    const/16 v13, 0x12c

    :goto_4
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    filled-new-array {v5, v13}, [Ljava/lang/Object;

    move-result-object v5

    const v13, 0x7f0f008d

    invoke-virtual {v10, v13, v5}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v0, v5}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v12

    aput-boolean v12, v8, v12

    goto :goto_5

    :cond_7
    const v5, 0x7f0f008e

    invoke-virtual {v10, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v0, v5}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v12

    :goto_5
    const v0, 0x7f0f008c

    invoke-virtual {v10, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    if-nez v9, :cond_8

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v5

    goto :goto_8

    :cond_8
    iget-boolean v13, v4, Lov;->e:Z

    if-nez v13, :cond_a

    iget-boolean v14, v4, Lov;->f:Z

    if-eqz v14, :cond_9

    goto :goto_6

    :cond_9
    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v5

    goto :goto_8

    :cond_a
    :goto_6
    if-eqz v13, :cond_b

    const-string v13, "show_touches"

    goto :goto_7

    :cond_b
    const-string v13, "pointer_location"

    :goto_7
    filled-new-array {v13}, [Ljava/lang/Object;

    move-result-object v13

    const v14, 0x7f0f008b

    invoke-virtual {v10, v14, v13}, Landroid/content/Context;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    filled-new-array {v0, v13}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v5

    aput-boolean v12, v8, v5

    :goto_8
    const v0, 0x7f0f0092

    invoke-virtual {v10, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    if-nez v9, :cond_c

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v5

    goto :goto_a

    :cond_c
    iget-object v2, v4, Lov;->g:Ljava/lang/Boolean;

    if-nez v2, :cond_d

    const v2, 0x7f0f0091

    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_9

    :cond_d
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_e

    const v2, 0x7f0f0090

    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    :cond_e
    :goto_9
    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v5

    :goto_a
    const v0, 0x7f0f0087

    invoke-virtual {v10, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    iget-boolean v2, v4, Lov;->h:Z

    const/4 v13, 0x4

    if-eqz v2, :cond_f

    const v2, 0x7f0f0085

    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v13

    aput-boolean v12, v8, v13

    goto :goto_b

    :cond_f
    const v2, 0x7f0f0086

    invoke-virtual {v10, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    aput-object v0, v7, v13

    :goto_b
    move v3, v11

    :goto_c
    if-ge v3, v6, :cond_18

    aget-object v0, v7, v3

    aget-object v2, v0, v11

    aget-object v0, v0, v12

    aget-boolean v5, v8, v3

    if-nez v9, :cond_10

    if-ge v3, v13, :cond_10

    move v14, v12

    goto :goto_d

    :cond_10
    move v14, v11

    :goto_d
    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v15, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v6, Landroid/view/View;

    invoke-direct {v6, v10}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v13, 0x7f050262

    invoke-virtual {v10, v13}, Landroid/content/Context;->getColor(I)I

    move-result v11

    invoke-virtual {v6, v11}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    iget v13, v1, Law;->d:F

    move/from16 v17, v3

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-static {v12, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/4 v12, -0x1

    invoke-direct {v11, v12, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v15, v6, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    invoke-virtual {v3, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v11, 0x41200000    # 10.0f

    mul-float/2addr v11, v13

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    invoke-virtual {v3, v6, v11, v6, v11}, Landroid/view/View;->setPadding(IIII)V

    const/high16 v6, 0x41500000    # 13.0f

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v10, v6, v12, v11}, Lcom/zayon/optimize/ui/ZyBox;->c(Landroid/content/Context;FZF)Lcom/zayon/optimize/ui/ZyBox;

    move-result-object v6

    if-eqz v14, :cond_11

    const v12, 0x7f050262

    invoke-virtual {v10, v12}, Landroid/content/Context;->getColor(I)I

    move-result v12

    goto :goto_e

    :cond_11
    if-eqz v5, :cond_12

    iget v12, v1, Law;->T:I

    goto :goto_e

    :cond_12
    iget v12, v1, Law;->S:I

    :goto_e
    invoke-virtual {v6, v12}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    new-instance v12, Landroid/widget/ImageView;

    invoke-direct {v12, v10}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    if-eqz v14, :cond_13

    const v16, 0x7f0700bd

    :goto_f
    move/from16 v11, v16

    goto :goto_10

    :cond_13
    if-eqz v5, :cond_14

    const v16, 0x7f070094

    goto :goto_f

    :cond_14
    const v16, 0x7f070090

    goto :goto_f

    :goto_10
    invoke-virtual {v12, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v11, v1, Law;->O:I

    if-eqz v14, :cond_15

    move v14, v11

    goto :goto_11

    :cond_15
    if-eqz v5, :cond_16

    iget v14, v1, Law;->Q:I

    goto :goto_11

    :cond_16
    iget v14, v1, Law;->P:I

    :goto_11
    invoke-virtual {v12, v14}, Landroid/widget/ImageView;->setColorFilter(I)V

    const/high16 v14, 0x41800000    # 16.0f

    mul-float/2addr v14, v13

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v14, 0x11

    iput v14, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    invoke-virtual {v6, v12, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x41d00000    # 26.0f

    mul-float/2addr v12, v13

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v14

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    invoke-direct {v4, v14, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v12, 0x1

    invoke-virtual {v4, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v6, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v6, v10}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41580000    # 13.5f

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const v2, 0x7f080003

    invoke-static {v10, v2}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iget v2, v1, Law;->N:I

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v2, Lcom/zayon/optimize/ui/ZyTextView;

    invoke-direct {v2, v10}, Lcom/zayon/optimize/ui/ZyTextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v0, 0x41380000    # 11.5f

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const v0, 0x7f080002

    invoke-static {v10, v0}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    if-eqz v5, :cond_17

    iget v11, v1, Law;->R:I

    :cond_17
    invoke-virtual {v2, v11}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v0, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v6

    iput v6, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v4, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    invoke-direct {v0, v6, v5, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41400000    # 12.0f

    mul-float/2addr v2, v13

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v3, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v15, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v0, 0x0

    invoke-virtual {v15, v0}, Landroid/view/View;->setAlpha(F)V

    const/high16 v0, -0x3ec00000    # -12.0f

    mul-float/2addr v13, v0

    invoke-virtual {v15, v13}, Landroid/view/View;->setTranslationX(F)V

    iget-object v0, v1, Law;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Lzv;

    const/4 v5, 0x0

    move-object/from16 v4, p1

    move-object v2, v15

    move/from16 v3, v17

    invoke-direct/range {v0 .. v5}, Lzv;-><init>(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;I)V

    add-int/lit8 v3, v3, 0x1

    int-to-long v4, v3

    const-wide/16 v13, 0x140

    mul-long/2addr v4, v13

    iget-object v2, v1, Law;->e:Landroid/os/Handler;

    invoke-virtual {v2, v0, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-object/from16 v4, p1

    move v11, v6

    const/4 v6, 0x5

    const/4 v13, 0x4

    goto/16 :goto_c

    :cond_18
    return-void
.end method

.method public final h(I)V
    .locals 9

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Law;->D:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v1, v3, :cond_4

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    const/4 v3, 0x1

    if-ge v1, p1, :cond_0

    move v4, v3

    goto :goto_1

    :cond_0
    move v4, v0

    :goto_1
    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    if-eqz v4, :cond_1

    const v6, 0x7f070091

    goto :goto_2

    :cond_1
    const v6, 0x7f0700d1

    :goto_2
    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v6, p0, Law;->O:I

    iget v7, p0, Law;->N:I

    if-eqz v4, :cond_2

    move v8, v7

    goto :goto_3

    :cond_2
    move v8, v6

    :goto_3
    invoke-virtual {v5, v8}, Landroid/widget/ImageView;->setColorFilter(I)V

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    if-eqz v4, :cond_3

    move v6, v7

    :cond_3
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_4
    return-void
.end method

.method public final i(F)V
    .locals 2

    iget-object v0, p0, Law;->F:Landroid/view/View;

    invoke-virtual {v0, p1}, Landroid/view/View;->setScaleX(F)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/high16 v1, 0x42c80000    # 100.0f

    mul-float/2addr p1, v1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "%"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Law;->A:Landroid/widget/TextView;

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final j(Landroid/view/View;)V
    .locals 4

    iget-object v0, p0, Law;->k:Landroid/view/View;

    iget-object v1, p0, Law;->l:Landroid/view/View;

    iget-object v2, p0, Law;->i:Landroid/view/View;

    iget-object p0, p0, Law;->j:Landroid/view/View;

    filled-new-array {v2, p0, v0, v1}, [Landroid/view/View;

    move-result-object p0

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    const/4 v2, 0x4

    if-ge v1, v2, :cond_1

    aget-object v2, p0, v1

    if-ne v2, p1, :cond_0

    move v3, v0

    goto :goto_1

    :cond_0
    const/16 v3, 0x8

    :goto_1
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final k(Z)V
    .locals 2

    iput-boolean p1, p0, Law;->c0:Z

    if-eqz p1, :cond_0

    const/4 p1, 0x4

    goto :goto_0

    :cond_0
    const/16 p1, 0xc

    :goto_0
    iput p1, p0, Law;->j0:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Law;->b0:Z

    const/4 p1, 0x0

    iput p1, p0, Law;->h0:I

    iput p1, p0, Law;->i0:I

    iget-object v0, p0, Law;->l0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :goto_1
    const/4 v0, 0x6

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Law;->m0:[Ljava/lang/Long;

    const/4 v1, 0x0

    aput-object v1, v0, p1

    invoke-virtual {p0, p1}, Law;->l(I)V

    add-int/lit8 p1, p1, 0x1

    goto :goto_1

    :cond_1
    iget-object p1, p0, Law;->m:Landroid/view/View;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Law;->e()V

    invoke-virtual {p0}, Law;->d()V

    return-void
.end method

.method public final l(I)V
    .locals 6

    iget v0, p0, Law;->f0:I

    const/4 v1, 0x0

    if-ne p1, v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-object v2, p0, Law;->r:[Lcom/zayon/optimize/ui/ZyBox;

    aget-object v3, v2, p1

    iget v4, p0, Law;->Z:I

    if-eqz v0, :cond_1

    move v5, v4

    goto :goto_1

    :cond_1
    iget v5, p0, Law;->I:I

    :goto_1
    invoke-virtual {v3, v5}, Lcom/zayon/optimize/ui/ZyBox;->setBg(I)V

    aget-object v3, v2, p1

    if-eqz v0, :cond_2

    goto :goto_2

    :cond_2
    iget v4, p0, Law;->J:I

    :goto_2
    invoke-virtual {v3, v4}, Lcom/zayon/optimize/ui/ZyBox;->setBorderColor(I)V

    aget-object v2, v2, p1

    const/4 v3, 0x0

    if-eqz v0, :cond_3

    const/high16 v4, 0x3f800000    # 1.0f

    goto :goto_3

    :cond_3
    move v4, v3

    :goto_3
    invoke-virtual {v2, v4}, Lcom/zayon/optimize/ui/ZyBox;->setShadowMix(F)V

    iget-object v2, p0, Law;->s:[Landroid/widget/TextView;

    aget-object v2, v2, p1

    iget-object v4, p0, Law;->b:Landroid/content/Context;

    if-eqz v0, :cond_4

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    const p1, 0x7f0f00ae

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(I)V

    const/high16 p1, 0x7f080000

    invoke-static {v4, p1}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const p1, 0x3e0f5c29    # 0.14f

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/high16 p1, 0x41500000    # 13.0f

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setTextSize(F)V

    iget p0, p0, Law;->K:I

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    :cond_4
    iget-object v0, p0, Law;->m0:[Ljava/lang/Long;

    aget-object v5, v0, p1

    if-eqz v5, :cond_6

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v0, p1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, " ms"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v1, 0x7f080004

    invoke-static {v4, v1}, Let0;->a(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setLetterSpacing(F)V

    const/high16 v1, 0x41700000    # 15.0f

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setTextSize(F)V

    aget-object p1, v0, p1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const-wide/16 v3, 0x5a

    cmp-long p1, v0, v3

    if-lez p1, :cond_5

    iget p0, p0, Law;->L:I

    goto :goto_4

    :cond_5
    iget p0, p0, Law;->M:I

    :goto_4
    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    :cond_6
    const/4 p0, 0x4

    invoke-virtual {v2, p0}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public final m(Ljava/lang/Runnable;)V
    .locals 3

    iget-boolean v0, p0, Law;->e0:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    invoke-static {v0}, Lcom/zayon/optimize/core/ZyCore;->featureActive(I)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_1
    iput-boolean v0, p0, Law;->e0:Z

    iget-object v0, p0, Law;->b:Landroid/content/Context;

    const v1, 0x7f0f0095

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f0700ab

    iget-object v2, p0, Law;->c:Lu20;

    invoke-virtual {v2, v1, v0}, Lu20;->u(ILjava/lang/String;)V

    new-instance v0, Ltv;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Ltv;-><init>(Law;Ljava/lang/Runnable;I)V

    iget-object p0, p0, Law;->f:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
