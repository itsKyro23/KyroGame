.class public final synthetic Lbm1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lhm3;


# instance fields
.field public final h:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lbm1;->h:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 0

    iget-object p0, p0, Lbm1;->h:Landroid/content/Context;

    invoke-static {p0}, Lcom/google/android/play/core/hsdp/service/HsdpDeepLinkServiceFactory;->lambda$createInternal$1(Landroid/content/Context;)Lwt4;

    move-result-object p0

    return-object p0
.end method

.method public b(Log;)Lox4;
    .locals 11

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    const/16 v2, 0x23

    const-string v3, "createCodec:"

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-lt v0, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p0, p0, Lbm1;->h:Landroid/content/Context;

    if-eqz p0, :cond_6

    const/16 v1, 0x1c

    if-lt v0, v1, :cond_6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "com.amazon.hardware.tv_screen"

    invoke-virtual {p0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_1

    goto/16 :goto_7

    :cond_1
    :goto_0
    iget-object p0, p1, Log;->k:Ljava/lang/Object;

    check-cast p0, Lfx4;

    iget-object p0, p0, Lfx4;->o:Ljava/lang/String;

    invoke-static {p0}, Lxr1;->f(Ljava/lang/String;)I

    move-result p0

    packed-switch p0, :pswitch_data_0

    const-string v1, "camera motion"

    goto :goto_1

    :pswitch_0
    const-string v1, "metadata"

    goto :goto_1

    :pswitch_1
    const-string v1, "image"

    goto :goto_1

    :pswitch_2
    const-string v1, "text"

    goto :goto_1

    :pswitch_3
    const-string v1, "video"

    goto :goto_1

    :pswitch_4
    const-string v1, "audio"

    goto :goto_1

    :pswitch_5
    const-string v1, "default"

    goto :goto_1

    :pswitch_6
    const-string v1, "unknown"

    goto :goto_1

    :pswitch_7
    const-string v1, "none"

    :goto_1
    const-string v6, "Creating an asynchronous MediaCodec adapter for track type "

    invoke-virtual {v6, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lhd1;->B(Ljava/lang/String;)V

    iget-object v1, p1, Log;->i:Ljava/lang/Object;

    check-cast v1, Lrx4;

    iget-object v6, v1, Lrx4;->a:Ljava/lang/String;

    :try_start_0
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    add-int/lit8 v7, v7, 0xc

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v7}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    invoke-static {v6}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    const/16 v6, 0x24

    if-lt v0, v6, :cond_2

    :try_start_1
    new-instance v5, Ld03;

    const/16 v6, 0x13

    invoke-direct {v5, v6, v3}, Ld03;-><init>(ILjava/lang/Object;)V

    const/4 v6, 0x4

    goto :goto_2

    :cond_2
    new-instance v6, Lkx4;

    new-instance v7, Landroid/os/HandlerThread;

    const-string v8, "ExoPlayer:MediaCodecQueueingThread:"

    invoke-static {p0, v8}, Lix4;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    new-instance v8, Lfz2;

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    invoke-direct {v6, v3, v7, v8}, Lkx4;-><init>(Landroid/media/MediaCodec;Landroid/os/HandlerThread;Lfz2;)V

    move-object v10, v6

    move v6, v5

    move-object v5, v10

    :goto_2
    new-instance v7, Lix4;

    new-instance v8, Landroid/os/HandlerThread;

    const-string v9, "ExoPlayer:MediaCodecAsyncAdapter:"

    invoke-static {p0, v9}, Lix4;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v8, p0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iget-object p0, p1, Log;->m:Ljava/lang/Object;

    check-cast p0, Lzy2;

    invoke-direct {v7, v3, v8, v5, p0}, Lix4;-><init>(Landroid/media/MediaCodec;Landroid/os/HandlerThread;Lpx4;Lzy2;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    iget-object p0, p1, Log;->l:Ljava/lang/Object;

    check-cast p0, Landroid/view/Surface;

    if-nez p0, :cond_3

    iget-boolean v1, v1, Lrx4;->h:Z

    if-eqz v1, :cond_3

    if-lt v0, v2, :cond_3

    or-int/lit8 v6, v6, 0x8

    goto :goto_3

    :catch_0
    move-exception p0

    goto :goto_4

    :cond_3
    :goto_3
    iget-object p1, p1, Log;->j:Ljava/lang/Object;

    check-cast p1, Landroid/media/MediaFormat;

    invoke-virtual {v7, p1, p0, v6}, Lix4;->a(Landroid/media/MediaFormat;Landroid/view/Surface;I)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    return-object v7

    :goto_4
    move-object v4, v7

    goto :goto_5

    :catch_1
    move-exception p0

    goto :goto_5

    :catch_2
    move-exception p0

    move-object v3, v4

    :goto_5
    if-nez v4, :cond_4

    if-eqz v3, :cond_5

    invoke-virtual {v3}, Landroid/media/MediaCodec;->release()V

    goto :goto_6

    :cond_4
    invoke-virtual {v4}, Lix4;->j()V

    :cond_5
    :goto_6
    throw p0

    :cond_6
    :goto_7
    :try_start_3
    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Lrx4;

    iget-object v1, p0, Lrx4;->a:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    invoke-static {v1}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v1

    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_6
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_5

    :try_start_4
    const-string v3, "configureCodec"

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    iget-object v3, p1, Log;->l:Ljava/lang/Object;

    check-cast v3, Landroid/view/Surface;

    if-nez v3, :cond_7

    iget-boolean p0, p0, Lrx4;->h:Z

    if-eqz p0, :cond_7

    if-lt v0, v2, :cond_7

    const/16 v5, 0x8

    goto :goto_8

    :catch_3
    move-exception p0

    goto :goto_9

    :catch_4
    move-exception p0

    goto :goto_9

    :cond_7
    :goto_8
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Landroid/media/MediaFormat;

    invoke-virtual {v1, p0, v3, v4, v5}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    const-string p0, "startCodec"

    invoke-static {p0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/media/MediaCodec;->start()V

    invoke-static {}, Landroid/os/Trace;->endSection()V

    new-instance p0, Lry2;

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Lzy2;

    invoke-direct {p0, v1, p1}, Lry2;-><init>(Landroid/media/MediaCodec;Lzy2;)V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_3

    return-object p0

    :goto_9
    move-object v4, v1

    goto :goto_a

    :catch_5
    move-exception p0

    goto :goto_a

    :catch_6
    move-exception p0

    :goto_a
    if-eqz v4, :cond_8

    invoke-virtual {v4}, Landroid/media/MediaCodec;->release()V

    :cond_8
    throw p0

    :pswitch_data_0
    .packed-switch -0x2
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
