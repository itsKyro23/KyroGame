.class public final synthetic Lav3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;

.field public j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    iput p2, p0, Lav3;->h:I

    iput-object p1, p0, Lav3;->i:Ljava/lang/Object;

    iput-object p3, p0, Lav3;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lq14;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lav3;->h:I

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lav3;->i:Ljava/lang/Object;

    return-void
.end method

.method private final a()V
    .locals 12

    const/4 v1, 0x1

    :try_start_0
    const-string v2, "Exception while executing runnable "
    :try_end_0
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v0, 0x0

    move v3, v0

    :goto_0
    :try_start_1
    iget-object v4, p0, Lav3;->i:Ljava/lang/Object;

    check-cast v4, Lq14;

    iget-object v5, v4, Lq14;->i:Ljava/util/ArrayDeque;

    monitor-enter v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-nez v0, :cond_1

    :try_start_2
    iget v0, v4, Lq14;->l:I

    const/4 v6, 0x4

    if-ne v0, v6, :cond_0

    monitor-exit v5
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v3, :cond_2

    :goto_1
    :try_start_3
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V
    :try_end_3
    .catch Ljava/lang/Error; {:try_start_3 .. :try_end_3} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    goto/16 :goto_7

    :catchall_0
    move-exception v0

    goto :goto_5

    :cond_0
    :try_start_4
    iget-wide v7, v4, Lq14;->j:J

    const-wide/16 v9, 0x1

    add-long/2addr v7, v9

    iput-wide v7, v4, Lq14;->j:J

    iput v6, v4, Lq14;->l:I

    :cond_1
    iget-object v0, v4, Lq14;->i:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    iput-object v0, p0, Lav3;->j:Ljava/lang/Object;

    if-nez v0, :cond_3

    iget-object v0, p0, Lav3;->i:Ljava/lang/Object;

    check-cast v0, Lq14;

    iput v1, v0, Lq14;->l:I

    monitor-exit v5

    if-eqz v3, :cond_2

    goto :goto_1

    :cond_2
    :goto_2
    return-void

    :cond_3
    monitor-exit v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :try_start_5
    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    move-result v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    or-int/2addr v3, v0

    const/4 v4, 0x0

    :try_start_6
    iget-object v0, p0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    iput-object v4, p0, Lav3;->j:Ljava/lang/Object;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_3
    move v0, v1

    goto :goto_0

    :catchall_1
    move-exception v0

    goto :goto_6

    :catchall_2
    move-exception v0

    goto :goto_4

    :catch_1
    move-exception v0

    move-object v10, v0

    :try_start_8
    sget-object v0, Lq14;->m:Lxm0;

    invoke-virtual {v0}, Lxm0;->a()Ljava/util/logging/Logger;

    move-result-object v5

    sget-object v6, Ljava/util/logging/Level;->SEVERE:Ljava/util/logging/Level;

    const-string v7, "com.google.common.util.concurrent.SequentialExecutor$QueueWorker"

    const-string v8, "workOnQueue"

    iget-object v0, p0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v9

    add-int/lit8 v9, v9, 0x23

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v9}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v11, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual/range {v5 .. v10}, Ljava/util/logging/Logger;->logp(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    :try_start_9
    iput-object v4, p0, Lav3;->j:Ljava/lang/Object;

    goto :goto_3

    :goto_4
    iput-object v4, p0, Lav3;->j:Ljava/lang/Object;

    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    :goto_5
    :try_start_a
    monitor-exit v5
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_0

    :try_start_b
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :goto_6
    if-eqz v3, :cond_4

    :try_start_c
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->interrupt()V

    :cond_4
    throw v0
    :try_end_c
    .catch Ljava/lang/Error; {:try_start_c .. :try_end_c} :catch_0

    :goto_7
    iget-object p0, p0, Lav3;->i:Ljava/lang/Object;

    check-cast p0, Lq14;

    iget-object v2, p0, Lq14;->i:Ljava/util/ArrayDeque;

    monitor-enter v2

    :try_start_d
    iput v1, p0, Lq14;->l:I

    monitor-exit v2
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_3

    throw v0

    :catchall_3
    move-exception v0

    move-object p0, v0

    :try_start_e
    monitor-exit v2
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    throw p0
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v0, p0

    iget v1, v0, Lav3;->h:I

    const-wide/16 v2, 0x0

    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    packed-switch v1, :pswitch_data_0

    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Loz4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Lbk1;

    iget-object v6, v1, Loz4;->y:Lul1;

    if-nez v6, :cond_0

    move-object v6, v0

    goto :goto_0

    :cond_0
    new-instance v6, Lpj1;

    invoke-direct {v6, v4, v5, v2, v3}, Lpj1;-><init>(JJ)V

    :goto_0
    iput-object v6, v1, Loz4;->H:Lbk1;

    invoke-interface {v0}, Lbk1;->a()J

    move-result-wide v2

    iput-wide v2, v1, Loz4;->I:J

    iget-boolean v2, v1, Loz4;->M:Z

    if-nez v2, :cond_1

    invoke-interface {v0}, Lbk1;->a()J

    move-result-wide v2

    cmp-long v2, v2, v4

    if-nez v2, :cond_1

    move v8, v7

    :cond_1
    iput-boolean v8, v1, Loz4;->J:Z

    if-eq v7, v8, :cond_2

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    :goto_1
    iput v7, v1, Loz4;->K:I

    iget-boolean v2, v1, Loz4;->D:Z

    if-eqz v2, :cond_3

    iget-object v2, v1, Loz4;->l:Lqz4;

    iget-wide v3, v1, Loz4;->I:J

    invoke-virtual {v2, v3, v4, v0, v8}, Lqz4;->s(JLbk1;Z)V

    goto :goto_2

    :cond_3
    invoke-virtual {v1}, Loz4;->s()V

    :goto_2
    return-void

    :pswitch_0
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Ljk1;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/os/Bundle;

    :try_start_0
    iget-object v2, v1, Ljk1;->b:Lwf2;

    iget-object v2, v2, Lwf2;->r:Ljava/lang/Object;

    check-cast v2, Landroid/os/IInterface;

    check-cast v2, Lfy3;

    if-nez v2, :cond_4

    goto :goto_4

    :cond_4
    iget-object v1, v1, Ljk1;->d:Ljf1;

    check-cast v2, Lqc3;

    invoke-virtual {v2}, Ljd1;->W()Landroid/os/Parcel;

    move-result-object v3

    sget v4, Lte2;->a:I

    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {v0, v3, v8}, Landroid/os/Bundle;->writeToParcel(Landroid/os/Parcel;I)V

    if-nez v1, :cond_5

    invoke-virtual {v3, v6}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    goto :goto_3

    :cond_5
    invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    :goto_3
    const/4 v0, 0x4

    invoke-virtual {v2, v3, v0}, Ljd1;->Y(Landroid/os/Parcel;I)V
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_4
    return-void

    :pswitch_1
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lxx4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Ley2;

    iget-object v2, v1, Lxx4;->C:Lyl4;

    iget-object v3, v1, Lxx4;->I:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1, v0, v2, v8}, Lxx4;->n(Ley2;Lyl4;I)I

    move-result v0

    invoke-virtual {v3, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    return-void

    :pswitch_2
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Luv4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/media/AudioDeviceInfo;

    iget-object v2, v1, Luv4;->d:Ljava/lang/Object;

    check-cast v2, Lsv4;

    if-nez v2, :cond_6

    goto :goto_5

    :cond_6
    iget-object v1, v1, Luv4;->b:Ljava/lang/Object;

    check-cast v1, Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    check-cast v1, Llw4;

    iget-object v1, v1, Llw4;->f:Lwf2;

    if-eqz v1, :cond_8

    iget-object v2, v1, Lwf2;->q:Ljava/lang/Object;

    check-cast v2, Landroid/media/AudioDeviceInfo;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    goto :goto_5

    :cond_7
    iput-object v0, v1, Lwf2;->q:Ljava/lang/Object;

    iget-object v2, v1, Lwf2;->h:Landroid/content/Context;

    iget-object v3, v1, Lwf2;->r:Ljava/lang/Object;

    check-cast v3, Lbs2;

    invoke-virtual {v1}, Lwf2;->k()Ljava/util/List;

    move-result-object v4

    sget-object v5, Lpt4;->e:Lqy3;

    new-instance v5, Landroid/content/IntentFilter;

    const-string v7, "android.media.action.HDMI_AUDIO_PLUG"

    invoke-direct {v5, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v6, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v5

    invoke-static {v2, v5, v3, v0, v4}, Lpt4;->a(Landroid/content/Context;Landroid/content/Intent;Lbs2;Landroid/media/AudioDeviceInfo;Ljava/util/List;)Lpt4;

    move-result-object v0

    invoke-virtual {v1, v0}, Lwf2;->l(Lpt4;)V

    :cond_8
    :goto_5
    return-void

    :pswitch_3
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lni;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Lfm3;

    invoke-virtual {v0}, Lfm3;->a()Ld34;

    invoke-interface {v1}, Lni;->a()V

    return-void

    :pswitch_4
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lzy2;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Lbm4;

    sget-object v2, Lvh3;->a:Ljava/lang/String;

    iget-object v1, v1, Lzy2;->j:Ljava/lang/Object;

    check-cast v1, Lsn4;

    iget-object v1, v1, Lsn4;->h:Lhp4;

    iget-object v1, v1, Lhp4;->K:Lzy2;

    invoke-virtual {v1, v0}, Lzy2;->e(Lbm4;)V

    return-void

    :pswitch_5
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lkt4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/media/metrics/PlaybackErrorEvent;

    iget-object v1, v1, Lkt4;->k:Landroid/media/metrics/PlaybackSession;

    invoke-static {v1, v0}, Lit4;->q(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackErrorEvent;)V

    return-void

    :pswitch_6
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lkt4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/media/metrics/TrackChangeEvent;

    iget-object v1, v1, Lkt4;->k:Landroid/media/metrics/PlaybackSession;

    invoke-static {v1, v0}, Ljz0;->q(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/TrackChangeEvent;)V

    return-void

    :pswitch_7
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lkt4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/media/metrics/NetworkEvent;

    iget-object v1, v1, Lkt4;->k:Landroid/media/metrics/PlaybackSession;

    invoke-static {v1, v0}, Lit4;->p(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/NetworkEvent;)V

    return-void

    :pswitch_8
    iget-object v1, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v1, Lbu4;

    iget-object v0, v0, Lav3;->i:Ljava/lang/Object;

    move-object v9, v0

    check-cast v9, Lks4;

    iget v0, v1, Lbu4;->a:I

    monitor-enter v9

    :try_start_1
    iget-object v1, v9, Lks4;->l:Landroid/util/SparseArray;

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lbu4;

    if-eqz v2, :cond_9

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x14

    invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->remove(I)V

    const-string v0, "Timed out waiting for response"

    new-instance v1, Lsb2;

    invoke-direct {v1, v0, v6}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v2, v1}, Lbu4;->c(Lsb2;)V

    invoke-virtual {v9}, Lks4;->d()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_9
    monitor-exit v9

    goto :goto_6

    :catchall_0
    move-exception v0

    goto :goto_7

    :goto_6
    return-void

    :goto_7
    :try_start_2
    monitor-exit v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :pswitch_9
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    move-object v9, v1

    check-cast v9, Lhp4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Lt90;

    iget v1, v9, Lhp4;->M:I

    iget v6, v0, Lt90;->b:I

    sub-int/2addr v1, v6

    iput v1, v9, Lhp4;->M:I

    iget-boolean v6, v0, Lt90;->d:Z

    if-eqz v6, :cond_a

    iget v6, v0, Lt90;->e:I

    iput v6, v9, Lhp4;->N:I

    iput-boolean v7, v9, Lhp4;->O:Z

    :cond_a
    if-nez v1, :cond_15

    iget-object v1, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v1, Lcr4;

    iget-object v1, v1, Lcr4;->a:Ly02;

    iget-object v6, v9, Lhp4;->e0:Lcr4;

    iget-object v6, v6, Lcr4;->a:Ly02;

    invoke-virtual {v6}, Ly02;->g()Z

    move-result v6

    const/4 v10, -0x1

    if-nez v6, :cond_b

    invoke-virtual {v1}, Ly02;->g()Z

    move-result v6

    if-eqz v6, :cond_b

    iput v10, v9, Lhp4;->f0:I

    iput-wide v2, v9, Lhp4;->g0:J

    :cond_b
    invoke-virtual {v1}, Ly02;->g()Z

    move-result v2

    if-nez v2, :cond_d

    move-object v2, v1

    check-cast v2, Lhr4;

    iget-object v2, v2, Lhr4;->h:[Ly02;

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    iget-object v6, v9, Lhp4;->w:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ne v3, v11, :cond_c

    move v3, v7

    goto :goto_8

    :cond_c
    move v3, v8

    :goto_8
    invoke-static {v3}, La60;->D(Z)V

    move v3, v8

    :goto_9
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v11

    if-ge v3, v11, :cond_d

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lbp4;

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ly02;

    iput-object v12, v11, Lbp4;->b:Ly02;

    add-int/lit8 v3, v3, 0x1

    goto :goto_9

    :cond_d
    iget-boolean v2, v9, Lhp4;->O:Z

    if-eqz v2, :cond_14

    iget-object v2, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v2, Lcr4;

    iget-object v2, v2, Lcr4;->a:Ly02;

    invoke-virtual {v2}, Ly02;->g()Z

    move-result v2

    if-eqz v2, :cond_e

    iget-object v2, v9, Lhp4;->e0:Lcr4;

    iget-object v2, v2, Lcr4;->a:Ly02;

    invoke-virtual {v2}, Ly02;->g()Z

    move-result v2

    if-eqz v2, :cond_e

    move v2, v7

    goto :goto_a

    :cond_e
    move v2, v8

    :goto_a
    iget-object v3, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v3, Lcr4;

    iget-object v3, v3, Lcr4;->b:Lwy4;

    iget-object v6, v9, Lhp4;->e0:Lcr4;

    iget-object v6, v6, Lcr4;->b:Lwy4;

    invoke-virtual {v3, v6}, Lwy4;->c(Lwy4;)Z

    move-result v3

    iget-object v6, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v6, Lcr4;

    iget-wide v11, v6, Lcr4;->d:J

    iget-object v6, v9, Lhp4;->e0:Lcr4;

    iget-wide v13, v6, Lcr4;->s:J

    if-nez v2, :cond_f

    if-eqz v3, :cond_10

    cmp-long v2, v11, v13

    if-eqz v2, :cond_f

    goto :goto_b

    :cond_f
    move v7, v8

    :cond_10
    :goto_b
    if-eqz v7, :cond_13

    invoke-virtual {v9}, Lhp4;->Q1()I

    move-result v10

    invoke-virtual {v1}, Ly02;->g()Z

    move-result v2

    if-nez v2, :cond_12

    iget-object v2, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v2, Lcr4;

    iget-object v2, v2, Lcr4;->b:Lwy4;

    invoke-virtual {v2}, Lwy4;->b()Z

    move-result v2

    if-eqz v2, :cond_11

    goto :goto_c

    :cond_11
    iget-object v2, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v2, Lcr4;

    iget-object v3, v2, Lcr4;->b:Lwy4;

    iget-wide v4, v2, Lcr4;->d:J

    iget-object v2, v3, Lwy4;->a:Ljava/lang/Object;

    iget-object v3, v9, Lhp4;->v:Lrz1;

    invoke-virtual {v1, v2, v3}, Ly02;->o(Ljava/lang/Object;Lrz1;)Lrz1;

    goto :goto_d

    :cond_12
    :goto_c
    iget-object v1, v0, Lt90;->f:Ljava/lang/Object;

    check-cast v1, Lcr4;

    iget-wide v1, v1, Lcr4;->d:J

    move-wide v4, v1

    :cond_13
    :goto_d
    move-wide v14, v4

    move v12, v7

    :goto_e
    move/from16 v16, v10

    goto :goto_f

    :cond_14
    move-wide v14, v4

    move v12, v8

    goto :goto_e

    :goto_f
    iput-boolean v8, v9, Lhp4;->O:Z

    iget-object v0, v0, Lt90;->f:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Lcr4;

    const/4 v11, 0x1

    iget v13, v9, Lhp4;->N:I

    invoke-virtual/range {v9 .. v16}, Lhp4;->f2(Lcr4;IZIJI)V

    :cond_15
    return-void

    :pswitch_a
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lye2;

    iget-object v1, v1, Lye2;->k:Ljava/lang/Object;

    check-cast v1, Lbj1;

    iget-object v1, v1, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    :pswitch_b
    invoke-direct {v0}, Lav3;->a()V

    return-void

    :pswitch_c
    const-string v1, "app_set_id_storage"

    iget-object v2, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v2, Loo4;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lh21;

    iget-object v0, v2, Loo4;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-static {v0}, Loo4;->I(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v4, "app_set_id"

    invoke-interface {v2, v4, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0}, Loo4;->I(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v5

    const-string v6, "app_set_id_last_used_time"

    const-wide/16 v9, -0x1

    invoke-interface {v5, v6, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v5

    cmp-long v11, v5, v9

    if-eqz v11, :cond_16

    const-wide v9, 0x7d8702800L

    add-long/2addr v9, v5

    :cond_16
    if-eqz v2, :cond_18

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    cmp-long v5, v5, v9

    if-lez v5, :cond_17

    goto :goto_10

    :cond_17
    :try_start_3
    invoke-static {v0}, Loo4;->J(Landroid/content/Context;)V
    :try_end_3
    .catch Lcn4; {:try_start_3 .. :try_end_3} :catch_1

    goto/16 :goto_12

    :catch_1
    move-exception v0

    invoke-virtual {v3, v0}, Lh21;->a(Ljava/lang/Exception;)V

    goto/16 :goto_14

    :cond_18
    :goto_10
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    :try_start_4
    invoke-virtual {v0, v1, v8}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5, v4, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v4

    if-nez v4, :cond_1a

    const-string v1, "Failed to store app set ID generated for App "

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-eqz v2, :cond_19

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    goto :goto_11

    :catch_2
    move-exception v0

    goto :goto_13

    :cond_19
    :goto_11
    new-instance v0, Lcn4;

    const-string v1, "Failed to store the app set ID."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1a
    invoke-static {v0}, Loo4;->J(Landroid/content/Context;)V

    invoke-virtual {v0, v1, v8}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v6, "app_set_id_creation_time"

    invoke-interface {v1, v6, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v1

    if-nez v1, :cond_1c

    const-string v1, "Failed to store app set ID creation time for App "

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-eqz v2, :cond_1b

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    :cond_1b
    new-instance v0, Lcn4;

    const-string v1, "Failed to store the app set ID creation time."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_4
    .catch Lcn4; {:try_start_4 .. :try_end_4} :catch_2

    :cond_1c
    :goto_12
    new-instance v0, Lg9;

    invoke-direct {v0, v2, v7}, Lg9;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v3, v0}, Lh21;->b(Ljava/lang/Object;)V

    goto :goto_14

    :goto_13
    invoke-virtual {v3, v0}, Lh21;->a(Ljava/lang/Exception;)V

    :goto_14
    return-void

    :pswitch_d
    iget-object v1, v0, Lav3;->i:Ljava/lang/Object;

    check-cast v1, Lu73;

    iget-object v0, v0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    iget-object v2, v1, Lu73;->p:Ljava/lang/Object;

    check-cast v2, Lpu3;

    if-nez v2, :cond_1d

    iget-boolean v2, v1, Lu73;->h:Z

    if-nez v2, :cond_1d

    iget-object v2, v1, Lu73;->k:Ljava/lang/Object;

    check-cast v2, Ll24;

    new-array v3, v8, [Ljava/lang/Object;

    const-string v4, "Initiate binding to the service."

    invoke-virtual {v2, v4, v3}, Ll24;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v2, v1, Lu73;->l:Ljava/lang/Object;

    check-cast v2, Ljava/util/ArrayList;

    monitor-enter v2

    :try_start_5
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    new-instance v0, Lwb1;

    const/4 v2, 0x3

    invoke-direct {v0, v2, v1}, Lwb1;-><init>(ILjava/lang/Object;)V

    iput-object v0, v1, Lu73;->o:Ljava/lang/Object;

    iput-boolean v7, v1, Lu73;->h:Z

    iget-object v2, v1, Lu73;->j:Ljava/lang/Object;

    check-cast v2, Landroid/content/Context;

    iget-object v3, v1, Lu73;->m:Ljava/lang/Object;

    check-cast v3, Landroid/content/Intent;

    const/16 v4, 0x41

    invoke-virtual {v2, v3, v0, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    if-nez v0, :cond_1f

    iget-object v0, v1, Lu73;->k:Ljava/lang/Object;

    check-cast v0, Ll24;

    new-array v2, v8, [Ljava/lang/Object;

    const-string v3, "Failed to bind to the service."

    invoke-virtual {v0, v3, v2}, Ll24;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iput-boolean v8, v1, Lu73;->h:Z

    iget-object v0, v1, Lu73;->l:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/util/ArrayList;

    monitor-enter v1

    :try_start_6
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    monitor-exit v1

    goto :goto_15

    :catchall_1
    move-exception v0

    monitor-exit v1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    throw v0

    :catchall_2
    move-exception v0

    :try_start_7
    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    throw v0

    :cond_1d
    iget-boolean v2, v1, Lu73;->h:Z

    if-eqz v2, :cond_1e

    iget-object v2, v1, Lu73;->k:Ljava/lang/Object;

    check-cast v2, Ll24;

    new-array v3, v8, [Ljava/lang/Object;

    const-string v4, "Waiting to bind to the service."

    invoke-virtual {v2, v4, v3}, Ll24;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v1, v1, Lu73;->l:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    monitor-enter v1

    :try_start_8
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    monitor-exit v1

    goto :goto_15

    :catchall_3
    move-exception v0

    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    throw v0

    :cond_1e
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_1f
    :goto_15
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    iget v0, p0, Lav3;->h:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_0
    iget-object v0, p0, Lav3;->j:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    const-string v1, "}"

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v2, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x22

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "SequentialExecutorWorker{running="

    invoke-static {v2, v0, p0, v1}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_0
    iget-object p0, p0, Lav3;->i:Ljava/lang/Object;

    check-cast p0, Lq14;

    iget p0, p0, Lq14;->l:I

    const/4 v0, 0x1

    if-eq p0, v0, :cond_4

    const/4 v0, 0x2

    if-eq p0, v0, :cond_3

    const/4 v0, 0x3

    if-eq p0, v0, :cond_2

    const/4 v0, 0x4

    if-eq p0, v0, :cond_1

    const-string p0, "null"

    goto :goto_0

    :cond_1
    const-string p0, "RUNNING"

    goto :goto_0

    :cond_2
    const-string p0, "QUEUED"

    goto :goto_0

    :cond_3
    const-string p0, "QUEUING"

    goto :goto_0

    :cond_4
    const-string p0, "IDLE"

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v2, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x20

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "SequentialExecutorWorker{state="

    invoke-static {v2, v0, p0, v1}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method
