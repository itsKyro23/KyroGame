.class public final Laq4;
.super Llt4;
.source "SourceFile"


# static fields
.field private static final zzb:Laq4;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:I

.field private zzg:I

.field private zzh:I

.field private zzi:Lqt4;

.field private zzj:Ljava/lang/String;

.field private zzk:Lyp4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Laq4;

    invoke-direct {v0}, Laq4;-><init>()V

    sput-object v0, Laq4;->zzb:Laq4;

    const-class v1, Laq4;

    invoke-static {v1, v0}, Llt4;->k(Ljava/lang/Class;Llt4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Llt4;-><init>()V

    sget-object v0, Lmt4;->l:Lmt4;

    iput-object v0, p0, Laq4;->zzi:Lqt4;

    const-string v0, ""

    iput-object v0, p0, Laq4;->zzj:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final f(I)Ljava/lang/Object;
    .locals 12

    add-int/lit8 p1, p1, -0x1

    if-eqz p1, :cond_4

    const/4 p0, 0x2

    if-eq p1, p0, :cond_3

    const/4 p0, 0x3

    if-eq p1, p0, :cond_2

    const/4 p0, 0x4

    if-eq p1, p0, :cond_1

    const/4 p0, 0x5

    if-ne p1, p0, :cond_0

    sget-object p0, Laq4;->zzb:Laq4;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    throw p0

    :cond_1
    new-instance p0, Lso4;

    sget-object p1, Laq4;->zzb:Laq4;

    invoke-direct {p0, p1}, Ljt4;-><init>(Llt4;)V

    return-object p0

    :cond_2
    new-instance p0, Laq4;

    invoke-direct {p0}, Laq4;-><init>()V

    return-object p0

    :cond_3
    sget-object v3, Lh30;->F:Lh30;

    sget-object v5, Lq24;->D:Lq24;

    sget-object v7, Lt30;->C:Lt30;

    sget-object v9, Lq24;->C:Lq24;

    const-string v10, "zzk"

    const-string v11, "zzj"

    const-string v0, "zzd"

    const-string v1, "zze"

    const-string v2, "zzf"

    const-string v4, "zzg"

    const-string v6, "zzh"

    const-string v8, "zzi"

    filled-new-array/range {v0 .. v11}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Laq4;->zzb:Laq4;

    new-instance v0, Lxu4;

    const-string v1, "\u0004\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0001\u0000\u0001\u1004\u0000\u0002\u180c\u0001\u0003\u180c\u0002\u0004\u180c\u0003\u0005\u082c\u0006\u1009\u0005\u0007\u1208\u0004"

    invoke-direct {v0, p1, v1, p0}, Lxu4;-><init>(Los4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0

    :cond_4
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
