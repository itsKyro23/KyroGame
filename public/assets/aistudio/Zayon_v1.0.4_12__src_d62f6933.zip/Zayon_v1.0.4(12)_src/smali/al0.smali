.class public final Lal0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements La32;


# instance fields
.field public h:Z

.field public i:I


# virtual methods
.method public i(Lx42;)V
    .locals 3

    sget v0, Lim2;->k0:I

    invoke-static {}, Ln42;->A()Lm42;

    move-result-object v0

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Ln42;

    invoke-virtual {v1}, Ln42;->z()Z

    move-result v1

    iget-boolean v2, p0, Lal0;->h:Z

    if-eq v1, v2, :cond_0

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Ln42;

    invoke-virtual {v1, v2}, Ln42;->B(Z)V

    :cond_0
    iget p0, p0, Lal0;->i:I

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Ln42;

    invoke-virtual {v1, p0}, Ln42;->y(I)V

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object p0

    check-cast p0, Ln42;

    invoke-virtual {p1}, Lkg4;->c()V

    iget-object p1, p1, Lkg4;->i:Lng4;

    check-cast p1, Ly42;

    invoke-virtual {p1, p0}, Ly42;->C(Ln42;)V

    return-void
.end method
