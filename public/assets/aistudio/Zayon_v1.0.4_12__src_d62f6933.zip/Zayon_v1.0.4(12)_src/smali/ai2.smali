.class public final Lai2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lp12;


# instance fields
.field public final h:Landroid/content/Context;

.field public final i:Ljava/lang/Object;

.field public final j:Ljava/lang/String;

.field public k:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    :cond_0
    iput-object p1, p0, Lai2;->h:Landroid/content/Context;

    iput-object p2, p0, Lai2;->j:Ljava/lang/String;

    const/4 p1, 0x0

    iput-boolean p1, p0, Lai2;->k:Z

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lai2;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 4

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v1, v0, Lcw4;->x:Lbi2;

    iget-object v2, p0, Lai2;->h:Landroid/content/Context;

    invoke-virtual {v1, v2}, Lbi2;->a(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lai2;->i:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-boolean v3, p0, Lai2;->k:Z

    if-ne v3, p1, :cond_1

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    iput-boolean p1, p0, Lai2;->k:Z

    iget-object p1, p0, Lai2;->j:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_2

    monitor-exit v1

    return-void

    :cond_2
    iget-boolean p0, p0, Lai2;->k:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, v0, Lcw4;->x:Lbi2;

    if-eqz p0, :cond_4

    :try_start_1
    invoke-virtual {v0, v2}, Lbi2;->a(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    const-string p0, "beginAdUnitExposure"

    invoke-virtual {v0, v2, p1, p0}, Lbi2;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :cond_4
    invoke-virtual {v0, v2}, Lbi2;->a(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_5

    goto :goto_0

    :cond_5
    const-string p0, "endAdUnitExposure"

    invoke-virtual {v0, v2, p1, p0}, Lbi2;->j(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    monitor-exit v1

    return-void

    :goto_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public final s0(Lo12;)V
    .locals 0

    iget-boolean p1, p1, Lo12;->j:Z

    invoke-virtual {p0, p1}, Lai2;->a(Z)V

    return-void
.end method
