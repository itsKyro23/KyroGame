.class public final Lap3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lbq3;

.field public final b:Lmq3;

.field public final c:Lvt3;

.field public final d:Lju3;

.field public final e:Lqp3;

.field public final f:J

.field public final g:Lnk4;

.field public final h:J

.field public final i:J

.field public final j:Z

.field public final k:J

.field public final l:Z


# direct methods
.method public constructor <init>(Lbq3;Lmq3;Lvt3;Lju3;Lqp3;Lnk4;Lcp3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lap3;->a:Lbq3;

    iput-object p2, p0, Lap3;->b:Lmq3;

    iput-object p3, p0, Lap3;->c:Lvt3;

    iput-object p4, p0, Lap3;->d:Lju3;

    iput-object p5, p0, Lap3;->e:Lqp3;

    invoke-virtual {p7}, Lcp3;->Y()J

    move-result-wide p1

    iput-wide p1, p0, Lap3;->f:J

    iput-object p6, p0, Lap3;->g:Lnk4;

    invoke-virtual {p7}, Lcp3;->X()J

    move-result-wide p1

    iput-wide p1, p0, Lap3;->h:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Lap3;->i:J

    invoke-virtual {p7}, Lcp3;->h0()Z

    move-result p1

    iput-boolean p1, p0, Lap3;->j:Z

    invoke-virtual {p7}, Lcp3;->g0()J

    move-result-wide p1

    iput-wide p1, p0, Lap3;->k:J

    invoke-virtual {p7}, Lcp3;->n0()Z

    move-result p1

    iput-boolean p1, p0, Lap3;->l:Z

    return-void
.end method
