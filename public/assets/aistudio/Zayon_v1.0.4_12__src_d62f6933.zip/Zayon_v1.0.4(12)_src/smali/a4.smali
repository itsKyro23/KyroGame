.class public final synthetic La4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lf4;
.implements Lpb1;
.implements Lbj0;
.implements Lnh;
.implements Lwi0;
.implements Ly5;
.implements Lkd0;
.implements Lus0;
.implements Ld5;
.implements Ltp0;
.implements Lqu0;
.implements Ll11;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    iput p2, p0, La4;->h:I

    iput-object p1, p0, La4;->i:Ljava/lang/Object;

    iput-object p3, p0, La4;->j:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 7

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lad0;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Lbd0;

    iget-object v1, v0, Lad0;->a:Landroid/content/Context;

    iget-object p0, p0, Lbd0;->a:Ljava/lang/String;

    invoke-static {v1}, Lcd0;->e(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v4, 0x0

    :cond_0
    :goto_0
    if-ge v4, v3, :cond_1

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v4, v4, 0x1

    check-cast v5, Lbd0;

    iget-object v6, v5, Lbd0;->a:Ljava/lang/String;

    invoke-virtual {v6, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-static {p1}, Lcd0;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, v5, Lbd0;->c:Ljava/lang/String;

    goto :goto_0

    :cond_1
    invoke-static {v1, v2}, Lcd0;->f(Landroid/content/Context;Ljava/util/ArrayList;)V

    invoke-virtual {v0}, Lad0;->a()V

    return-void
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lsu0;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Ljb;

    move-object v1, p1

    check-cast v1, Landroid/database/sqlite/SQLiteDatabase;

    iget-object p1, v0, Lsu0;->k:Lsa;

    iget v2, p1, Lsa;->b:I

    invoke-virtual {v0, v1, p0, v2}, Lsu0;->e(Landroid/database/sqlite/SQLiteDatabase;Ljb;I)Ljava/util/ArrayList;

    move-result-object v9

    invoke-static {}, Lbo0;->values()[Lbo0;

    move-result-object v2

    array-length v3, v2

    const/4 v10, 0x0

    move v4, v10

    :goto_0
    if-ge v4, v3, :cond_3

    aget-object v5, v2, v4

    iget-object v6, p0, Ljb;->c:Lbo0;

    if-ne v5, v6, :cond_0

    goto :goto_1

    :cond_0
    iget v6, p1, Lsa;->b:I

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v7

    sub-int/2addr v6, v7

    if-gtz v6, :cond_1

    goto :goto_2

    :cond_1
    invoke-static {}, Ljb;->a()Loo4;

    move-result-object v7

    iget-object v8, p0, Ljb;->a:Ljava/lang/String;

    invoke-virtual {v7, v8}, Loo4;->t(Ljava/lang/String;)V

    if-eqz v5, :cond_2

    iput-object v5, v7, Loo4;->k:Ljava/lang/Object;

    iget-object v5, p0, Ljb;->b:[B

    iput-object v5, v7, Loo4;->j:Ljava/lang/Object;

    invoke-virtual {v7}, Loo4;->d()Ljb;

    move-result-object v5

    invoke-virtual {v0, v1, v5, v6}, Lsu0;->e(Landroid/database/sqlite/SQLiteDatabase;Ljb;I)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :goto_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    const-string p0, "Null priority"

    invoke-static {p0}, Ls40;->l(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_3
    :goto_2
    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "event_id IN ("

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move v0, v10

    :goto_3
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v11, 0x1

    if-ge v0, v2, :cond_5

    invoke-virtual {v9, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lbb;

    iget-wide v2, v2, Lbb;->a:J

    invoke-virtual {p1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v11

    if-ge v0, v2, :cond_4

    const/16 v2, 0x2c

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_5
    const/16 v0, 0x29

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v0, "name"

    const-string v2, "value"

    const-string v3, "event_id"

    filled-new-array {v3, v0, v2}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v2, "event_metadata"

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    :goto_4
    :try_start_0
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {p1, v10}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    if-nez v2, :cond_6

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    new-instance v0, Lru0;

    invoke-interface {p1, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    invoke-interface {p1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v1, v3}, Lru0;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v2, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_4

    :cond_7
    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    invoke-virtual {v9}, Ljava/util/ArrayList;->listIterator()Ljava/util/ListIterator;

    move-result-object p1

    :goto_5
    invoke-interface {p1}, Ljava/util/ListIterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-interface {p1}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbb;

    iget-wide v1, v0, Lbb;->a:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_8

    goto :goto_5

    :cond_8
    iget-object v3, v0, Lbb;->c:Lra;

    invoke-virtual {v3}, Lra;->c()Lqa;

    move-result-object v3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {p0, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Set;

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_6
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_9

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lru0;

    iget-object v6, v5, Lru0;->a:Ljava/lang/String;

    iget-object v5, v5, Lru0;->b:Ljava/lang/String;

    invoke-virtual {v3, v6, v5}, Lqa;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6

    :cond_9
    iget-object v0, v0, Lbb;->b:Ljb;

    invoke-virtual {v3}, Lqa;->b()Lra;

    move-result-object v3

    new-instance v4, Lbb;

    invoke-direct {v4, v1, v2, v0, v3}, Lbb;-><init>(JLjb;Lra;)V

    invoke-interface {p1, v4}, Ljava/util/ListIterator;->set(Ljava/lang/Object;)V

    goto :goto_5

    :cond_a
    return-object v9

    :catchall_0
    move-exception v0

    move-object p0, v0

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    throw p0
.end method

.method public b(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lpb1;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Lio/github/muntashirakon/adb/AdbStream;

    const-string v1, "__ZEC__"

    invoke-virtual {p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-gez v1, :cond_0

    invoke-interface {v0, p1}, Lpb1;->b(Ljava/lang/String;)V

    return-void

    :cond_0
    if-lez v1, :cond_1

    const/4 v2, 0x0

    invoke-virtual {p1, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-interface {v0, p1}, Lpb1;->b(Ljava/lang/String;)V

    :cond_1
    :try_start_0
    invoke-virtual {p0}, Lio/github/muntashirakon/adb/AdbStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public c(Z)V
    .locals 3

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, [Z

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Lz3;

    const/4 v1, 0x0

    aget-boolean v2, v0, v1

    if-eqz v2, :cond_0

    return-void

    :cond_0
    const/4 v2, 0x1

    aput-boolean v2, v0, v1

    invoke-virtual {p0, p1}, Lz3;->c(Z)V

    return-void
.end method

.method public d()Ljava/lang/Object;
    .locals 7

    iget v0, p0, La4;->h:I

    const/4 v1, 0x0

    iget-object v2, p0, La4;->j:Ljava/lang/Object;

    iget-object p0, p0, La4;->i:Ljava/lang/Object;

    check-cast p0, Lsj1;

    packed-switch v0, :pswitch_data_0

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    iget-object v3, p0, Lsj1;->i:Ljava/lang/Object;

    check-cast v3, Lsu0;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    int-to-long v4, v4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v6, Lgb0;->n:Lgb0;

    invoke-virtual {v3, v4, v5, v6, v2}, Lsu0;->f(JLgb0;Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    return-object v1

    :pswitch_0
    check-cast v2, Ljava/lang/Iterable;

    iget-object p0, p0, Lsj1;->c:Ljava/lang/Object;

    check-cast p0, Lsu0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_1

    :cond_1
    invoke-static {v2}, Lsu0;->h(Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "DELETE FROM events WHERE _id in "

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lsu0;->a()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object p0

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    :goto_1
    return-object v1

    :pswitch_data_0
    .packed-switch 0xf
        :pswitch_0
    .end packed-switch
.end method

.method public e(ZZ)V
    .locals 2

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lvk0;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    iget-boolean v1, v0, Lvk0;->M:Z

    if-eqz v1, :cond_0

    return-void

    :cond_0
    if-eqz p1, :cond_1

    const/4 p1, 0x1

    invoke-virtual {v0, p1, p0}, Lvk0;->W(ILjava/lang/String;)V

    return-void

    :cond_1
    iget-object p0, v0, Lvk0;->a:Landroid/content/Context;

    const/4 p1, 0x3

    if-eqz p2, :cond_2

    const p2, 0x7f0f022d

    invoke-virtual {p0, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p1, p0}, Lvk0;->W(ILjava/lang/String;)V

    return-void

    :cond_2
    const p2, 0x7f0f024e

    invoke-virtual {p0, p2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p1, p0}, Lvk0;->W(ILjava/lang/String;)V

    return-void
.end method

.method public f(Lad;Ljava/util/List;)V
    .locals 3

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lpn0;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Lon0;

    iget v1, p1, Lad;->a:I

    if-nez v1, :cond_1

    if-eqz p2, :cond_1

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance p2, Ljava/lang/Thread;

    new-instance v1, Lz4;

    const/16 v2, 0x10

    invoke-direct {v1, v2, v0, p1, p0}, Lz4;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const-string p0, "zayon-billing-verify"

    invoke-direct {p2, v1, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    return-void

    :cond_1
    :goto_0
    if-eqz p0, :cond_2

    iget-object p2, v0, Lpn0;->c:Landroid/os/Handler;

    new-instance v0, Lck0;

    const/16 v1, 0xe

    invoke-direct {v0, p0, v1, p1}, Lck0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {p2, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    return-void
.end method

.method public g(Landroid/view/View;Lx91;)Lx91;
    .locals 7

    iget-object p1, p0, La4;->i:Ljava/lang/Object;

    check-cast p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/view/View;

    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    const/16 v0, 0x80

    iget-object v1, p2, Lx91;->a:Lu91;

    invoke-virtual {v1, v0}, Lu91;->h(I)Ly50;

    move-result-object v0

    iget-object v1, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/high16 v2, 0x42920000    # 73.0f

    iget v3, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->G:F

    mul-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v3, v0, Ly50;->a:I

    iget v4, v0, Ly50;->d:I

    iget v5, v0, Ly50;->b:I

    add-int/2addr v2, v3

    iget v3, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-eq v3, v2, :cond_0

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    iget-object v2, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I:Landroid/view/View;

    invoke-virtual {v2, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    const/high16 v1, 0x41a00000    # 20.0f

    iget v2, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->G:F

    mul-float/2addr v2, v1

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget-object v2, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->I:Landroid/view/View;

    iget v3, v0, Ly50;->a:I

    add-int v6, v1, v5

    iget p1, p1, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->G:F

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    add-int/2addr v1, v4

    invoke-virtual {v2, v3, v6, p1, v1}, Landroid/view/View;->setPadding(IIII)V

    const/4 p1, 0x0

    iget v0, v0, Ly50;->c:I

    invoke-virtual {p0, p1, v5, v0, v4}, Landroid/view/View;->setPadding(IIII)V

    return-object p2
.end method

.method public h(F)V
    .locals 2

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lcom/zayon/optimize/MainActivity;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/view/View;

    sget-boolean v1, Lcom/zayon/optimize/MainActivity;->o0:Z

    iput p1, v0, Lcom/zayon/optimize/MainActivity;->c0:F

    sget-object v0, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-static {p0, p1, v0}, Lcom/zayon/optimize/MainActivity;->x(Landroid/view/View;FLandroid/graphics/Shader$TileMode;)V

    return-void
.end method

.method public i(Lg21;)V
    .locals 2

    iget v0, p0, La4;->h:I

    iget-object v1, p0, La4;->j:Ljava/lang/Object;

    iget-object p0, p0, La4;->i:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_0

    check-cast p0, Lcom/google/firebase/messaging/EnhancedIntentService;

    check-cast v1, Landroid/content/Intent;

    invoke-static {p0, v1, p1}, Lcom/google/firebase/messaging/EnhancedIntentService;->b(Lcom/google/firebase/messaging/EnhancedIntentService;Landroid/content/Intent;Lg21;)V

    return-void

    :pswitch_0
    check-cast p0, Landroid/content/SharedPreferences;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p1}, Lg21;->j()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "version_topic"

    invoke-interface {p0, p1, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public j(Ljava/lang/String;Z)V
    .locals 3

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Landroid/content/BroadcastReceiver$PendingResult;

    sget v1, Lcom/zayon/optimize/ui/pusat/PairNotifier$PairReplyReceiver;->a:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p2, :cond_0

    invoke-static {v0, p1, v2, v1}, Lic1;->g(Landroid/content/Context;Ljava/lang/String;ZZ)V

    goto :goto_0

    :cond_0
    invoke-static {v0, p1, v1, v2}, Lic1;->g(Landroid/content/Context;Ljava/lang/String;ZZ)V

    :goto_0
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    return-void
.end method

.method public k(Log;)Ljava/lang/Object;
    .locals 3

    iget v0, p0, La4;->h:I

    iget-object v1, p0, La4;->j:Ljava/lang/Object;

    iget-object p0, p0, La4;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    packed-switch v0, :pswitch_data_0

    check-cast v1, Lb;

    const-class v0, Landroid/content/Context;

    invoke-virtual {p1, v0}, Log;->c(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/Context;

    iget v0, v1, Lb;->h:I

    const-string v1, ""

    packed-switch v0, :pswitch_data_1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_3

    invoke-static {p1}, Lcom/google/firebase/FirebaseCommonRegistrar;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :pswitch_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v2, "android.hardware.type.television"

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v1, "tv"

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v2, "android.hardware.type.watch"

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v1, "watch"

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v2, "android.hardware.type.automotive"

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v1, "auto"

    goto :goto_0

    :cond_2
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const-string v0, "android.hardware.type.embedded"

    invoke-virtual {p1, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_3

    const-string v1, "embedded"

    goto :goto_0

    :pswitch_1
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    if-eqz p1, :cond_3

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->minSdkVersion:I

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :pswitch_2
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    if-eqz p1, :cond_3

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    :cond_3
    :goto_0
    new-instance p1, Lwa;

    invoke-direct {p1, p0, v1}, Lwa;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    return-object p1

    :pswitch_3
    check-cast v1, Lch;

    :try_start_0
    invoke-static {p0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    iget-object p0, v1, Lch;->f:Lnh;

    invoke-interface {p0, p1}, Lnh;->k(Log;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-object p0

    :catchall_0
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0

    :pswitch_data_0
    .packed-switch 0x3
        :pswitch_3
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x16
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public l(Lad;Lgq0;)V
    .locals 10

    iget-object v0, p0, La4;->i:Ljava/lang/Object;

    check-cast v0, Lpn0;

    iget-object p0, p0, La4;->j:Ljava/lang/Object;

    check-cast p0, Lsn0;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iget p1, p1, Lad;->a:I

    if-nez p1, :cond_6

    iget-object p1, p2, Lgq0;->a:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    move-object v8, p2

    check-cast v8, Lmo0;

    iget-object p2, v8, Lmo0;->h:Ljava/util/ArrayList;

    const/4 v2, 0x0

    if-eqz p2, :cond_5

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Llo0;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v5

    :cond_2
    if-ge v3, v5, :cond_3

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v3, v3, 0x1

    check-cast v6, Llo0;

    iget-object v7, v6, Llo0;->a:Ljava/lang/String;

    if-nez v7, :cond_2

    move-object v4, v6

    :cond_3
    iget-object p2, v4, Llo0;->c:Lso3;

    iget-object p2, p2, Lso3;->i:Ljava/lang/Object;

    check-cast p2, Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lko0;

    new-instance v2, Lnn0;

    iget-object v3, v8, Lmo0;->c:Ljava/lang/String;

    move-object v6, v4

    iget-object v4, p2, Lko0;->a:Ljava/lang/String;

    move-object v7, v6

    iget-wide v5, p2, Lko0;->b:J

    iget-object p2, p2, Lko0;->c:Ljava/lang/String;

    iget-object v9, v7, Llo0;->b:Ljava/lang/String;

    move-object v7, p2

    invoke-direct/range {v2 .. v9}, Lnn0;-><init>(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Lmo0;Ljava/lang/String;)V

    :cond_5
    :goto_1
    if-eqz v2, :cond_0

    iget-object p2, v2, Lnn0;->a:Ljava/lang/String;

    invoke-virtual {v1, p2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_6
    iget-object p1, v0, Lpn0;->c:Landroid/os/Handler;

    new-instance p2, Lck0;

    const/16 v0, 0xc

    invoke-direct {p2, p0, v0, v1}, Lck0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
