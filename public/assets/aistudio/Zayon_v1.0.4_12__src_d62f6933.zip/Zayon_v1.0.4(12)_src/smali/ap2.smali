.class public final Lap2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lto2;


# virtual methods
.method public final a(Ljava/util/HashMap;)V
    .locals 1

    sget-object p0, Lk52;->Vb:Lg52;

    sget-object v0, Lvx1;->e:Lvx1;

    iget-object v0, v0, Lvx1;->c:Li52;

    invoke-virtual {v0, p0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_1

    invoke-virtual {p1}, Ljava/util/HashMap;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "is_topics_ad_personalization_allowed"

    invoke-virtual {p1, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_1

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0

    sget-object p1, Lcw4;->B:Lcw4;

    iget-object p1, p1, Lcw4;->h:Lui2;

    invoke-virtual {p1}, Lui2;->g()Lol4;

    move-result-object p1

    invoke-virtual {p1, p0}, Lol4;->u(Z)V

    :cond_1
    :goto_0
    return-void
.end method
