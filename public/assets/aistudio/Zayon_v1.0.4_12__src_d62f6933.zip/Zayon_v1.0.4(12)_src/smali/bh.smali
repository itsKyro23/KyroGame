.class public final Lbh;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Le73;


# instance fields
.field public h:Ljava/lang/String;

.field public i:I

.field public final j:I

.field public final k:Ljava/io/Serializable;

.field public final l:Ljava/io/Serializable;

.field public final m:Ljava/lang/Object;

.field public n:Ljava/lang/Object;


# direct methods
.method public varargs constructor <init>(Ldq0;[Ldq0;)V
    .locals 3

    .line 65
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 66
    iput-object v0, p0, Lbh;->h:Ljava/lang/String;

    .line 67
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lbh;->k:Ljava/io/Serializable;

    .line 68
    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    iput-object v1, p0, Lbh;->l:Ljava/io/Serializable;

    const/4 v1, 0x0

    .line 69
    iput v1, p0, Lbh;->i:I

    .line 70
    iput v1, p0, Lbh;->j:I

    .line 71
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, p0, Lbh;->m:Ljava/lang/Object;

    .line 72
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 73
    array-length p1, p2

    :goto_0
    if-ge v1, p1, :cond_0

    aget-object v0, p2, v1

    .line 74
    const-string v2, "Null interface"

    invoke-static {v0, v2}, Luo2;->c(Ljava/lang/Object;Ljava/lang/String;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 75
    :cond_0
    iget-object p0, p0, Lbh;->k:Ljava/io/Serializable;

    check-cast p0, Ljava/util/HashSet;

    invoke-static {p0, p2}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    return-void
.end method

.method public varargs constructor <init>(Ljava/lang/Class;[Ljava/lang/Class;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lbh;->h:Ljava/lang/String;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lbh;->k:Ljava/io/Serializable;

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    iput-object v1, p0, Lbh;->l:Ljava/io/Serializable;

    const/4 v1, 0x0

    iput v1, p0, Lbh;->i:I

    iput v1, p0, Lbh;->j:I

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, p0, Lbh;->m:Ljava/lang/Object;

    invoke-static {p1}, Ldq0;->a(Ljava/lang/Class;)Ldq0;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    array-length p1, p2

    :goto_0
    if-ge v1, p1, :cond_0

    aget-object v0, p2, v1

    const-string v2, "Null interface"

    invoke-static {v0, v2}, Luo2;->c(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v2, p0, Lbh;->k:Ljava/io/Serializable;

    check-cast v2, Ljava/util/HashSet;

    invoke-static {v0}, Ldq0;->a(Ljava/lang/Class;)Ldq0;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILandroid/webkit/WebView;Ljava/lang/String;I)V
    .locals 0

    .line 64
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbh;->h:Ljava/lang/String;

    iput-object p2, p0, Lbh;->k:Ljava/io/Serializable;

    iput-object p3, p0, Lbh;->l:Ljava/io/Serializable;

    iput p4, p0, Lbh;->i:I

    iput-object p5, p0, Lbh;->m:Ljava/lang/Object;

    iput-object p6, p0, Lbh;->n:Ljava/lang/Object;

    iput p7, p0, Lbh;->j:I

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .locals 12

    iget-object v0, p0, Lbh;->h:Ljava/lang/String;

    iget-object v1, p0, Lbh;->k:Ljava/io/Serializable;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Lbh;->l:Ljava/io/Serializable;

    check-cast v2, Ljava/lang/String;

    iget v3, p0, Lbh;->i:I

    iget-object v4, p0, Lbh;->m:Ljava/lang/Object;

    move-object v7, v4

    check-cast v7, Landroid/webkit/WebView;

    iget-object v4, p0, Lbh;->n:Ljava/lang/Object;

    move-object v8, v4

    check-cast v8, Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v11, 0x0

    if-nez v4, :cond_5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_4

    new-instance v6, Ldw2;

    invoke-direct {v6, v0, v1}, Ldw2;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "javascript"

    invoke-static {v0}, Ljl2;->o(Ljava/lang/String;)Lvk3;

    move-result-object v0

    invoke-static {v2}, Ljl2;->o(Ljava/lang/String;)Lvk3;

    move-result-object v1

    invoke-static {v3}, Lf73;->c(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljl2;->s(Ljava/lang/String;)Lrk3;

    move-result-object v4

    sget-object v5, Lvk3;->k:Lvk3;

    if-ne v0, v5, :cond_0

    sget p0, Lj23;->b:I

    const-string p0, "Omid js session error; Unable to parse impression owner: javascript"

    invoke-static {p0}, Lj23;->g(Ljava/lang/String;)V

    return-object v11

    :cond_0
    if-nez v4, :cond_1

    invoke-static {v3}, Lf73;->c(I)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Omid js session error; Unable to parse creative type: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget v0, Lj23;->b:I

    invoke-static {p0}, Lj23;->g(Ljava/lang/String;)V

    return-object v11

    :cond_1
    sget-object v3, Lrk3;->l:Lrk3;

    if-ne v4, v3, :cond_2

    if-ne v1, v5, :cond_2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    sget v0, Lj23;->b:I

    const-string v0, "Omid js session error; Video events owner unknown for video creative: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lj23;->g(Ljava/lang/String;)V

    return-object v11

    :cond_2
    new-instance v5, Lqh;

    sget-object v10, Lok3;->j:Lok3;

    const-string v9, ""

    invoke-direct/range {v5 .. v10}, Lqh;-><init>(Ldw2;Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Lok3;)V

    iget p0, p0, Lbh;->j:I

    invoke-static {p0}, Lf73;->d(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljl2;->p(Ljava/lang/String;)Ltk3;

    move-result-object p0

    const/4 v2, 0x1

    invoke-static {v4, p0, v0, v1, v2}, Ljn3;->b(Lrk3;Ltk3;Lvk3;Lvk3;Z)Ljn3;

    move-result-object p0

    sget-object v0, Lpw0;->n:Lyn1;

    iget-boolean v0, v0, Lyn1;->i:Z

    if-eqz v0, :cond_3

    new-instance v0, Lpk3;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, p0, v5, v1}, Lpk3;-><init>(Ljn3;Lqh;Ljava/lang/String;)V

    new-instance p0, Lh73;

    invoke-direct {p0, v0, v5}, Lh73;-><init>(Lpk3;Lqh;)V

    return-object p0

    :cond_3
    const-string p0, "Method called before OM SDK activation"

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-object v11

    :cond_4
    const-string p0, "Version is null or empty"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-object v11

    :cond_5
    const-string p0, "Name is null or empty"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-object v11
.end method

.method public b(Lzp;)V
    .locals 2

    iget-object v0, p1, Lzp;->a:Ldq0;

    iget-object v1, p0, Lbh;->k:Ljava/io/Serializable;

    check-cast v1, Ljava/util/HashSet;

    invoke-virtual {v1, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object p0, p0, Lbh;->l:Ljava/io/Serializable;

    check-cast p0, Ljava/util/HashSet;

    invoke-virtual {p0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void

    :cond_0
    const-string p0, "Components are not allowed to depend on interfaces they themselves provide."

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method

.method public c()Lch;
    .locals 9

    iget-object v0, p0, Lbh;->n:Ljava/lang/Object;

    check-cast v0, Lnh;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    new-instance v1, Lch;

    iget-object v2, p0, Lbh;->h:Ljava/lang/String;

    new-instance v3, Ljava/util/HashSet;

    iget-object v0, p0, Lbh;->k:Ljava/io/Serializable;

    check-cast v0, Ljava/util/HashSet;

    invoke-direct {v3, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    new-instance v4, Ljava/util/HashSet;

    iget-object v0, p0, Lbh;->l:Ljava/io/Serializable;

    check-cast v0, Ljava/util/HashSet;

    invoke-direct {v4, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    iget v5, p0, Lbh;->i:I

    iget-object v0, p0, Lbh;->n:Ljava/lang/Object;

    move-object v7, v0

    check-cast v7, Lnh;

    iget-object v0, p0, Lbh;->m:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Ljava/util/HashSet;

    iget v6, p0, Lbh;->j:I

    invoke-direct/range {v1 .. v8}, Lch;-><init>(Ljava/lang/String;Ljava/util/Set;Ljava/util/Set;IILnh;Ljava/util/Set;)V

    return-object v1

    :cond_1
    const-string p0, "Missing required property: factory."

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
