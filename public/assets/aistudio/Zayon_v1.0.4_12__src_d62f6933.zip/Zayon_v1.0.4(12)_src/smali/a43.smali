.class public final enum La43;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum h:La43;

.field public static final enum i:La43;

.field public static final enum j:La43;

.field public static final synthetic k:[La43;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, La43;

    const-string v1, "AD_REQUESTED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, La43;->h:La43;

    new-instance v1, La43;

    const-string v2, "AD_LOADED"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, La43;->i:La43;

    new-instance v2, La43;

    const-string v3, "AD_LOAD_FAILED"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, La43;->j:La43;

    filled-new-array {v0, v1, v2}, [La43;

    move-result-object v0

    sput-object v0, La43;->k:[La43;

    return-void
.end method

.method public static values()[La43;
    .locals 1

    sget-object v0, La43;->k:[La43;

    invoke-virtual {v0}, [La43;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La43;

    return-object v0
.end method
