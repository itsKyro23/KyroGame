.class public final Lar3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lwq3;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Loy1;


# direct methods
.method public synthetic constructor <init>(Loy1;I)V
    .locals 0

    iput p2, p0, Lar3;->h:I

    iput-object p1, p0, Lar3;->i:Loy1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a([B[B)V
    .locals 16

    move-object/from16 v0, p0

    iget-object v0, v0, Lar3;->i:Loy1;

    iget v1, v0, Loy1;->B:I

    not-int v1, v1

    iput v1, v0, Loy1;->B:I

    iget v2, v0, Loy1;->M1:I

    iget v3, v0, Loy1;->K1:I

    xor-int/2addr v2, v3

    iget v3, v0, Loy1;->y:I

    or-int/2addr v2, v3

    iget v4, v0, Loy1;->O:I

    xor-int/2addr v2, v4

    iget v4, v0, Loy1;->l2:I

    xor-int/2addr v2, v4

    iget v4, v0, Loy1;->W0:I

    xor-int/2addr v2, v4

    iget v4, v0, Loy1;->P:I

    xor-int/2addr v2, v4

    iput v2, v0, Loy1;->P:I

    iget v4, v0, Loy1;->G:I

    iget v5, v0, Loy1;->I0:I

    not-int v6, v5

    and-int v7, v4, v6

    xor-int v8, v4, v7

    iput v8, v0, Loy1;->W0:I

    iget v9, v0, Loy1;->b:I

    xor-int/2addr v7, v9

    iget v10, v0, Loy1;->s0:I

    or-int/2addr v7, v10

    iget v11, v0, Loy1;->x:I

    xor-int/2addr v7, v11

    iget v12, v0, Loy1;->u1:I

    xor-int/2addr v7, v12

    iput v7, v0, Loy1;->u1:I

    xor-int v12, v9, v4

    iput v12, v0, Loy1;->l2:I

    and-int/2addr v6, v12

    or-int v13, v10, v6

    iget v14, v0, Loy1;->H1:I

    xor-int/2addr v13, v14

    iput v13, v0, Loy1;->O:I

    not-int v14, v6

    and-int/2addr v14, v10

    xor-int/2addr v11, v14

    or-int/2addr v11, v3

    and-int v14, v10, v6

    or-int/2addr v5, v12

    xor-int/2addr v5, v9

    or-int v9, v10, v5

    iget v12, v0, Loy1;->h0:I

    xor-int/2addr v12, v9

    iput v12, v0, Loy1;->b:I

    iget v15, v0, Loy1;->e2:I

    xor-int/2addr v12, v15

    iget v15, v0, Loy1;->y2:I

    or-int/2addr v12, v15

    xor-int/2addr v7, v12

    iget v12, v0, Loy1;->L:I

    xor-int/2addr v7, v12

    iput v7, v0, Loy1;->L:I

    and-int v12, v10, v5

    xor-int/2addr v12, v5

    or-int/2addr v12, v3

    move/from16 p0, v5

    iget v5, v0, Loy1;->h1:I

    xor-int/2addr v5, v12

    iput v5, v0, Loy1;->e2:I

    xor-int v12, p0, v14

    iput v12, v0, Loy1;->K1:I

    xor-int/2addr v11, v12

    iput v11, v0, Loy1;->H1:I

    not-int v12, v3

    xor-int/2addr v8, v9

    iget v9, v0, Loy1;->D:I

    and-int/2addr v8, v12

    xor-int/2addr v8, v9

    or-int/2addr v8, v15

    xor-int/2addr v5, v8

    iget v8, v0, Loy1;->h2:I

    xor-int/2addr v5, v8

    iput v5, v0, Loy1;->h2:I

    iget v8, v0, Loy1;->R0:I

    xor-int/2addr v8, v6

    iget v9, v0, Loy1;->Y0:I

    xor-int/2addr v8, v9

    iput v8, v0, Loy1;->Y0:I

    and-int v9, v8, v12

    xor-int/2addr v8, v9

    or-int/2addr v8, v15

    iget v9, v0, Loy1;->C:I

    xor-int/2addr v8, v9

    iput v8, v0, Loy1;->x:I

    iget v9, v0, Loy1;->p:I

    xor-int/2addr v8, v9

    iput v8, v0, Loy1;->p:I

    iget v9, v0, Loy1;->M:I

    xor-int/2addr v6, v9

    or-int/2addr v6, v10

    xor-int/2addr v6, v4

    and-int/2addr v6, v12

    xor-int/2addr v6, v13

    or-int/2addr v6, v15

    xor-int/2addr v6, v11

    iget v9, v0, Loy1;->t:I

    xor-int/2addr v6, v9

    iput v6, v0, Loy1;->t:I

    iget v9, v0, Loy1;->i:I

    not-int v11, v4

    and-int/2addr v11, v9

    iget v12, v0, Loy1;->q2:I

    xor-int/2addr v11, v12

    iput v11, v0, Loy1;->I0:I

    and-int/2addr v3, v11

    iget v11, v0, Loy1;->f1:I

    xor-int/2addr v3, v11

    iget v11, v0, Loy1;->t0:I

    or-int/2addr v3, v11

    iget v11, v0, Loy1;->E:I

    xor-int/2addr v3, v11

    iget v11, v0, Loy1;->F0:I

    and-int/2addr v3, v11

    iget v12, v0, Loy1;->s1:I

    xor-int/2addr v3, v12

    iput v3, v0, Loy1;->y:I

    iget v12, v0, Loy1;->F:I

    xor-int/2addr v3, v12

    iput v3, v0, Loy1;->F:I

    and-int/lit16 v12, v5, 0xff

    int-to-byte v12, v12

    const/4 v13, 0x0

    aput-byte v12, p2, v13

    ushr-int/lit8 v12, v5, 0x8

    const/16 v13, 0xff

    and-int/2addr v12, v13

    int-to-byte v12, v12

    const/4 v14, 0x1

    aput-byte v12, p2, v14

    ushr-int/lit8 v12, v5, 0x10

    and-int/2addr v12, v13

    int-to-byte v12, v12

    const/4 v14, 0x2

    aput-byte v12, p2, v14

    const/16 v12, 0x18

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/4 v14, 0x3

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->m1:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/4 v15, 0x4

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/4 v15, 0x5

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/4 v15, 0x6

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/4 v14, 0x7

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->d:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0x8

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x9

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0xa

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0xb

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->R:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0xc

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0xd

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0xe

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0xf

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->f:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0x10

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x11

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x12

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0x13

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->j0:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0x14

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x15

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x16

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0x17

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->C1:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    aput-byte v14, p2, v12

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x19

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x1a

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0x1b

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->r1:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0x1c

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x1d

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x1e

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0x1f

    aput-byte v5, p2, v14

    iget v5, v0, Loy1;->j:I

    and-int/lit16 v14, v5, 0xff

    int-to-byte v14, v14

    const/16 v15, 0x20

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x8

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x21

    aput-byte v14, p2, v15

    ushr-int/lit8 v14, v5, 0x10

    and-int/2addr v14, v13

    int-to-byte v14, v14

    const/16 v15, 0x22

    aput-byte v14, p2, v15

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v14, 0x23

    aput-byte v5, p2, v14

    and-int/lit16 v5, v9, 0xff

    int-to-byte v5, v5

    const/16 v14, 0x24

    aput-byte v5, p2, v14

    ushr-int/lit8 v5, v9, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v14, 0x25

    aput-byte v5, p2, v14

    ushr-int/lit8 v5, v9, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v14, 0x26

    aput-byte v5, p2, v14

    shr-int/lit8 v5, v9, 0x18

    int-to-byte v5, v5

    const/16 v9, 0x27

    aput-byte v5, p2, v9

    iget v5, v0, Loy1;->s2:I

    and-int/lit16 v9, v5, 0xff

    int-to-byte v9, v9

    const/16 v14, 0x28

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x8

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x29

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x10

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x2a

    aput-byte v9, p2, v14

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v9, 0x2b

    aput-byte v5, p2, v9

    iget v5, v0, Loy1;->P1:I

    and-int/lit16 v9, v5, 0xff

    int-to-byte v9, v9

    const/16 v14, 0x2c

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x8

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x2d

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x10

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x2e

    aput-byte v9, p2, v14

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v9, 0x2f

    aput-byte v5, p2, v9

    iget v5, v0, Loy1;->I1:I

    and-int/lit16 v9, v5, 0xff

    int-to-byte v9, v9

    const/16 v14, 0x30

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x8

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x31

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x10

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x32

    aput-byte v9, p2, v14

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v9, 0x33

    aput-byte v5, p2, v9

    iget v5, v0, Loy1;->y0:I

    and-int/lit16 v9, v5, 0xff

    int-to-byte v9, v9

    const/16 v14, 0x34

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x8

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x35

    aput-byte v9, p2, v14

    ushr-int/lit8 v9, v5, 0x10

    and-int/2addr v9, v13

    int-to-byte v9, v9

    const/16 v14, 0x36

    aput-byte v9, p2, v14

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v9, 0x37

    aput-byte v5, p2, v9

    and-int/lit16 v5, v8, 0xff

    int-to-byte v5, v5

    const/16 v9, 0x38

    aput-byte v5, p2, v9

    ushr-int/lit8 v5, v8, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v9, 0x39

    aput-byte v5, p2, v9

    ushr-int/lit8 v5, v8, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v9, 0x3a

    aput-byte v5, p2, v9

    shr-int/lit8 v5, v8, 0x18

    int-to-byte v5, v5

    const/16 v8, 0x3b

    aput-byte v5, p2, v8

    iget v5, v0, Loy1;->W:I

    and-int/lit16 v8, v5, 0xff

    int-to-byte v8, v8

    const/16 v9, 0x3c

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x8

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x3d

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x10

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x3e

    aput-byte v8, p2, v9

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v8, 0x3f

    aput-byte v5, p2, v8

    iget v5, v0, Loy1;->r:I

    and-int/lit16 v8, v5, 0xff

    int-to-byte v8, v8

    const/16 v9, 0x40

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x8

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x41

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x10

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x42

    aput-byte v8, p2, v9

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v8, 0x43

    aput-byte v5, p2, v8

    iget v5, v0, Loy1;->q:I

    and-int/lit16 v8, v5, 0xff

    int-to-byte v8, v8

    const/16 v9, 0x44

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x8

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x45

    aput-byte v8, p2, v9

    ushr-int/lit8 v8, v5, 0x10

    and-int/2addr v8, v13

    int-to-byte v8, v8

    const/16 v9, 0x46

    aput-byte v8, p2, v9

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v8, 0x47

    aput-byte v5, p2, v8

    and-int/lit16 v5, v6, 0xff

    int-to-byte v5, v5

    const/16 v8, 0x48

    aput-byte v5, p2, v8

    ushr-int/lit8 v5, v6, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v8, 0x49

    aput-byte v5, p2, v8

    ushr-int/lit8 v5, v6, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v8, 0x4a

    aput-byte v5, p2, v8

    shr-int/lit8 v5, v6, 0x18

    int-to-byte v5, v5

    const/16 v6, 0x4b

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->c1:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x4c

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x4d

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x4e

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x4f

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->v:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x50

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x51

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x52

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x53

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->u:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x54

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x55

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x56

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x57

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->a1:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x58

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x59

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x5a

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x5b

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->o0:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x5c

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x5d

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x5e

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x5f

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->p2:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x60

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x61

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x62

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x63

    aput-byte v5, p2, v6

    iget v5, v0, Loy1;->o1:I

    and-int/lit16 v6, v5, 0xff

    int-to-byte v6, v6

    const/16 v8, 0x64

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x8

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x65

    aput-byte v6, p2, v8

    ushr-int/lit8 v6, v5, 0x10

    and-int/2addr v6, v13

    int-to-byte v6, v6

    const/16 v8, 0x66

    aput-byte v6, p2, v8

    shr-int/2addr v5, v12

    int-to-byte v5, v5

    const/16 v6, 0x67

    aput-byte v5, p2, v6

    and-int/lit16 v5, v1, 0xff

    int-to-byte v5, v5

    const/16 v6, 0x68

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x69

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x6a

    aput-byte v5, p2, v6

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v5, 0x6b

    aput-byte v1, p2, v5

    iget v1, v0, Loy1;->v0:I

    and-int/lit16 v5, v1, 0xff

    int-to-byte v5, v5

    const/16 v6, 0x6c

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x6d

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x6e

    aput-byte v5, p2, v6

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v5, 0x6f

    aput-byte v1, p2, v5

    iget v1, v0, Loy1;->g2:I

    and-int/lit16 v5, v1, 0xff

    int-to-byte v5, v5

    const/16 v6, 0x70

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x71

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x72

    aput-byte v5, p2, v6

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v5, 0x73

    aput-byte v1, p2, v5

    iget v1, v0, Loy1;->Z0:I

    and-int/lit16 v5, v1, 0xff

    int-to-byte v5, v5

    const/16 v6, 0x74

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x8

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x75

    aput-byte v5, p2, v6

    ushr-int/lit8 v5, v1, 0x10

    and-int/2addr v5, v13

    int-to-byte v5, v5

    const/16 v6, 0x76

    aput-byte v5, p2, v6

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v5, 0x77

    aput-byte v1, p2, v5

    and-int/lit16 v1, v3, 0xff

    int-to-byte v1, v1

    const/16 v5, 0x78

    aput-byte v1, p2, v5

    ushr-int/lit8 v1, v3, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v5, 0x79

    aput-byte v1, p2, v5

    ushr-int/lit8 v1, v3, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v5, 0x7a

    aput-byte v1, p2, v5

    shr-int/lit8 v1, v3, 0x18

    int-to-byte v1, v1

    const/16 v3, 0x7b

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->G2:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v5, 0x7c

    aput-byte v3, p2, v5

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v5, 0x7d

    aput-byte v3, p2, v5

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v5, 0x7e

    aput-byte v3, p2, v5

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x7f

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->n1:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v5, 0x80

    aput-byte v3, p2, v5

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v5, 0x81

    aput-byte v3, p2, v5

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v5, 0x82

    aput-byte v3, p2, v5

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x83

    aput-byte v1, p2, v3

    and-int/lit16 v1, v4, 0xff

    int-to-byte v1, v1

    const/16 v3, 0x84

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v4, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0x85

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v4, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0x86

    aput-byte v1, p2, v3

    shr-int/lit8 v1, v4, 0x18

    int-to-byte v1, v1

    const/16 v3, 0x87

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->J:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v4, 0x88

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x89

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x8a

    aput-byte v3, p2, v4

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x8b

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->O0:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v4, 0x8c

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x8d

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x8e

    aput-byte v3, p2, v4

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x8f

    aput-byte v1, p2, v3

    and-int/lit16 v1, v7, 0xff

    int-to-byte v1, v1

    const/16 v3, 0x90

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v7, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0x91

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v7, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0x92

    aput-byte v1, p2, v3

    shr-int/lit8 v1, v7, 0x18

    int-to-byte v1, v1

    const/16 v3, 0x93

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->z2:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v4, 0x94

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x95

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x96

    aput-byte v3, p2, v4

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x97

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->J0:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v4, 0x98

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x99

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x9a

    aput-byte v3, p2, v4

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x9b

    aput-byte v1, p2, v3

    iget v1, v0, Loy1;->Q0:I

    and-int/lit16 v3, v1, 0xff

    int-to-byte v3, v3

    const/16 v4, 0x9c

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x8

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x9d

    aput-byte v3, p2, v4

    ushr-int/lit8 v3, v1, 0x10

    and-int/2addr v3, v13

    int-to-byte v3, v3

    const/16 v4, 0x9e

    aput-byte v3, p2, v4

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v3, 0x9f

    aput-byte v1, p2, v3

    and-int/lit16 v1, v2, 0xff

    int-to-byte v1, v1

    const/16 v3, 0xa0

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v2, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0xa1

    aput-byte v1, p2, v3

    ushr-int/lit8 v1, v2, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v3, 0xa2

    aput-byte v1, p2, v3

    shr-int/lit8 v1, v2, 0x18

    int-to-byte v1, v1

    const/16 v2, 0xa3

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->g:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xa4

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xa5

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xa6

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xa7

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->S1:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xa8

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xa9

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xaa

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xab

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->X0:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xac

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xad

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xae

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xaf

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->T:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xb0

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xb1

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xb2

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xb3

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->w1:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xb4

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xb5

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xb6

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xb7

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->x2:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xb8

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xb9

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xba

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xbb

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->K0:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xbc

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xbd

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xbe

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xbf

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->S0:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xc0

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xc1

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xc2

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xc3

    aput-byte v1, p2, v2

    and-int/lit16 v1, v10, 0xff

    int-to-byte v1, v1

    const/16 v2, 0xc4

    aput-byte v1, p2, v2

    ushr-int/lit8 v1, v10, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v2, 0xc5

    aput-byte v1, p2, v2

    ushr-int/lit8 v1, v10, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v2, 0xc6

    aput-byte v1, p2, v2

    shr-int/lit8 v1, v10, 0x18

    int-to-byte v1, v1

    const/16 v2, 0xc7

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->Z:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xc8

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xc9

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xca

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xcb

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->Y:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xcc

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xcd

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xce

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xcf

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->f2:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xd0

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xd1

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xd2

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xd3

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->a0:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xd4

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xd5

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xd6

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xd7

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->d0:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xd8

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xd9

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xda

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xdb

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->b2:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xdc

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xdd

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xde

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xdf

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->k1:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xe0

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xe1

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xe2

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xe3

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->i1:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xe4

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xe5

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xe6

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xe7

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->r2:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xe8

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xe9

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xea

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xeb

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->A2:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xec

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xed

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xee

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xef

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->d1:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xf0

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xf1

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xf2

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xf3

    aput-byte v1, p2, v2

    iget v1, v0, Loy1;->U:I

    and-int/lit16 v2, v1, 0xff

    int-to-byte v2, v2

    const/16 v3, 0xf4

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x8

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xf5

    aput-byte v2, p2, v3

    ushr-int/lit8 v2, v1, 0x10

    and-int/2addr v2, v13

    int-to-byte v2, v2

    const/16 v3, 0xf6

    aput-byte v2, p2, v3

    shr-int/2addr v1, v12

    int-to-byte v1, v1

    const/16 v2, 0xf7

    aput-byte v1, p2, v2

    iget v0, v0, Loy1;->z0:I

    and-int/lit16 v1, v0, 0xff

    int-to-byte v1, v1

    const/16 v2, 0xf8

    aput-byte v1, p2, v2

    ushr-int/lit8 v1, v0, 0x8

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v2, 0xf9

    aput-byte v1, p2, v2

    ushr-int/lit8 v1, v0, 0x10

    and-int/2addr v1, v13

    int-to-byte v1, v1

    const/16 v2, 0xfa

    aput-byte v1, p2, v2

    shr-int/2addr v0, v12

    int-to-byte v0, v0

    const/16 v1, 0xfb

    aput-byte v0, p2, v1

    and-int/lit16 v0, v11, 0xff

    int-to-byte v0, v0

    const/16 v1, 0xfc

    aput-byte v0, p2, v1

    ushr-int/lit8 v0, v11, 0x8

    and-int/2addr v0, v13

    int-to-byte v0, v0

    const/16 v1, 0xfd

    aput-byte v0, p2, v1

    ushr-int/lit8 v0, v11, 0x10

    and-int/2addr v0, v13

    int-to-byte v0, v0

    const/16 v1, 0xfe

    aput-byte v0, p2, v1

    shr-int/lit8 v0, v11, 0x18

    int-to-byte v0, v0

    aput-byte v0, p2, v13

    return-void
.end method


# virtual methods
.method public final b([B[B)V
    .locals 128

    move-object/from16 v0, p0

    iget v1, v0, Lar3;->h:I

    packed-switch v1, :pswitch_data_0

    iget-object v0, v0, Lar3;->i:Loy1;

    iget v1, v0, Loy1;->C1:I

    iget v2, v0, Loy1;->G0:I

    xor-int/2addr v1, v2

    iget v2, v0, Loy1;->o:I

    not-int v1, v1

    and-int/2addr v1, v2

    iget v3, v0, Loy1;->i0:I

    iget v4, v0, Loy1;->Q1:I

    or-int v5, v3, v4

    iget v6, v0, Loy1;->g:I

    xor-int/2addr v5, v6

    iget v7, v0, Loy1;->E:I

    and-int/2addr v5, v7

    iget v8, v0, Loy1;->Y1:I

    or-int v9, v3, v8

    xor-int/2addr v8, v9

    and-int v9, v7, v8

    not-int v9, v9

    and-int/2addr v9, v2

    not-int v8, v8

    and-int/2addr v8, v7

    iget v10, v0, Loy1;->t1:I

    xor-int/2addr v8, v10

    iget v10, v0, Loy1;->w:I

    xor-int/2addr v1, v8

    and-int/2addr v1, v10

    iget v8, v0, Loy1;->H0:I

    xor-int/2addr v1, v8

    iget v8, v0, Loy1;->d0:I

    xor-int/2addr v1, v8

    iput v1, v0, Loy1;->d0:I

    not-int v8, v3

    iget v11, v0, Loy1;->m1:I

    and-int/2addr v11, v8

    iget v12, v0, Loy1;->n2:I

    xor-int/2addr v11, v12

    not-int v13, v7

    and-int/2addr v11, v13

    not-int v11, v11

    and-int/2addr v11, v2

    iget v13, v0, Loy1;->V:I

    xor-int/2addr v11, v13

    iget v13, v0, Loy1;->p0:I

    xor-int/2addr v11, v13

    iget v13, v0, Loy1;->g2:I

    xor-int/2addr v11, v13

    iput v11, v0, Loy1;->g2:I

    iget v13, v0, Loy1;->f2:I

    not-int v14, v11

    and-int v15, v13, v14

    move/from16 p0, v2

    iget v2, v0, Loy1;->y0:I

    or-int/2addr v2, v11

    move/from16 p1, v2

    iget v2, v0, Loy1;->m2:I

    xor-int v2, v2, p1

    move/from16 p1, v2

    iget v2, v0, Loy1;->r1:I

    xor-int/2addr v2, v11

    move/from16 p2, v2

    iget v2, v0, Loy1;->R0:I

    xor-int v16, p2, v2

    move/from16 p2, v3

    iget v3, v0, Loy1;->L:I

    move/from16 v17, v4

    not-int v4, v3

    and-int/2addr v4, v11

    iput v4, v0, Loy1;->m2:I

    move/from16 v18, v3

    not-int v3, v4

    and-int v19, v13, v3

    and-int/2addr v3, v11

    not-int v3, v3

    and-int/2addr v3, v13

    move/from16 v20, v3

    iget v3, v0, Loy1;->G1:I

    xor-int v3, v20, v3

    move/from16 v21, v3

    iget v3, v0, Loy1;->H1:I

    and-int v21, v3, v21

    move/from16 v22, v4

    iget v4, v0, Loy1;->J2:I

    xor-int v4, v22, v4

    move/from16 v23, v4

    not-int v4, v2

    move/from16 v24, v2

    iget v2, v0, Loy1;->J0:I

    and-int/2addr v2, v11

    move/from16 v25, v2

    iget v2, v0, Loy1;->M0:I

    xor-int v25, v2, v25

    move/from16 v26, v2

    iget v2, v0, Loy1;->f:I

    and-int v25, v2, v25

    and-int v27, v13, v11

    move/from16 v28, v4

    iget v4, v0, Loy1;->p1:I

    not-int v4, v4

    move/from16 v29, v4

    iget v4, v0, Loy1;->I2:I

    and-int v29, v11, v29

    xor-int v29, v4, v29

    and-int v29, v2, v29

    move/from16 v30, v5

    iget v5, v0, Loy1;->L0:I

    or-int/2addr v5, v11

    move/from16 v31, v5

    iget v5, v0, Loy1;->v1:I

    xor-int v5, v5, v31

    and-int v31, v18, v11

    and-int v32, v31, v24

    and-int v33, v13, v31

    move/from16 v34, v5

    iget v5, v0, Loy1;->u1:I

    or-int/2addr v5, v11

    move/from16 v35, v5

    iget v5, v0, Loy1;->N1:I

    xor-int v35, v5, v35

    move/from16 v36, v5

    xor-int v5, v35, v25

    iput v5, v0, Loy1;->J0:I

    xor-int v25, v11, v27

    xor-int v33, v22, v33

    and-int v25, v25, v28

    and-int v23, v23, v28

    or-int v35, v11, v26

    move/from16 v37, v5

    iget v5, v0, Loy1;->K:I

    xor-int v5, v5, v35

    not-int v5, v5

    and-int/2addr v5, v2

    xor-int v5, p1, v5

    move/from16 v35, v6

    iget v6, v0, Loy1;->r2:I

    move/from16 p1, v7

    not-int v7, v6

    and-int v38, v5, v7

    move/from16 v39, v6

    xor-int v6, v37, v38

    iput v6, v0, Loy1;->y0:I

    move/from16 v38, v6

    iget v6, v0, Loy1;->O0:I

    xor-int v6, v38, v6

    iput v6, v0, Loy1;->O0:I

    not-int v5, v5

    and-int v5, v39, v5

    move/from16 v38, v5

    iget v5, v0, Loy1;->s0:I

    xor-int v37, v37, v38

    xor-int v5, v37, v5

    iput v5, v0, Loy1;->s0:I

    move/from16 v37, v7

    iget v7, v0, Loy1;->g1:I

    and-int/2addr v7, v11

    xor-int v7, v26, v7

    xor-int v7, v7, v29

    not-int v4, v4

    and-int/2addr v4, v11

    xor-int v4, v36, v4

    not-int v4, v4

    and-int/2addr v4, v2

    xor-int v4, v34, v4

    move/from16 v26, v7

    iget v7, v0, Loy1;->k0:I

    and-int v29, v4, v37

    xor-int v29, v26, v29

    xor-int v7, v29, v7

    iput v7, v0, Loy1;->k0:I

    not-int v4, v4

    and-int v4, v39, v4

    move/from16 v29, v4

    iget v4, v0, Loy1;->a0:I

    xor-int v26, v26, v29

    xor-int v4, v26, v4

    iput v4, v0, Loy1;->a0:I

    xor-int v26, v11, v13

    and-int v26, v26, v24

    and-int v14, v18, v14

    xor-int v20, v14, v20

    move/from16 v29, v4

    not-int v4, v14

    and-int/2addr v4, v13

    or-int v4, v24, v4

    move/from16 v34, v4

    iget v4, v0, Loy1;->x0:I

    xor-int/2addr v4, v14

    xor-int v36, v14, v13

    xor-int v32, v36, v32

    and-int v36, v36, v28

    xor-int v33, v33, v36

    and-int v36, v3, v33

    and-int v38, v13, v14

    xor-int v38, v11, v38

    or-int v40, v11, v14

    xor-int v23, v40, v23

    and-int v23, v3, v23

    xor-int v16, v16, v23

    and-int v23, v13, v40

    and-int v41, v23, v28

    xor-int v23, v11, v23

    or-int v23, v24, v23

    xor-int v26, v40, v26

    xor-int v21, v26, v21

    and-int v14, v14, v28

    not-int v14, v14

    and-int/2addr v14, v3

    xor-int v26, v31, v15

    and-int v26, v26, v28

    move/from16 v31, v4

    xor-int v4, v20, v26

    not-int v4, v4

    and-int/2addr v4, v3

    xor-int v20, v18, v27

    xor-int v20, v20, v25

    and-int v20, v3, v20

    move/from16 v25, v4

    xor-int v4, v18, v20

    xor-int v11, v18, v11

    and-int v18, v13, v11

    move/from16 v20, v8

    xor-int v8, v18, v41

    not-int v8, v8

    and-int/2addr v8, v3

    xor-int/2addr v13, v11

    xor-int/2addr v11, v15

    and-int v11, v11, v28

    xor-int v15, v31, v11

    and-int/2addr v15, v3

    and-int v18, v35, v20

    move/from16 v26, v8

    iget v8, v0, Loy1;->s2:I

    xor-int v8, v18, v8

    move/from16 v18, v8

    iget v8, v0, Loy1;->U0:I

    and-int v8, v8, v20

    move/from16 v27, v8

    iget v8, v0, Loy1;->q0:I

    xor-int v8, v8, v27

    move/from16 v27, v8

    iget v8, v0, Loy1;->A:I

    xor-int v8, v27, v8

    move/from16 v27, v8

    iget v8, v0, Loy1;->x:I

    xor-int v8, v27, v8

    and-int v27, v8, v3

    move/from16 v31, v8

    iget v8, v0, Loy1;->e1:I

    xor-int v40, v8, v27

    move/from16 v41, v9

    iget v9, v0, Loy1;->P1:I

    xor-int v9, v9, v31

    move/from16 v42, v9

    iget v9, v0, Loy1;->D0:I

    and-int v9, v31, v9

    move/from16 v43, v9

    not-int v9, v3

    and-int v9, v31, v9

    xor-int v44, v8, v9

    move/from16 v45, v3

    iget v3, v0, Loy1;->p:I

    and-int v46, v31, v3

    not-int v8, v8

    move/from16 v47, v8

    iget v8, v0, Loy1;->F2:I

    and-int v47, v31, v47

    xor-int v48, v8, v47

    move/from16 v49, v8

    not-int v8, v3

    move/from16 v50, v3

    iget v3, v0, Loy1;->O1:I

    and-int v8, v31, v8

    xor-int/2addr v8, v3

    and-int v47, v47, v28

    move/from16 v51, v3

    iget v3, v0, Loy1;->M1:I

    xor-int v52, v3, v31

    move/from16 v53, v3

    xor-int v3, v53, v9

    xor-int v54, v51, v9

    move/from16 v55, v8

    xor-int v8, v49, v46

    xor-int v50, v50, v27

    xor-int v49, v49, v27

    and-int v56, p1, p2

    xor-int v17, v17, v56

    xor-int v17, v17, v41

    or-int v12, p2, v12

    xor-int v12, v12, v30

    and-int v12, p0, v12

    move/from16 v30, v9

    iget v9, v0, Loy1;->t2:I

    xor-int v9, v9, p2

    not-int v9, v9

    and-int v9, p1, v9

    move/from16 p1, v9

    iget v9, v0, Loy1;->A0:I

    xor-int v9, v9, p1

    move/from16 p1, v9

    iget v9, v0, Loy1;->K0:I

    xor-int v12, p1, v12

    xor-int/2addr v9, v12

    iget v12, v0, Loy1;->Z:I

    xor-int/2addr v9, v12

    iput v9, v0, Loy1;->Z:I

    iget v12, v0, Loy1;->T0:I

    move/from16 p1, v9

    not-int v9, v12

    and-int v9, p1, v9

    xor-int v41, v2, v9

    xor-int v41, v41, v39

    move/from16 v56, v9

    iget v9, v0, Loy1;->V0:I

    move/from16 v57, v10

    xor-int v10, v9, v56

    not-int v10, v10

    and-int v10, v39, v10

    move/from16 v56, v10

    iget v10, v0, Loy1;->J:I

    move/from16 v58, v11

    not-int v11, v10

    and-int v59, p1, v9

    xor-int v60, v9, v59

    and-int v61, v39, v60

    move/from16 v62, v10

    xor-int v10, v9, p1

    iput v10, v0, Loy1;->A0:I

    move/from16 v63, v10

    iget v10, v0, Loy1;->B:I

    and-int v64, p1, v10

    xor-int v64, v2, v64

    and-int v37, v64, v37

    xor-int v37, v60, v37

    or-int v37, v62, v37

    and-int v60, p1, v2

    and-int v64, v39, v60

    move/from16 v65, v11

    iget v11, v0, Loy1;->k1:I

    and-int v66, p1, v11

    move/from16 v67, v12

    iget v12, v0, Loy1;->b0:I

    xor-int v66, v12, v66

    move/from16 v68, v13

    iget v13, v0, Loy1;->q1:I

    xor-int v13, v66, v13

    or-int v13, v62, v13

    xor-int v66, v12, v59

    move/from16 v69, v13

    iget v13, v0, Loy1;->b:I

    xor-int v13, v66, v13

    or-int v13, v62, v13

    xor-int v59, v10, v59

    move/from16 v70, v13

    iget v13, v0, Loy1;->P:I

    xor-int v13, v59, v13

    or-int v13, v62, v13

    not-int v9, v9

    move/from16 v59, v9

    iget v9, v0, Loy1;->c2:I

    and-int v59, p1, v59

    move/from16 v71, v9

    xor-int v9, v71, v59

    not-int v9, v9

    and-int v9, v39, v9

    move/from16 v72, v9

    not-int v9, v2

    and-int v9, p1, v9

    move/from16 v73, v2

    not-int v2, v9

    and-int v2, v39, v2

    not-int v11, v11

    and-int v11, p1, v11

    xor-int/2addr v11, v12

    or-int v11, v62, v11

    xor-int v74, v73, v9

    not-int v12, v12

    and-int v12, p1, v12

    xor-int v12, v67, v12

    move/from16 v67, v2

    not-int v2, v12

    and-int v2, v39, v2

    move/from16 v75, v2

    iget v2, v0, Loy1;->j0:I

    move/from16 v76, v2

    xor-int v2, v76, v59

    iput v2, v0, Loy1;->V0:I

    xor-int v2, v2, v75

    xor-int v2, v2, v37

    xor-int v37, v10, v60

    xor-int v37, v37, v39

    xor-int/2addr v9, v10

    and-int v9, v39, v9

    xor-int v9, v71, v9

    iput v9, v0, Loy1;->b0:I

    xor-int v9, v9, v69

    move/from16 v59, v2

    iget v2, v0, Loy1;->Y0:I

    and-int v2, p1, v2

    xor-int v2, v73, v2

    iput v2, v0, Loy1;->Y0:I

    xor-int v2, v2, v72

    iput v2, v0, Loy1;->t2:I

    and-int v60, p1, v76

    move/from16 v69, v2

    xor-int v2, v71, v60

    not-int v2, v2

    and-int v2, v39, v2

    xor-int v2, v63, v2

    or-int v2, v62, v2

    move/from16 v39, v2

    iget v2, v0, Loy1;->o2:I

    and-int v2, v2, v20

    move/from16 v20, v2

    iget v2, v0, Loy1;->z2:I

    xor-int v2, v2, v20

    not-int v2, v2

    and-int v2, v35, v2

    move/from16 v20, v2

    iget v2, v0, Loy1;->h:I

    xor-int v2, v2, v20

    move/from16 v20, v2

    iget v2, v0, Loy1;->d:I

    xor-int v2, v20, v2

    move/from16 v20, v9

    iget v9, v0, Loy1;->E0:I

    and-int/2addr v9, v2

    move/from16 v60, v9

    iget v9, v0, Loy1;->V1:I

    xor-int v9, v9, v60

    move/from16 v60, v9

    iget v9, v0, Loy1;->W:I

    not-int v9, v9

    move/from16 v62, v9

    iget v9, v0, Loy1;->l1:I

    and-int v62, v2, v62

    xor-int v9, v9, v62

    move/from16 v62, v9

    iget v9, v0, Loy1;->X:I

    move/from16 v63, v11

    or-int v11, v9, v2

    move/from16 v71, v12

    iget v12, v0, Loy1;->f0:I

    move/from16 v72, v12

    not-int v12, v11

    and-int v12, v72, v12

    move/from16 v73, v11

    iget v11, v0, Loy1;->C:I

    not-int v11, v11

    move/from16 v75, v11

    iget v11, v0, Loy1;->u2:I

    and-int v75, v2, v75

    xor-int v11, v11, v75

    or-int/2addr v11, v10

    move/from16 v75, v11

    iget v11, v0, Loy1;->M:I

    xor-int v62, v62, v75

    xor-int v11, v62, v11

    iput v11, v0, Loy1;->M:I

    or-int/2addr v11, v7

    iput v11, v0, Loy1;->C:I

    iget v11, v0, Loy1;->k2:I

    and-int/2addr v11, v2

    move/from16 v62, v11

    iget v11, v0, Loy1;->l2:I

    xor-int v11, v11, v62

    or-int/2addr v11, v10

    move/from16 v62, v11

    not-int v11, v2

    and-int v75, v72, v11

    move/from16 v76, v2

    iget v2, v0, Loy1;->x1:I

    and-int v2, v76, v2

    move/from16 v77, v2

    iget v2, v0, Loy1;->n1:I

    xor-int v2, v2, v77

    or-int/2addr v2, v10

    move/from16 v77, v2

    iget v2, v0, Loy1;->Z0:I

    xor-int v60, v60, v77

    xor-int v2, v60, v2

    iput v2, v0, Loy1;->Z0:I

    move/from16 v60, v11

    iget v11, v0, Loy1;->A2:I

    not-int v11, v11

    move/from16 v77, v11

    iget v11, v0, Loy1;->F0:I

    and-int v77, v76, v77

    xor-int v11, v11, v77

    move/from16 v77, v11

    iget v11, v0, Loy1;->S:I

    xor-int v62, v77, v62

    xor-int v11, v62, v11

    iput v11, v0, Loy1;->S:I

    move/from16 v62, v12

    iget v12, v0, Loy1;->f1:I

    not-int v12, v12

    move/from16 v77, v12

    iget v12, v0, Loy1;->A1:I

    and-int v77, v76, v77

    xor-int v12, v12, v77

    move/from16 v77, v12

    iget v12, v0, Loy1;->g0:I

    and-int v12, v76, v12

    move/from16 v78, v12

    iget v12, v0, Loy1;->S0:I

    xor-int v12, v12, v78

    move/from16 v78, v12

    not-int v12, v10

    move/from16 v79, v10

    iget v10, v0, Loy1;->y:I

    and-int v12, v78, v12

    xor-int v12, v77, v12

    xor-int/2addr v10, v12

    iput v10, v0, Loy1;->y:I

    or-int v12, p2, v35

    not-int v12, v12

    and-int v12, p0, v12

    xor-int v12, v18, v12

    and-int v12, v12, v57

    xor-int v12, v17, v12

    move/from16 p0, v12

    iget v12, v0, Loy1;->H:I

    xor-int v17, v71, v64

    and-int v18, v74, v65

    xor-int v12, p0, v12

    iput v12, v0, Loy1;->H:I

    move/from16 p0, v13

    iget v13, v0, Loy1;->G2:I

    move/from16 v64, v14

    not-int v14, v13

    and-int/2addr v14, v12

    xor-int/2addr v14, v13

    iput v14, v0, Loy1;->g0:I

    iget v14, v0, Loy1;->o0:I

    move/from16 v71, v13

    not-int v13, v12

    and-int/2addr v14, v13

    move/from16 v74, v12

    iget v12, v0, Loy1;->C2:I

    xor-int/2addr v14, v12

    move/from16 v77, v13

    iget v13, v0, Loy1;->R:I

    and-int v13, v74, v13

    move/from16 v78, v13

    iget v13, v0, Loy1;->R1:I

    move/from16 v80, v13

    xor-int v13, v80, v78

    iput v13, v0, Loy1;->R:I

    iget v13, v0, Loy1;->c:I

    or-int v13, v13, v74

    move/from16 v78, v13

    iget v13, v0, Loy1;->O:I

    xor-int v78, v13, v78

    move/from16 v81, v13

    iget v13, v0, Loy1;->q2:I

    not-int v13, v13

    and-int v13, v74, v13

    xor-int v13, v81, v13

    move/from16 v81, v13

    iget v13, v0, Loy1;->z1:I

    or-int v13, v74, v13

    xor-int v13, v80, v13

    iput v13, v0, Loy1;->z1:I

    move/from16 v80, v13

    not-int v13, v12

    move/from16 v82, v12

    iget v12, v0, Loy1;->X0:I

    and-int v13, v74, v13

    xor-int/2addr v13, v12

    or-int v83, v71, v74

    xor-int v82, v82, v83

    move/from16 v83, v12

    iget v12, v0, Loy1;->h1:I

    and-int v12, v12, v77

    move/from16 v84, v12

    iget v12, v0, Loy1;->Q:I

    xor-int v12, v12, v84

    move/from16 v84, v12

    and-int v12, v83, v77

    iput v12, v0, Loy1;->X0:I

    and-int v12, v71, v77

    move/from16 v71, v12

    iget v12, v0, Loy1;->I:I

    xor-int v12, v12, v71

    iput v12, v0, Loy1;->G2:I

    iget v12, v0, Loy1;->U1:I

    or-int v12, v12, v74

    move/from16 v71, v12

    iget v12, v0, Loy1;->W1:I

    and-int v77, v12, v77

    move/from16 v83, v12

    iget v12, v0, Loy1;->N0:I

    xor-int v12, v12, v77

    or-int v77, v74, v83

    move/from16 v83, v12

    iget v12, v0, Loy1;->W0:I

    xor-int v12, v12, v77

    move/from16 v77, v12

    iget v12, v0, Loy1;->T1:I

    move/from16 v85, v12

    iget v12, v0, Loy1;->d1:I

    xor-int v12, v85, v12

    move/from16 v85, v12

    iget v12, v0, Loy1;->d2:I

    xor-int v12, v85, v12

    move/from16 v85, v12

    iget v12, v0, Loy1;->a2:I

    xor-int v12, v85, v12

    move/from16 v85, v12

    iget v12, v0, Loy1;->Z1:I

    xor-int v12, v85, v12

    move/from16 v85, v12

    iget v12, v0, Loy1;->k:I

    xor-int v12, v85, v12

    move/from16 v85, v13

    iget v13, v0, Loy1;->t0:I

    move/from16 v86, v13

    not-int v13, v12

    and-int v87, v86, v13

    move/from16 v88, v12

    iget v12, v0, Loy1;->h0:I

    xor-int v12, v12, v87

    move/from16 v87, v12

    iget v12, v0, Loy1;->m0:I

    or-int v12, v88, v12

    move/from16 v89, v12

    iget v12, v0, Loy1;->e2:I

    xor-int v12, v12, v89

    move/from16 v89, v13

    iget v13, v0, Loy1;->e0:I

    xor-int v56, p1, v56

    xor-int v61, v66, v61

    and-int v56, v56, v65

    xor-int v17, v17, v39

    xor-int v39, v69, v63

    xor-int v18, v37, v18

    xor-int v37, v61, v70

    xor-int v41, v41, v56

    not-int v12, v12

    and-int/2addr v12, v13

    move/from16 v56, v12

    iget v12, v0, Loy1;->S1:I

    xor-int v56, v87, v56

    xor-int v12, v56, v12

    move/from16 v56, v13

    not-int v13, v12

    and-int v20, v20, v13

    xor-int v20, v59, v20

    move/from16 v59, v12

    xor-int v12, v20, v35

    iput v12, v0, Loy1;->g:I

    or-int v20, v12, v11

    move/from16 v35, v13

    xor-int v13, v11, v20

    move/from16 v61, v14

    not-int v14, v12

    and-int v63, v11, v14

    or-int v37, v59, v37

    xor-int v37, v41, v37

    move/from16 v41, v12

    xor-int v12, v37, v56

    iput v12, v0, Loy1;->b:I

    move/from16 v37, v14

    not-int v14, v5

    and-int/2addr v14, v12

    iput v14, v0, Loy1;->C1:I

    xor-int v14, p1, v67

    xor-int v14, v14, p0

    move/from16 p0, v5

    not-int v5, v12

    and-int v65, v6, v5

    move/from16 v66, v5

    or-int v5, v6, v12

    move/from16 p1, v12

    and-int v12, p1, v6

    move/from16 v67, v14

    not-int v14, v12

    move/from16 v69, v12

    not-int v12, v6

    xor-int v70, v6, p1

    or-int v67, v67, v59

    move/from16 v87, v6

    iget v6, v0, Loy1;->U:I

    xor-int v17, v17, v67

    xor-int v6, v17, v6

    iput v6, v0, Loy1;->U:I

    iget v6, v0, Loy1;->u:I

    and-int v17, v39, v35

    xor-int v17, v18, v17

    xor-int v6, v17, v6

    iput v6, v0, Loy1;->u:I

    move/from16 v17, v6

    iget v6, v0, Loy1;->E1:I

    or-int v6, v88, v6

    move/from16 v18, v6

    iget v6, v0, Loy1;->E2:I

    xor-int v6, v6, v18

    and-int v6, v56, v6

    move/from16 v18, v6

    iget v6, v0, Loy1;->B0:I

    not-int v6, v6

    and-int v6, v88, v6

    xor-int v6, v86, v6

    move/from16 v35, v6

    iget v6, v0, Loy1;->C0:I

    and-int v6, v6, v89

    move/from16 v39, v6

    iget v6, v0, Loy1;->a1:I

    xor-int v6, v6, v39

    not-int v6, v6

    and-int v6, v56, v6

    move/from16 v39, v6

    iget v6, v0, Loy1;->N:I

    xor-int v35, v35, v39

    xor-int v6, v35, v6

    move/from16 v35, v12

    iget v12, v0, Loy1;->z0:I

    move/from16 v39, v12

    not-int v12, v6

    and-int v67, v39, v12

    move/from16 v86, v6

    iget v6, v0, Loy1;->h2:I

    or-int v67, v6, v67

    move/from16 v90, v12

    iget v12, v0, Loy1;->F:I

    and-int v91, v12, v90

    move/from16 v92, v12

    iget v12, v0, Loy1;->i1:I

    or-int v93, v86, v12

    move/from16 v94, v12

    iget v12, v0, Loy1;->X1:I

    xor-int v95, v12, v93

    and-int v95, v6, v95

    or-int v96, v86, v12

    move/from16 v97, v12

    iget v12, v0, Loy1;->o1:I

    move/from16 v98, v12

    xor-int v12, v98, v96

    move/from16 v99, v14

    not-int v14, v12

    and-int/2addr v14, v6

    and-int v100, v94, v90

    xor-int v101, v98, v100

    move/from16 v102, v12

    not-int v12, v6

    move/from16 v103, v6

    iget v6, v0, Loy1;->x2:I

    or-int v104, v86, v6

    xor-int v105, v94, v104

    xor-int v48, v48, v86

    xor-int v47, v48, v47

    or-int v48, v86, v52

    xor-int v48, v31, v48

    or-int v48, v24, v48

    move/from16 v106, v6

    iget v6, v0, Loy1;->D:I

    xor-int v107, v6, v91

    or-int v107, v107, v103

    xor-int v108, v106, v107

    move/from16 v109, v6

    not-int v6, v1

    move/from16 v110, v1

    iget v1, v0, Loy1;->j1:I

    and-int v101, v101, v12

    and-int v108, v108, v6

    move/from16 v111, v1

    xor-int v1, v101, v108

    not-int v1, v1

    and-int v1, v111, v1

    xor-int v91, v91, v107

    or-int v91, v110, v91

    or-int v53, v86, v53

    xor-int v53, v54, v53

    and-int v101, v54, v86

    xor-int v27, v27, v101

    and-int v27, v27, v28

    move/from16 v28, v1

    iget v1, v0, Loy1;->H2:I

    xor-int v101, v1, v86

    or-int v107, v103, v101

    xor-int v100, v1, v100

    and-int v40, v40, v86

    xor-int v40, v30, v40

    or-int v40, v24, v40

    or-int v108, v86, v1

    xor-int v112, v98, v108

    xor-int v93, v94, v93

    and-int v113, v45, v86

    xor-int v51, v51, v113

    xor-int v48, v51, v48

    and-int v48, v92, v48

    move/from16 v51, v1

    not-int v1, v3

    and-int v1, v86, v1

    xor-int v1, v54, v1

    or-int v1, v24, v1

    xor-int v1, v31, v1

    not-int v1, v1

    and-int v1, v92, v1

    move/from16 v54, v1

    iget v1, v0, Loy1;->G:I

    xor-int v47, v47, v54

    and-int v54, v93, v12

    and-int v93, v105, v12

    xor-int v1, v47, v1

    iput v1, v0, Loy1;->G:I

    move/from16 v47, v3

    xor-int v3, v1, p1

    iput v3, v0, Loy1;->W0:I

    not-int v3, v1

    move/from16 v105, v1

    and-int v1, p1, v3

    iput v1, v0, Loy1;->e1:I

    or-int v1, v105, p1

    iput v1, v0, Loy1;->L0:I

    and-int v1, v1, v66

    or-int v1, p0, v1

    iput v1, v0, Loy1;->O1:I

    and-int v1, v105, p1

    iput v1, v0, Loy1;->N0:I

    not-int v1, v1

    and-int v1, p1, v1

    iput v1, v0, Loy1;->Q:I

    and-int v1, v43, v86

    xor-int v1, v42, v1

    and-int v42, v44, v90

    or-int v42, v24, v42

    or-int v43, v86, v92

    xor-int v44, v51, v43

    or-int v44, v103, v44

    xor-int v113, v92, v44

    or-int v113, v110, v113

    and-int v98, v98, v90

    move/from16 p0, v1

    xor-int v1, v109, v98

    not-int v1, v1

    and-int v1, v103, v1

    xor-int v1, v101, v1

    and-int/2addr v1, v6

    xor-int v98, v39, v104

    xor-int v54, v98, v54

    xor-int v54, v54, v91

    and-int v54, v111, v54

    xor-int v91, v98, v95

    or-int v30, v86, v30

    xor-int v30, v52, v30

    move/from16 v52, v1

    iget v1, v0, Loy1;->s:I

    xor-int v30, v30, v42

    xor-int v30, v30, v48

    xor-int v1, v30, v1

    iput v1, v0, Loy1;->s:I

    move/from16 v30, v3

    and-int v3, v11, v1

    move/from16 v42, v6

    not-int v6, v3

    and-int v48, v1, v6

    or-int v95, v41, v48

    xor-int v20, v48, v20

    and-int v3, v3, v37

    move/from16 v48, v6

    not-int v6, v1

    and-int v98, v11, v6

    and-int v98, v98, v37

    and-int v101, v1, v37

    xor-int v109, v11, v1

    or-int v114, v41, v109

    and-int v115, v109, v37

    xor-int v115, v11, v115

    or-int v116, v41, v1

    and-int v117, v17, v1

    or-int v118, v1, v11

    move/from16 v119, v1

    xor-int v1, v118, v95

    iput v1, v0, Loy1;->U0:I

    and-int v1, v118, v6

    iput v1, v0, Loy1;->F0:I

    xor-int v120, v119, v41

    not-int v11, v11

    and-int v11, v119, v11

    and-int v121, v11, v37

    xor-int v14, v108, v14

    xor-int v14, v14, v113

    not-int v14, v14

    and-int v14, v111, v14

    move/from16 v113, v1

    iget v1, v0, Loy1;->K1:I

    xor-int v93, v100, v93

    move/from16 v100, v1

    and-int v1, p1, v35

    and-int v99, p1, v99

    and-int v66, v5, v66

    xor-int v52, v93, v52

    xor-int v14, v52, v14

    xor-int v14, v14, v100

    iput v14, v0, Loy1;->K1:I

    or-int v52, v108, v103

    xor-int v52, v86, v52

    or-int v52, v110, v52

    move/from16 v93, v6

    iget v6, v0, Loy1;->i:I

    xor-int v52, v91, v52

    xor-int v52, v52, v54

    xor-int v6, v52, v6

    iput v6, v0, Loy1;->i:I

    move/from16 v52, v11

    or-int v11, v6, v10

    xor-int v54, v6, v10

    move/from16 v91, v12

    not-int v12, v6

    move/from16 v100, v6

    and-int v6, v10, v12

    move/from16 v108, v12

    not-int v12, v6

    and-int/2addr v12, v10

    and-int v122, v10, v100

    move/from16 v123, v6

    not-int v6, v10

    and-int v124, v100, v6

    or-int v125, v124, v10

    xor-int v39, v39, v86

    xor-int v44, v39, v44

    and-int v44, v44, v42

    xor-int v43, v92, v43

    or-int v43, v43, v103

    xor-int v43, v112, v43

    move/from16 v112, v6

    iget v6, v0, Loy1;->y1:I

    xor-int v126, v109, v95

    xor-int v114, v109, v114

    xor-int v116, v119, v116

    move/from16 v127, v6

    xor-int v6, v118, v98

    xor-int v40, v53, v40

    xor-int v53, v102, v107

    xor-int v19, v22, v19

    and-int v22, v127, v90

    xor-int v22, v51, v22

    and-int v22, v22, v91

    xor-int v22, v39, v22

    and-int v22, v22, v42

    or-int v39, v86, v49

    not-int v8, v8

    and-int v8, v86, v8

    xor-int v8, v45, v8

    or-int v8, v24, v8

    xor-int v8, p0, v8

    xor-int v42, v94, v96

    xor-int v42, v42, v67

    move/from16 p0, v8

    xor-int v8, v42, v44

    not-int v8, v8

    and-int v8, v111, v8

    xor-int v22, v43, v22

    xor-int v8, v22, v8

    xor-int v8, v8, v88

    iput v8, v0, Loy1;->P1:I

    xor-int v22, v70, v8

    move/from16 v42, v10

    not-int v10, v8

    and-int v43, v69, v10

    xor-int v44, v69, v43

    and-int v49, v65, v10

    move/from16 v51, v8

    xor-int v8, v69, v49

    or-int v67, v51, v5

    xor-int v67, v5, v67

    and-int v90, p1, v10

    or-int v91, v51, v69

    xor-int v91, v69, v91

    xor-int v94, p1, v49

    or-int v96, v51, v99

    xor-int v69, v69, v96

    and-int v96, v87, v10

    and-int v98, v70, v10

    xor-int v70, v70, v98

    xor-int v49, v65, v49

    xor-int v65, v65, v90

    or-int v98, v51, v66

    xor-int v98, v87, v98

    xor-int v97, v97, v104

    and-int v97, v103, v97

    xor-int v97, v86, v97

    or-int v97, v110, v97

    xor-int v53, v53, v97

    xor-int v28, v53, v28

    move/from16 v53, v10

    xor-int v10, v28, p2

    iput v10, v0, Loy1;->i0:I

    move/from16 p1, v12

    not-int v12, v10

    move/from16 p2, v10

    and-int v10, v114, v12

    iput v10, v0, Loy1;->j0:I

    not-int v10, v6

    and-int v10, p2, v10

    xor-int v10, v63, v10

    iput v10, v0, Loy1;->Z1:I

    and-int v10, p2, v93

    or-int v6, v6, p2

    xor-int v6, v115, v6

    and-int v28, v116, v12

    move/from16 v63, v10

    xor-int v10, v3, v28

    iput v10, v0, Loy1;->Y1:I

    and-int v10, v126, v12

    xor-int v10, v114, v10

    iput v10, v0, Loy1;->G0:I

    not-int v10, v13

    or-int v13, v95, p2

    xor-int v13, v41, v13

    and-int v28, p2, v101

    move/from16 v41, v10

    xor-int v10, v115, v28

    and-int v28, p2, v48

    move/from16 v48, v12

    xor-int v12, v120, v28

    iput v12, v0, Loy1;->H0:I

    xor-int v12, v38, v58

    xor-int v28, v68, v34

    xor-int v19, v19, v23

    xor-int v23, v52, v101

    xor-int v34, v109, v101

    xor-int v15, v32, v15

    xor-int v12, v12, v25

    xor-int v25, v28, v64

    xor-int v19, v19, v26

    move/from16 v26, v12

    xor-int v12, v33, v36

    not-int v3, v3

    move/from16 v28, v3

    and-int v3, p2, v37

    and-int v23, p2, v23

    move/from16 v32, v13

    xor-int v13, v20, v23

    iput v13, v0, Loy1;->k2:I

    and-int v13, v55, v86

    xor-int v13, v46, v13

    xor-int v13, v13, v27

    not-int v13, v13

    and-int v13, v92, v13

    move/from16 v20, v13

    iget v13, v0, Loy1;->c0:I

    xor-int v20, p0, v20

    xor-int v13, v20, v13

    iput v13, v0, Loy1;->c0:I

    move/from16 p0, v13

    not-int v13, v7

    and-int v13, p0, v13

    iput v13, v0, Loy1;->B0:I

    or-int v13, v86, v50

    xor-int v13, v47, v13

    or-int v13, v24, v13

    xor-int v13, v39, v13

    not-int v13, v13

    and-int v13, v92, v13

    move/from16 p0, v7

    iget v7, v0, Loy1;->Y:I

    xor-int v13, v40, v13

    xor-int/2addr v7, v13

    iput v7, v0, Loy1;->Y:I

    and-int v13, v7, v35

    move/from16 v20, v13

    iget v13, v0, Loy1;->F1:I

    or-int v13, v88, v13

    move/from16 v23, v13

    iget v13, v0, Loy1;->b2:I

    xor-int v13, v13, v23

    xor-int v13, v13, v18

    move/from16 v18, v13

    iget v13, v0, Loy1;->T:I

    xor-int v13, v18, v13

    and-int v18, v13, v21

    move/from16 v21, v13

    iget v13, v0, Loy1;->e:I

    xor-int v18, v19, v18

    xor-int v13, v18, v13

    iput v13, v0, Loy1;->e:I

    move/from16 v18, v14

    not-int v14, v13

    move/from16 v19, v13

    and-int v13, v7, v14

    iput v13, v0, Loy1;->E1:I

    move/from16 v23, v13

    not-int v13, v7

    move/from16 v24, v7

    and-int v7, v19, v24

    iput v7, v0, Loy1;->A:I

    move/from16 v27, v13

    not-int v13, v7

    and-int v13, v19, v13

    not-int v13, v13

    and-int v33, v87, v13

    not-int v4, v4

    and-int v4, v21, v4

    xor-int v4, v16, v4

    xor-int v4, v4, v57

    iput v4, v0, Loy1;->w:I

    and-int v4, v4, v48

    iput v4, v0, Loy1;->V:I

    iget v4, v0, Loy1;->q:I

    and-int v16, v21, v26

    xor-int v15, v15, v16

    xor-int/2addr v4, v15

    iput v4, v0, Loy1;->q:I

    and-int v15, v4, v112

    xor-int v16, v123, v15

    move/from16 v26, v4

    xor-int v4, v125, v26

    and-int v36, v26, v122

    xor-int v37, v124, v36

    and-int v38, v26, v108

    xor-int v38, v54, v38

    xor-int v39, v100, v26

    xor-int v15, p1, v15

    move/from16 v40, v7

    not-int v7, v11

    and-int v46, v26, v42

    move/from16 v47, v7

    xor-int v7, v100, v46

    and-int v48, v26, v123

    xor-int v50, v54, v48

    xor-int v11, v11, v46

    move/from16 v46, v11

    xor-int v11, v100, v36

    iput v11, v0, Loy1;->o1:I

    xor-int v36, v42, v48

    not-int v12, v12

    move/from16 v42, v11

    iget v11, v0, Loy1;->y2:I

    and-int v12, v21, v12

    xor-int v12, v25, v12

    xor-int/2addr v11, v12

    iput v11, v0, Loy1;->y2:I

    not-int v12, v11

    and-int v25, v70, v12

    xor-int v25, v51, v25

    or-int v48, v69, v11

    move/from16 v51, v11

    xor-int v11, v87, v48

    iput v11, v0, Loy1;->o2:I

    and-int v48, v51, v1

    xor-int v48, v67, v48

    move/from16 v55, v11

    not-int v11, v5

    and-int v11, v51, v11

    xor-int v11, v49, v11

    move/from16 v57, v5

    and-int v5, v51, v67

    iput v5, v0, Loy1;->V1:I

    and-int v53, v1, v53

    xor-int v58, v1, v96

    xor-int v53, v99, v53

    move/from16 v64, v5

    xor-int v5, v99, v90

    xor-int v43, v66, v43

    move/from16 v66, v11

    not-int v11, v1

    and-int v57, v51, v57

    xor-int v57, v1, v57

    and-int v67, v98, v12

    move/from16 v68, v1

    xor-int v1, v94, v67

    iput v1, v0, Loy1;->s2:I

    not-int v5, v5

    not-int v8, v8

    and-int v8, v51, v8

    xor-int v8, v98, v8

    iput v8, v0, Loy1;->i1:I

    or-int v67, v91, v51

    move/from16 v69, v1

    xor-int v1, v68, v67

    iput v1, v0, Loy1;->H2:I

    and-int v12, v58, v12

    xor-int v12, v68, v12

    or-int v53, v51, v53

    move/from16 v58, v1

    xor-int v1, v22, v53

    iput v1, v0, Loy1;->a2:I

    xor-int v22, v24, v19

    move/from16 v53, v1

    or-int v1, v24, v19

    or-int v43, v43, v51

    xor-int v43, v44, v43

    and-int v44, v51, v49

    move/from16 v49, v5

    xor-int v5, v65, v44

    iput v5, v0, Loy1;->T1:I

    move/from16 v44, v5

    iget v5, v0, Loy1;->n:I

    or-int v5, v88, v5

    move/from16 v67, v5

    iget v5, v0, Loy1;->v2:I

    xor-int v5, v5, v67

    move/from16 v67, v5

    iget v5, v0, Loy1;->B2:I

    and-int v5, v5, v89

    move/from16 v68, v5

    iget v5, v0, Loy1;->w1:I

    xor-int v5, v5, v68

    not-int v5, v5

    and-int v5, v56, v5

    move/from16 v56, v5

    iget v5, v0, Loy1;->z:I

    xor-int v56, v67, v56

    xor-int v5, v56, v5

    iput v5, v0, Loy1;->z:I

    move/from16 v56, v8

    not-int v8, v5

    move/from16 v67, v5

    and-int v5, v76, v8

    move/from16 v68, v8

    not-int v8, v9

    move/from16 v70, v8

    not-int v8, v5

    and-int v8, v76, v8

    or-int/2addr v8, v9

    xor-int v88, v76, v8

    and-int v88, v72, v88

    move/from16 v89, v5

    and-int v5, v89, v70

    move/from16 v90, v8

    not-int v8, v5

    and-int v8, v72, v8

    move/from16 v91, v5

    and-int v5, v72, v67

    iput v5, v0, Loy1;->D0:I

    or-int v5, v67, v84

    xor-int v5, v77, v5

    iput v5, v0, Loy1;->h1:I

    xor-int v77, v67, v76

    move/from16 v84, v5

    or-int v5, v9, v77

    xor-int v93, v76, v5

    move/from16 v94, v8

    xor-int v8, v77, v9

    iput v8, v0, Loy1;->d1:I

    iput v5, v0, Loy1;->h0:I

    and-int v8, v72, v77

    xor-int v90, v77, v90

    move/from16 v96, v5

    xor-int v5, v90, v72

    iput v5, v0, Loy1;->w1:I

    or-int v85, v67, v85

    move/from16 v90, v5

    xor-int v5, v81, v85

    iput v5, v0, Loy1;->R1:I

    and-int v5, v61, v68

    xor-int v5, v82, v5

    not-int v5, v5

    and-int v5, v111, v5

    and-int v61, v78, v68

    xor-int v61, v83, v61

    and-int v61, v111, v61

    move/from16 v78, v5

    iget v5, v0, Loy1;->v0:I

    xor-int v61, v84, v61

    xor-int v5, v61, v5

    iput v5, v0, Loy1;->v0:I

    and-int v61, v5, v22

    xor-int v81, v23, v61

    and-int v81, v87, v81

    and-int v82, v5, v23

    xor-int v82, v1, v82

    move/from16 v83, v5

    xor-int v5, v82, v20

    iput v5, v0, Loy1;->g1:I

    move/from16 v20, v5

    not-int v5, v2

    and-int v84, v83, v14

    move/from16 v85, v2

    xor-int v2, v24, v84

    not-int v2, v2

    and-int v2, v87, v2

    and-int v13, v83, v13

    xor-int v84, v22, v13

    and-int v84, v87, v84

    move/from16 v97, v2

    xor-int v2, v19, v83

    not-int v2, v2

    and-int v2, v87, v2

    xor-int v2, v40, v2

    or-int v2, v2, v85

    move/from16 v98, v2

    and-int v2, v83, v19

    move/from16 v99, v5

    xor-int v5, v19, v2

    iput v5, v0, Loy1;->E0:I

    and-int v27, v19, v27

    and-int/2addr v14, v1

    move/from16 v101, v8

    not-int v8, v5

    and-int v8, v87, v8

    and-int v102, v83, v1

    xor-int v103, v22, v102

    or-int v103, v103, v85

    and-int v103, v18, v103

    move/from16 v104, v5

    xor-int v5, v23, v83

    iput v5, v0, Loy1;->K0:I

    xor-int v5, v5, v33

    iput v5, v0, Loy1;->N1:I

    move/from16 v33, v5

    iget v5, v0, Loy1;->v:I

    xor-int v81, v82, v81

    and-int v81, v81, v99

    xor-int v33, v33, v81

    xor-int v33, v33, v103

    xor-int v5, v33, v5

    iput v5, v0, Loy1;->v:I

    xor-int v5, v24, v102

    xor-int v5, v5, v84

    iput v5, v0, Loy1;->O:I

    not-int v1, v1

    and-int v1, v83, v1

    move/from16 v33, v1

    xor-int v1, v40, v33

    not-int v1, v1

    and-int v1, v87, v1

    and-int v35, v102, v35

    or-int v35, v85, v35

    xor-int v20, v20, v35

    and-int v27, v83, v27

    move/from16 v35, v1

    xor-int v1, v22, v27

    not-int v1, v1

    and-int v1, v87, v1

    xor-int v1, v23, v1

    iput v1, v0, Loy1;->F1:I

    xor-int v1, v1, v98

    not-int v1, v1

    and-int v1, v18, v1

    xor-int v8, v33, v8

    and-int v8, v8, v99

    xor-int v8, v35, v8

    not-int v8, v8

    and-int v8, v18, v8

    xor-int v8, v20, v8

    xor-int v8, v8, v72

    iput v8, v0, Loy1;->k1:I

    not-int v2, v2

    and-int v2, v87, v2

    and-int v20, v83, v24

    move/from16 v23, v1

    xor-int v1, v22, v20

    not-int v1, v1

    and-int v1, v87, v1

    not-int v14, v14

    and-int v14, v83, v14

    and-int v14, v14, v87

    xor-int v14, v24, v14

    and-int v14, v14, v99

    move/from16 v20, v1

    xor-int v1, v40, v83

    iput v1, v0, Loy1;->G1:I

    xor-int/2addr v1, v2

    or-int v1, v1, v85

    xor-int v2, v40, v61

    and-int v2, v2, v87

    xor-int v2, v104, v2

    or-int v2, v85, v2

    xor-int/2addr v2, v5

    iput v2, v0, Loy1;->b2:I

    xor-int v5, v19, v13

    iput v5, v0, Loy1;->u1:I

    xor-int v13, v5, v20

    iput v13, v0, Loy1;->X1:I

    xor-int/2addr v1, v13

    not-int v1, v1

    and-int v1, v18, v1

    xor-int/2addr v1, v2

    iput v1, v0, Loy1;->c:I

    xor-int v1, v1, v45

    iput v1, v0, Loy1;->H1:I

    xor-int v1, v5, v97

    iput v1, v0, Loy1;->I:I

    xor-int/2addr v1, v14

    iput v1, v0, Loy1;->r1:I

    xor-int v1, v1, v23

    iput v1, v0, Loy1;->q2:I

    xor-int v1, v1, v106

    iput v1, v0, Loy1;->x2:I

    and-int v2, v71, v68

    xor-int v2, v80, v2

    xor-int v2, v2, v78

    iget v5, v0, Loy1;->m:I

    xor-int/2addr v2, v5

    iput v2, v0, Loy1;->m:I

    or-int v2, v67, v76

    xor-int v5, v2, v73

    xor-int v13, v5, v62

    or-int v14, v9, v2

    move/from16 v18, v2

    not-int v2, v14

    and-int v2, v72, v2

    xor-int v18, v18, v91

    move/from16 v19, v2

    xor-int v2, v18, v94

    move/from16 v18, v5

    iget v5, v0, Loy1;->u0:I

    not-int v2, v2

    and-int/2addr v2, v5

    xor-int v14, v89, v14

    xor-int v14, v14, v19

    iput v14, v0, Loy1;->U1:I

    and-int v19, v26, v47

    and-int v20, v67, v76

    and-int v22, v20, v70

    move/from16 v23, v2

    xor-int v2, v67, v22

    iput v2, v0, Loy1;->k:I

    move/from16 v22, v5

    not-int v5, v2

    and-int v5, v72, v5

    xor-int v5, v67, v5

    and-int v5, v22, v5

    xor-int v5, v90, v5

    iput v5, v0, Loy1;->e0:I

    xor-int v2, v2, v101

    not-int v2, v2

    and-int v2, v22, v2

    xor-int/2addr v2, v14

    not-int v2, v2

    and-int v2, v74, v2

    xor-int/2addr v2, v5

    iput v2, v0, Loy1;->M1:I

    and-int v5, v51, v49

    and-int v11, v51, v11

    iget v14, v0, Loy1;->c1:I

    xor-int/2addr v2, v14

    iput v2, v0, Loy1;->c1:I

    or-int/2addr v12, v2

    xor-int v12, v53, v12

    not-int v14, v2

    and-int v24, v57, v14

    xor-int v24, v55, v24

    and-int v24, v83, v24

    or-int/2addr v11, v2

    xor-int v11, v56, v11

    iput v11, v0, Loy1;->f1:I

    xor-int v11, v11, v24

    xor-int v11, v11, v21

    iput v11, v0, Loy1;->T:I

    and-int v11, v48, v14

    xor-int v11, v25, v11

    not-int v11, v11

    and-int v11, v83, v11

    xor-int/2addr v11, v12

    xor-int v11, v11, v67

    iput v11, v0, Loy1;->p2:I

    not-int v12, v11

    and-int v21, v8, v12

    move/from16 v24, v2

    xor-int v2, v11, v21

    iput v2, v0, Loy1;->d2:I

    and-int v2, v8, v11

    and-int/2addr v5, v14

    xor-int v5, v69, v5

    iput v5, v0, Loy1;->z0:I

    and-int v25, v43, v14

    move/from16 v27, v2

    xor-int v2, v58, v25

    iput v2, v0, Loy1;->C0:I

    and-int v14, v65, v14

    xor-int v14, v44, v14

    not-int v14, v14

    and-int v14, v83, v14

    xor-int/2addr v2, v14

    iput v2, v0, Loy1;->z2:I

    xor-int v2, v2, v59

    iput v2, v0, Loy1;->S1:I

    or-int v2, v24, v66

    xor-int v2, v64, v2

    and-int v2, v83, v2

    xor-int/2addr v2, v5

    xor-int v2, v2, v86

    iput v2, v0, Loy1;->N:I

    not-int v5, v2

    and-int v14, v1, v5

    iput v14, v0, Loy1;->p1:I

    and-int v14, v72, v20

    xor-int v14, v96, v14

    not-int v14, v14

    and-int v14, v22, v14

    not-int v14, v14

    and-int v14, v74, v14

    xor-int v20, v67, v73

    and-int v20, v72, v20

    move/from16 v24, v2

    xor-int v2, v93, v20

    not-int v2, v2

    and-int v2, v22, v2

    move/from16 v20, v2

    and-int v2, v67, v60

    iput v2, v0, Loy1;->y1:I

    move/from16 v25, v2

    xor-int v2, v25, v91

    iput v2, v0, Loy1;->n:I

    xor-int v2, v2, v75

    and-int v2, v22, v2

    xor-int/2addr v2, v13

    not-int v2, v2

    and-int v2, v74, v2

    or-int v13, v76, v25

    and-int v13, v13, v70

    xor-int v13, v77, v13

    iput v13, v0, Loy1;->l1:I

    xor-int v13, v13, v88

    iput v13, v0, Loy1;->B2:I

    xor-int v13, v13, v23

    iput v13, v0, Loy1;->v2:I

    move/from16 v23, v2

    iget v2, v0, Loy1;->a:I

    xor-int v13, v13, v23

    xor-int/2addr v2, v13

    iput v2, v0, Loy1;->a:I

    and-int v13, v2, v47

    or-int v23, v2, p1

    xor-int v23, v4, v23

    or-int v33, v38, v2

    xor-int v33, v7, v33

    or-int v35, v54, v2

    xor-int v35, v42, v35

    and-int v16, v2, v16

    xor-int v38, v100, v16

    and-int v38, v38, v30

    xor-int v13, v19, v13

    xor-int v13, v13, v38

    and-int v13, p0, v13

    move/from16 v19, v5

    not-int v5, v7

    and-int/2addr v5, v2

    xor-int v5, v42, v5

    or-int v5, v5, v105

    xor-int v5, v33, v5

    and-int v5, p0, v5

    xor-int v16, v50, v16

    or-int v16, v16, v105

    xor-int v16, v35, v16

    or-int v16, p0, v16

    move/from16 p1, v5

    not-int v5, v4

    and-int/2addr v5, v2

    xor-int/2addr v5, v15

    and-int/2addr v4, v2

    xor-int v4, v36, v4

    and-int v4, v4, v30

    and-int/2addr v7, v2

    xor-int v7, v100, v7

    or-int v7, v7, v105

    not-int v15, v2

    and-int v15, v39, v15

    xor-int v15, v54, v15

    move/from16 v33, v2

    iget v2, v0, Loy1;->I1:I

    and-int v28, p2, v28

    xor-int v35, v113, v95

    xor-int v36, v52, v121

    xor-int/2addr v7, v15

    xor-int/2addr v7, v13

    xor-int/2addr v4, v5

    xor-int v5, v34, v28

    and-int v13, p2, v41

    xor-int v15, v35, p2

    xor-int v28, v36, v63

    xor-int/2addr v2, v7

    iput v2, v0, Loy1;->I1:I

    or-int v2, v46, v33

    and-int v2, v2, v30

    xor-int v2, v23, v2

    xor-int v7, v2, v16

    xor-int v7, v7, v92

    iput v7, v0, Loy1;->F:I

    move/from16 p2, v2

    or-int v2, v24, v7

    iput v2, v0, Loy1;->I2:I

    and-int v7, v7, v19

    iput v7, v0, Loy1;->C2:I

    not-int v1, v1

    and-int/2addr v1, v2

    iput v1, v0, Loy1;->l2:I

    iput v2, v0, Loy1;->q0:I

    iput v7, v0, Loy1;->J2:I

    xor-int v1, p2, p1

    xor-int v1, v1, v79

    iput v1, v0, Loy1;->B:I

    and-int v1, v33, v26

    xor-int v1, v37, v1

    and-int v1, v1, v30

    not-int v1, v1

    and-int v1, p0, v1

    xor-int/2addr v1, v4

    xor-int v1, v1, v22

    iput v1, v0, Loy1;->P:I

    and-int v2, v72, v25

    iput v2, v0, Loy1;->n1:I

    not-int v2, v2

    and-int v2, v22, v2

    iput v2, v0, Loy1;->p0:I

    or-int v2, v9, v25

    xor-int v2, v77, v2

    not-int v2, v2

    and-int v2, v72, v2

    xor-int v2, v18, v2

    xor-int v2, v2, v20

    xor-int/2addr v2, v14

    iget v4, v0, Loy1;->B1:I

    xor-int/2addr v2, v4

    iput v2, v0, Loy1;->B1:I

    not-int v4, v6

    not-int v3, v3

    and-int/2addr v3, v2

    xor-int v3, v32, v3

    and-int v3, v29, v3

    not-int v6, v10

    and-int/2addr v6, v2

    xor-int/2addr v5, v6

    xor-int/2addr v3, v5

    xor-int v3, v3, v31

    iput v3, v0, Loy1;->x:I

    xor-int v3, v119, v2

    iput v3, v0, Loy1;->D:I

    xor-int v5, v3, v117

    iput v5, v0, Loy1;->S0:I

    not-int v3, v3

    and-int v3, v17, v3

    xor-int v3, v119, v3

    iput v3, v0, Loy1;->A1:I

    and-int v3, v2, v28

    xor-int/2addr v3, v13

    not-int v3, v3

    and-int v3, v29, v3

    and-int/2addr v2, v4

    xor-int/2addr v2, v15

    xor-int/2addr v2, v3

    xor-int v2, v2, v76

    iput v2, v0, Loy1;->d:I

    not-int v3, v2

    and-int v4, v11, v3

    and-int/2addr v4, v8

    iput v4, v0, Loy1;->m0:I

    or-int/2addr v1, v4

    iput v1, v0, Loy1;->m1:I

    and-int v1, v2, v11

    iput v1, v0, Loy1;->q1:I

    and-int v4, v8, v1

    iput v4, v0, Loy1;->t0:I

    not-int v1, v1

    and-int/2addr v1, v8

    and-int v4, v8, v3

    iput v4, v0, Loy1;->F2:I

    xor-int v5, v2, v21

    iput v5, v0, Loy1;->e2:I

    xor-int/2addr v4, v2

    iput v4, v0, Loy1;->o0:I

    or-int v4, v11, v2

    iput v4, v0, Loy1;->u2:I

    not-int v5, v4

    and-int/2addr v5, v8

    xor-int/2addr v5, v4

    iput v5, v0, Loy1;->A2:I

    and-int/2addr v3, v4

    iput v3, v0, Loy1;->W:I

    not-int v5, v3

    and-int/2addr v5, v8

    iput v5, v0, Loy1;->W1:I

    xor-int/2addr v5, v2

    iput v5, v0, Loy1;->x1:I

    xor-int v3, v3, v27

    iput v3, v0, Loy1;->h:I

    xor-int/2addr v1, v4

    iput v1, v0, Loy1;->M0:I

    xor-int v1, v4, v8

    iput v1, v0, Loy1;->x0:I

    and-int v1, v2, v12

    iput v1, v0, Loy1;->a1:I

    and-int v3, v8, v1

    xor-int/2addr v1, v3

    iput v1, v0, Loy1;->v1:I

    xor-int v1, v11, v2

    iput v1, v0, Loy1;->n2:I

    and-int/2addr v1, v8

    xor-int/2addr v1, v11

    iput v1, v0, Loy1;->E2:I

    return-void

    :pswitch_0
    invoke-direct/range {p0 .. p2}, Lar3;->a([B[B)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
