.class public final synthetic Lah1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lxh1;
.implements Ler4;


# static fields
.field public static final synthetic i:Lah1;


# instance fields
.field public final synthetic h:I


# direct methods
.method public static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, Lah1;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lah1;-><init>(I)V

    sput-object v0, Lah1;->i:Lah1;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, Lah1;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final synthetic c(JJLfx4;Landroid/media/MediaFormat;)V
    .locals 0

    return-void
.end method

.method private final d(JJLfx4;Landroid/media/MediaFormat;)V
    .locals 0

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/Object;)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method

.method public final b(JJLfx4;Landroid/media/MediaFormat;)V
    .locals 0

    iget p0, p0, Lah1;->h:I

    return-void
.end method
