.class public final synthetic Lbk0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/BooleanSupplier;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lvk0;


# direct methods
.method public synthetic constructor <init>(Lvk0;I)V
    .locals 0

    iput p2, p0, Lbk0;->a:I

    iput-object p1, p0, Lbk0;->b:Lvk0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getAsBoolean()Z
    .locals 1

    iget v0, p0, Lbk0;->a:I

    iget-object p0, p0, Lbk0;->b:Lvk0;

    packed-switch v0, :pswitch_data_0

    iget-boolean p0, p0, Lvk0;->M:Z

    return p0

    :pswitch_0
    iget-boolean p0, p0, Lvk0;->M:Z

    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
