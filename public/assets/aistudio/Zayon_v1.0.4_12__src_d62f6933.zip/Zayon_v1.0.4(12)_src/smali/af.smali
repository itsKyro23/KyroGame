.class public final synthetic Laf;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ldf;


# direct methods
.method public synthetic constructor <init>(Ldf;I)V
    .locals 0

    iput p2, p0, Laf;->h:I

    iput-object p1, p0, Laf;->i:Ldf;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget v0, p0, Laf;->h:I

    iget-object p0, p0, Laf;->i:Ldf;

    packed-switch v0, :pswitch_data_0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Ldf;->V:J

    iget-object v0, p0, Ldf;->G:Lcf;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Ldf;->b()V

    return-void

    :pswitch_0
    invoke-virtual {p0}, Ldf;->b()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
