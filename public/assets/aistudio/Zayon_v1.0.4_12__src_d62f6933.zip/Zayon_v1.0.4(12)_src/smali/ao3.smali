.class public final Lao3;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzb:Lao3;


# instance fields
.field private zza:Leh4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lao3;

    invoke-direct {v0}, Lao3;-><init>()V

    sput-object v0, Lao3;->zzb:Lao3;

    const-class v1, Lao3;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Leh4;->i:Leh4;

    iput-object v0, p0, Lao3;->zza:Leh4;

    return-void
.end method

.method public static A(Ljava/io/FileInputStream;)Lao3;
    .locals 2

    sget-object v0, Lao3;->zzb:Lao3;

    new-instance v1, Lbg4;

    invoke-direct {v1, p0}, Lbg4;-><init>(Ljava/io/InputStream;)V

    sget-object p0, Lgg4;->a:Lgg4;

    sget p0, Lsf4;->a:I

    sget-object p0, Lgg4;->b:Lgg4;

    invoke-static {v0, v1, p0}, Lng4;->k(Lng4;Lcg4;Lgg4;)Lng4;

    move-result-object p0

    invoke-static {p0}, Lng4;->x(Lng4;)V

    check-cast p0, Lao3;

    return-object p0
.end method

.method public static B()Lao3;
    .locals 1

    sget-object v0, Lao3;->zzb:Lao3;

    return-object v0
.end method


# virtual methods
.method public final C()Leh4;
    .locals 2

    iget-object v0, p0, Lao3;->zza:Leh4;

    iget-boolean v1, v0, Leh4;->h:Z

    if-nez v1, :cond_0

    invoke-virtual {v0}, Leh4;->a()Leh4;

    move-result-object v0

    iput-object v0, p0, Lao3;->zza:Leh4;

    :cond_0
    return-object v0
.end method

.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lzn3;

    sget-object p1, Lao3;->zzb:Lao3;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lao3;

    invoke-direct {p0}, Lao3;-><init>()V

    return-object p0

    :cond_2
    sget-object p0, Lai4;->j:Lai4;

    sget-object p1, Lai4;->l:Lai4;

    invoke-static {}, Lyn3;->P()Lyn3;

    move-result-object p2

    new-instance v0, Ldh4;

    invoke-direct {v0, p0, p1, p2}, Ldh4;-><init>(Lai4;Lai4;Lyn3;)V

    const-string p0, "zza"

    filled-new-array {p0, v0}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lao3;->zzb:Lao3;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method

.method public final y()I
    .locals 0

    iget-object p0, p0, Lao3;->zza:Leh4;

    invoke-virtual {p0}, Ljava/util/AbstractMap;->size()I

    move-result p0

    return p0
.end method

.method public final z()Ljava/util/Map;
    .locals 0

    iget-object p0, p0, Lao3;->zza:Leh4;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method
