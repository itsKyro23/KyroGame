.class public final Lb52;
.super Lng4;
.source "SourceFile"


# static fields
.field public static final zza:I = 0x1

.field public static final zzb:I = 0x2

.field public static final zzc:I = 0x3

.field public static final zzd:I = 0x4

.field private static final zzj:Lb52;


# instance fields
.field private zze:I

.field private zzf:Lz42;

.field private zzg:Lug4;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lug4;"
        }
    .end annotation
.end field

.field private zzh:I

.field private zzi:Lr32;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lb52;

    invoke-direct {v0}, Lb52;-><init>()V

    sput-object v0, Lb52;->zzj:Lb52;

    const-class v1, Lb52;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Lkh4;->l:Lkh4;

    iput-object v0, p0, Lb52;->zzg:Lug4;

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 7

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lh42;

    sget-object p1, Lb52;->zzj:Lb52;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lb52;

    invoke-direct {p0}, Lb52;-><init>()V

    return-object p0

    :cond_2
    sget-object v5, Lnv1;->y:Lnv1;

    const-string v6, "zzi"

    const-string v0, "zze"

    const-string v1, "zzf"

    const-string v2, "zzg"

    const-class v3, Lq32;

    const-string v4, "zzh"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lb52;->zzj:Lb52;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0001\u0000\u0001\u1009\u0000\u0002\u001b\u0003\u180c\u0001\u0004\u1009\u0002"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method
