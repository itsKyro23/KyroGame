.class public final synthetic La53;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lty1;

.field public final synthetic c:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lty1;Landroid/content/Context;I)V
    .locals 0

    iput p3, p0, La53;->a:I

    iput-object p1, p0, La53;->b:Lty1;

    iput-object p2, p0, La53;->c:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 2

    iget v0, p0, La53;->a:I

    iget-object v1, p0, La53;->c:Landroid/content/Context;

    iget-object p0, p0, La53;->b:Lty1;

    packed-switch v0, :pswitch_data_0

    iget-object p0, p0, Lty1;->b:Lry1;

    invoke-interface {p0, v1}, Lry1;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_0
    iget-object p0, p0, Lty1;->b:Lry1;

    invoke-interface {p0, v1}, Lry1;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
