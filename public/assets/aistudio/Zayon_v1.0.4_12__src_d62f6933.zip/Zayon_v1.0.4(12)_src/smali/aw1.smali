.class public final Law1;
.super Lng4;
.source "SourceFile"


# static fields
.field public static final synthetic a:I

.field private static final zzg:Law1;


# instance fields
.field private zza:I

.field private zzb:J

.field private zzc:Z

.field private zzd:Z

.field private zze:J

.field private zzf:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Law1;

    invoke-direct {v0}, Law1;-><init>()V

    sput-object v0, Law1;->zzg:Law1;

    const-class v1, Law1;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Lng4;-><init>()V

    const-wide/16 v0, 0x64

    iput-wide v0, p0, Law1;->zzb:J

    const-wide/16 v0, 0x12c

    iput-wide v0, p0, Law1;->zze:J

    const-wide/16 v0, 0x3e8

    iput-wide v0, p0, Law1;->zzf:J

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 6

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lpv1;

    sget-object p1, Law1;->zzg:Law1;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Law1;

    invoke-direct {p0}, Law1;-><init>()V

    return-object p0

    :cond_2
    const-string v4, "zze"

    const-string v5, "zzf"

    const-string v0, "zza"

    const-string v1, "zzb"

    const-string v2, "zzc"

    const-string v3, "zzd"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Law1;->zzg:Law1;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001\u1002\u0000\u0002\u1007\u0001\u0003\u1007\u0002\u0004\u1002\u0003\u0005\u1002\u0004"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method
