.class public final Lbj3;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzb:Lbj3;


# instance fields
.field private zza:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lbj3;

    invoke-direct {v0}, Lng4;-><init>()V

    sput-object v0, Lbj3;->zzb:Lbj3;

    const-class v1, Lbj3;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method


# virtual methods
.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lh42;

    sget-object p1, Lbj3;->zzb:Lbj3;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lbj3;

    invoke-direct {p0}, Lng4;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zza"

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lbj3;->zzb:Lbj3;

    new-instance p2, Llh4;

    const-string v0, "\u0004\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0007"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method
