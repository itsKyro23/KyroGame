.class public final Lbl0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Z

.field public c:I

.field public final d:[F

.field public final e:[F


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lbl0;->c:I

    const/4 v0, 0x4

    new-array v1, v0, [F

    fill-array-data v1, :array_0

    iput-object v1, p0, Lbl0;->d:[F

    new-array v0, v0, [F

    fill-array-data v0, :array_1

    iput-object v0, p0, Lbl0;->e:[F

    return-void

    :array_0
    .array-data 4
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
    .end array-data

    :array_1
    .array-data 4
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
        0x3fb33333    # 1.4f
    .end array-data
.end method


# virtual methods
.method public final a()Lbl0;
    .locals 5

    new-instance v0, Lbl0;

    invoke-direct {v0}, Lbl0;-><init>()V

    iget-boolean v1, p0, Lbl0;->a:Z

    iput-boolean v1, v0, Lbl0;->a:Z

    iget-boolean v1, p0, Lbl0;->b:Z

    iput-boolean v1, v0, Lbl0;->b:Z

    iget v1, p0, Lbl0;->c:I

    iput v1, v0, Lbl0;->c:I

    iget-object v1, p0, Lbl0;->d:[F

    const/4 v2, 0x0

    iget-object v3, v0, Lbl0;->d:[F

    const/4 v4, 0x4

    invoke-static {v1, v2, v3, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object p0, p0, Lbl0;->e:[F

    iget-object v1, v0, Lbl0;->e:[F

    invoke-static {p0, v2, v1, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v0
.end method
