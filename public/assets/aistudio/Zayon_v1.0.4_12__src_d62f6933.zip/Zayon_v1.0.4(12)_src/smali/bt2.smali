.class public abstract synthetic Lbt2;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget v0, Llt2;->g:I

    return-void
.end method

.method public static a(Ljava/lang/Exception;)Ljava/lang/String;
    .locals 3

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_1

    const-string p0, ""

    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    sget v1, Lre2;->a:I

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x28

    if-le v1, v2, :cond_2

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    return-object p0

    :catchall_0
    const-string p0, "BillingLogger"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    return-object v0
.end method

.method public static b(IILad;Ljava/lang/String;Lwm4;)Lgm4;
    .locals 3

    :try_start_0
    invoke-static {}, Lrm4;->q()Lnm4;

    move-result-object v0

    iget v1, p2, Lad;->a:I

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v2, v0, Lmr3;->i:Lus3;

    check-cast v2, Lrm4;

    invoke-static {v2, v1}, Lrm4;->p(Lrm4;I)V

    iget-object v1, p2, Lad;->c:Ljava/lang/String;

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v2, v0, Lmr3;->i:Lus3;

    check-cast v2, Lrm4;

    invoke-static {v2, v1}, Lrm4;->s(Lrm4;Ljava/lang/String;)V

    iget p2, p2, Lad;->b:I

    if-eqz p2, :cond_0

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v1, v0, Lmr3;->i:Lus3;

    check-cast v1, Lrm4;

    invoke-static {v1, p2}, Lrm4;->u(Lrm4;I)V

    :cond_0
    if-eqz p0, :cond_1

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p2, v0, Lmr3;->i:Lus3;

    check-cast p2, Lrm4;

    invoke-static {p2, p0}, Lrm4;->v(Lrm4;I)V

    :cond_1
    if-eqz p3, :cond_2

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p0, v0, Lmr3;->i:Lus3;

    check-cast p0, Lrm4;

    invoke-static {p0, p3}, Lrm4;->r(Lrm4;Ljava/lang/String;)V

    :cond_2
    invoke-static {}, Lgm4;->s()Ldm4;

    move-result-object p0

    invoke-virtual {p0, v0}, Ldm4;->c(Lnm4;)V

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p2, p0, Lmr3;->i:Lus3;

    check-cast p2, Lgm4;

    invoke-static {p2, p1}, Lgm4;->r(Lgm4;I)V

    sget-object p1, Lwm4;->i:Lwm4;

    invoke-virtual {p4, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {p0}, Lmr3;->b()V

    iget-object p1, p0, Lmr3;->i:Lus3;

    check-cast p1, Lgm4;

    invoke-static {p1, p4}, Lgm4;->v(Lgm4;Lwm4;)V

    :cond_3
    invoke-virtual {p0}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lgm4;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p0

    :catchall_0
    const-string p0, "BillingLogger"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static c(ILwm4;)Lmm4;
    .locals 2

    :try_start_0
    invoke-static {}, Lmm4;->q()Ljm4;

    move-result-object v0

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object v1, v0, Lmr3;->i:Lus3;

    check-cast v1, Lmm4;

    invoke-static {v1, p0}, Lmm4;->p(Lmm4;I)V

    sget-object p0, Lwm4;->i:Lwm4;

    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    invoke-virtual {v0}, Lmr3;->b()V

    iget-object p0, v0, Lmr3;->i:Lus3;

    check-cast p0, Lmm4;

    invoke-static {p0, p1}, Lmm4;->s(Lmm4;Lwm4;)V

    :cond_0
    invoke-virtual {v0}, Lmr3;->a()Lus3;

    move-result-object p0

    check-cast p0, Lmm4;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    const-string p0, "BillingLogger"

    invoke-static {p0}, Lre2;->h(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
