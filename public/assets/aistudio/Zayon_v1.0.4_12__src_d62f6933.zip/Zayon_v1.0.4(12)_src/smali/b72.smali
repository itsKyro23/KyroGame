.class public abstract Lb72;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lu72;


# direct methods
.method public constructor <init>()V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.client.IAdLoader"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2

    const/4 v0, 0x1

    if-eq p3, v0, :cond_4

    const/4 v1, 0x2

    if-eq p3, v1, :cond_3

    const/4 v1, 0x3

    if-eq p3, v1, :cond_2

    const/4 v1, 0x4

    if-eq p3, v1, :cond_1

    const/4 v1, 0x5

    if-eq p3, v1, :cond_0

    const/4 p0, 0x0

    return p0

    :cond_0
    sget-object p3, Ltp4;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Ltp4;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v1

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3, v1}, Lu72;->d3(Ltp4;I)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v0

    :cond_1
    invoke-interface {p0}, Lu72;->g()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v0

    :cond_2
    invoke-interface {p0}, Lu72;->e()Z

    move-result p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    sget-object p1, Lg12;->a:Ljava/lang/ClassLoader;

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeInt(I)V

    return v0

    :cond_3
    invoke-interface {p0}, Lu72;->c()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p2, p0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v0

    :cond_4
    sget-object p3, Ltp4;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Ltp4;

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lu72;->E1(Ltp4;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v0
.end method
