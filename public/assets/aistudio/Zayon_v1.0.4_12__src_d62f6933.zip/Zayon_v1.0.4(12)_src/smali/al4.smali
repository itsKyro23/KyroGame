.class public final Lal4;
.super Lll;
.source "SourceFile"


# instance fields
.field public final i:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Lw52;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lal4;->i:Ljava/lang/ref/WeakReference;

    return-void
.end method


# virtual methods
.method public final a(Lkl;)V
    .locals 5

    iget-object p0, p0, Lal4;->i:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lw52;

    if-eqz p0, :cond_3

    iput-object p1, p0, Lw52;->b:Lkl;

    :try_start_0
    iget-object p1, p1, Lkl;->a:Lz40;

    check-cast p1, Lx40;

    invoke-virtual {p1}, Lx40;->M0()Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object p0, p0, Lw52;->d:Luv4;

    if-eqz p0, :cond_3

    iget-object p1, p0, Luv4;->a:Ljava/lang/Object;

    check-cast p1, Lw52;

    iget-object v0, p1, Lw52;->b:Lkl;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    iput-object v1, p1, Lw52;->a:La90;

    move-object v2, v1

    goto :goto_0

    :cond_0
    iget-object v2, p1, Lw52;->a:La90;

    if-nez v2, :cond_1

    invoke-virtual {v0, v1}, Lkl;->b(Lal;)La90;

    move-result-object v2

    iput-object v2, p1, Lw52;->a:La90;

    :cond_1
    :goto_0
    new-instance v0, Ljl;

    invoke-direct {v0, v2}, Ljl;-><init>(La90;)V

    iget-object v2, p0, Luv4;->b:Ljava/lang/Object;

    check-cast v2, Landroid/os/Bundle;

    invoke-static {v0, v2}, Lzu4;->y(Ljl;Landroid/os/Bundle;)V

    invoke-virtual {v0}, Ljl;->b()Llx2;

    move-result-object v0

    iget-object v2, v0, Llx2;->i:Ljava/lang/Object;

    check-cast v2, Landroid/content/Intent;

    iget-object v3, p0, Luv4;->c:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    invoke-static {v3}, Lfv2;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    iget-object p0, p0, Luv4;->d:Ljava/lang/Object;

    check-cast p0, Landroid/net/Uri;

    invoke-virtual {v2, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    iget-object p0, v0, Llx2;->j:Ljava/lang/Object;

    check-cast p0, Landroid/os/Bundle;

    invoke-virtual {v3, v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V

    check-cast v3, Landroid/app/Activity;

    iget-object p0, p1, Lw52;->c:Lal4;

    if-nez p0, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {v3, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    iput-object v1, p1, Lw52;->b:Lkl;

    iput-object v1, p1, Lw52;->a:La90;

    iput-object v1, p1, Lw52;->c:Lal4;

    :cond_3
    :goto_1
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    iget-object p0, p0, Lal4;->i:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lw52;

    if-eqz p0, :cond_0

    const/4 p1, 0x0

    iput-object p1, p0, Lw52;->b:Lkl;

    iput-object p1, p0, Lw52;->a:La90;

    :cond_0
    return-void
.end method
