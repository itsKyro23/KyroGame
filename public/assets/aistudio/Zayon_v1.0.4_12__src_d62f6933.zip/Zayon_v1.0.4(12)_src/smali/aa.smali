.class public final Laa;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lsi0;


# static fields
.field public static final a:Laa;

.field public static final b:Lju;

.field public static final c:Lju;

.field public static final d:Lju;

.field public static final e:Lju;

.field public static final f:Lju;

.field public static final g:Lju;

.field public static final h:Lju;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Laa;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Laa;->a:Laa;

    const-string v0, "requestTimeMs"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->b:Lju;

    const-string v0, "requestUptimeMs"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->c:Lju;

    const-string v0, "clientInfo"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->d:Lju;

    const-string v0, "logSource"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->e:Lju;

    const-string v0, "logSourceName"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->f:Lju;

    const-string v0, "logEvent"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->g:Lju;

    const-string v0, "qosTier"

    invoke-static {v0}, Lju;->a(Ljava/lang/String;)Lju;

    move-result-object v0

    sput-object v0, Laa;->h:Lju;

    return-void
.end method


# virtual methods
.method public final encode(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    check-cast p1, Lib0;

    check-cast p2, Lti0;

    move-object p0, p1

    check-cast p0, Lya;

    iget-wide v0, p0, Lya;->a:J

    sget-object p0, Laa;->b:Lju;

    invoke-interface {p2, p0, v0, v1}, Lti0;->e(Lju;J)Lti0;

    check-cast p1, Lya;

    iget-wide v0, p1, Lya;->b:J

    sget-object p0, Laa;->c:Lju;

    invoke-interface {p2, p0, v0, v1}, Lti0;->e(Lju;J)Lti0;

    sget-object p0, Laa;->d:Lju;

    iget-object v0, p1, Lya;->c:Lna;

    invoke-interface {p2, p0, v0}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    sget-object p0, Laa;->e:Lju;

    iget-object v0, p1, Lya;->d:Ljava/lang/Integer;

    invoke-interface {p2, p0, v0}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    sget-object p0, Laa;->f:Lju;

    iget-object v0, p1, Lya;->e:Ljava/lang/String;

    invoke-interface {p2, p0, v0}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    sget-object p0, Laa;->g:Lju;

    iget-object p1, p1, Lya;->f:Ljava/util/ArrayList;

    invoke-interface {p2, p0, p1}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    sget-object p0, Laa;->h:Lju;

    sget-object p1, Lbq0;->h:Lbq0;

    invoke-interface {p2, p0, p1}, Lti0;->a(Lju;Ljava/lang/Object;)Lti0;

    return-void
.end method
