.class public final La3;
.super Ljx;
.source "SourceFile"


# instance fields
.field public final synthetic q:I

.field public final synthetic r:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/ActionMenuItemView;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, La3;->q:I

    iput-object p1, p0, La3;->r:Landroid/view/View;

    invoke-direct {p0, p1}, Ljx;-><init>(Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>(Le3;Le3;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, La3;->q:I

    .line 9
    iput-object p1, p0, La3;->r:Landroid/view/View;

    invoke-direct {p0, p2}, Ljx;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public final b()Lox0;
    .locals 2

    iget v0, p0, La3;->q:I

    const/4 v1, 0x0

    iget-object p0, p0, La3;->r:Landroid/view/View;

    packed-switch v0, :pswitch_data_0

    check-cast p0, Le3;

    iget-object p0, p0, Le3;->k:Lf3;

    iget-object p0, p0, Lf3;->z:Lc3;

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lqe0;->a()Loe0;

    move-result-object v1

    :goto_0
    return-object v1

    :pswitch_0
    check-cast p0, Landroidx/appcompat/view/menu/ActionMenuItemView;

    iget-object p0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->t:Lb3;

    if-eqz p0, :cond_1

    check-cast p0, Ld3;

    iget-object p0, p0, Ld3;->a:Lf3;

    iget-object p0, p0, Lf3;->A:Lc3;

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Lqe0;->a()Loe0;

    move-result-object v1

    :cond_1
    return-object v1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final d()Z
    .locals 3

    iget v0, p0, La3;->q:I

    const/4 v1, 0x1

    iget-object v2, p0, La3;->r:Landroid/view/View;

    packed-switch v0, :pswitch_data_0

    check-cast v2, Le3;

    iget-object p0, v2, Le3;->k:Lf3;

    invoke-virtual {p0}, Lf3;->l()Z

    return v1

    :pswitch_0
    check-cast v2, Landroidx/appcompat/view/menu/ActionMenuItemView;

    iget-object v0, v2, Landroidx/appcompat/view/menu/ActionMenuItemView;->r:Lfe0;

    if-eqz v0, :cond_0

    iget-object v2, v2, Landroidx/appcompat/view/menu/ActionMenuItemView;->o:Lje0;

    invoke-interface {v0, v2}, Lfe0;->a(Lje0;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, La3;->b()Lox0;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lox0;->a()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public e()Z
    .locals 1

    iget v0, p0, La3;->q:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljx;->e()Z

    move-result p0

    return p0

    :pswitch_0
    iget-object p0, p0, La3;->r:Landroid/view/View;

    check-cast p0, Le3;

    iget-object p0, p0, Le3;->k:Lf3;

    iget-object v0, p0, Lf3;->B:Lvt2;

    if-eqz v0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lf3;->d()Z

    const/4 p0, 0x1

    :goto_0
    return p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
