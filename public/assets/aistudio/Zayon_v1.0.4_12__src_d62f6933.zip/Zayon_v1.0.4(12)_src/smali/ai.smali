.class public final synthetic Lai;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Lji;


# direct methods
.method public synthetic constructor <init>(Lji;I)V
    .locals 0

    iput p2, p0, Lai;->h:I

    iput-object p1, p0, Lai;->i:Lji;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget p1, p0, Lai;->h:I

    iget-object p0, p0, Lai;->i:Lji;

    packed-switch p1, :pswitch_data_0

    iget p1, p0, Lji;->q:I

    if-nez p1, :cond_1

    iget-boolean p1, p0, Lji;->t:Z

    if-nez p1, :cond_1

    iget-object p0, p0, Lji;->b:Lkh0;

    iget-object p0, p0, Lkh0;->a:Lcom/zayon/optimize/MainActivity;

    new-instance p1, Landroid/content/Intent;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    const-string v2, "android.settings.WIRELESS_SETTINGS"

    if-lt v0, v1, :cond_0

    const-string v0, "android.settings.panel.action.INTERNET_CONNECTIVITY"

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    :try_start_1
    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_1
    :goto_1
    return-void

    :pswitch_0
    invoke-virtual {p0}, Lji;->g()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
