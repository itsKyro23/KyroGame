.class public final Lax4;
.super Ljava/io/IOException;
.source "SourceFile"
