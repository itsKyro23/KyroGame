.class public final enum Lbo0;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum h:Lbo0;

.field public static final enum i:Lbo0;

.field public static final enum j:Lbo0;

.field public static final synthetic k:[Lbo0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, Lbo0;

    const-string v1, "DEFAULT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lbo0;->h:Lbo0;

    new-instance v1, Lbo0;

    const-string v2, "VERY_LOW"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lbo0;->i:Lbo0;

    new-instance v2, Lbo0;

    const-string v3, "HIGHEST"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lbo0;->j:Lbo0;

    filled-new-array {v0, v1, v2}, [Lbo0;

    move-result-object v0

    sput-object v0, Lbo0;->k:[Lbo0;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lbo0;
    .locals 1

    const-class v0, Lbo0;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lbo0;

    return-object p0
.end method

.method public static values()[Lbo0;
    .locals 1

    sget-object v0, Lbo0;->k:[Lbo0;

    invoke-virtual {v0}, [Lbo0;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lbo0;

    return-object v0
.end method
