.class public final Lb63;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lkg2;

.field public final b:Lorg/json/JSONObject;

.field public final c:Ljava/lang/String;

.field public final d:Lji3;


# direct methods
.method public constructor <init>(Lkg2;Lorg/json/JSONObject;Ljava/lang/String;Lji3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb63;->a:Lkg2;

    iput-object p2, p0, Lb63;->b:Lorg/json/JSONObject;

    iput-object p3, p0, Lb63;->c:Ljava/lang/String;

    iput-object p4, p0, Lb63;->d:Lji3;

    return-void
.end method
