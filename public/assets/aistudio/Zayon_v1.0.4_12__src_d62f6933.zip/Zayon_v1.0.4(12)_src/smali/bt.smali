.class public interface abstract Lbt;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/lang/Class;Lsi0;)Lbt;
.end method
