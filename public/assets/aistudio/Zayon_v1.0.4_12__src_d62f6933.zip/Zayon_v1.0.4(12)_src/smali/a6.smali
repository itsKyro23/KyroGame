.class public final La6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb6;
