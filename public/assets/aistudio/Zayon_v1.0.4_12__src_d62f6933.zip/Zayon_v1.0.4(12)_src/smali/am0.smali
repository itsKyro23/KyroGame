.class public final Lam0;
.super Landroid/view/View;
.source "SourceFile"


# static fields
.field public static final A:[F

.field public static final B:[F

.field public static final t:[F

.field public static final u:[F

.field public static final v:[F

.field public static final w:[F

.field public static final x:[F

.field public static final y:[F

.field public static final z:[F


# instance fields
.field public final h:Lul0;

.field public final i:Lvj0;

.field public final j:Landroid/graphics/Paint;

.field public final k:Landroid/graphics/Paint;

.field public final l:Landroid/graphics/Paint;

.field public final m:Landroid/graphics/Paint;

.field public final n:Landroid/graphics/Path;

.field public final o:Ljava/text/SimpleDateFormat;

.field public p:Landroid/graphics/Paint;

.field public q:Landroid/graphics/Paint;

.field public r:Landroid/graphics/Paint;

.field public s:F


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/16 v0, 0x10

    new-array v1, v0, [F

    fill-array-data v1, :array_0

    sput-object v1, Lam0;->t:[F

    new-array v0, v0, [F

    fill-array-data v0, :array_1

    sput-object v0, Lam0;->u:[F

    const/16 v0, 0x8

    new-array v1, v0, [F

    fill-array-data v1, :array_2

    sput-object v1, Lam0;->v:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_3

    sput-object v1, Lam0;->w:[F

    const/16 v1, 0xc

    new-array v1, v1, [F

    fill-array-data v1, :array_4

    sput-object v1, Lam0;->x:[F

    const/16 v1, 0xc

    new-array v1, v1, [F

    fill-array-data v1, :array_5

    sput-object v1, Lam0;->y:[F

    new-array v1, v0, [F

    fill-array-data v1, :array_6

    sput-object v1, Lam0;->z:[F

    new-array v0, v0, [F

    fill-array-data v0, :array_7

    sput-object v0, Lam0;->A:[F

    const/4 v0, 0x5

    new-array v0, v0, [F

    fill-array-data v0, :array_8

    sput-object v0, Lam0;->B:[F

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x428c0000    # 70.0f
        0x41f00000    # 30.0f
        0x42300000    # 44.0f
        0x43d70000    # 430.0f
        0x41400000    # 12.0f
        0x43ee0000    # 476.0f
        0x0
        0x442b0000    # 684.0f
        0x0
        0x44368000    # 730.0f
        0x41400000    # 12.0f
        0x448d4000    # 1130.0f
        0x42300000    # 44.0f
        0x44910000    # 1160.0f
        0x428c0000    # 70.0f
    .end array-data

    :array_1
    .array-data 4
        0x44910000    # 1160.0f
        0x43340000    # 180.0f
        0x448d4000    # 1130.0f
        0x43520000    # 210.0f
        0x44368000    # 730.0f
        0x43740000    # 244.0f
        0x442b0000    # 684.0f
        0x43800000    # 256.0f
        0x43ee0000    # 476.0f
        0x43800000    # 256.0f
        0x43d70000    # 430.0f
        0x43740000    # 244.0f
        0x41f00000    # 30.0f
        0x43520000    # 210.0f
        0x0
        0x43340000    # 180.0f
    .end array-data

    :array_2
    .array-data 4
        0x43d70000    # 430.0f
        0x41400000    # 12.0f
        0x43ee0000    # 476.0f
        0x0
        0x442b0000    # 684.0f
        0x0
        0x44368000    # 730.0f
        0x41400000    # 12.0f
    .end array-data

    :array_3
    .array-data 4
        0x43d70000    # 430.0f
        0x43740000    # 244.0f
        0x43ee0000    # 476.0f
        0x43800000    # 256.0f
        0x442b0000    # 684.0f
        0x43800000    # 256.0f
        0x44368000    # 730.0f
        0x43740000    # 244.0f
    .end array-data

    :array_4
    .array-data 4
        0x43160000    # 150.0f
        0x42380000    # 46.0f
        0x43d90000    # 434.0f
        0x41b80000    # 23.0f
        0x43f00000    # 480.0f
        0x41300000    # 11.0f
        0x442a0000    # 680.0f
        0x41300000    # 11.0f
        0x44358000    # 726.0f
        0x41b80000    # 23.0f
        0x447c8000    # 1010.0f
        0x42380000    # 46.0f
    .end array-data

    :array_5
    .array-data 4
        0x43160000    # 150.0f
        0x43520000    # 210.0f
        0x43d90000    # 434.0f
        0x436a0000    # 234.0f
        0x43f00000    # 480.0f
        0x43750000    # 245.0f
        0x442a0000    # 680.0f
        0x43750000    # 245.0f
        0x44358000    # 726.0f
        0x436a0000    # 234.0f
        0x447c8000    # 1010.0f
        0x43520000    # 210.0f
    .end array-data

    :array_6
    .array-data 4
        0x0
        0x42ce0000    # 103.0f
        0x41000000    # 8.0f
        0x42de0000    # 111.0f
        0x41000000    # 8.0f
        0x430b0000    # 139.0f
        0x0
        0x43130000    # 147.0f
    .end array-data

    :array_7
    .array-data 4
        0x44910000    # 1160.0f
        0x42ce0000    # 103.0f
        0x44900000    # 1152.0f
        0x42de0000    # 111.0f
        0x44900000    # 1152.0f
        0x430b0000    # 139.0f
        0x44910000    # 1160.0f
        0x43130000    # 147.0f
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x3ecccccd    # 0.4f
        0x3f333333    # 0.7f
        0x3f666666    # 0.9f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public constructor <init>(Lul0;)V
    .locals 5

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lam0;->j:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lam0;->k:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lam0;->m:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    iput-object v2, p0, Lam0;->n:Landroid/graphics/Path;

    new-instance v2, Ljava/text/SimpleDateFormat;

    const-string v3, "hh:mm a"

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v2, v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v2, p0, Lam0;->o:Ljava/text/SimpleDateFormat;

    const/high16 v2, -0x40800000    # -1.0f

    iput v2, p0, Lam0;->s:F

    iput-object p1, p0, Lam0;->h:Lul0;

    iget-object p1, p1, Lul0;->s:Lvj0;

    iput-object p1, p0, Lam0;->i:Lvj0;

    sget-object p1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v2, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    sget-object v3, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lam0;->l:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;FFF)V
    .locals 7

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/high16 v0, 0x42340000    # 45.0f

    invoke-virtual {p1, v0, p2, p3}, Landroid/graphics/Canvas;->rotate(FFF)V

    iget-object v0, p0, Lam0;->i:Lvj0;

    iget v0, v0, Lvj0;->q:I

    iget-object v6, p0, Lam0;->m:Landroid/graphics/Paint;

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 p0, 0x40000000    # 2.0f

    div-float/2addr p4, p0

    sub-float v2, p2, p4

    sub-float v3, p3, p4

    add-float v4, p2, p4

    add-float v5, p3, p4

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method public final b(Landroid/graphics/Canvas;FLjava/lang/String;I)V
    .locals 9

    const v0, 0x413e76c8    # 11.903999f

    const v1, 0x4178e148    # 15.555f

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const v1, 0x406c8b42    # 3.6959996f

    const v2, 0x40b63d70    # 5.6949997f

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    add-float/2addr v1, v0

    const/high16 v2, 0x43420000    # 194.0f

    add-float/2addr v0, v2

    invoke-virtual {p0, v0}, Lam0;->g(F)F

    move-result v0

    iget-object v3, p0, Lam0;->q:Landroid/graphics/Paint;

    invoke-virtual {p0, p2}, Lam0;->f(F)F

    move-result v4

    invoke-static {p1, v3, p3, v4, v0}, Lvj0;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Ljava/lang/String;FF)V

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "%"

    invoke-static {p4, v3, p3}, Lq60;->n(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p3

    iget-object v3, p0, Lam0;->r:Landroid/graphics/Paint;

    const/high16 v4, 0x42a40000    # 82.0f

    add-float/2addr v4, p2

    invoke-virtual {p0, v4}, Lam0;->f(F)F

    move-result v4

    iget-object v5, p0, Lam0;->r:Landroid/graphics/Paint;

    invoke-virtual {v5, p3}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v5

    sub-float/2addr v4, v5

    invoke-static {p1, v3, p3, v4, v0}, Lvj0;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Ljava/lang/String;FF)V

    add-float/2addr v1, v2

    const/high16 p3, 0x40a00000    # 5.0f

    add-float/2addr v1, p3

    int-to-float p3, p4

    const/high16 p4, 0x42c80000    # 100.0f

    div-float/2addr p3, p4

    const/high16 p4, 0x41200000    # 10.0f

    mul-float/2addr p3, p4

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    const-wide/high16 v2, 0x4034000000000000L    # 20.0

    invoke-static {v2, v3}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Math;->tan(D)D

    move-result-wide v2

    double-to-float p4, v2

    const/high16 v0, 0x40000000    # 2.0f

    mul-float/2addr p4, v0

    const/4 v0, 0x0

    :goto_0
    const/16 v2, 0xa

    iget-object v3, p0, Lam0;->i:Lvj0;

    iget-object v4, p0, Lam0;->m:Landroid/graphics/Paint;

    if-ge v0, v2, :cond_1

    int-to-float v2, v0

    const v5, 0x41066666    # 8.4f

    mul-float/2addr v2, v5

    add-float/2addr v2, p2

    iget-object v5, p0, Lam0;->n:Landroid/graphics/Path;

    invoke-virtual {v5}, Landroid/graphics/Path;->reset()V

    add-float v6, v2, p4

    invoke-virtual {p0, v6}, Lam0;->f(F)F

    move-result v6

    invoke-virtual {p0, v1}, Lam0;->g(F)F

    move-result v7

    invoke-virtual {v5, v6, v7}, Landroid/graphics/Path;->moveTo(FF)V

    const v6, 0x40cccccd    # 6.4f

    add-float/2addr v6, v2

    add-float v7, v6, p4

    invoke-virtual {p0, v7}, Lam0;->f(F)F

    move-result v7

    invoke-virtual {p0, v1}, Lam0;->g(F)F

    move-result v8

    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    sub-float/2addr v6, p4

    invoke-virtual {p0, v6}, Lam0;->f(F)F

    move-result v6

    const/high16 v7, 0x40800000    # 4.0f

    add-float/2addr v7, v1

    invoke-virtual {p0, v7}, Lam0;->g(F)F

    move-result v8

    invoke-virtual {v5, v6, v8}, Landroid/graphics/Path;->lineTo(FF)V

    sub-float/2addr v2, p4

    invoke-virtual {p0, v2}, Lam0;->f(F)F

    move-result v2

    invoke-virtual {p0, v7}, Lam0;->g(F)F

    move-result v6

    invoke-virtual {v5, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v5}, Landroid/graphics/Path;->close()V

    iget v2, v3, Lvj0;->q:I

    if-ge v0, p3, :cond_0

    goto :goto_1

    :cond_0
    const v3, 0x3e3851ec    # 0.18f

    invoke-static {v2, v3}, Lvj0;->a(IF)I

    move-result v2

    :goto_1
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p1, v5, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    iget p0, v3, Lvj0;->q:I

    invoke-virtual {v4, p0}, Landroid/graphics/Paint;->setColor(I)V

    return-void
.end method

.method public final c(Landroid/graphics/Canvas;[FF)V
    .locals 5

    iget-object v0, p0, Lam0;->i:Lvj0;

    iget v1, v0, Lvj0;->c:F

    invoke-static {}, Lvj0;->f()Z

    move-result v2

    const/high16 v3, 0x40200000    # 2.5f

    if-eqz v2, :cond_0

    mul-float v2, v1, v3

    iget-object v4, p0, Lam0;->l:Landroid/graphics/Paint;

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0, p2, p3}, Lam0;->d([FF)Landroid/graphics/Path;

    move-result-object v2

    invoke-virtual {p1, v2, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    :cond_0
    iget v0, v0, Lvj0;->r:I

    iget-object v2, p0, Lam0;->k:Landroid/graphics/Paint;

    invoke-virtual {v2, v0}, Landroid/graphics/Paint;->setColor(I)V

    mul-float/2addr v1, v3

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0, p2, p3}, Lam0;->d([FF)Landroid/graphics/Path;

    move-result-object p0

    invoke-virtual {p1, p0, v2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method

.method public final d([FF)Landroid/graphics/Path;
    .locals 4

    iget-object v0, p0, Lam0;->n:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    const/4 v1, 0x0

    aget v1, p1, v1

    invoke-virtual {p0, v1}, Lam0;->f(F)F

    move-result v1

    const/4 v2, 0x1

    aget v2, p1, v2

    add-float/2addr v2, p2

    invoke-virtual {p0, v2}, Lam0;->g(F)F

    move-result v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->moveTo(FF)V

    const/4 v1, 0x2

    :goto_0
    array-length v2, p1

    if-ge v1, v2, :cond_0

    aget v2, p1, v1

    invoke-virtual {p0, v2}, Lam0;->f(F)F

    move-result v2

    add-int/lit8 v3, v1, 0x1

    aget v3, p1, v3

    add-float/2addr v3, p2

    invoke-virtual {p0, v3}, Lam0;->g(F)F

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v1, v1, 0x2

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public final e([FF[F)Landroid/graphics/Path;
    .locals 5

    iget-object v0, p0, Lam0;->n:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    const/4 v1, 0x0

    aget v2, p1, v1

    invoke-virtual {p0, v2}, Lam0;->f(F)F

    move-result v2

    const/4 v3, 0x1

    aget v3, p1, v3

    invoke-virtual {p0, v3}, Lam0;->g(F)F

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/graphics/Path;->moveTo(FF)V

    const/4 v2, 0x2

    :goto_0
    array-length v3, p1

    if-ge v2, v3, :cond_0

    aget v3, p1, v2

    invoke-virtual {p0, v3}, Lam0;->f(F)F

    move-result v3

    add-int/lit8 v4, v2, 0x1

    aget v4, p1, v4

    invoke-virtual {p0, v4}, Lam0;->g(F)F

    move-result v4

    invoke-virtual {v0, v3, v4}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v2, v2, 0x2

    goto :goto_0

    :cond_0
    if-eqz p3, :cond_1

    :goto_1
    array-length p1, p3

    if-ge v1, p1, :cond_1

    aget p1, p3, v1

    invoke-virtual {p0, p1}, Lam0;->f(F)F

    move-result p1

    add-int/lit8 v2, v1, 0x1

    aget v2, p3, v2

    add-float/2addr v2, p2

    invoke-virtual {p0, v2}, Lam0;->g(F)F

    move-result v2

    invoke-virtual {v0, p1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v1, v1, 0x2

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Landroid/graphics/Path;->close()V

    return-object v0
.end method

.method public final f(F)F
    .locals 1

    const/high16 v0, 0x42700000    # 60.0f

    add-float/2addr p1, v0

    iget-object p0, p0, Lam0;->h:Lul0;

    invoke-virtual {p0, p1}, Lul0;->a(F)F

    move-result p0

    return p0
.end method

.method public final g(F)F
    .locals 1

    const/high16 v0, 0x41200000    # 10.0f

    add-float/2addr p1, v0

    iget-object p0, p0, Lam0;->h:Lul0;

    invoke-virtual {p0, p1}, Lul0;->b(F)F

    move-result p0

    return p0
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lam0;->p:Landroid/graphics/Paint;

    if-nez v2, :cond_0

    return-void

    :cond_0
    iget-object v2, v0, Lam0;->i:Lvj0;

    iget v3, v2, Lvj0;->c:F

    iget v4, v2, Lvj0;->q:I

    const/high16 v5, 0x43700000    # 240.0f

    iget-object v6, v0, Lam0;->h:Lul0;

    iget v7, v6, Lul0;->x:F

    mul-float/2addr v7, v5

    iget v5, v0, Lam0;->s:F

    cmpl-float v5, v5, v7

    iget-object v8, v0, Lam0;->j:Landroid/graphics/Paint;

    const/4 v9, 0x0

    if-eqz v5, :cond_1

    iput v7, v0, Lam0;->s:F

    new-instance v10, Landroid/graphics/LinearGradient;

    invoke-virtual {v0, v9}, Lam0;->g(F)F

    move-result v12

    const/high16 v5, 0x43800000    # 256.0f

    add-float/2addr v5, v7

    invoke-virtual {v0, v5}, Lam0;->g(F)F

    move-result v14

    iget-object v15, v2, Lvj0;->g0:[I

    sget-object v16, Lam0;->B:[F

    sget-object v17, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v11, 0x0

    const/4 v13, 0x0

    invoke-direct/range {v10 .. v17}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :cond_1
    sget-object v5, Lam0;->t:[F

    sget-object v10, Lam0;->u:[F

    invoke-virtual {v0, v5, v7, v10}, Lam0;->e([FF[F)Landroid/graphics/Path;

    move-result-object v11

    invoke-virtual {v1, v11, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    iget-object v8, v0, Lam0;->k:Landroid/graphics/Paint;

    invoke-virtual {v8, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v11, 0x3fc00000    # 1.5f

    mul-float/2addr v11, v3

    invoke-virtual {v8, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {v0, v5, v7, v10}, Lam0;->e([FF[F)Landroid/graphics/Path;

    move-result-object v5

    invoke-virtual {v1, v5, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    sget-object v5, Lam0;->v:[F

    invoke-virtual {v0, v1, v5, v9}, Lam0;->c(Landroid/graphics/Canvas;[FF)V

    sget-object v5, Lam0;->w:[F

    invoke-virtual {v0, v1, v5, v7}, Lam0;->c(Landroid/graphics/Canvas;[FF)V

    iget v5, v2, Lvj0;->n0:I

    invoke-virtual {v8, v5}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v8, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v3, Lam0;->x:[F

    invoke-virtual {v0, v3, v9}, Lam0;->d([FF)Landroid/graphics/Path;

    move-result-object v3

    invoke-virtual {v1, v3, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    sget-object v3, Lam0;->y:[F

    invoke-virtual {v0, v3, v7}, Lam0;->d([FF)Landroid/graphics/Path;

    move-result-object v3

    invoke-virtual {v1, v3, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    iget-object v3, v0, Lam0;->m:Landroid/graphics/Paint;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v4, Lam0;->z:[F

    const/4 v5, 0x0

    invoke-virtual {v0, v4, v9, v5}, Lam0;->e([FF[F)Landroid/graphics/Path;

    move-result-object v4

    invoke-virtual {v1, v4, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    sget-object v4, Lam0;->A:[F

    invoke-virtual {v0, v4, v9, v5}, Lam0;->e([FF[F)Landroid/graphics/Path;

    move-result-object v4

    invoke-virtual {v1, v4, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    iget v2, v2, Lvj0;->c:F

    new-instance v3, Ljava/util/Date;

    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    iget-object v4, v0, Lam0;->o:Ljava/text/SimpleDateFormat;

    invoke-virtual {v4, v3}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, v0, Lam0;->p:Landroid/graphics/Paint;

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    const/high16 v5, 0x40a00000    # 5.0f

    mul-float/2addr v5, v2

    const/high16 v7, 0x41400000    # 12.0f

    mul-float/2addr v7, v2

    add-float v8, v5, v7

    add-float/2addr v8, v4

    add-float/2addr v8, v7

    add-float/2addr v8, v5

    const/high16 v4, 0x44110000    # 580.0f

    invoke-virtual {v0, v4}, Lam0;->f(F)F

    move-result v4

    const/high16 v7, 0x40000000    # 2.0f

    div-float v9, v8, v7

    sub-float/2addr v4, v9

    const/high16 v9, 0x41a00000    # 20.0f

    invoke-virtual {v0, v9}, Lam0;->g(F)F

    move-result v9

    iget-object v10, v0, Lam0;->p:Landroid/graphics/Paint;

    const/4 v11, 0x1

    invoke-static {v10, v11}, Lvj0;->j(Landroid/graphics/Paint;Z)F

    move-result v10

    div-float/2addr v10, v7

    add-float/2addr v10, v9

    const/high16 v7, 0x40200000    # 2.5f

    mul-float/2addr v7, v2

    add-float v12, v4, v7

    invoke-virtual {v0, v1, v12, v10, v5}, Lam0;->a(Landroid/graphics/Canvas;FFF)V

    iget-object v12, v0, Lam0;->p:Landroid/graphics/Paint;

    const/high16 v13, 0x41880000    # 17.0f

    mul-float/2addr v2, v13

    add-float/2addr v2, v4

    invoke-static {v12, v11, v9}, Lvj0;->b(Landroid/graphics/Paint;ZF)F

    move-result v9

    invoke-static {v1, v12, v3, v2, v9}, Lvj0;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;Ljava/lang/String;FF)V

    add-float/2addr v4, v8

    sub-float/2addr v4, v7

    invoke-virtual {v0, v1, v4, v10, v5}, Lam0;->a(Landroid/graphics/Canvas;FFF)V

    const-string v2, "RAM"

    iget v3, v6, Lul0;->A:I

    const v4, 0x43f18000    # 483.0f

    invoke-virtual {v0, v1, v4, v2, v3}, Lam0;->b(Landroid/graphics/Canvas;FLjava/lang/String;I)V

    const-string v2, "CPU"

    iget v3, v6, Lul0;->B:I

    const v4, 0x4414c000    # 595.0f

    invoke-virtual {v0, v1, v4, v2, v3}, Lam0;->b(Landroid/graphics/Canvas;FLjava/lang/String;I)V

    return-void
.end method
