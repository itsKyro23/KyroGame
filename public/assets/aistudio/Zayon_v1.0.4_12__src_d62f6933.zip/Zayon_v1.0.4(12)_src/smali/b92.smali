.class public final Lb92;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lt82;


# instance fields
.field public final synthetic h:I

.field public final i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, Lb92;->h:I

    const-string p1, "com.google.android.gms.ads.internal.formats.client.IOnUnifiedNativeAdLoadedListener"

    invoke-direct {p0, p1}, Lf12;-><init>(Ljava/lang/String;)V

    iput-object p2, p0, Lb92;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 4

    const/4 v0, 0x1

    if-ne p3, v0, :cond_2

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_0

    const/4 p3, 0x0

    goto :goto_0

    :cond_0
    const-string v1, "com.google.android.gms.ads.internal.formats.client.IUnifiedNativeAd"

    invoke-interface {p3, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v2

    instance-of v3, v2, Lw82;

    if-eqz v3, :cond_1

    move-object p3, v2

    check-cast p3, Lw82;

    goto :goto_0

    :cond_1
    new-instance v2, Lv82;

    const/4 v3, 0x4

    invoke-direct {v2, p3, v1, v3}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    move-object p3, v2

    :goto_0
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {p0, p3}, Lt82;->g2(Lw82;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v0

    :cond_2
    const/4 p0, 0x0

    return p0
.end method

.method public final g2(Lw82;)V
    .locals 12

    iget v0, p0, Lb92;->h:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Lge2;

    invoke-direct {v0, p1}, Lge2;-><init>(Lw82;)V

    iget-object p0, p0, Lb92;->i:Ljava/lang/Object;

    check-cast p0, Lzy2;

    iget-object p1, p0, Lzy2;->i:Ljava/lang/Object;

    check-cast p1, Lq43;

    iget-object p0, p0, Lzy2;->j:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p1, v0, p0}, Lq43;->P3(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :pswitch_0
    const-string v0, "com.google.android.gms.ads.internal.formats.client.INativeAdImage"

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, La71;

    invoke-direct {v2}, La71;-><init>()V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    :try_start_0
    invoke-interface {p1}, Lw82;->c()Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_3

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Landroid/os/IBinder;

    if-eqz v7, :cond_2

    check-cast v6, Landroid/os/IBinder;

    invoke-interface {v6, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v7

    instance-of v8, v7, Ly72;

    if-eqz v8, :cond_1

    check-cast v7, Ly72;

    goto :goto_1

    :cond_1
    new-instance v7, Lx72;

    invoke-direct {v7, v6}, Lx72;-><init>(Landroid/os/IBinder;)V

    goto :goto_1

    :cond_2
    move-object v7, v4

    :goto_1
    if-eqz v7, :cond_0

    new-instance v6, Lz72;

    invoke-direct {v6, v7}, Lz72;-><init>(Ly72;)V

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-static {}, Lj23;->e()V

    :cond_3
    :try_start_1
    invoke-interface {p1}, Lw82;->v()Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_6

    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Landroid/os/IBinder;

    if-eqz v7, :cond_5

    check-cast v6, Landroid/os/IBinder;

    invoke-static {v6}, Lfb3;->P3(Landroid/os/IBinder;)Luu2;

    move-result-object v6

    goto :goto_3

    :cond_5
    move-object v6, v4

    :goto_3
    if-eqz v6, :cond_4

    new-instance v7, Ll34;

    invoke-direct {v7, v6}, Ll34;-><init>(Luu2;)V

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    invoke-static {}, Lj23;->e()V

    :cond_6
    :try_start_2
    invoke-interface {p1}, Lw82;->g()Ly72;

    move-result-object v3

    if-eqz v3, :cond_7

    new-instance v5, Lz72;

    invoke-direct {v5, v3}, Lz72;-><init>(Ly72;)V
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_5

    :cond_7
    :goto_4
    move-object v5, v4

    goto :goto_5

    :catch_2
    invoke-static {}, Lj23;->e()V

    goto :goto_4

    :goto_5
    :try_start_3
    invoke-interface {p1}, Lw82;->m()Lr72;

    move-result-object v3

    if-eqz v3, :cond_b

    invoke-interface {p1}, Lw82;->m()Lr72;

    move-result-object v3

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_5

    :try_start_4
    invoke-interface {v3}, Lr72;->a()Ljava/lang/String;
    :try_end_4
    .catch Landroid/os/RemoteException; {:try_start_4 .. :try_end_4} :catch_3

    goto :goto_6

    :catch_3
    :try_start_5
    invoke-static {}, Lj23;->e()V
    :try_end_5
    .catch Landroid/os/RemoteException; {:try_start_5 .. :try_end_5} :catch_5

    :goto_6
    :try_start_6
    invoke-interface {v3}, Lr72;->d()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    const/4 v8, 0x0

    :cond_8
    :goto_7
    if-ge v8, v7, :cond_b

    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    add-int/lit8 v8, v8, 0x1

    instance-of v10, v9, Landroid/os/IBinder;

    if-eqz v10, :cond_a

    check-cast v9, Landroid/os/IBinder;

    invoke-interface {v9, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v10

    instance-of v11, v10, Ly72;

    if-eqz v11, :cond_9

    check-cast v10, Ly72;

    goto :goto_8

    :cond_9
    new-instance v10, Lx72;

    invoke-direct {v10, v9}, Lx72;-><init>(Landroid/os/IBinder;)V

    goto :goto_8

    :cond_a
    move-object v10, v4

    :goto_8
    if-eqz v10, :cond_8

    new-instance v9, Lz72;

    invoke-direct {v9, v10}, Lz72;-><init>(Ly72;)V

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_6
    .catch Landroid/os/RemoteException; {:try_start_6 .. :try_end_6} :catch_4

    goto :goto_7

    :catch_4
    :try_start_7
    invoke-static {}, Lj23;->e()V
    :try_end_7
    .catch Landroid/os/RemoteException; {:try_start_7 .. :try_end_7} :catch_5

    goto :goto_9

    :catch_5
    invoke-static {}, Lj23;->e()V

    :cond_b
    :goto_9
    iget-object p0, p0, Lb92;->i:Ljava/lang/Object;

    check-cast p0, Lm23;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lve1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    iput-object v3, v0, Lve1;->l:Landroid/os/Bundle;

    :try_start_8
    invoke-interface {p1}, Lw82;->b()Ljava/lang/String;

    move-result-object v3
    :try_end_8
    .catch Landroid/os/RemoteException; {:try_start_8 .. :try_end_8} :catch_6

    goto :goto_a

    :catch_6
    invoke-static {}, Lj23;->e()V

    move-object v3, v4

    :goto_a
    iput-object v3, v0, Lve1;->a:Ljava/lang/String;

    iput-object v1, v0, Lve1;->b:Ljava/util/ArrayList;

    :try_start_9
    invoke-interface {p1}, Lw82;->e()Ljava/lang/String;

    move-result-object v1
    :try_end_9
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_9} :catch_7

    goto :goto_b

    :catch_7
    invoke-static {}, Lj23;->e()V

    move-object v1, v4

    :goto_b
    iput-object v1, v0, Lve1;->c:Ljava/lang/String;

    iput-object v5, v0, Lve1;->d:Lz72;

    :try_start_a
    invoke-interface {p1}, Lw82;->l()Ljava/lang/String;

    move-result-object v1
    :try_end_a
    .catch Landroid/os/RemoteException; {:try_start_a .. :try_end_a} :catch_8

    goto :goto_c

    :catch_8
    invoke-static {}, Lj23;->e()V

    move-object v1, v4

    :goto_c
    iput-object v1, v0, Lve1;->e:Ljava/lang/String;

    :try_start_b
    invoke-interface {p1}, Lw82;->h()Ljava/lang/String;

    move-result-object v1
    :try_end_b
    .catch Landroid/os/RemoteException; {:try_start_b .. :try_end_b} :catch_9

    goto :goto_d

    :catch_9
    invoke-static {}, Lj23;->e()V

    move-object v1, v4

    :goto_d
    iput-object v1, v0, Lve1;->f:Ljava/lang/String;

    :try_start_c
    invoke-interface {p1}, Lw82;->i()D

    move-result-wide v5

    const-wide/high16 v7, -0x4010000000000000L    # -1.0

    cmpl-double v1, v5, v7

    if-nez v1, :cond_c

    :goto_e
    move-object v1, v4

    goto :goto_f

    :cond_c
    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1
    :try_end_c
    .catch Landroid/os/RemoteException; {:try_start_c .. :try_end_c} :catch_a

    goto :goto_f

    :catch_a
    invoke-static {}, Lj23;->e()V

    goto :goto_e

    :goto_f
    iput-object v1, v0, Lve1;->g:Ljava/lang/Double;

    :try_start_d
    invoke-interface {p1}, Lw82;->j()Ljava/lang/String;

    move-result-object v1
    :try_end_d
    .catch Landroid/os/RemoteException; {:try_start_d .. :try_end_d} :catch_b

    goto :goto_10

    :catch_b
    invoke-static {}, Lj23;->e()V

    move-object v1, v4

    :goto_10
    iput-object v1, v0, Lve1;->h:Ljava/lang/String;

    :try_start_e
    invoke-interface {p1}, Lw82;->n()Ljava/lang/String;

    move-result-object v1
    :try_end_e
    .catch Landroid/os/RemoteException; {:try_start_e .. :try_end_e} :catch_c

    goto :goto_11

    :catch_c
    invoke-static {}, Lj23;->e()V

    move-object v1, v4

    :goto_11
    iput-object v1, v0, Lve1;->i:Ljava/lang/String;

    :try_start_f
    invoke-interface {p1}, Lw82;->G()Ll50;

    move-result-object v1

    if-eqz v1, :cond_d

    invoke-static {v1}, Lui0;->d1(Ll50;)Ljava/lang/Object;

    move-result-object v4
    :try_end_f
    .catch Landroid/os/RemoteException; {:try_start_f .. :try_end_f} :catch_d

    goto :goto_12

    :catch_d
    invoke-static {}, Lj23;->e()V

    :cond_d
    :goto_12
    iput-object v4, v0, Lve1;->k:Ljava/lang/Object;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lve1;->m:Z

    iput-boolean v1, v0, Lve1;->n:Z

    :try_start_10
    invoke-interface {p1}, Lw82;->o()Lo23;

    move-result-object v1

    if-eqz v1, :cond_e

    invoke-interface {p1}, Lw82;->o()Lo23;

    move-result-object p1

    invoke-virtual {v2, p1}, La71;->a(Lo23;)V
    :try_end_10
    .catch Landroid/os/RemoteException; {:try_start_10 .. :try_end_10} :catch_e

    goto :goto_13

    :catch_e
    invoke-static {}, Lj23;->e()V

    :cond_e
    :goto_13
    iput-object v2, v0, Lve1;->j:La71;

    iget-object p1, p0, Lm23;->i:Lbe0;

    iget-object p0, p0, Lm23;->h:Lcom/google/ads/mediation/AbstractAdViewAdapter;

    check-cast p1, Loo4;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "#008 Must be called on the main UI thread."

    invoke-static {v1}, Lck2;->d(Ljava/lang/String;)V

    const-string v1, "Adapter called onAdLoaded."

    invoke-static {v1}, Lj23;->c(Ljava/lang/String;)V

    iput-object v0, p1, Loo4;->j:Ljava/lang/Object;

    instance-of p0, p0, Lcom/google/ads/mediation/admob/AdMobAdapter;

    if-eqz p0, :cond_f

    goto :goto_14

    :cond_f
    new-instance p0, Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lrc2;

    invoke-direct {v0}, Lrc2;-><init>()V

    monitor-enter p0

    :try_start_11
    monitor-exit p0
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_0

    :goto_14
    :try_start_12
    iget-object p0, p1, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Llc2;

    invoke-interface {p0}, Llc2;->h()V
    :try_end_12
    .catch Landroid/os/RemoteException; {:try_start_12 .. :try_end_12} :catch_f

    goto :goto_15

    :catch_f
    move-exception p0

    const-string p1, "#007 Could not call remote method."

    invoke-static {p1, p0}, Lj23;->i(Ljava/lang/String;Ljava/lang/Exception;)V

    :goto_15
    return-void

    :catchall_0
    move-exception p1

    :try_start_13
    monitor-exit p0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_0

    throw p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
