.class public final Laj1;
.super Lbv1;
.source "SourceFile"


# instance fields
.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:Lec2;


# direct methods
.method public constructor <init>(Lfu1;Landroid/content/Context;Lec2;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Laj1;->b:Landroid/content/Context;

    iput-object p3, p0, Laj1;->c:Lec2;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final bridge synthetic a()Ljava/lang/Object;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method public final b()Ljava/lang/Object;
    .locals 6

    new-instance v0, Lui0;

    iget-object v1, p0, Laj1;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lui0;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    :try_start_0
    const-string v3, "com.google.android.gms.ads.DynamiteSignalGeneratorCreatorImpl"
    :try_end_0
    .catch Lzt4; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    invoke-static {v1}, Lvm;->q(Landroid/content/Context;)Lqr;

    move-result-object v1

    invoke-virtual {v1, v3}, Lqr;->b(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    check-cast v1, Landroid/os/IBinder;

    sget v3, Lli2;->h:I

    const-string v3, "com.google.android.gms.ads.internal.signals.ISignalGeneratorCreator"

    if-nez v1, :cond_0

    move-object v4, v2

    goto :goto_0

    :cond_0
    invoke-interface {v1, v3}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v4

    instance-of v5, v4, Lmi2;

    if-eqz v5, :cond_1

    check-cast v4, Lmi2;

    goto :goto_0

    :cond_1
    new-instance v4, Lki2;

    const/4 v5, 0x4

    invoke-direct {v4, v1, v3, v5}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :goto_0
    :try_start_2
    iget-object p0, p0, Laj1;->c:Lec2;

    check-cast v4, Lki2;

    invoke-virtual {v4, v0, p0}, Lki2;->A1(Lui0;Lec2;)Lji2;

    move-result-object p0

    return-object p0

    :catch_0
    move-exception p0

    new-instance v0, Lzt4;

    invoke-direct {v0, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    throw v0
    :try_end_2
    .catch Lzt4; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    return-object v2
.end method

.method public final c(Lrm2;)Ljava/lang/Object;
    .locals 2

    new-instance v0, Lui0;

    iget-object v1, p0, Laj1;->b:Landroid/content/Context;

    invoke-direct {v0, v1}, Lui0;-><init>(Ljava/lang/Object;)V

    iget-object p0, p0, Laj1;->c:Lec2;

    const v1, 0xfb1b728

    invoke-interface {p1, v0, p0, v1}, Lrm2;->t1(Ll50;Lgc2;I)Lji2;

    move-result-object p0

    return-object p0
.end method
