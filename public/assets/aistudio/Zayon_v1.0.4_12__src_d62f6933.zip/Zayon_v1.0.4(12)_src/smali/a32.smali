.class public interface abstract La32;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract i(Lx42;)V
.end method
