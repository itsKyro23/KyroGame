.class public interface abstract Laz;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lwz;
