.class public final Lba3;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lrd2;


# static fields
.field public static final synthetic l:I


# instance fields
.field public final h:Lfj2;

.field public final i:Lorg/json/JSONObject;

.field public final j:J

.field public k:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Lpd2;Lfj2;J)V
    .locals 2

    const-string v0, "com.google.android.gms.ads.internal.mediation.client.rtb.ISignalsCallback"

    invoke-direct {p0, v0}, Lf12;-><init>(Ljava/lang/String;)V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lba3;->i:Lorg/json/JSONObject;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lba3;->k:Z

    iput-object p3, p0, Lba3;->h:Lfj2;

    iput-wide p4, p0, Lba3;->j:J

    :try_start_0
    const-string p0, "adapter_version"

    invoke-interface {p2}, Lpd2;->c()Ltd2;

    move-result-object p3

    invoke-virtual {p3}, Ltd2;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v0, p0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p0, "sdk_version"

    invoke-interface {p2}, Lpd2;->e()Ltd2;

    move-result-object p2

    invoke-virtual {p2}, Ltd2;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p0, "name"

    invoke-virtual {v0, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 7

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq p3, v2, :cond_2

    if-eq p3, v1, :cond_1

    const/4 v3, 0x3

    if-eq p3, v3, :cond_0

    return v0

    :cond_0
    sget-object p3, Lh23;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    check-cast p3, Lh23;

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    monitor-enter p0

    :try_start_0
    iget-object p1, p3, Lh23;->i:Ljava/lang/String;

    invoke-virtual {p0, v1, p1}, Lba3;->P3(ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    goto/16 :goto_1

    :catchall_0
    move-exception p1

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :cond_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    monitor-enter p0

    :try_start_2
    invoke-virtual {p0, v1, p3}, Lba3;->P3(ILjava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit p0

    goto :goto_1

    :catchall_1
    move-exception p1

    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p1

    :cond_2
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    monitor-enter p0

    :try_start_4
    iget-boolean p1, p0, Lba3;->k:Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    if-eqz p1, :cond_3

    :goto_0
    monitor-exit p0

    goto :goto_1

    :cond_3
    if-nez p3, :cond_4

    :try_start_5
    const-string p1, "Adapter returned null signals"

    monitor-enter p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :try_start_6
    invoke-virtual {p0, v1, p1}, Lba3;->P3(ILjava/lang/String;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_0

    :catchall_2
    move-exception p1

    :try_start_8
    monitor-exit p0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    :try_start_9
    throw p1
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    :catchall_3
    move-exception p1

    goto :goto_2

    :cond_4
    :try_start_a
    iget-object p1, p0, Lba3;->i:Lorg/json/JSONObject;

    const-string v1, "signals"

    invoke-virtual {p1, v1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p3, Lk52;->l2:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v3, v1, Lvx1;->c:Li52;

    invoke-virtual {v3, p3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Boolean;

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    if-eqz p3, :cond_5

    const-string p3, "latency"

    sget-object v3, Lcw4;->B:Lcw4;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-wide v5, p0, Lba3;->j:J

    sub-long/2addr v3, v5

    invoke-virtual {p1, p3, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :cond_5
    sget-object p3, Lk52;->k2:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, p3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/Boolean;

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p3

    if-eqz p3, :cond_6

    const-string p3, "signal_error_code"

    invoke-virtual {p1, p3, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_a
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_a} :catch_0
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    :catch_0
    :cond_6
    :try_start_b
    iget-object p1, p0, Lba3;->h:Lfj2;

    iget-object p3, p0, Lba3;->i:Lorg/json/JSONObject;

    invoke-virtual {p1, p3}, Lfj2;->a(Ljava/lang/Object;)Z

    iput-boolean v2, p0, Lba3;->k:Z
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    monitor-exit p0

    :goto_1
    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v2

    :goto_2
    :try_start_c
    monitor-exit p0
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    throw p1
.end method

.method public final declared-synchronized P3(ILjava/lang/String;)V
    .locals 6

    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, Lba3;->k:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    iget-object v0, p0, Lba3;->i:Lorg/json/JSONObject;

    const-string v1, "signal_error"

    invoke-virtual {v0, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    sget-object p2, Lk52;->l2:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_1

    const-string p2, "latency"

    sget-object v2, Lcw4;->B:Lcw4;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, p0, Lba3;->j:J

    sub-long/2addr v2, v4

    invoke-virtual {v0, p2, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    :goto_0
    sget-object p2, Lk52;->k2:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_2

    const-string p2, "signal_error_code"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_2
    :try_start_2
    iget-object p1, p0, Lba3;->h:Lfj2;

    iget-object p2, p0, Lba3;->i:Lorg/json/JSONObject;

    invoke-virtual {p1, p2}, Lfj2;->a(Ljava/lang/Object;)Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Lba3;->k:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit p0

    return-void

    :goto_1
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1
.end method
