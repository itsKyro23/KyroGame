.class public final synthetic Lae3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 11
    iput p1, p0, Lae3;->a:I

    iput-object p2, p0, Lae3;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Li14;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lae3;->a:I

    sget-object v0, Li14;->i:Li14;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lae3;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 33

    move-object/from16 v0, p0

    iget v1, v0, Lae3;->a:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    packed-switch v1, :pswitch_data_0

    sget-object v1, Lzu4;->l:Lrc3;

    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v1, v1, Lcw4;->c:Lzu4;

    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Landroid/net/Uri;

    invoke-static {v0}, Lzu4;->o(Landroid/net/Uri;)Ljava/util/HashMap;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lfu3;

    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const-string v2, "android.intent.action.USER_PRESENT"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    iget-object v2, v0, Lfu3;->a:Landroid/content/Context;

    invoke-virtual {v2, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-object v4

    :pswitch_1
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lyt3;

    new-instance v0, Lzl1;

    const/16 v2, 0xd

    invoke-direct {v0, v2, v1}, Lzl1;-><init>(ILjava/lang/Object;)V

    monitor-enter v1

    :try_start_0
    iget-object v2, v1, Lyt3;->b:Lju3;

    iget-object v3, v1, Lyt3;->a:Landroid/content/Context;

    iget-object v4, v1, Lyt3;->c:Lcp3;

    new-instance v5, Lxt3;

    invoke-direct {v5, v3, v4}, Lxt3;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-static {v5}, Lsl3;->e(Lxt3;)Lyd;

    move-result-object v3

    iget-object v4, v1, Lyt3;->d:Lzi2;

    invoke-static {v3, v0, v4}, Ln50;->L(Lna0;Lnv3;Ljava/util/concurrent/Executor;)Ln04;

    move-result-object v0

    const/16 v3, 0x34

    invoke-virtual {v2, v3, v0}, Lju3;->e(ILb14;)V

    iput-object v0, v1, Lyt3;->f:Lna0;

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string v0, ""

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :pswitch_2
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lnk4;

    invoke-interface {v0}, Lnk4;->d()Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :pswitch_3
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lpq3;

    iget-object v1, v0, Lpq3;->c:Lnk4;

    invoke-interface {v1}, Lnk4;->d()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvq3;

    invoke-virtual {v1}, Lvq3;->a()V

    iget-object v0, v0, Lpq3;->b:Lnk4;

    invoke-interface {v0}, Lnk4;->d()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lfr3;

    invoke-virtual {v0}, Lfr3;->a()V

    return-object v4

    :pswitch_4
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lwp3;

    monitor-enter v1

    :try_start_2
    new-instance v2, Ljava/io/FileInputStream;

    iget-object v0, v1, Lwp3;->a:Ljava/io/File;

    invoke-direct {v2, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_2
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Lup3; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    iget-object v0, v1, Lwp3;->c:Lvp3;

    invoke-interface {v0, v2}, Lvp3;->o(Ljava/io/FileInputStream;)Ljava/lang/Object;

    move-result-object v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_4
    .catch Ljava/io/FileNotFoundException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Lup3; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception v0

    goto :goto_4

    :catch_0
    move-exception v0

    goto :goto_1

    :catch_1
    move-exception v0

    goto :goto_2

    :catchall_2
    move-exception v0

    move-object v3, v0

    :try_start_6
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    goto :goto_0

    :catchall_3
    move-exception v0

    :try_start_7
    invoke-virtual {v3, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_0
    throw v3
    :try_end_7
    .catch Ljava/io/FileNotFoundException; {:try_start_7 .. :try_end_7} :catch_2
    .catch Lup3; {:try_start_7 .. :try_end_7} :catch_1
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    :goto_1
    :try_start_8
    iget-object v2, v1, Lwp3;->d:Lnv3;

    new-instance v3, Lup3;

    invoke-direct {v3, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    invoke-interface {v2, v3}, Lnv3;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    monitor-exit v1

    goto :goto_3

    :goto_2
    iget-object v2, v1, Lwp3;->d:Lnv3;

    invoke-interface {v2, v0}, Lnv3;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    monitor-exit v1

    goto :goto_3

    :catch_2
    iget-object v0, v1, Lwp3;->c:Lvp3;

    invoke-interface {v0}, Lvp3;->f()Ljava/lang/Object;

    move-result-object v0

    monitor-exit v1

    :goto_3
    return-object v0

    :goto_4
    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    throw v0

    :pswitch_5
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Ll41;

    iget-object v0, v0, Ll41;->i:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    iget v1, v1, Landroid/content/pm/PackageInfo;->versionCode:I

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v2, v1}, Lw93;->l(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lsw1;

    move-result-object v0

    return-object v0

    :pswitch_6
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lwh3;

    invoke-interface {v0}, Lwh3;->a()V

    return-object v4

    :pswitch_7
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lpb3;

    new-instance v1, Led3;

    iget-object v0, v0, Lpb3;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    const/4 v2, 0x3

    invoke-direct {v1, v2, v0}, Led3;-><init>(ILjava/lang/Object;)V

    return-object v1

    :pswitch_8
    new-instance v1, Lic3;

    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Li14;

    iget-object v0, v0, Li14;->h:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    sget-object v3, Li14;->i:Li14;

    invoke-direct {v1, v0, v2, v4}, Lic3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    return-object v1

    :pswitch_9
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lmb3;

    iget-object v0, v0, Lmb3;->c:Landroid/content/Context;

    const-string v1, "phone"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getNetworkOperator()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getPhoneType()I

    move-result v8

    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v2, v1, Lcw4;->c:Lzu4;

    invoke-static {v0}, Lzu4;->c(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, -0x1

    if-eqz v2, :cond_1

    const-string v2, "connectivity"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/net/ConnectivityManager;

    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v3

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Landroid/net/NetworkInfo;->getType()I

    move-result v4

    invoke-virtual {v3}, Landroid/net/NetworkInfo;->getDetailedState()Landroid/net/NetworkInfo$DetailedState;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    move/from16 v32, v4

    move v4, v3

    move/from16 v3, v32

    goto :goto_5

    :cond_0
    move v3, v4

    :goto_5
    invoke-virtual {v2}, Landroid/net/ConnectivityManager;->isActiveNetworkMetered()Z

    move-result v2

    move v9, v2

    move v6, v3

    :goto_6
    move v10, v4

    goto :goto_7

    :cond_1
    const/4 v2, -0x2

    move v6, v2

    move v9, v3

    goto :goto_6

    :goto_7
    new-instance v4, Lbe3;

    iget-object v1, v1, Lcw4;->f:Lne4;

    invoke-virtual {v1, v0}, Lne4;->g(Landroid/content/Context;)I

    move-result v7

    invoke-direct/range {v4 .. v10}, Lbe3;-><init>(Ljava/lang/String;IIIZI)V

    return-object v4

    :pswitch_a
    iget-object v0, v0, Lae3;->b:Ljava/lang/Object;

    check-cast v0, Lya3;

    const-string v1, "."

    iget-object v5, v0, Lya3;->c:Ljava/lang/Object;

    check-cast v5, Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    const-string v7, "geo:0,0?q=donuts"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v8

    new-instance v9, Landroid/content/Intent;

    const-string v10, "android.intent.action.VIEW"

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-direct {v9, v10, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v7, 0x10000

    invoke-virtual {v6, v9, v7}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v9

    const-string v11, "http://www.google.com"

    new-instance v12, Landroid/content/Intent;

    invoke-static {v11}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v11

    invoke-direct {v12, v10, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v6, v12, v7}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v11

    invoke-virtual {v8}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v15

    sget-object v12, Lcw4;->B:Lcw4;

    iget-object v12, v12, Lcw4;->c:Lzu4;

    sget-object v12, Lwv1;->g:Lwv1;

    iget-object v12, v12, Lwv1;->a:Lsc3;

    invoke-static {}, Lsc3;->q()Z

    move-result v16

    invoke-static {v5}, Lgx1;->m(Landroid/content/Context;)Z

    move-result v17

    invoke-static {v5}, Lgx1;->z(Landroid/content/Context;)Z

    move-result v18

    invoke-virtual {v8}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v19

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, Landroid/os/LocaleList;->getDefault()Landroid/os/LocaleList;

    move-result-object v12

    move v13, v3

    :goto_8
    invoke-virtual {v12}, Landroid/os/LocaleList;->size()I

    move-result v14

    if-ge v13, v14, :cond_2

    invoke-virtual {v12, v13}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v14

    invoke-virtual {v14}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v13, v13, 0x1

    goto :goto_8

    :cond_2
    const-string v12, "market://details?id=com.google.android.gms.ads"

    new-instance v13, Landroid/content/Intent;

    invoke-static {v12}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v12

    invoke-direct {v13, v10, v12}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v6, v13, v7}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v12

    if-nez v12, :cond_4

    :catch_3
    :cond_3
    :goto_9
    move/from16 v20, v2

    :catch_4
    move-object/from16 v21, v4

    goto :goto_a

    :cond_4
    iget-object v12, v12, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-nez v12, :cond_5

    goto :goto_9

    :cond_5
    :try_start_9
    invoke-static {v5}, Ljb1;->a(Landroid/content/Context;)Lgl0;

    move-result-object v13

    iget-object v14, v12, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v13, v3, v14}, Lgl0;->b(ILjava/lang/String;)Landroid/content/pm/PackageInfo;

    move-result-object v13

    if-eqz v13, :cond_3

    iget v13, v13, Landroid/content/pm/PackageInfo;->versionCode:I

    iget-object v12, v12, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-static {v13}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    add-int/2addr v14, v2

    invoke-static {v12}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/String;->length()I

    move-result v20
    :try_end_9
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_9 .. :try_end_9} :catch_3

    add-int v14, v14, v20

    move/from16 v20, v2

    :try_start_a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v14}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2
    :try_end_a
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_a .. :try_end_a} :catch_4

    move-object/from16 v21, v2

    :goto_a
    :try_start_b
    invoke-static {v5}, Ljb1;->a(Landroid/content/Context;)Lgl0;

    move-result-object v2

    const-string v12, "com.android.vending"

    const/16 v13, 0x80

    invoke-virtual {v2, v13, v12}, Lgl0;->b(ILjava/lang/String;)Landroid/content/pm/PackageInfo;

    move-result-object v2

    if-eqz v2, :cond_6

    iget v12, v2, Landroid/content/pm/PackageInfo;->versionCode:I

    iget-object v2, v2, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v13

    add-int/lit8 v13, v13, 0x1

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    add-int/2addr v13, v14

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14, v13}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_5

    move-object/from16 v22, v1

    goto :goto_b

    :catch_5
    :cond_6
    move-object/from16 v22, v4

    :goto_b
    sget-object v1, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lk52;->nf:Lg52;

    sget-object v12, Lvx1;->e:Lvx1;

    iget-object v13, v12, Lvx1;->c:Li52;

    invoke-virtual {v13, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-static {v5}, Lzu4;->H(Landroid/content/Context;)Ldw2;

    move-result-object v1

    iget-object v2, v1, Ldw2;->h:Ljava/lang/String;

    iget-object v4, v1, Ldw2;->i:Ljava/lang/String;

    move-object/from16 v29, v2

    :goto_c
    move-object/from16 v30, v4

    goto :goto_d

    :cond_7
    sget-object v2, Lk52;->mf:Lg52;

    iget-object v12, v12, Lvx1;->c:Li52;

    invoke-virtual {v12, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-static {v5}, Lzu4;->H(Landroid/content/Context;)Ldw2;

    move-result-object v1

    iget-object v1, v1, Ldw2;->h:Ljava/lang/String;

    :cond_8
    move-object/from16 v29, v1

    goto :goto_c

    :goto_d
    new-instance v1, Landroid/content/Intent;

    const-string v2, "http://www.example.com"

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v1, v10, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v6, v1, v3}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v2

    invoke-virtual {v6, v1, v7}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_a

    if-eqz v2, :cond_a

    move v4, v3

    :goto_e
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    if-ge v4, v6, :cond_a

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/pm/ResolveInfo;

    iget-object v7, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v7, v7, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    iget-object v6, v6, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v6, v6, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_9

    iget-object v1, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-static {v5}, Lfv2;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    move/from16 v23, v1

    goto :goto_f

    :cond_9
    add-int/lit8 v4, v4, 0x1

    goto :goto_e

    :cond_a
    move/from16 v23, v3

    :goto_f
    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v1, v1, Lcw4;->c:Lzu4;

    new-instance v1, Landroid/os/StatFs;

    invoke-static {}, Landroid/os/Environment;->getDataDirectory()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/StatFs;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Landroid/os/StatFs;->getAvailableBytes()J

    move-result-wide v1

    const-wide/16 v6, 0x400

    div-long v24, v1, v6

    sget-object v1, Lk52;->Vc:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_b

    invoke-static {v5}, Lzu4;->d(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_b

    move/from16 v26, v20

    goto :goto_10

    :cond_b
    move/from16 v26, v3

    :goto_10
    sget-object v1, Lk52;->Zc:Lg52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_d

    sget-object v1, Lk52;->bd:Lg52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_c

    iget-object v1, v0, Lya3;->e:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    :goto_11
    move-object/from16 v27, v1

    goto :goto_12

    :cond_c
    invoke-static {v5}, Lsc3;->j(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    goto :goto_11

    :cond_d
    const-string v1, ""

    goto :goto_11

    :goto_12
    if-eqz v11, :cond_e

    move/from16 v14, v20

    goto :goto_13

    :cond_e
    move v14, v3

    :goto_13
    if-eqz v9, :cond_f

    move/from16 v13, v20

    goto :goto_14

    :cond_f
    move v13, v3

    :goto_14
    iget-object v0, v0, Lya3;->b:Ljava/lang/Object;

    check-cast v0, Lw43;

    new-instance v12, Lzd3;

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    sget v28, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0}, Lw43;->a()Ljava/lang/String;

    move-result-object v31

    move-object/from16 v20, v8

    invoke-direct/range {v12 .. v31}, Lzd3;-><init>(ZZLjava/lang/String;ZZZLjava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;ZJZLjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v12

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
