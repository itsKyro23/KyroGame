.class public final synthetic La44;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk64;
.implements Lm64;
.implements Lt54;
.implements Ls64;
.implements Lv54;


# static fields
.field public static final synthetic A:La44;

.field public static final synthetic B:La44;

.field public static final synthetic C:La44;

.field public static final synthetic D:La44;

.field public static final synthetic E:La44;

.field public static final synthetic F:La44;

.field public static final synthetic G:La44;

.field public static final synthetic H:La44;

.field public static final synthetic I:La44;

.field public static final synthetic J:La44;

.field public static final synthetic K:La44;

.field public static final synthetic i:La44;

.field public static final synthetic j:La44;

.field public static final synthetic k:La44;

.field public static final synthetic l:La44;

.field public static final synthetic m:La44;

.field public static final synthetic n:La44;

.field public static final synthetic o:La44;

.field public static final synthetic p:La44;

.field public static final synthetic q:La44;

.field public static final synthetic r:La44;

.field public static final synthetic s:La44;

.field public static final synthetic t:La44;

.field public static final synthetic u:La44;

.field public static final synthetic v:La44;

.field public static final synthetic w:La44;

.field public static final synthetic x:La44;

.field public static final synthetic y:La44;

.field public static final synthetic z:La44;


# instance fields
.field public final synthetic h:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, La44;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->i:La44;

    new-instance v0, La44;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->j:La44;

    new-instance v0, La44;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->k:La44;

    new-instance v0, La44;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->l:La44;

    new-instance v0, La44;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->m:La44;

    new-instance v0, La44;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->n:La44;

    new-instance v0, La44;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->o:La44;

    new-instance v0, La44;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->p:La44;

    new-instance v0, La44;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->q:La44;

    new-instance v0, La44;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->r:La44;

    new-instance v0, La44;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->s:La44;

    new-instance v0, La44;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->t:La44;

    new-instance v0, La44;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->u:La44;

    new-instance v0, La44;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->v:La44;

    new-instance v0, La44;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->w:La44;

    new-instance v0, La44;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->x:La44;

    new-instance v0, La44;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->y:La44;

    new-instance v0, La44;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->z:La44;

    new-instance v0, La44;

    const/16 v1, 0x13

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->A:La44;

    new-instance v0, La44;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->B:La44;

    new-instance v0, La44;

    const/16 v1, 0x15

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->C:La44;

    new-instance v0, La44;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->D:La44;

    new-instance v0, La44;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->E:La44;

    new-instance v0, La44;

    const/16 v1, 0x18

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->F:La44;

    new-instance v0, La44;

    const/16 v1, 0x19

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->G:La44;

    new-instance v0, La44;

    const/16 v1, 0x1a

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->H:La44;

    new-instance v0, La44;

    const/16 v1, 0x1b

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->I:La44;

    new-instance v0, La44;

    const/16 v1, 0x1c

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->J:La44;

    new-instance v0, La44;

    const/16 v1, 0x1d

    invoke-direct {v0, v1}, La44;-><init>(I)V

    sput-object v0, La44;->K:La44;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, La44;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Log;)Llv0;
    .locals 9

    iget p0, p0, La44;->h:I

    const/16 v0, 0x17

    const/16 v1, 0x19

    const/4 v2, 0x1

    const/16 v3, 0xc

    const/4 v4, 0x0

    const-string v5, "Only version 0 keys are accepted"

    const/4 v6, 0x0

    sparse-switch p0, :sswitch_data_0

    sget-object p0, Lzd4;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.RsaSsaPssPrivateKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    :try_start_0
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lpb4;->G(Lyf4;Lgg4;)Lpb4;

    move-result-object p0

    invoke-virtual {p0}, Lpb4;->y()I

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lpb4;->z()Lrb4;

    move-result-object v0

    invoke-virtual {v0}, Lrb4;->y()I

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Lrb4;->A()Lyf4;

    move-result-object v1

    invoke-virtual {v1}, Lyf4;->b()[B

    move-result-object v1

    new-instance v3, Ljava/math/BigInteger;

    invoke-direct {v3, v2, v1}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-virtual {v3}, Ljava/math/BigInteger;->bitLength()I

    move-result v1

    invoke-virtual {v0}, Lrb4;->B()Lyf4;

    move-result-object v5

    invoke-virtual {v5}, Lyf4;->b()[B

    move-result-object v5

    new-instance v7, Ljava/math/BigInteger;

    invoke-direct {v7, v2, v5}, Ljava/math/BigInteger;-><init>(I[B)V

    sget-object v2, Lzc4;->g:Ljava/math/BigInteger;

    new-instance v2, Lxc4;

    invoke-direct {v2}, Lxc4;-><init>()V

    sget-object v5, Lzd4;->g:Lkd1;

    invoke-virtual {v0}, Lrb4;->z()Lnb4;

    move-result-object v8

    invoke-virtual {v8}, Lnb4;->y()Lu94;

    move-result-object v8

    invoke-virtual {v5, v8}, Lkd1;->c(Lu94;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lyc4;

    iput-object v8, v2, Lxc4;->c:Lyc4;

    invoke-virtual {v0}, Lrb4;->z()Lnb4;

    move-result-object v8

    invoke-virtual {v8}, Lnb4;->z()Lu94;

    move-result-object v8

    invoke-virtual {v5, v8}, Lkd1;->c(Lu94;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lyc4;

    iput-object v5, v2, Lxc4;->d:Lyc4;

    iput-object v7, v2, Lxc4;->b:Ljava/math/BigInteger;

    invoke-virtual {v2, v1}, Lxc4;->a(I)V

    invoke-virtual {v0}, Lrb4;->z()Lnb4;

    move-result-object v0

    invoke-virtual {v0}, Lnb4;->A()I

    move-result v0

    invoke-virtual {v2, v0}, Lxc4;->b(I)V

    iget-object v0, p1, Log;->l:Ljava/lang/Object;

    check-cast v0, Lm24;

    invoke-static {v0}, Lzd4;->b(Lm24;)Lf24;

    move-result-object v0

    iput-object v0, v2, Lxc4;->f:Lf24;

    invoke-virtual {v2}, Lxc4;->c()Lzc4;

    move-result-object v0

    new-instance v1, Lxh2;

    const/16 v2, 0x1a

    invoke-direct {v1, v2, v4}, Lxh2;-><init>(IZ)V

    iput-object v0, v1, Lxh2;->i:Ljava/lang/Object;

    iput-object v3, v1, Lxh2;->j:Ljava/lang/Object;

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    iput-object p1, v1, Lxh2;->k:Ljava/lang/Object;

    invoke-virtual {v1}, Lxh2;->F()Lbd4;

    move-result-object p1

    new-instance v0, Lqh;

    invoke-direct {v0, v4}, Lqh;-><init>(Z)V

    iput-object p1, v0, Lqh;->h:Ljava/lang/Object;

    invoke-virtual {p0}, Lpb4;->B()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object p1

    invoke-virtual {p0}, Lpb4;->C()Lyf4;

    move-result-object v1

    invoke-static {v1}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object v1

    iput-object p1, v0, Lqh;->j:Ljava/lang/Object;

    iput-object v1, v0, Lqh;->k:Ljava/lang/Object;

    invoke-virtual {p0}, Lpb4;->A()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object p1

    iput-object p1, v0, Lqh;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lpb4;->D()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object p1

    invoke-virtual {p0}, Lpb4;->E()Lyf4;

    move-result-object v1

    invoke-static {v1}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object v1

    iput-object p1, v0, Lqh;->l:Ljava/lang/Object;

    iput-object v1, v0, Lqh;->m:Ljava/lang/Object;

    invoke-virtual {p0}, Lpb4;->F()Lyf4;

    move-result-object p0

    invoke-static {p0}, Lzd4;->e(Lyf4;)Lu33;

    move-result-object p0

    iput-object p0, v0, Lqh;->n:Ljava/lang/Object;

    invoke-virtual {v0}, Lqh;->s()Lad4;

    move-result-object v6

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Lyg4; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string p0, "Parsing RsaSsaPssPrivateKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_0

    :cond_2
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to RsaSsaPssProtoSerialization.parsePrivateKey: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_0
    return-object v6

    :sswitch_0
    sget-object p0, Lvd4;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.RsaSsaPkcs1PrivateKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    :try_start_1
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lhb4;->G(Lyf4;Lgg4;)Lhb4;

    move-result-object p0

    invoke-virtual {p0}, Lhb4;->y()I

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {p0}, Lhb4;->z()Ljb4;

    move-result-object v0

    invoke-virtual {v0}, Ljb4;->y()I

    move-result v3

    if-nez v3, :cond_3

    invoke-virtual {v0}, Ljb4;->A()Lyf4;

    move-result-object v3

    invoke-virtual {v3}, Lyf4;->b()[B

    move-result-object v3

    new-instance v5, Ljava/math/BigInteger;

    invoke-direct {v5, v2, v3}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-virtual {v5}, Ljava/math/BigInteger;->bitLength()I

    move-result v3

    invoke-virtual {v0}, Ljb4;->B()Lyf4;

    move-result-object v7

    invoke-virtual {v7}, Lyf4;->b()[B

    move-result-object v7

    new-instance v8, Ljava/math/BigInteger;

    invoke-direct {v8, v2, v7}, Ljava/math/BigInteger;-><init>(I[B)V

    sget-object v2, Ltc4;->e:Ljava/math/BigInteger;

    new-instance v2, Lrc4;

    invoke-direct {v2}, Lrc4;-><init>()V

    sget-object v7, Lvd4;->g:Lkd1;

    invoke-virtual {v0}, Ljb4;->z()Lfb4;

    move-result-object v0

    invoke-virtual {v0}, Lfb4;->y()Lu94;

    move-result-object v0

    invoke-virtual {v7, v0}, Lkd1;->c(Lu94;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lsc4;

    iput-object v0, v2, Lrc4;->c:Lsc4;

    iput-object v8, v2, Lrc4;->b:Ljava/math/BigInteger;

    invoke-virtual {v2, v3}, Lrc4;->a(I)V

    iget-object v0, p1, Log;->l:Ljava/lang/Object;

    check-cast v0, Lm24;

    invoke-static {v0}, Lvd4;->b(Lm24;)Ll34;

    move-result-object v0

    iput-object v0, v2, Lrc4;->d:Ll34;

    invoke-virtual {v2}, Lrc4;->b()Ltc4;

    move-result-object v0

    new-instance v2, Loo4;

    invoke-direct {v2, v1, v4}, Loo4;-><init>(IZ)V

    iput-object v0, v2, Loo4;->i:Ljava/lang/Object;

    iput-object v5, v2, Loo4;->j:Ljava/lang/Object;

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    iput-object p1, v2, Loo4;->k:Ljava/lang/Object;

    invoke-virtual {v2}, Loo4;->D()Lvc4;

    move-result-object p1

    new-instance v0, Lqh;

    invoke-direct {v0, v4}, Lqh;-><init>(Z)V

    iput-object p1, v0, Lqh;->h:Ljava/lang/Object;

    invoke-virtual {p0}, Lhb4;->B()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object p1

    invoke-virtual {p0}, Lhb4;->C()Lyf4;

    move-result-object v1

    invoke-static {v1}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object v1

    iput-object p1, v0, Lqh;->j:Ljava/lang/Object;

    iput-object v1, v0, Lqh;->k:Ljava/lang/Object;

    invoke-virtual {p0}, Lhb4;->A()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object p1

    iput-object p1, v0, Lqh;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lhb4;->D()Lyf4;

    move-result-object p1

    invoke-static {p1}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object p1

    invoke-virtual {p0}, Lhb4;->E()Lyf4;

    move-result-object v1

    invoke-static {v1}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object v1

    iput-object p1, v0, Lqh;->l:Ljava/lang/Object;

    iput-object v1, v0, Lqh;->m:Ljava/lang/Object;

    invoke-virtual {p0}, Lhb4;->F()Lyf4;

    move-result-object p0

    invoke-static {p0}, Lvd4;->d(Lyf4;)Lu33;

    move-result-object p0

    iput-object p0, v0, Lqh;->n:Ljava/lang/Object;

    invoke-virtual {v0}, Lqh;->r()Luc4;

    move-result-object v6

    goto :goto_1

    :cond_3
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_1
    .catch Lyg4; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const-string p0, "Parsing RsaSsaPkcs1PrivateKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_1

    :cond_5
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to RsaSsaPkcs1ProtoSerialization.parsePrivateKey: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_1
    return-object v6

    :sswitch_1
    sget-object p0, Lqd4;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.Ed25519PrivateKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    :try_start_2
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lr94;->B(Lyf4;Lgg4;)Lr94;

    move-result-object p0

    invoke-virtual {p0}, Lr94;->y()I

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p0}, Lr94;->A()Lt94;

    move-result-object v0

    invoke-virtual {v0}, Lt94;->y()I

    move-result v1

    if-nez v1, :cond_6

    iget-object v1, p1, Log;->l:Ljava/lang/Object;

    check-cast v1, Lm24;

    invoke-static {v1}, Lqd4;->b(Lm24;)Lh34;

    move-result-object v1

    invoke-virtual {v0}, Lt94;->z()Lyf4;

    move-result-object v0

    invoke-virtual {v0}, Lyf4;->b()[B

    move-result-object v0

    invoke-static {v0}, Lxe4;->a([B)Lxe4;

    move-result-object v0

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-static {v1, v0, p1}, Lmc4;->I(Lh34;Lxe4;Ljava/lang/Integer;)Lmc4;

    move-result-object p1

    invoke-virtual {p0}, Lr94;->z()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance v0, Lf53;

    invoke-static {p0}, Lxe4;->a([B)Lxe4;

    move-result-object p0

    invoke-direct {v0, v3, p0}, Lf53;-><init>(ILjava/lang/Object;)V

    invoke-static {p1, v0}, Ljc4;->I(Lmc4;Lf53;)Ljc4;

    move-result-object v6

    goto :goto_2

    :cond_6
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_2
    .catch Lyg4; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    const-string p0, "Parsing Ed25519PrivateKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_2

    :cond_8
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to Ed25519ProtoSerialization.parsePrivateKey: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_2
    return-object v6

    :sswitch_2
    sget-object p0, Lod4;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v1, "type.googleapis.com/google.crypto.tink.EcdsaPrivateKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    :try_start_3
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v1, Lgg4;->a:Lgg4;

    sget v1, Lsf4;->a:I

    sget-object v1, Lgg4;->b:Lgg4;

    invoke-static {p0, v1}, Lm94;->B(Lyf4;Lgg4;)Lm94;

    move-result-object p0

    invoke-virtual {p0}, Lm94;->y()I

    move-result v1

    if-nez v1, :cond_a

    invoke-virtual {p0}, Lm94;->z()Lo94;

    move-result-object v1

    invoke-virtual {v1}, Lo94;->y()I

    move-result v3

    if-nez v3, :cond_9

    new-instance v3, La90;

    const/16 v5, 0x1c

    invoke-direct {v3, v5}, La90;-><init>(I)V

    invoke-virtual {v1}, Lo94;->z()Lk94;

    move-result-object v5

    invoke-virtual {v5}, Lk94;->y()Lu94;

    move-result-object v5

    invoke-static {v5}, Lod4;->b(Lu94;)Lm24;

    move-result-object v5

    iput-object v5, v3, La90;->k:Ljava/lang/Object;

    invoke-virtual {v1}, Lo94;->z()Lk94;

    move-result-object v5

    invoke-virtual {v5}, Lk94;->D()I

    move-result v5

    invoke-static {v5}, Lod4;->h(I)Lc34;

    move-result-object v5

    iput-object v5, v3, La90;->i:Ljava/lang/Object;

    invoke-virtual {v1}, Lo94;->z()Lk94;

    move-result-object v5

    invoke-virtual {v5}, Lk94;->C()I

    move-result v5

    invoke-static {v5}, Lod4;->g(I)Ldc4;

    move-result-object v5

    iput-object v5, v3, La90;->j:Ljava/lang/Object;

    iget-object v5, p1, Log;->l:Ljava/lang/Object;

    check-cast v5, Lm24;

    invoke-static {v5}, Lod4;->c(Lm24;)Ld34;

    move-result-object v5

    iput-object v5, v3, La90;->l:Ljava/lang/Object;

    invoke-virtual {v3}, La90;->A()Lec4;

    move-result-object v3

    new-instance v5, Lwg3;

    invoke-direct {v5, v0, v4}, Lwg3;-><init>(IZ)V

    iput-object v3, v5, Lwg3;->i:Ljava/lang/Object;

    new-instance v0, Ljava/security/spec/ECPoint;

    invoke-virtual {v1}, Lo94;->A()Lyf4;

    move-result-object v3

    invoke-virtual {v3}, Lyf4;->b()[B

    move-result-object v3

    new-instance v4, Ljava/math/BigInteger;

    invoke-direct {v4, v2, v3}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-virtual {v1}, Lo94;->B()Lyf4;

    move-result-object v1

    invoke-virtual {v1}, Lyf4;->b()[B

    move-result-object v1

    new-instance v3, Ljava/math/BigInteger;

    invoke-direct {v3, v2, v1}, Ljava/math/BigInteger;-><init>(I[B)V

    invoke-direct {v0, v4, v3}, Ljava/security/spec/ECPoint;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    iput-object v0, v5, Lwg3;->j:Ljava/lang/Object;

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    iput-object p1, v5, Lwg3;->k:Ljava/lang/Object;

    invoke-virtual {v5}, Lwg3;->o()Lgc4;

    move-result-object p1

    new-instance v0, Lzy2;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lzy2;-><init>(I)V

    iput-object p1, v0, Lzy2;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lm94;->A()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance p1, Ljava/math/BigInteger;

    invoke-direct {p1, v2, p0}, Ljava/math/BigInteger;-><init>(I[B)V

    new-instance p0, Lu33;

    const/16 v1, 0xd

    invoke-direct {p0, v1, p1}, Lu33;-><init>(ILjava/lang/Object;)V

    iput-object p0, v0, Lzy2;->j:Ljava/lang/Object;

    invoke-virtual {v0}, Lzy2;->m()Lfc4;

    move-result-object v6

    goto :goto_3

    :cond_9
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_3
    .catch Lyg4; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    const-string p0, "Parsing EcdsaPrivateKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_3

    :cond_b
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to EcdsaProtoSerialization.parsePrivateKey: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_3
    return-object v6

    :sswitch_3
    sget-object p0, Lo74;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_d

    :try_start_4
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lz74;->B(Lyf4;Lgg4;)Lz74;

    move-result-object p0

    invoke-virtual {p0}, Lz74;->y()I

    move-result v0

    if-nez v0, :cond_c

    new-instance v0, Loo4;

    invoke-direct {v0}, Loo4;-><init>()V

    invoke-virtual {p0}, Lz74;->z()Lyf4;

    move-result-object v1

    invoke-virtual {v1}, Lyf4;->f()I

    move-result v1

    invoke-virtual {v0, v1}, Loo4;->x(I)V

    invoke-virtual {p0}, Lz74;->A()Ld84;

    move-result-object v1

    invoke-virtual {v1}, Ld84;->y()I

    move-result v1

    invoke-virtual {v0, v1}, Loo4;->A(I)V

    iget-object v1, p1, Log;->l:Ljava/lang/Object;

    check-cast v1, Lm24;

    invoke-static {v1}, Lo74;->b(Lm24;)Lf24;

    move-result-object v1

    iput-object v1, v0, Loo4;->k:Ljava/lang/Object;

    invoke-virtual {v0}, Loo4;->C()Lc74;

    move-result-object v0

    new-instance v1, Lwg3;

    const/16 v2, 0x16

    invoke-direct {v1, v2, v4}, Lwg3;-><init>(IZ)V

    iput-object v0, v1, Lwg3;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lz74;->z()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance v0, Lf53;

    invoke-static {p0}, Lxe4;->a([B)Lxe4;

    move-result-object p0

    invoke-direct {v0, v3, p0}, Lf53;-><init>(ILjava/lang/Object;)V

    iput-object v0, v1, Lwg3;->j:Ljava/lang/Object;

    iget-object p0, p1, Log;->m:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    iput-object p0, v1, Lwg3;->k:Ljava/lang/Object;

    invoke-virtual {v1}, Lwg3;->n()La74;

    move-result-object v6

    goto :goto_4

    :cond_c
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_4
    .catch Lyg4; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    const-string p0, "Parsing AesCmacKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_4

    :cond_d
    const-string p0, "Wrong type URL in call to AesCmacProtoSerialization.parseKey"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_4
    return-object v6

    :sswitch_4
    sget-object p0, Lf54;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_f

    :try_start_5
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lbc4;->A(Lyf4;Lgg4;)Lbc4;

    move-result-object p0

    invoke-virtual {p0}, Lbc4;->y()I

    move-result v0

    if-nez v0, :cond_e

    iget-object v0, p1, Log;->l:Ljava/lang/Object;

    check-cast v0, Lm24;

    invoke-static {v0}, Lf54;->b(Lm24;)Ll34;

    move-result-object v0

    invoke-virtual {p0}, Lbc4;->z()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance v1, Lf53;

    invoke-static {p0}, Lxe4;->a([B)Lxe4;

    move-result-object p0

    invoke-direct {v1, v3, p0}, Lf53;-><init>(ILjava/lang/Object;)V

    iget-object p0, p1, Log;->m:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-static {v0, v1, p0}, Lj44;->I(Ll34;Lf53;Ljava/lang/Integer;)Lj44;

    move-result-object v6

    goto :goto_5

    :cond_e
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_5
    .catch Lyg4; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    const-string p0, "Parsing XChaCha20Poly1305Key failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_5

    :cond_f
    const-string p0, "Wrong type URL in call to XChaCha20Poly1305ProtoSerialization.parseKey"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_5
    return-object v6

    :sswitch_5
    sget-object p0, Lt44;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v1, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_13

    :try_start_6
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v1, Lgg4;->a:Lgg4;

    sget v1, Lsf4;->a:I

    sget-object v1, Lgg4;->b:Lgg4;

    invoke-static {p0, v1}, Lb94;->A(Lyf4;Lgg4;)Lb94;

    move-result-object p0

    invoke-virtual {p0}, Lb94;->y()I

    move-result v1

    if-nez v1, :cond_12

    invoke-virtual {p0}, Lb94;->z()Lyf4;

    move-result-object v1

    invoke-virtual {v1}, Lyf4;->f()I

    move-result v1

    const/16 v2, 0x10

    if-eq v1, v2, :cond_11

    const/16 v2, 0x20

    if-ne v1, v2, :cond_10

    goto :goto_6

    :cond_10
    new-instance p0, Ljava/security/InvalidAlgorithmParameterException;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Invalid key size %d; only 16-byte and 32-byte AES keys are supported"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_11
    :goto_6
    iget-object v2, p1, Log;->l:Ljava/lang/Object;

    check-cast v2, Lm24;

    invoke-static {v2}, Lt44;->b(Lm24;)Lf24;

    move-result-object v2

    new-instance v5, Lq34;

    invoke-direct {v5, v1, v2}, Lq34;-><init>(ILf24;)V

    new-instance v1, Loo4;

    invoke-direct {v1, v0, v4}, Loo4;-><init>(IZ)V

    iput-object v5, v1, Loo4;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lb94;->z()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance v0, Lf53;

    invoke-static {p0}, Lxe4;->a([B)Lxe4;

    move-result-object p0

    invoke-direct {v0, v3, p0}, Lf53;-><init>(ILjava/lang/Object;)V

    iput-object v0, v1, Loo4;->j:Ljava/lang/Object;

    iget-object p0, p1, Log;->m:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    iput-object p0, v1, Loo4;->k:Ljava/lang/Object;

    invoke-virtual {v1}, Loo4;->B()Ln34;

    move-result-object v6

    goto :goto_7

    :cond_12
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_6
    .catch Lyg4; {:try_start_6 .. :try_end_6} :catch_6

    :catch_6
    const-string p0, "Parsing AesGcmSivKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_7

    :cond_13
    const-string p0, "Wrong type URL in call to AesGcmSivProtoSerialization.parseKey"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_7
    return-object v6

    :sswitch_6
    sget-object p0, Ln44;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_17

    :try_start_7
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lf84;->B(Lyf4;Lgg4;)Lf84;

    move-result-object p0

    invoke-virtual {p0}, Lf84;->y()I

    move-result v0

    if-nez v0, :cond_16

    invoke-virtual {p0}, Lf84;->z()Lj84;

    move-result-object v0

    invoke-virtual {v0}, Lj84;->y()I

    move-result v0

    if-nez v0, :cond_15

    invoke-virtual {p0}, Lf84;->A()Ly94;

    move-result-object v0

    invoke-virtual {v0}, Ly94;->y()I

    move-result v0

    if-nez v0, :cond_14

    new-instance v0, Lqa;

    const/4 v2, 0x5

    invoke-direct {v0, v2}, Lqa;-><init>(I)V

    invoke-virtual {p0}, Lf84;->z()Lj84;

    move-result-object v2

    invoke-virtual {v2}, Lj84;->A()Lyf4;

    move-result-object v2

    invoke-virtual {v2}, Lyf4;->f()I

    move-result v2

    invoke-virtual {v0, v2}, Lqa;->c(I)V

    invoke-virtual {p0}, Lf84;->A()Ly94;

    move-result-object v2

    invoke-virtual {v2}, Ly94;->A()Lyf4;

    move-result-object v2

    invoke-virtual {v2}, Lyf4;->f()I

    move-result v2

    invoke-virtual {v0, v2}, Lqa;->g(I)V

    invoke-virtual {p0}, Lf84;->z()Lj84;

    move-result-object v2

    invoke-virtual {v2}, Lj84;->z()Ln84;

    move-result-object v2

    invoke-virtual {v2}, Ln84;->y()I

    move-result v2

    invoke-virtual {v0, v2}, Lqa;->j(I)V

    invoke-virtual {p0}, Lf84;->A()Ly94;

    move-result-object v2

    invoke-virtual {v2}, Ly94;->z()Lca4;

    move-result-object v2

    invoke-virtual {v2}, Lca4;->z()I

    move-result v2

    invoke-virtual {v0, v2}, Lqa;->l(I)V

    invoke-virtual {p0}, Lf84;->A()Ly94;

    move-result-object v2

    invoke-virtual {v2}, Ly94;->z()Lca4;

    move-result-object v2

    invoke-virtual {v2}, Lca4;->y()Lu94;

    move-result-object v2

    invoke-static {v2}, Ln44;->c(Lu94;)Lc34;

    move-result-object v2

    iput-object v2, v0, Lqa;->l:Ljava/lang/Object;

    iget-object v2, p1, Log;->l:Ljava/lang/Object;

    check-cast v2, Lm24;

    invoke-static {v2}, Ln44;->b(Lm24;)Ld34;

    move-result-object v2

    iput-object v2, v0, Lqa;->m:Ljava/lang/Object;

    invoke-virtual {v0}, Lqa;->n()Le34;

    move-result-object v0

    new-instance v2, Ll41;

    invoke-direct {v2, v1}, Ll41;-><init>(I)V

    iput-object v0, v2, Ll41;->i:Ljava/lang/Object;

    invoke-virtual {p0}, Lf84;->z()Lj84;

    move-result-object v0

    invoke-virtual {v0}, Lj84;->A()Lyf4;

    move-result-object v0

    invoke-virtual {v0}, Lyf4;->b()[B

    move-result-object v0

    new-instance v1, Lf53;

    invoke-static {v0}, Lxe4;->a([B)Lxe4;

    move-result-object v0

    invoke-direct {v1, v3, v0}, Lf53;-><init>(ILjava/lang/Object;)V

    iput-object v1, v2, Ll41;->j:Ljava/lang/Object;

    invoke-virtual {p0}, Lf84;->A()Ly94;

    move-result-object p0

    invoke-virtual {p0}, Ly94;->A()Lyf4;

    move-result-object p0

    invoke-virtual {p0}, Lyf4;->b()[B

    move-result-object p0

    new-instance v0, Lf53;

    invoke-static {p0}, Lxe4;->a([B)Lxe4;

    move-result-object p0

    invoke-direct {v0, v3, p0}, Lf53;-><init>(ILjava/lang/Object;)V

    iput-object v0, v2, Ll41;->k:Ljava/lang/Object;

    iget-object p0, p1, Log;->m:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    iput-object p0, v2, Ll41;->l:Ljava/lang/Object;

    invoke-virtual {v2}, Ll41;->F()Lx24;

    move-result-object v6

    goto :goto_8

    :cond_14
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string p1, "Only version 0 keys inner HMAC keys are accepted"

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_15
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string p1, "Only version 0 keys inner AES CTR keys are accepted"

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_16
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-direct {p0, v5}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_7
    .catch Lyg4; {:try_start_7 .. :try_end_7} :catch_7

    :catch_7
    const-string p0, "Parsing AesCtrHmacAeadKey failed"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_8

    :cond_17
    const-string p0, "Wrong type URL in call to AesCtrHmacAeadProtoSerialization.parseKey"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_8
    return-object v6

    :sswitch_7
    sget-object p0, Le44;->a:Ll64;

    iget-object p0, p1, Log;->i:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const-string v0, "KmsEnvelopeAeadKeys are only accepted with version 0, got "

    if-eqz p0, :cond_1b

    :try_start_8
    iget-object p0, p1, Log;->j:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v1, Lgg4;->a:Lgg4;

    sget v1, Lsf4;->a:I

    sget-object v1, Lgg4;->b:Lgg4;

    invoke-static {p0, v1}, Lva4;->A(Lyf4;Lgg4;)Lva4;

    move-result-object p0

    invoke-virtual {p0}, Lva4;->y()I

    move-result v1

    if-nez v1, :cond_1a

    invoke-virtual {p0}, Lva4;->z()Lza4;

    move-result-object p0

    iget-object v0, p1, Log;->l:Ljava/lang/Object;

    check-cast v0, Lm24;

    const-string v1, "Unable to parse OutputPrefixType: "

    sget-object v2, Lm24;->d:Lm24;

    if-ne v0, v2, :cond_18

    goto :goto_9

    :cond_18
    sget-object v2, Lm24;->f:Lm24;

    if-ne v0, v2, :cond_19

    :goto_9
    invoke-static {p0, v2}, Le44;->b(Lza4;Lm24;)Ld44;

    move-result-object p0

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-static {p0, p1}, Lc44;->I(Ld44;Ljava/lang/Integer;)Lc44;

    move-result-object v6

    goto :goto_a

    :cond_19
    new-instance p0, Ljava/security/GeneralSecurityException;

    iget-object p1, v0, Lm24;->b:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1a
    new-instance p1, Ljava/security/GeneralSecurityException;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, 0x3a

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_8
    .catch Lyg4; {:try_start_8 .. :try_end_8} :catch_8

    :catch_8
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "Parsing KmsEnvelopeAeadKey failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_1b
    const-string p0, "Wrong type URL in call to LegacyKmsEnvelopeAeadProtoSerialization.parseKey"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_a
    return-object v6

    nop

    :sswitch_data_0
    .sparse-switch
        0x2 -> :sswitch_7
        0x4 -> :sswitch_6
        0x8 -> :sswitch_5
        0xc -> :sswitch_4
        0x10 -> :sswitch_3
        0x17 -> :sswitch_2
        0x19 -> :sswitch_1
        0x1b -> :sswitch_0
    .end sparse-switch
.end method

.method public b(Loo4;)Lk24;
    .locals 4

    iget p0, p0, La44;->h:I

    const-string v0, "Only version 0 parameters are accepted"

    const-string v1, "Unable to parse OutputPrefixType: "

    const/4 v2, 0x0

    sparse-switch p0, :sswitch_data_0

    sget-object p0, Ld54;->a:Ll64;

    iget-object p0, p1, Loo4;->j:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v3, "type.googleapis.com/google.crypto.tink.XAesGcmKey"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    :try_start_0
    iget-object p0, p1, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v3, Lgg4;->a:Lgg4;

    sget v3, Lsf4;->a:I

    sget-object v3, Lgg4;->b:Lgg4;

    invoke-static {p0, v3}, Lvb4;->A(Lyf4;Lgg4;)Lvb4;

    move-result-object p0
    :try_end_0
    .catch Lyg4; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {p0}, Lvb4;->y()I

    move-result v3

    if-nez v3, :cond_2

    iget-object p1, p1, Loo4;->k:Ljava/lang/Object;

    check-cast p1, Lm24;

    sget-object v0, Lm24;->d:Lm24;

    if-ne p1, v0, :cond_0

    sget-object p1, Lh34;->f:Lh34;

    goto :goto_0

    :cond_0
    sget-object v0, Lm24;->f:Lm24;

    if-ne p1, v0, :cond_1

    sget-object p1, Lh34;->g:Lh34;

    :goto_0
    invoke-virtual {p0}, Lvb4;->z()Lzb4;

    move-result-object p0

    invoke-virtual {p0}, Lzb4;->y()I

    move-result p0

    invoke-static {p1, p0}, Li44;->b(Lh34;I)Li44;

    move-result-object v2

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/security/GeneralSecurityException;

    iget-object p1, p1, Lm24;->b:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    invoke-static {v0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_1

    :catch_0
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "Parsing XAesGcmParameters failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_3
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to XAesGcmProtoSerialization.parseParameters: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_1
    return-object v2

    :sswitch_0
    sget-object p0, Lq44;->a:Ll64;

    iget-object p0, p1, Loo4;->j:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v1, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    :try_start_1
    iget-object p0, p1, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v1, Lgg4;->a:Lgg4;

    sget v1, Lsf4;->a:I

    sget-object v1, Lgg4;->b:Lgg4;

    invoke-static {p0, v1}, Lz84;->A(Lyf4;Lgg4;)Lz84;

    move-result-object p0
    :try_end_1
    .catch Lyg4; {:try_start_1 .. :try_end_1} :catch_1

    invoke-virtual {p0}, Lz84;->z()I

    move-result v1

    if-nez v1, :cond_4

    new-instance v0, Ll41;

    const/16 v1, 0x1a

    invoke-direct {v0, v1}, Ll41;-><init>(I)V

    invoke-virtual {p0}, Lz84;->y()I

    move-result p0

    invoke-virtual {v0, p0}, Ll41;->x(I)V

    invoke-virtual {v0}, Ll41;->z()V

    invoke-virtual {v0}, Ll41;->B()V

    iget-object p0, p1, Loo4;->k:Ljava/lang/Object;

    check-cast p0, Lm24;

    invoke-static {p0}, Lq44;->b(Lm24;)Ll34;

    move-result-object p0

    iput-object p0, v0, Ll41;->l:Ljava/lang/Object;

    invoke-virtual {v0}, Ll41;->G()Lm34;

    move-result-object v2

    goto :goto_2

    :cond_4
    invoke-static {v0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_2

    :catch_1
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "Parsing AesGcmParameters failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_5
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to AesGcmProtoSerialization.parseParameters: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_2
    return-object v2

    :sswitch_1
    sget-object p0, Lb44;->a:Ll64;

    iget-object p0, p1, Loo4;->j:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string v0, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    :try_start_2
    iget-object p0, p1, Loo4;->i:Ljava/lang/Object;

    check-cast p0, Lyf4;

    sget-object v0, Lgg4;->a:Lgg4;

    sget v0, Lsf4;->a:I

    sget-object v0, Lgg4;->b:Lgg4;

    invoke-static {p0, v0}, Lta4;->z(Lyf4;Lgg4;)Lta4;

    move-result-object p0
    :try_end_2
    .catch Lyg4; {:try_start_2 .. :try_end_2} :catch_2

    invoke-virtual {p0}, Lta4;->y()Ljava/lang/String;

    move-result-object p0

    iget-object p1, p1, Loo4;->k:Ljava/lang/Object;

    check-cast p1, Lm24;

    sget-object v0, Lm24;->d:Lm24;

    if-ne p1, v0, :cond_6

    sget-object p1, Lm24;->i:Lm24;

    goto :goto_3

    :cond_6
    sget-object v0, Lm24;->f:Lm24;

    if-ne p1, v0, :cond_7

    sget-object p1, Lm24;->j:Lm24;

    :goto_3
    new-instance v2, Lz34;

    invoke-direct {v2, p0, p1}, Lz34;-><init>(Ljava/lang/String;Lm24;)V

    goto :goto_4

    :cond_7
    new-instance p0, Ljava/security/GeneralSecurityException;

    iget-object p1, p1, Lm24;->b:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :catch_2
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "Parsing KmsAeadKeyFormat failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_8
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Wrong type URL in call to LegacyKmsAeadProtoSerialization.parseParameters: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    :goto_4
    return-object v2

    nop

    :sswitch_data_0
    .sparse-switch
        0x0 -> :sswitch_1
        0x6 -> :sswitch_0
    .end sparse-switch
.end method

.method public c(Llv0;)Ljava/lang/Object;
    .locals 14

    iget p0, p0, La44;->h:I

    const/16 v0, 0x20

    const/4 v1, 0x1

    const/4 v2, 0x0

    sparse-switch p0, :sswitch_data_0

    check-cast p1, Lad4;

    :try_start_0
    invoke-static {p1}, Lrd4;->b(Lad4;)Lrd4;

    move-result-object v2
    :try_end_0
    .catch Ljava/security/NoSuchProviderException; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_0

    :catch_0
    sget-object p0, Lme4;->g:Lme4;

    iget-object p0, p0, Lme4;->a:Lle4;

    const-string v0, "RSA"

    invoke-interface {p0, v0}, Lle4;->r(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/security/KeyFactory;

    new-instance v3, Ljava/security/spec/RSAPrivateCrtKeySpec;

    iget-object v1, p1, Lad4;->o:Lbd4;

    iget-object v12, p1, Lad4;->o:Lbd4;

    iget-object v4, v1, Lbd4;->p:Ljava/math/BigInteger;

    iget-object v1, v12, Lbd4;->o:Lzc4;

    iget-object v13, v12, Lbd4;->o:Lzc4;

    iget-object v5, v1, Lzc4;->b:Ljava/math/BigInteger;

    iget-object v1, p1, Lad4;->p:Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    move-object v6, v1

    check-cast v6, Ljava/math/BigInteger;

    iget-object v1, p1, Lad4;->q:Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    move-object v7, v1

    check-cast v7, Ljava/math/BigInteger;

    iget-object v1, p1, Lad4;->r:Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    move-object v8, v1

    check-cast v8, Ljava/math/BigInteger;

    iget-object v1, p1, Lad4;->s:Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    move-object v9, v1

    check-cast v9, Ljava/math/BigInteger;

    iget-object v1, p1, Lad4;->t:Lu33;

    iget-object v1, v1, Lu33;->i:Ljava/lang/Object;

    move-object v10, v1

    check-cast v10, Ljava/math/BigInteger;

    iget-object p1, p1, Lad4;->u:Lu33;

    iget-object p1, p1, Lu33;->i:Ljava/lang/Object;

    move-object v11, p1

    check-cast v11, Ljava/math/BigInteger;

    invoke-direct/range {v3 .. v11}, Ljava/security/spec/RSAPrivateCrtKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-virtual {p0, v3}, Ljava/security/KeyFactory;->generatePrivate(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;

    move-result-object p0

    check-cast p0, Ljava/security/interfaces/RSAPrivateCrtKey;

    new-instance p1, Lrd4;

    sget-object v1, Lwe4;->a:Lkd1;

    iget-object v3, v13, Lzc4;->d:Lyc4;

    invoke-virtual {v1, v3}, Lkd1;->b(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v3

    check-cast v3, Lre4;

    iget-object v4, v13, Lzc4;->e:Lyc4;

    invoke-virtual {v1, v4}, Lkd1;->b(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v1

    check-cast v1, Lre4;

    iget-object v4, v12, Lbd4;->q:Lxe4;

    invoke-virtual {v4}, Lxe4;->b()[B

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Li54;->a()Z

    move-result v4

    if-nez v4, :cond_1

    invoke-static {v3}, Lbo;->y(Lre4;)V

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->bitLength()I

    move-result v1

    invoke-static {v1}, Lbo;->A(I)V

    invoke-interface {p0}, Ljava/security/interfaces/RSAPrivateCrtKey;->getPublicExponent()Ljava/math/BigInteger;

    move-result-object v1

    invoke-static {v1}, Lbo;->E(Ljava/math/BigInteger;)V

    sget-object v1, Lme4;->g:Lme4;

    iget-object v1, v1, Lme4;->a:Lle4;

    invoke-interface {v1, v0}, Lle4;->r(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/security/KeyFactory;

    new-instance v1, Ljava/security/spec/RSAPublicKeySpec;

    invoke-interface {p0}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object v2

    invoke-interface {p0}, Ljava/security/interfaces/RSAPrivateCrtKey;->getPublicExponent()Ljava/math/BigInteger;

    move-result-object p0

    invoke-direct {v1, v2, p0}, Ljava/security/spec/RSAPublicKeySpec;-><init>(Ljava/math/BigInteger;Ljava/math/BigInteger;)V

    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p0

    check-cast p0, Ljava/security/interfaces/RSAPublicKey;

    move-object v2, p1

    goto :goto_0

    :cond_0
    const-string p0, "sigHash and mgf1Hash must be the same"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    const-string p0, "Can not use RSA PSS in FIPS-mode, as BoringCrypto module is not available."

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    :goto_0
    return-object v2

    :sswitch_0
    check-cast p1, Lz54;

    iget-object p0, p1, Lz54;->o:Log;

    sget-object p1, Lr54;->d:Lr54;

    iget-object v0, p0, Log;->i:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    const-class v2, Lp24;

    invoke-virtual {p1, v2, v0}, Lr54;->b(Ljava/lang/Class;Ljava/lang/String;)Lx54;

    move-result-object p1

    iget-object v0, p0, Log;->j:Ljava/lang/Object;

    check-cast v0, Lyf4;

    invoke-virtual {p1, v0}, Lx54;->a(Lyf4;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lp24;

    new-instance v0, Lud4;

    iget-object v2, p0, Log;->l:Ljava/lang/Object;

    check-cast v2, Lm24;

    iget-object p0, p0, Log;->m:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-static {v2, p0}, Lw93;->m(Lm24;Ljava/lang/Integer;)Lxe4;

    move-result-object p0

    invoke-virtual {p0}, Lxe4;->b()[B

    move-result-object p0

    sget-object v3, Lm24;->e:Lm24;

    const/4 v4, 0x0

    if-eq v2, v3, :cond_2

    new-array v1, v4, [B

    goto :goto_1

    :cond_2
    new-array v1, v1, [B

    aput-byte v4, v1, v4

    :goto_1
    invoke-direct {v0, p1, p0, v1}, Lud4;-><init>(Lp24;[B[B)V

    return-object v0

    :sswitch_1
    check-cast p1, Ljc4;

    invoke-static {v1}, Ls9;->n(I)Z

    move-result p0

    const-string v3, "Can not use Ed25519 in FIPS-mode."

    if-eqz p0, :cond_5

    :try_start_1
    invoke-static {p1}, Lrd4;->a(Ljc4;)Lrd4;

    move-result-object v2
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    new-instance p0, Lrd4;

    iget-object v4, p1, Ljc4;->p:Lf53;

    iget-object p1, p1, Ljc4;->o:Lmc4;

    iget-object v4, v4, Lf53;->i:Ljava/lang/Object;

    check-cast v4, Lxe4;

    invoke-virtual {v4}, Lxe4;->b()[B

    move-result-object v4

    iget-object p1, p1, Lmc4;->q:Lxe4;

    invoke-virtual {p1}, Lxe4;->b()[B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {v1}, Ls9;->n(I)Z

    move-result p1

    if-eqz p1, :cond_4

    array-length p1, v4

    if-ne p1, v0, :cond_3

    invoke-static {v4}, Lck2;->B([B)[B

    move-result-object p1

    invoke-static {p1}, Lck2;->x([B)[B

    move-object v2, p0

    goto :goto_2

    :cond_3
    const-string p0, "Given private key\'s length is not 32"

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    goto :goto_2

    :cond_4
    invoke-static {v3}, Lnu0;->h(Ljava/lang/String;)V

    goto :goto_2

    :cond_5
    invoke-static {v3}, Lnu0;->h(Ljava/lang/String;)V

    :goto_2
    return-object v2

    :sswitch_2
    check-cast p1, Lz54;

    iget-object p0, p1, Lz54;->o:Log;

    sget-object v0, Lr54;->d:Lr54;

    iget-object v1, p0, Log;->i:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    const-class v2, Lj24;

    invoke-virtual {v0, v2, v1}, Lr54;->b(Ljava/lang/Class;Ljava/lang/String;)Lx54;

    move-result-object v0

    iget-object v1, p0, Log;->j:Ljava/lang/Object;

    check-cast v1, Lyf4;

    invoke-virtual {v0, v1}, Lx54;->a(Lyf4;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj24;

    iget-object p0, p0, Log;->l:Ljava/lang/Object;

    check-cast p0, Lm24;

    invoke-static {p0}, Lw93;->x(Lm24;)I

    iget-object p1, p1, Lz54;->o:Log;

    iget-object p1, p1, Log;->m:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-static {p0, p1}, Lw93;->m(Lm24;Ljava/lang/Integer;)Lxe4;

    move-result-object p0

    invoke-virtual {p0}, Lxe4;->b()[B

    new-instance p0, Lr74;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0

    :sswitch_3
    check-cast p1, La74;

    sget-object p0, Lb74;->a:Lq64;

    iget-object p0, p1, La74;->o:Lc74;

    iget p0, p0, Lc74;->a:I

    if-ne p0, v0, :cond_6

    new-instance v2, Lte4;

    invoke-direct {v2, p1}, Lte4;-><init>(La74;)V

    goto :goto_3

    :cond_6
    const-string p0, "AesCmacKey size wrong, must be 32 bytes"

    invoke-static {p0}, Lnu0;->h(Ljava/lang/String;)V

    :goto_3
    return-object v2

    :sswitch_4
    check-cast p1, Lj44;

    sget-object p0, Ll44;->a:Lq64;

    :try_start_2
    invoke-static {}, Lu44;->a()Ljavax/crypto/Cipher;
    :try_end_2
    .catch Ljava/security/GeneralSecurityException; {:try_start_2 .. :try_end_2} :catch_2

    invoke-static {}, Lu44;->a()Ljavax/crypto/Cipher;

    move-result-object p0

    new-instance v0, Le54;

    iget-object v1, p1, Lj44;->p:Lf53;

    iget-object v1, v1, Lf53;->i:Ljava/lang/Object;

    check-cast v1, Lxe4;

    invoke-virtual {v1}, Lxe4;->b()[B

    move-result-object v1

    iget-object p1, p1, Lj44;->q:Lxe4;

    invoke-virtual {p1}, Lxe4;->b()[B

    move-result-object p1

    invoke-virtual {p0}, Ljavax/crypto/Cipher;->getProvider()Ljava/security/Provider;

    move-result-object p0

    invoke-direct {v0, v1, p1, p0}, Le54;-><init>([B[BLjava/security/Provider;)V

    goto :goto_4

    :catch_2
    new-instance v0, Lz44;

    iget-object p0, p1, Lj44;->p:Lf53;

    iget-object p0, p0, Lf53;->i:Ljava/lang/Object;

    check-cast p0, Lxe4;

    invoke-virtual {p0}, Lxe4;->b()[B

    move-result-object p0

    iget-object p1, p1, Lj44;->q:Lxe4;

    invoke-virtual {p1}, Lxe4;->b()[B

    move-result-object p1

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0, p1}, Lz44;-><init>(I[B[B)V

    :goto_4
    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        0x3 -> :sswitch_4
        0xe -> :sswitch_3
        0xf -> :sswitch_2
        0x13 -> :sswitch_1
        0x14 -> :sswitch_0
    .end sparse-switch
.end method

.method public c(Llv0;)Log;
    .locals 5

    iget p0, p0, La44;->h:I

    const/4 v0, 0x0

    sparse-switch p0, :sswitch_data_0

    check-cast p1, Lbd4;

    .line 462
    invoke-static {p1}, Lzd4;->d(Lbd4;)Lrb4;

    move-result-object p0

    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->m:Ll24;

    .line 463
    iget-object v1, p1, Lbd4;->o:Lzc4;

    .line 464
    iget-object v1, v1, Lzc4;->c:Lf24;

    .line 465
    invoke-static {v1}, Lzd4;->a(Lf24;)Lm24;

    move-result-object v1

    .line 466
    iget-object p1, p1, Lbd4;->r:Ljava/lang/Integer;

    .line 467
    const-string v2, "type.googleapis.com/google.crypto.tink.RsaSsaPssPublicKey"

    .line 468
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 469
    :sswitch_0
    check-cast p1, Lvc4;

    .line 470
    invoke-static {p1}, Lvd4;->c(Lvc4;)Ljb4;

    move-result-object p0

    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->m:Ll24;

    .line 471
    iget-object v1, p1, Lvc4;->o:Ltc4;

    .line 472
    iget-object v1, v1, Ltc4;->c:Ll34;

    .line 473
    invoke-static {v1}, Lvd4;->a(Ll34;)Lm24;

    move-result-object v1

    .line 474
    iget-object p1, p1, Lvc4;->r:Ljava/lang/Integer;

    .line 475
    const-string v2, "type.googleapis.com/google.crypto.tink.RsaSsaPkcs1PublicKey"

    .line 476
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 477
    :sswitch_1
    check-cast p1, Lmc4;

    .line 478
    invoke-static {p1}, Lqd4;->c(Lmc4;)Lt94;

    move-result-object p0

    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->m:Ll24;

    .line 479
    iget-object v1, p1, Lmc4;->o:Lic4;

    .line 480
    iget-object v1, v1, Lic4;->a:Lh34;

    .line 481
    invoke-static {v1}, Lqd4;->a(Lh34;)Lm24;

    move-result-object v1

    .line 482
    iget-object p1, p1, Lmc4;->r:Ljava/lang/Integer;

    .line 483
    const-string v2, "type.googleapis.com/google.crypto.tink.Ed25519PublicKey"

    .line 484
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 485
    :sswitch_2
    check-cast p1, Lgc4;

    .line 486
    invoke-static {p1}, Lod4;->f(Lgc4;)Lo94;

    move-result-object p0

    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->m:Ll24;

    .line 487
    iget-object v1, p1, Lgc4;->o:Lec4;

    .line 488
    iget-object v1, v1, Lec4;->d:Ld34;

    .line 489
    invoke-static {v1}, Lod4;->a(Ld34;)Lm24;

    move-result-object v1

    .line 490
    iget-object p1, p1, Lgc4;->r:Ljava/lang/Integer;

    .line 491
    const-string v2, "type.googleapis.com/google.crypto.tink.EcdsaPublicKey"

    .line 492
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 493
    :sswitch_3
    check-cast p1, Lf74;

    sget-object p0, Lq74;->a:Lkd1;

    .line 494
    invoke-static {}, Ly94;->C()Lv94;

    move-result-object p0

    .line 495
    iget-object v1, p1, Lf74;->o:Li74;

    .line 496
    invoke-static {}, Lca4;->A()Lba4;

    move-result-object v2

    .line 497
    iget v3, v1, Li74;->b:I

    .line 498
    invoke-virtual {v2}, Lkg4;->c()V

    .line 499
    iget-object v4, v2, Lkg4;->i:Lng4;

    .line 500
    check-cast v4, Lca4;

    invoke-virtual {v4, v3}, Lca4;->D(I)V

    .line 501
    sget-object v3, Lq74;->a:Lkd1;

    .line 502
    iget-object v1, v1, Li74;->d:Lh74;

    .line 503
    invoke-virtual {v3, v1}, Lkd1;->b(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v1

    check-cast v1, Lu94;

    .line 504
    invoke-virtual {v2}, Lkg4;->c()V

    iget-object v3, v2, Lkg4;->i:Lng4;

    .line 505
    check-cast v3, Lca4;

    invoke-virtual {v3, v1}, Lca4;->C(Lu94;)V

    .line 506
    invoke-virtual {v2}, Lkg4;->d()Lng4;

    move-result-object v1

    check-cast v1, Lca4;

    .line 507
    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v2, p0, Lkg4;->i:Lng4;

    .line 508
    check-cast v2, Ly94;

    invoke-virtual {v2, v1}, Ly94;->E(Lca4;)V

    .line 509
    iget-object v1, p1, Lf74;->p:Lf53;

    .line 510
    iget-object v1, v1, Lf53;->i:Ljava/lang/Object;

    check-cast v1, Lxe4;

    .line 511
    invoke-virtual {v1}, Lxe4;->b()[B

    move-result-object v1

    .line 512
    array-length v2, v1

    .line 513
    invoke-static {v0, v2, v1}, Lyf4;->t(II[B)Lwf4;

    move-result-object v0

    .line 514
    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v1, p0, Lkg4;->i:Lng4;

    .line 515
    check-cast v1, Ly94;

    invoke-virtual {v1, v0}, Ly94;->F(Lyf4;)V

    .line 516
    invoke-virtual {p0}, Lkg4;->d()Lng4;

    move-result-object p0

    check-cast p0, Ly94;

    .line 517
    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->k:Ll24;

    .line 518
    iget-object v1, p1, Lf74;->o:Li74;

    .line 519
    iget-object v1, v1, Li74;->c:Ll24;

    .line 520
    invoke-static {v1}, Lq74;->a(Ll24;)Lm24;

    move-result-object v1

    .line 521
    iget-object p1, p1, Lf74;->r:Ljava/lang/Integer;

    .line 522
    const-string v2, "type.googleapis.com/google.crypto.tink.HmacKey"

    .line 523
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 524
    :sswitch_4
    check-cast p1, Lz54;

    .line 525
    iget-object p0, p1, Lz54;->o:Log;

    return-object p0

    .line 526
    :sswitch_5
    check-cast p1, Lr34;

    sget-object p0, Lv44;->a:Ll64;

    .line 527
    invoke-static {}, Lf94;->B()Le94;

    move-result-object p0

    .line 528
    iget-object v1, p1, Lr34;->p:Lf53;

    .line 529
    iget-object v1, v1, Lf53;->i:Ljava/lang/Object;

    check-cast v1, Lxe4;

    .line 530
    invoke-virtual {v1}, Lxe4;->b()[B

    move-result-object v1

    .line 531
    array-length v2, v1

    .line 532
    invoke-static {v0, v2, v1}, Lyf4;->t(II[B)Lwf4;

    move-result-object v0

    .line 533
    invoke-virtual {p0}, Lkg4;->c()V

    .line 534
    iget-object v1, p0, Lkg4;->i:Lng4;

    .line 535
    check-cast v1, Lf94;

    invoke-virtual {v1, v0}, Lf94;->C(Lyf4;)V

    .line 536
    invoke-virtual {p0}, Lkg4;->d()Lng4;

    move-result-object p0

    check-cast p0, Lf94;

    .line 537
    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->k:Ll24;

    .line 538
    iget-object v1, p1, Lr34;->o:Lt34;

    .line 539
    iget-object v1, v1, Lt34;->a:Ll24;

    .line 540
    invoke-static {v1}, Lv44;->a(Ll24;)Lm24;

    move-result-object v1

    .line 541
    iget-object p1, p1, Lr34;->r:Ljava/lang/Integer;

    .line 542
    const-string v2, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    .line 543
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    .line 544
    :sswitch_6
    check-cast p1, Lf34;

    sget-object p0, Lo44;->a:Ll64;

    .line 545
    invoke-static {}, Lp84;->C()Lo84;

    move-result-object p0

    .line 546
    iget-object v1, p1, Lf34;->o:Li34;

    .line 547
    invoke-static {}, Lt84;->z()Ls84;

    move-result-object v2

    .line 548
    iget v1, v1, Li34;->b:I

    .line 549
    invoke-virtual {v2}, Lkg4;->c()V

    .line 550
    iget-object v3, v2, Lkg4;->i:Lng4;

    .line 551
    check-cast v3, Lt84;

    invoke-virtual {v3, v1}, Lt84;->B(I)V

    .line 552
    invoke-virtual {v2}, Lkg4;->d()Lng4;

    move-result-object v1

    check-cast v1, Lt84;

    .line 553
    invoke-virtual {p0}, Lkg4;->c()V

    .line 554
    iget-object v2, p0, Lkg4;->i:Lng4;

    .line 555
    check-cast v2, Lp84;

    invoke-virtual {v2, v1}, Lp84;->D(Lt84;)V

    .line 556
    iget-object v1, p1, Lf34;->p:Lf53;

    .line 557
    iget-object v1, v1, Lf53;->i:Ljava/lang/Object;

    check-cast v1, Lxe4;

    .line 558
    invoke-virtual {v1}, Lxe4;->b()[B

    move-result-object v1

    .line 559
    array-length v2, v1

    .line 560
    invoke-static {v0, v2, v1}, Lyf4;->t(II[B)Lwf4;

    move-result-object v0

    .line 561
    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v1, p0, Lkg4;->i:Lng4;

    .line 562
    check-cast v1, Lp84;

    invoke-virtual {v1, v0}, Lp84;->E(Lyf4;)V

    .line 563
    invoke-virtual {p0}, Lkg4;->d()Lng4;

    move-result-object p0

    check-cast p0, Lp84;

    .line 564
    invoke-virtual {p0}, Lqf4;->a()Lwf4;

    move-result-object p0

    sget-object v0, Ll24;->k:Ll24;

    .line 565
    iget-object v1, p1, Lf34;->o:Li34;

    .line 566
    iget-object v1, v1, Li34;->c:Lh34;

    .line 567
    invoke-static {v1}, Lo44;->a(Lh34;)Lm24;

    move-result-object v1

    .line 568
    iget-object p1, p1, Lf34;->r:Ljava/lang/Integer;

    .line 569
    const-string v2, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    .line 570
    invoke-static {v2, p0, v0, v1, p1}, Log;->p(Ljava/lang/String;Lyf4;Ll24;Lm24;Ljava/lang/Integer;)Log;

    move-result-object p0

    return-object p0

    nop

    :sswitch_data_0
    .sparse-switch
        0x5 -> :sswitch_6
        0x9 -> :sswitch_5
        0xd -> :sswitch_4
        0x11 -> :sswitch_3
        0x16 -> :sswitch_2
        0x18 -> :sswitch_1
        0x1a -> :sswitch_0
    .end sparse-switch
.end method

.method public e(Lk24;)Loo4;
    .locals 3

    iget p0, p0, La44;->h:I

    sparse-switch p0, :sswitch_data_0

    check-cast p1, Li44;

    sget-object p0, Ld54;->a:Ll64;

    iget-object p0, p1, Li44;->a:Lh34;

    sget-object v0, Lh34;->f:Lh34;

    if-eq p0, v0, :cond_1

    sget-object v0, Lh34;->g:Lh34;

    if-ne p0, v0, :cond_0

    sget-object p0, Lm24;->f:Lm24;

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    iget-object p0, p0, Lh34;->b:Ljava/lang/String;

    const-string v0, "Unable to serialize variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    sget-object p0, Lm24;->d:Lm24;

    :goto_0
    invoke-static {}, Lvb4;->B()Lub4;

    move-result-object v0

    invoke-static {}, Lzb4;->z()Lwb4;

    move-result-object v1

    iget p1, p1, Li44;->b:I

    invoke-virtual {v1}, Lkg4;->c()V

    iget-object v2, v1, Lkg4;->i:Lng4;

    check-cast v2, Lzb4;

    invoke-virtual {v2, p1}, Lzb4;->B(I)V

    invoke-virtual {v1}, Lkg4;->d()Lng4;

    move-result-object p1

    check-cast p1, Lzb4;

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Lvb4;

    invoke-virtual {v1, p1}, Lvb4;->C(Lzb4;)V

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object p1

    check-cast p1, Lvb4;

    invoke-virtual {p1}, Lqf4;->a()Lwf4;

    move-result-object p1

    const-string v0, "type.googleapis.com/google.crypto.tink.XAesGcmKey"

    invoke-static {v0, p0, p1}, Loo4;->w(Ljava/lang/String;Lm24;Lyf4;)Loo4;

    move-result-object p0

    return-object p0

    :sswitch_0
    check-cast p1, Lm34;

    sget-object p0, Lq44;->a:Ll64;

    iget-object p0, p1, Lm34;->b:Ll34;

    invoke-static {p0}, Lq44;->a(Ll34;)Lm24;

    move-result-object p0

    invoke-static {}, Lz84;->B()Ly84;

    move-result-object v0

    iget p1, p1, Lm34;->a:I

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Lz84;

    invoke-virtual {v1, p1}, Lz84;->C(I)V

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object p1

    check-cast p1, Lz84;

    invoke-virtual {p1}, Lqf4;->a()Lwf4;

    move-result-object p1

    const-string v0, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    invoke-static {v0, p0, p1}, Loo4;->w(Ljava/lang/String;Lm24;Lyf4;)Loo4;

    move-result-object p0

    return-object p0

    :sswitch_1
    check-cast p1, Lz34;

    sget-object p0, Lb44;->a:Ll64;

    iget-object p0, p1, Lz34;->b:Lm24;

    invoke-static {p0}, Lb44;->a(Lm24;)Lm24;

    move-result-object p0

    invoke-static {}, Lta4;->A()Lsa4;

    move-result-object v0

    iget-object p1, p1, Lz34;->a:Ljava/lang/String;

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v1, v0, Lkg4;->i:Lng4;

    check-cast v1, Lta4;

    invoke-virtual {v1, p1}, Lta4;->C(Ljava/lang/String;)V

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object p1

    check-cast p1, Lta4;

    invoke-virtual {p1}, Lqf4;->a()Lwf4;

    move-result-object p1

    const-string v0, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-static {v0, p0, p1}, Loo4;->w(Ljava/lang/String;Lm24;Lyf4;)Loo4;

    move-result-object p0

    return-object p0

    nop

    :sswitch_data_0
    .sparse-switch
        0x1 -> :sswitch_1
        0x7 -> :sswitch_0
    .end sparse-switch
.end method
