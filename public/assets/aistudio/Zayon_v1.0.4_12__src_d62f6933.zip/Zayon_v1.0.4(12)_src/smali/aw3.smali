.class public final Law3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lyv3;


# instance fields
.field public final h:Lud;

.field public volatile i:Lyv3;

.field public j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lyv3;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lud;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Law3;->h:Lud;

    iput-object p1, p0, Law3;->i:Lyv3;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Law3;->i:Lyv3;

    if-eqz v0, :cond_1

    iget-object v0, p0, Law3;->h:Lud;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Law3;->i:Lyv3;

    if-eqz v1, :cond_0

    iget-object v1, p0, Law3;->i:Lyv3;

    invoke-interface {v1}, Lyv3;->a()Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Law3;->j:Ljava/lang/Object;

    const/4 v2, 0x0

    iput-object v2, p0, Law3;->i:Lyv3;

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    monitor-exit v0

    goto :goto_1

    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    :cond_1
    :goto_1
    iget-object p0, p0, Law3;->j:Ljava/lang/Object;

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Law3;->i:Lyv3;

    if-nez v0, :cond_0

    iget-object p0, p0, Law3;->j:Ljava/lang/Object;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x19

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "<supplier that returned "

    const-string v2, ">"

    invoke-static {v1, v0, p0, v2}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    add-int/lit8 v0, v0, 0x13

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v0, "Suppliers.memoize("

    const-string v2, ")"

    invoke-static {v1, v0, p0, v2}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
