.class public final La00;
.super Ljava/lang/Object;


# instance fields
.field public a:La;

.field public b:Lxt3;

.field public c:Ls93;

.field public d:Z

.field public e:Z

.field public f:I

.field public g:[B

.field public h:[B

.field public i:[B

.field public j:[B

.field public k:[B

.field public l:[B

.field public m:[B

.field public n:[B

.field public o:[B

.field public p:[B

.field public q:[B

.field public r:I

.field public s:I

.field public t:J

.field public u:[B

.field public v:I

.field public w:J

.field public x:J


# virtual methods
.method public final a()V
    .locals 1

    iget-boolean v0, p0, La00;->e:Z

    if-nez v0, :cond_1

    iget-boolean p0, p0, La00;->d:Z

    if-eqz p0, :cond_0

    const-string p0, "GCM cipher cannot be reused for encryption"

    :goto_0
    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void

    :cond_0
    const-string p0, "GCM cipher needs to be initialised"

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final b([BII[B)V
    .locals 6

    array-length v0, p4

    sub-int/2addr v0, p3

    const/16 v1, 0x10

    if-lt v0, v1, :cond_2

    iget-wide v2, p0, La00;->t:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-nez v0, :cond_0

    invoke-virtual {p0}, La00;->g()V

    :cond_0
    new-array v0, v1, [B

    invoke-virtual {p0, v0}, La00;->f([B)V

    iget-object v2, p0, La00;->n:[B

    invoke-static {p2, v2, p1}, Llv0;->i(I[B[B)V

    iget-object v3, p0, La00;->b:Lxt3;

    invoke-virtual {v3, v2}, Lxt3;->t([B)V

    const/4 v2, 0x0

    :cond_1
    add-int v3, p3, v2

    aget-byte v4, v0, v2

    add-int v5, p2, v2

    aget-byte v5, p1, v5

    xor-int/2addr v4, v5

    int-to-byte v4, v4

    aput-byte v4, p4, v3

    add-int/lit8 v3, v2, 0x1

    add-int v4, p3, v3

    aget-byte v5, v0, v3

    add-int/2addr v3, p2

    aget-byte v3, p1, v3

    xor-int/2addr v3, v5

    int-to-byte v3, v3

    aput-byte v3, p4, v4

    add-int/lit8 v3, v2, 0x2

    add-int v4, p3, v3

    aget-byte v5, v0, v3

    add-int/2addr v3, p2

    aget-byte v3, p1, v3

    xor-int/2addr v3, v5

    int-to-byte v3, v3

    aput-byte v3, p4, v4

    add-int/lit8 v3, v2, 0x3

    add-int v4, p3, v3

    aget-byte v5, v0, v3

    add-int/2addr v3, p2

    aget-byte v3, p1, v3

    xor-int/2addr v3, v5

    int-to-byte v3, v3

    aput-byte v3, p4, v4

    add-int/lit8 v2, v2, 0x4

    if-lt v2, v1, :cond_1

    iget-wide p1, p0, La00;->t:J

    const-wide/16 p3, 0x10

    add-long/2addr p1, p3

    iput-wide p1, p0, La00;->t:J

    return-void

    :cond_2
    new-instance p0, Luj0;

    const-string p1, "Output buffer too short"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final c(I[B)I
    .locals 35

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    iget-object v3, v0, La00;->a:La;

    invoke-virtual {v0}, La00;->a()V

    iget-wide v4, v0, La00;->t:J

    const-wide/16 v6, 0x0

    cmp-long v4, v4, v6

    if-nez v4, :cond_0

    invoke-virtual {v0}, La00;->g()V

    :cond_0
    iget v4, v0, La00;->s:I

    iget-boolean v5, v0, La00;->d:Z

    iget v8, v0, La00;->f:I

    const-string v9, "Output buffer too short"

    if-eqz v5, :cond_2

    array-length v5, v2

    sub-int/2addr v5, v1

    add-int/2addr v8, v4

    if-lt v5, v8, :cond_1

    goto :goto_0

    :cond_1
    new-instance v0, Luj0;

    invoke-direct {v0, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    if-lt v4, v8, :cond_1a

    sub-int/2addr v4, v8

    array-length v5, v2

    sub-int/2addr v5, v1

    if-lt v5, v4, :cond_19

    :goto_0
    const/16 v5, 0x10

    const/4 v8, 0x0

    if-lez v4, :cond_6

    iget-object v9, v0, La00;->l:[B

    new-array v10, v5, [B

    invoke-virtual {v0, v10}, La00;->f([B)V

    iget-boolean v11, v0, La00;->d:Z

    if-eqz v11, :cond_4

    move v11, v4

    :goto_1
    add-int/lit8 v11, v11, -0x1

    if-ltz v11, :cond_3

    aget-byte v12, v9, v11

    aget-byte v13, v10, v11

    xor-int/2addr v12, v13

    int-to-byte v12, v12

    aput-byte v12, v9, v11

    goto :goto_1

    :cond_3
    iget-object v10, v0, La00;->n:[B

    invoke-virtual {v0, v10, v8, v4, v9}, La00;->e([BII[B)V

    goto :goto_3

    :cond_4
    iget-object v11, v0, La00;->n:[B

    invoke-virtual {v0, v11, v8, v4, v9}, La00;->e([BII[B)V

    move v11, v4

    :goto_2
    add-int/lit8 v11, v11, -0x1

    if-ltz v11, :cond_5

    aget-byte v12, v9, v11

    aget-byte v13, v10, v11

    xor-int/2addr v12, v13

    int-to-byte v12, v12

    aput-byte v12, v9, v11

    goto :goto_2

    :cond_5
    :goto_3
    invoke-static {v9, v8, v2, v1, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-wide v9, v0, La00;->t:J

    int-to-long v11, v4

    add-long/2addr v9, v11

    iput-wide v9, v0, La00;->t:J

    :cond_6
    iget-wide v9, v0, La00;->w:J

    iget v11, v0, La00;->v:I

    int-to-long v12, v11

    add-long/2addr v9, v12

    iput-wide v9, v0, La00;->w:J

    iget-wide v12, v0, La00;->x:J

    cmp-long v9, v9, v12

    const-wide/16 v12, 0x8

    if-lez v9, :cond_f

    if-lez v11, :cond_7

    iget-object v9, v0, La00;->o:[B

    iget-object v14, v0, La00;->u:[B

    invoke-virtual {v0, v9, v8, v11, v14}, La00;->e([BII[B)V

    :cond_7
    iget-wide v14, v0, La00;->x:J

    cmp-long v9, v14, v6

    if-lez v9, :cond_8

    iget-object v9, v0, La00;->o:[B

    iget-object v11, v0, La00;->p:[B

    invoke-static {v9, v11}, Llv0;->j([B[B)V

    :cond_8
    iget-wide v14, v0, La00;->t:J

    mul-long/2addr v14, v12

    const-wide/16 v16, 0x7f

    add-long v14, v14, v16

    const/4 v9, 0x7

    ushr-long/2addr v14, v9

    new-array v11, v5, [B

    move/from16 v16, v9

    iget-object v9, v0, La00;->c:Ls93;

    move-wide/from16 v17, v12

    const/4 v12, 0x4

    const/4 v13, 0x2

    if-nez v9, :cond_9

    new-instance v9, Ls93;

    invoke-direct {v9, v12}, Ls93;-><init>(I)V

    iput-object v9, v0, La00;->c:Ls93;

    move-wide/from16 v19, v6

    iget-object v6, v0, La00;->j:[B

    new-array v7, v13, [J

    invoke-static {v6, v7}, Ltb1;->b([B[J)V

    iput-object v7, v9, Ls93;->i:Ljava/lang/Object;

    goto :goto_4

    :cond_9
    move-wide/from16 v19, v6

    :goto_4
    iget-object v6, v0, La00;->c:Ls93;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-array v7, v13, [J

    const-wide/high16 v21, -0x8000000000000000L

    aput-wide v21, v7, v8

    cmp-long v9, v14, v19

    if-lez v9, :cond_c

    new-array v9, v13, [J

    iget-object v6, v6, Ls93;->i:Ljava/lang/Object;

    check-cast v6, [J

    aget-wide v21, v6, v8

    aput-wide v21, v9, v8

    const/16 v21, 0x1

    aget-wide v22, v6, v21

    aput-wide v22, v9, v21

    :goto_5
    const-wide/16 v22, 0x1

    and-long v22, v14, v22

    cmp-long v6, v22, v19

    if-eqz v6, :cond_a

    invoke-static {v7, v9}, Llv0;->g([J[J)V

    :cond_a
    new-array v6, v12, [J

    move-object/from16 v23, v11

    const/16 v22, 0x8

    aget-wide v10, v9, v8

    invoke-static {v8, v10, v11, v6}, Luo2;->d(IJ[J)V

    aget-wide v10, v9, v21

    invoke-static {v13, v10, v11, v6}, Luo2;->d(IJ[J)V

    aget-wide v10, v6, v8

    aget-wide v24, v6, v21

    aget-wide v26, v6, v13

    const/16 v28, 0x3

    aget-wide v28, v6, v28

    ushr-long v30, v28, v21

    xor-long v30, v28, v30

    ushr-long v32, v28, v13

    xor-long v30, v30, v32

    ushr-long v32, v28, v16

    xor-long v30, v30, v32

    xor-long v24, v24, v30

    const/16 v6, 0x3f

    shl-long v30, v28, v6

    const/16 v32, 0x3e

    shl-long v33, v28, v32

    xor-long v30, v30, v33

    const/16 v33, 0x39

    shl-long v28, v28, v33

    xor-long v28, v30, v28

    xor-long v26, v26, v28

    ushr-long v28, v26, v21

    xor-long v28, v26, v28

    ushr-long v30, v26, v13

    xor-long v28, v28, v30

    ushr-long v30, v26, v16

    xor-long v28, v28, v30

    xor-long v10, v10, v28

    shl-long v28, v26, v6

    shl-long v30, v26, v32

    xor-long v28, v28, v30

    shl-long v26, v26, v33

    xor-long v26, v28, v26

    xor-long v24, v24, v26

    aput-wide v10, v9, v8

    aput-wide v24, v9, v21

    ushr-long v14, v14, v21

    cmp-long v6, v14, v19

    if-gtz v6, :cond_b

    goto :goto_6

    :cond_b
    move-object/from16 v11, v23

    goto :goto_5

    :cond_c
    move-object/from16 v23, v11

    const/16 v22, 0x8

    :goto_6
    move v6, v8

    move v9, v6

    :goto_7
    if-ge v6, v13, :cond_d

    aget-wide v10, v7, v6

    move-object/from16 v12, v23

    invoke-static {v9, v10, v11, v12}, Ltb1;->k(IJ[B)V

    add-int/lit8 v9, v9, 0x8

    add-int/lit8 v6, v6, 0x1

    goto :goto_7

    :cond_d
    move-object/from16 v12, v23

    iget-object v6, v0, La00;->o:[B

    new-array v7, v13, [J

    invoke-static {v6, v7}, Ltb1;->b([B[J)V

    new-array v9, v13, [J

    invoke-static {v12, v9}, Ltb1;->b([B[J)V

    invoke-static {v7, v9}, Llv0;->g([J[J)V

    move v9, v8

    move v10, v9

    :goto_8
    if-ge v9, v13, :cond_e

    aget-wide v11, v7, v9

    invoke-static {v10, v11, v12, v6}, Ltb1;->k(IJ[B)V

    add-int/lit8 v10, v10, 0x8

    add-int/lit8 v9, v9, 0x1

    goto :goto_8

    :cond_e
    iget-object v6, v0, La00;->n:[B

    iget-object v7, v0, La00;->o:[B

    invoke-static {v6, v7}, Llv0;->j([B[B)V

    goto :goto_9

    :cond_f
    move-wide/from16 v19, v6

    move-wide/from16 v17, v12

    const/16 v22, 0x8

    :goto_9
    new-array v6, v5, [B

    iget-wide v9, v0, La00;->w:J

    mul-long v9, v9, v17

    invoke-static {v8, v9, v10, v6}, Ltb1;->k(IJ[B)V

    iget-wide v9, v0, La00;->t:J

    mul-long v9, v9, v17

    move/from16 v7, v22

    invoke-static {v7, v9, v10, v6}, Ltb1;->k(IJ[B)V

    iget-object v7, v0, La00;->n:[B

    invoke-static {v7, v6}, Llv0;->j([B[B)V

    iget-object v6, v0, La00;->b:Lxt3;

    invoke-virtual {v6, v7}, Lxt3;->t([B)V

    new-array v6, v5, [B

    iget-object v7, v0, La00;->k:[B

    invoke-virtual {v3, v7, v6}, La;->c([B[B)V

    iget-object v7, v0, La00;->n:[B

    invoke-static {v6, v7}, Llv0;->j([B[B)V

    iget v7, v0, La00;->f:I

    new-array v9, v7, [B

    iput-object v9, v0, La00;->m:[B

    invoke-static {v6, v8, v9, v8, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-boolean v6, v0, La00;->d:Z

    if-eqz v6, :cond_10

    iget-object v6, v0, La00;->m:[B

    iget v7, v0, La00;->s:I

    add-int/2addr v1, v7

    iget v7, v0, La00;->f:I

    invoke-static {v6, v8, v2, v1, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v1, v0, La00;->f:I

    add-int/2addr v4, v1

    goto :goto_d

    :cond_10
    iget v1, v0, La00;->f:I

    new-array v2, v1, [B

    iget-object v6, v0, La00;->l:[B

    invoke-static {v6, v4, v2, v8, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v6, v0, La00;->m:[B

    if-eqz v6, :cond_18

    if-ne v6, v2, :cond_11

    goto :goto_d

    :cond_11
    array-length v7, v6

    if-ge v7, v1, :cond_12

    array-length v7, v6

    goto :goto_a

    :cond_12
    move v7, v1

    :goto_a
    array-length v9, v6

    xor-int/2addr v9, v1

    move v10, v8

    :goto_b
    if-eq v10, v7, :cond_13

    aget-byte v11, v6, v10

    aget-byte v12, v2, v10

    xor-int/2addr v11, v12

    or-int/2addr v9, v11

    add-int/lit8 v10, v10, 0x1

    goto :goto_b

    :cond_13
    :goto_c
    if-ge v7, v1, :cond_14

    aget-byte v6, v2, v7

    not-int v10, v6

    xor-int/2addr v6, v10

    or-int/2addr v9, v6

    add-int/lit8 v7, v7, 0x1

    goto :goto_c

    :cond_14
    if-nez v9, :cond_18

    :goto_d
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-array v1, v5, [B

    iput-object v1, v0, La00;->n:[B

    new-array v1, v5, [B

    iput-object v1, v0, La00;->o:[B

    new-array v1, v5, [B

    iput-object v1, v0, La00;->p:[B

    new-array v1, v5, [B

    iput-object v1, v0, La00;->u:[B

    iput v8, v0, La00;->v:I

    move-wide/from16 v1, v19

    iput-wide v1, v0, La00;->w:J

    iput-wide v1, v0, La00;->x:J

    iget-object v3, v0, La00;->k:[B

    invoke-static {v3}, Lgx1;->c([B)[B

    move-result-object v3

    iput-object v3, v0, La00;->q:[B

    const/4 v3, -0x2

    iput v3, v0, La00;->r:I

    iput v8, v0, La00;->s:I

    iput-wide v1, v0, La00;->t:J

    iget-object v1, v0, La00;->l:[B

    if-eqz v1, :cond_15

    invoke-static {v1, v8}, Ljava/util/Arrays;->fill([BB)V

    :cond_15
    iget-boolean v1, v0, La00;->d:Z

    if-eqz v1, :cond_16

    iput-boolean v8, v0, La00;->e:Z

    return v4

    :cond_16
    iget-object v1, v0, La00;->i:[B

    if-eqz v1, :cond_17

    array-length v2, v1

    invoke-virtual {v0, v2, v1}, La00;->h(I[B)V

    :cond_17
    return v4

    :cond_18
    new-instance v0, Lm60;

    const-string v1, "mac check in GCM failed"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_19
    new-instance v0, Luj0;

    invoke-direct {v0, v9}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1a
    new-instance v0, Lm60;

    const-string v1, "data too short"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final d([BII[B)V
    .locals 6

    array-length v0, p4

    sub-int/2addr v0, p3

    const/16 v1, 0x10

    if-lt v0, v1, :cond_1

    iget-wide v2, p0, La00;->t:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-nez v0, :cond_0

    invoke-virtual {p0}, La00;->g()V

    :cond_0
    new-array v0, v1, [B

    invoke-virtual {p0, v0}, La00;->f([B)V

    invoke-static {p2, v0, p1}, Llv0;->i(I[B[B)V

    iget-object p1, p0, La00;->n:[B

    invoke-static {p1, v0}, Llv0;->j([B[B)V

    iget-object p2, p0, La00;->b:Lxt3;

    invoke-virtual {p2, p1}, Lxt3;->t([B)V

    const/4 p1, 0x0

    invoke-static {v0, p1, p4, p3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-wide p1, p0, La00;->t:J

    const-wide/16 p3, 0x10

    add-long/2addr p1, p3

    iput-wide p1, p0, La00;->t:J

    return-void

    :cond_1
    new-instance p0, Luj0;

    const-string p1, "Output buffer too short"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final e([BII[B)V
    .locals 2

    :goto_0
    add-int/lit8 p3, p3, -0x1

    if-ltz p3, :cond_0

    aget-byte v0, p1, p3

    add-int v1, p2, p3

    aget-byte v1, p4, v1

    xor-int/2addr v0, v1

    int-to-byte v0, v0

    aput-byte v0, p1, p3

    goto :goto_0

    :cond_0
    iget-object p0, p0, La00;->b:Lxt3;

    invoke-virtual {p0, p1}, Lxt3;->t([B)V

    return-void
.end method

.method public final f([B)V
    .locals 4

    iget v0, p0, La00;->r:I

    if-eqz v0, :cond_0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La00;->r:I

    iget-object v0, p0, La00;->q:[B

    const/16 v1, 0xf

    aget-byte v2, v0, v1

    and-int/lit16 v2, v2, 0xff

    add-int/lit8 v2, v2, 0x1

    int-to-byte v3, v2

    aput-byte v3, v0, v1

    ushr-int/lit8 v1, v2, 0x8

    const/16 v2, 0xe

    aget-byte v3, v0, v2

    and-int/lit16 v3, v3, 0xff

    add-int/2addr v1, v3

    int-to-byte v3, v1

    aput-byte v3, v0, v2

    ushr-int/lit8 v1, v1, 0x8

    const/16 v2, 0xd

    aget-byte v3, v0, v2

    and-int/lit16 v3, v3, 0xff

    add-int/2addr v1, v3

    int-to-byte v3, v1

    aput-byte v3, v0, v2

    ushr-int/lit8 v1, v1, 0x8

    const/16 v2, 0xc

    aget-byte v3, v0, v2

    and-int/lit16 v3, v3, 0xff

    add-int/2addr v1, v3

    int-to-byte v1, v1

    aput-byte v1, v0, v2

    iget-object p0, p0, La00;->a:La;

    invoke-virtual {p0, v0, p1}, La;->c([B[B)V

    return-void

    :cond_0
    const-string p0, "Attempt to process too many blocks"

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void
.end method

.method public final g()V
    .locals 9

    iget-wide v0, p0, La00;->w:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/16 v1, 0x10

    const/4 v4, 0x0

    if-lez v0, :cond_0

    iget-object v0, p0, La00;->o:[B

    iget-object v5, p0, La00;->p:[B

    invoke-static {v0, v4, v5, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-wide v5, p0, La00;->w:J

    iput-wide v5, p0, La00;->x:J

    :cond_0
    iget v0, p0, La00;->v:I

    if-lez v0, :cond_1

    iget-object v5, p0, La00;->p:[B

    iget-object v6, p0, La00;->u:[B

    invoke-virtual {p0, v5, v4, v0, v6}, La00;->e([BII[B)V

    iget-wide v5, p0, La00;->x:J

    iget v0, p0, La00;->v:I

    int-to-long v7, v0

    add-long/2addr v5, v7

    iput-wide v5, p0, La00;->x:J

    :cond_1
    iget-wide v5, p0, La00;->x:J

    cmp-long v0, v5, v2

    if-lez v0, :cond_2

    iget-object v0, p0, La00;->p:[B

    iget-object p0, p0, La00;->n:[B

    invoke-static {v0, v4, p0, v4, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_2
    return-void
.end method

.method public final h(I[B)V
    .locals 8

    iget-object v0, p0, La00;->b:Lxt3;

    invoke-virtual {p0}, La00;->a()V

    iget v1, p0, La00;->v:I

    const/4 v2, 0x0

    const-wide/16 v3, 0x10

    if-lez v1, :cond_1

    rsub-int/lit8 v5, v1, 0x10

    iget-object v6, p0, La00;->u:[B

    if-ge p1, v5, :cond_0

    invoke-static {p2, v2, v6, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p2, p0, La00;->v:I

    add-int/2addr p2, p1

    iput p2, p0, La00;->v:I

    return-void

    :cond_0
    invoke-static {p2, v2, v6, v1, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p0, La00;->o:[B

    iget-object v6, p0, La00;->u:[B

    invoke-static {v1, v6}, Llv0;->j([B[B)V

    invoke-virtual {v0, v1}, Lxt3;->t([B)V

    iget-wide v6, p0, La00;->w:J

    add-long/2addr v6, v3

    iput-wide v6, p0, La00;->w:J

    sub-int/2addr p1, v5

    goto :goto_0

    :cond_1
    move v5, v2

    :goto_0
    add-int/2addr p1, v5

    add-int/lit8 v1, p1, -0x10

    :goto_1
    if-gt v5, v1, :cond_2

    iget-object v6, p0, La00;->o:[B

    invoke-static {v5, v6, p2}, Llv0;->i(I[B[B)V

    invoke-virtual {v0, v6}, Lxt3;->t([B)V

    iget-wide v6, p0, La00;->w:J

    add-long/2addr v6, v3

    iput-wide v6, p0, La00;->w:J

    add-int/lit8 v5, v5, 0x10

    goto :goto_1

    :cond_2
    sub-int/2addr p1, v5

    iput p1, p0, La00;->v:I

    iget-object p0, p0, La00;->u:[B

    invoke-static {p2, v5, p0, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method
