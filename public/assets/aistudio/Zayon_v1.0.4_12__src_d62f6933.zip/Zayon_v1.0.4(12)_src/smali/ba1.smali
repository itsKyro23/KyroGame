.class public final enum Lba1;
.super Lfa1;
.source "SourceFile"
