.class public final Lbd3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ltk4;


# instance fields
.field public final a:Lxk4;

.field public final b:Lxk4;


# direct methods
.method public constructor <init>(Lfn2;Lsk4;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbd3;->a:Lxk4;

    iput-object p2, p0, Lbd3;->b:Lxk4;

    return-void
.end method


# virtual methods
.method public final a()Lpb3;
    .locals 3

    iget-object v0, p0, Lbd3;->a:Lxk4;

    check-cast v0, Lfn2;

    invoke-virtual {v0}, Lfn2;->a()Landroid/content/Context;

    move-result-object v0

    iget-object p0, p0, Lbd3;->b:Lxk4;

    invoke-interface {p0}, Lxk4;->d()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/Intent;

    new-instance v1, Lpb3;

    const/4 v2, 0x2

    invoke-direct {v1, v0, v2, p0}, Lpb3;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    return-object v1
.end method

.method public final bridge synthetic d()Ljava/lang/Object;
    .locals 0

    invoke-virtual {p0}, Lbd3;->a()Lpb3;

    move-result-object p0

    return-object p0
.end method
