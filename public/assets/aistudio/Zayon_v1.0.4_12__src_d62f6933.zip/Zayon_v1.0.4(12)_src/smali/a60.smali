.class public abstract La60;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lnj1;


# static fields
.field public static h:Landroid/content/Context;

.field public static i:Ljava/lang/Boolean;

.field public static final j:Lye;

.field public static final k:Lna1;

.field public static final l:Lna1;

.field public static final m:Lna1;

.field public static final n:Lna1;

.field public static final o:Lna1;

.field public static final p:Lna1;

.field public static final q:Lna1;

.field public static final r:Ls12;

.field public static final s:Lcx2;

.field public static final t:Ldd3;

.field public static u:Z

.field public static final synthetic v:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 4

    new-instance v0, Lye;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La60;->j:Lye;

    new-instance v0, Lna1;

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v3, v1, v2}, Lna1;-><init>(III)V

    sput-object v0, La60;->k:Lna1;

    new-instance v0, Lna1;

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v2, v3, v1}, Lna1;-><init>(III)V

    sput-object v0, La60;->l:Lna1;

    new-instance v0, Lna1;

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, v3, v1, v2}, Lna1;-><init>(III)V

    sput-object v0, La60;->m:Lna1;

    new-instance v0, Lna1;

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v2, v3, v1}, Lna1;-><init>(III)V

    sput-object v0, La60;->n:Lna1;

    new-instance v0, Lna1;

    const/4 v1, 0x4

    const/16 v2, 0x8

    invoke-direct {v0, v3, v2, v1}, Lna1;-><init>(III)V

    sput-object v0, La60;->o:Lna1;

    new-instance v0, Lna1;

    const/16 v1, 0x9

    const/4 v3, 0x5

    invoke-direct {v0, v2, v1, v3}, Lna1;-><init>(III)V

    sput-object v0, La60;->p:Lna1;

    new-instance v0, Lna1;

    const/16 v1, 0xc

    const/4 v2, 0x6

    const/16 v3, 0xb

    invoke-direct {v0, v3, v1, v2}, Lna1;-><init>(III)V

    sput-object v0, La60;->q:Lna1;

    new-instance v0, Ls12;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Ls12;-><init>(I)V

    sput-object v0, La60;->r:Ls12;

    new-instance v0, Lcx2;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lcx2;-><init>(I)V

    sput-object v0, La60;->s:Lcx2;

    new-instance v0, Ldd3;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, Ldd3;-><init>(I)V

    sput-object v0, La60;->t:Ldd3;

    return-void
.end method

.method public static A(Ljava/util/concurrent/Executor;La14;)Ljava/util/concurrent/Executor;
    .locals 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lz04;->h:Lz04;

    if-ne p0, v0, :cond_0

    return-object p0

    :cond_0
    new-instance v0, Ll14;

    invoke-direct {v0, p0, p1}, Ll14;-><init>(Ljava/util/concurrent/Executor;La14;)V

    return-object v0
.end method

.method public static B(ZLjava/lang/String;J)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method

.method public static C(ZLjava/lang/String;Ljava/lang/Object;)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    filled-new-array {p2}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method

.method public static D(Z)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lb;->a()V

    return-void
.end method

.method public static E(Ljava/lang/String;Z)V
    .locals 0

    if-eqz p1, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void
.end method

.method public static F(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {p1}, Ls40;->l(Ljava/lang/String;)V

    return-void
.end method

.method public static G(II)V
    .locals 2

    if-ltz p0, :cond_1

    if-lt p0, p1, :cond_0

    goto :goto_0

    :cond_0
    return-void

    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const-string v1, "index"

    if-ltz p0, :cond_3

    if-gez p1, :cond_2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0xf

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "negative size: "

    invoke-static {p1, p0, v0}, Loj;->i(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void

    :cond_2
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {v1, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%s (%s) must be less than size (%s)"

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_3
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {v1, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%s (%s) must not be negative"

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    :goto_1
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static H(II)V
    .locals 1

    if-ltz p0, :cond_0

    if-gt p0, p1, :cond_0

    return-void

    :cond_0
    const-string v0, "index"

    invoke-static {p0, p1, v0}, La60;->J(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ls40;->s(Ljava/lang/String;)V

    return-void
.end method

.method public static I(III)V
    .locals 1

    if-ltz p0, :cond_1

    if-lt p1, p0, :cond_1

    if-le p1, p2, :cond_0

    goto :goto_0

    :cond_0
    return-void

    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    if-ltz p0, :cond_4

    if-gt p0, p2, :cond_4

    if-ltz p1, :cond_3

    if-le p1, p2, :cond_2

    goto :goto_1

    :cond_2
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p1, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "end index (%s) must not be less than start index (%s)"

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_3
    :goto_1
    const-string p0, "end index"

    invoke-static {p1, p2, p0}, La60;->J(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_4
    const-string p1, "start index"

    invoke-static {p0, p2, p1}, La60;->J(IILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_2
    invoke-direct {v0, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static J(IILjava/lang/String;)Ljava/lang/String;
    .locals 0

    if-gez p0, :cond_0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p2, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%s (%s) must not be negative"

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    if-ltz p1, :cond_1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p2, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "%s (%s) must not be greater than size (%s)"

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance p2, Ljava/lang/StringBuilder;

    add-int/lit8 p0, p0, 0xf

    invoke-direct {p2, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string p0, "negative size: "

    invoke-static {p1, p0, p2}, Loj;->i(ILjava/lang/String;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static final f(Lsj;Lsj;Z)Lsj;
    .locals 3

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    new-instance v0, Lrg;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lrg;-><init>(I)V

    invoke-interface {p0, p2, v0}, Lsj;->e(Ljava/lang/Object;Loz;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    new-instance v2, Lrg;

    invoke-direct {v2, v1}, Lrg;-><init>(I)V

    invoke-interface {p1, p2, v2}, Lsj;->e(Ljava/lang/Object;Loz;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-nez v0, :cond_0

    if-nez p2, :cond_0

    invoke-interface {p0, p1}, Lsj;->f(Lsj;)Lsj;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance v0, Lrg;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lrg;-><init>(I)V

    sget-object v1, Lus;->h:Lus;

    invoke-interface {p0, v1, v0}, Lsj;->e(Ljava/lang/Object;Loz;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lsj;

    if-eqz p2, :cond_1

    check-cast p1, Lsj;

    new-instance p2, Lrg;

    const/4 v0, 0x4

    invoke-direct {p2, v0}, Lrg;-><init>(I)V

    invoke-interface {p1, v1, p2}, Lsj;->e(Ljava/lang/Object;Loz;)Ljava/lang/Object;

    move-result-object p1

    :cond_1
    check-cast p1, Lsj;

    invoke-interface {p0, p1}, Lsj;->f(Lsj;)Lsj;

    move-result-object p0

    return-object p0
.end method

.method public static g(Lk6;)Landroid/content/Intent;
    .locals 2

    invoke-virtual {p0}, Landroid/app/Activity;->getParentActivityIntent()Landroid/content/Intent;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object v0

    invoke-static {p0, v0}, La60;->i(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    new-instance v1, Landroid/content/ComponentName;

    invoke-direct {v1, p0, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    :try_start_1
    invoke-static {p0, v1}, La60;->i(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_2

    invoke-static {v1}, Landroid/content/Intent;->makeMainActivity(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :cond_2
    new-instance p0, Landroid/content/Intent;

    invoke-direct {p0}, Landroid/content/Intent;-><init>()V

    invoke-virtual {p0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p0
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    return-object p0

    :catch_0
    :goto_0
    const/4 p0, 0x0

    return-object p0

    :catch_1
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static h(Lk6;Landroid/content/ComponentName;)Landroid/content/Intent;
    .locals 2

    invoke-static {p0, p1}, La60;->i(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance v1, Landroid/content/ComponentName;

    invoke-virtual {p1}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p0, v1}, La60;->i(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_1

    invoke-static {v1}, Landroid/content/Intent;->makeMainActivity(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :cond_1
    new-instance p0, Landroid/content/Intent;

    invoke-direct {p0}, Landroid/content/Intent;-><init>()V

    invoke-virtual {p0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p0

    return-object p0
.end method

.method public static i(Landroid/content/Context;Landroid/content/ComponentName;)Ljava/lang/String;
    .locals 3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1d

    if-lt v1, v2, :cond_0

    const v1, 0x100c0280

    goto :goto_0

    :cond_0
    const v1, 0xc0280

    :goto_0
    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    move-result-object p1

    iget-object v0, p1, Landroid/content/pm/ActivityInfo;->parentActivityName:Ljava/lang/String;

    if-eqz v0, :cond_1

    return-object v0

    :cond_1
    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->metaData:Landroid/os/Bundle;

    const/4 v0, 0x0

    if-nez p1, :cond_2

    return-object v0

    :cond_2
    const-string v1, "android.support.PARENT_ACTIVITY"

    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_3

    return-object v0

    :cond_3
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/16 v1, 0x2e

    if-ne v0, v1, :cond_4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_4
    return-object p1
.end method

.method public static declared-synchronized j(Landroid/content/Context;)Z
    .locals 3

    const-class v0, La60;

    monitor-enter v0

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    sget-object v1, La60;->h:Landroid/content/Context;

    if-eqz v1, :cond_1

    sget-object v2, La60;->i:Ljava/lang/Boolean;

    if-eqz v2, :cond_1

    if-eq v1, p0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return p0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    :try_start_1
    sput-object v1, La60;->i:Ljava/lang/Boolean;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/pm/PackageManager;->isInstantApp()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    sput-object v1, La60;->i:Ljava/lang/Boolean;

    sput-object p0, La60;->h:Landroid/content/Context;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    monitor-exit v0

    return p0

    :goto_1
    :try_start_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public static final l(Lak;Lsj;)Lsj;
    .locals 1

    invoke-interface {p0}, Lak;->a()Lsj;

    move-result-object p0

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, La60;->f(Lsj;Lsj;Z)Lsj;

    move-result-object p0

    sget-object p1, Lvq;->a:Lxo;

    if-eq p0, p1, :cond_0

    sget-object v0, Lt30;->h:Lt30;

    invoke-interface {p0, v0}, Lsj;->h(Lrj;)Lqj;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-interface {p0, p1}, Lsj;->f(Lsj;)Lsj;

    move-result-object p0

    :cond_0
    return-object p0
.end method

.method public static final q(Llj;Lsj;Ljava/lang/Object;)Li51;
    .locals 2

    const/4 v0, 0x0

    if-nez p0, :cond_0

    goto :goto_1

    :cond_0
    sget-object v1, Lj51;->h:Lj51;

    invoke-interface {p1, v1}, Lsj;->h(Lrj;)Lqj;

    move-result-object v1

    if-eqz v1, :cond_4

    :cond_1
    instance-of v1, p0, Ltq;

    if-eqz v1, :cond_2

    goto :goto_0

    :cond_2
    invoke-interface {p0}, Lck;->c()Lck;

    move-result-object p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    instance-of v1, p0, Li51;

    if-eqz v1, :cond_1

    move-object v0, p0

    check-cast v0, Li51;

    :goto_0
    if-eqz v0, :cond_4

    invoke-virtual {v0, p1, p2}, Li51;->X(Lsj;Ljava/lang/Object;)V

    :cond_4
    :goto_1
    return-object v0
.end method

.method public static r(I)I
    .locals 4

    int-to-long v0, p0

    const-wide/32 v2, -0x3361d2af

    mul-long/2addr v0, v2

    long-to-int p0, v0

    const/16 v0, 0xf

    invoke-static {p0, v0}, Ljava/lang/Integer;->rotateLeft(II)I

    move-result p0

    int-to-long v0, p0

    const-wide/32 v2, 0x1b873593

    mul-long/2addr v0, v2

    long-to-int p0, v0

    return p0
.end method

.method public static s(Ljava/lang/String;)Ljava/math/BigDecimal;
    .locals 5

    invoke-static {p0}, La60;->w(Ljava/lang/String;)V

    new-instance v0, Ljava/math/BigDecimal;

    invoke-direct {v0, p0}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/math/BigDecimal;->scale()I

    move-result v1

    int-to-long v1, v1

    invoke-static {v1, v2}, Ljava/lang/Math;->abs(J)J

    move-result-wide v1

    const-wide/16 v3, 0x2710

    cmp-long v1, v1, v3

    if-gez v1, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/NumberFormatException;

    const-string v1, "Number has unsupported scale: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static t(Z)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Lnu0;->a()V

    return-void
.end method

.method public static u(I)Z
    .locals 3

    const/16 v0, 0x8

    const/4 v1, 0x1

    if-eq p0, v0, :cond_4

    const/4 v0, 0x7

    if-ne p0, v0, :cond_0

    goto :goto_1

    :cond_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1f

    if-lt v0, v2, :cond_2

    const/16 v2, 0x1a

    if-eq p0, v2, :cond_1

    const/16 v2, 0x1b

    if-eq p0, v2, :cond_1

    goto :goto_0

    :cond_1
    return v1

    :cond_2
    :goto_0
    const/16 v2, 0x21

    if-lt v0, v2, :cond_3

    const/16 v0, 0x1e

    if-ne p0, v0, :cond_3

    return v1

    :cond_3
    const/4 p0, 0x0

    return p0

    :cond_4
    :goto_1
    return v1
.end method

.method public static v(Ljava/lang/String;Z)V
    .locals 0

    if-eqz p1, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method

.method public static w(Ljava/lang/String;)V
    .locals 4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x2710

    if-gt v0, v1, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/NumberFormatException;

    const/4 v1, 0x0

    const/16 v2, 0x1e

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1c

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "Number string too large: "

    const-string v3, "..."

    invoke-static {v2, v1, p0, v3}, Lq60;->p(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static x(Ljava/nio/ByteBuffer;Z)V
    .locals 14

    invoke-virtual {p0}, Ljava/nio/Buffer;->position()I

    move-result v0

    invoke-virtual {p0}, Ljava/nio/Buffer;->limit()I

    move-result v1

    sub-int v2, v1, v0

    const/4 v3, 0x4

    if-lt v2, v3, :cond_13

    :goto_0
    if-ge v0, v1, :cond_13

    invoke-static {p0, v0, v1}, La60;->y(Ljava/nio/ByteBuffer;II)I

    move-result v0

    if-ne v0, v1, :cond_0

    goto/16 :goto_c

    :cond_0
    add-int/lit8 v2, v0, 0x3

    if-ge v2, v1, :cond_13

    invoke-virtual {p0, v2}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v4

    and-int/lit8 v4, v4, 0x7e

    shr-int/lit8 v4, v4, 0x1

    const/16 v5, 0x1f

    if-le v4, v5, :cond_13

    const/16 v5, 0x27

    if-ne v4, v5, :cond_12

    add-int/lit8 v0, v0, 0x5

    invoke-static {p0, v0, v1}, La60;->y(Ljava/nio/ByteBuffer;II)I

    move-result v2

    const/4 v4, 0x0

    move v5, v4

    :cond_1
    if-ge v0, v2, :cond_12

    move v6, v4

    :goto_1
    const/4 v7, 0x2

    const/4 v8, -0x1

    const/16 v9, 0xff

    const/4 v10, 0x3

    if-ge v0, v2, :cond_7

    add-int/lit8 v11, v0, 0x1

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v12

    and-int/2addr v12, v9

    if-ne v12, v10, :cond_4

    if-lt v5, v7, :cond_3

    move v5, v4

    :cond_2
    move v0, v11

    goto :goto_1

    :cond_3
    move v12, v10

    :cond_4
    if-nez v12, :cond_5

    add-int/lit8 v5, v5, 0x1

    goto :goto_2

    :cond_5
    move v5, v4

    :goto_2
    add-int/2addr v6, v12

    if-eq v12, v9, :cond_2

    if-ne v6, v3, :cond_6

    move v6, v5

    move v5, v0

    :goto_3
    move v0, v11

    goto :goto_4

    :cond_6
    move v6, v5

    move v5, v8

    goto :goto_3

    :cond_7
    move v6, v5

    move v5, v8

    :goto_4
    const/4 v11, -0x2

    if-lt v0, v2, :cond_8

    if-eq v5, v8, :cond_12

    invoke-virtual {p0, v5, v11}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    goto/16 :goto_b

    :cond_8
    move v12, v4

    :goto_5
    if-ge v0, v2, :cond_d

    add-int/lit8 v13, v0, 0x1

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v0

    and-int/2addr v0, v9

    if-ne v0, v10, :cond_b

    if-lt v6, v7, :cond_a

    move v6, v4

    :cond_9
    move v0, v13

    goto :goto_5

    :cond_a
    move v0, v10

    :cond_b
    if-nez v0, :cond_c

    add-int/lit8 v6, v6, 0x1

    goto :goto_6

    :cond_c
    move v6, v4

    :goto_6
    add-int/2addr v12, v0

    if-eq v0, v9, :cond_9

    move v0, v13

    :cond_d
    if-eq v5, v8, :cond_e

    if-eqz p1, :cond_f

    add-int v8, v0, v12

    invoke-static {v8, v2}, Ljava/lang/Math;->min(II)I

    move-result v8

    invoke-static {p0, v0, v8}, Ldy2;->f(Ljava/nio/ByteBuffer;II)Z

    move-result v8

    if-nez v8, :cond_e

    goto :goto_8

    :cond_e
    :goto_7
    move v5, v6

    move v6, v4

    goto :goto_9

    :cond_f
    :goto_8
    invoke-virtual {p0, v5, v11}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    goto :goto_7

    :goto_9
    if-ge v6, v12, :cond_1

    if-ge v0, v2, :cond_1

    add-int/lit8 v8, v0, 0x1

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v0

    and-int/2addr v0, v9

    if-ne v0, v10, :cond_11

    if-lt v5, v7, :cond_10

    add-int/lit8 v6, v6, -0x1

    :cond_10
    move v5, v4

    goto :goto_a

    :cond_11
    if-nez v0, :cond_10

    add-int/lit8 v5, v5, 0x1

    :goto_a
    add-int/lit8 v6, v6, 0x1

    move v0, v8

    goto :goto_9

    :cond_12
    :goto_b
    move v0, v2

    goto/16 :goto_0

    :cond_13
    :goto_c
    return-void
.end method

.method public static y(Ljava/nio/ByteBuffer;II)I
    .locals 4

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    if-ge p1, p2, :cond_3

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->get(I)B

    move-result v2

    and-int/lit16 v2, v2, 0xff

    const/4 v3, 0x2

    if-lt v1, v3, :cond_1

    const/4 v3, 0x1

    if-eq v2, v3, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 p1, p1, -0x2

    return p1

    :cond_1
    :goto_1
    if-nez v2, :cond_2

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_2
    move v1, v0

    :goto_2
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_3
    return p2
.end method

.method public static z(ILjava/lang/String;Z)V
    .locals 0

    if-eqz p2, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p1, p0}, Li60;->y(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lb;->o(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public abstract m(Lva0;)V
.end method

.method public abstract n(Ljava/lang/Object;)V
.end method

.method public abstract o(I)Landroid/view/View;
.end method

.method public abstract p()Z
.end method
