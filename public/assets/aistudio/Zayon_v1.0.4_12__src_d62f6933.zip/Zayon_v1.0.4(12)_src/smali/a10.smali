.class public final synthetic La10;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

.field public final synthetic c:Ln30;


# direct methods
.method public synthetic constructor <init>(Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;Ln30;I)V
    .locals 0

    iput p3, p0, La10;->a:I

    iput-object p1, p0, La10;->b:Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iput-object p2, p0, La10;->c:Ln30;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 8

    iget v0, p0, La10;->a:I

    iget-object v1, p0, La10;->c:Ln30;

    check-cast p1, Landroid/graphics/Bitmap;

    packed-switch v0, :pswitch_data_0

    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    iget-object p0, p0, La10;->b:Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iget-object v0, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->V:Ljava/util/ArrayList;

    iget-boolean v2, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->u0:Z

    if-nez v2, :cond_1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->a0:Ljava/util/HashMap;

    iget-object v3, v1, Ln30;->a:Ld00;

    iget-object v3, v3, Ld00;->a:Ljava/lang/String;

    invoke-virtual {v2, v3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget v2, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->Z:I

    if-ltz v2, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v2, v3, :cond_1

    iget v2, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->Z:I

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v1, :cond_1

    iget-object p0, p0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->N:Lcom/zayon/optimize/ui/gamespace/GsBackdropView;

    invoke-virtual {p0, p1}, Lcom/zayon/optimize/ui/gamespace/GsBackdropView;->setImage(Landroid/graphics/Bitmap;)V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    sget-boolean v0, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->U0:Z

    iget-object v3, p0, La10;->b:Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;

    iget-boolean p0, v3, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->u0:Z

    if-nez p0, :cond_5

    if-nez p1, :cond_2

    goto :goto_4

    :cond_2
    iput-object p1, v1, Ln30;->b:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Ln30;->a()V

    iget-object p0, v3, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->N:Lcom/zayon/optimize/ui/gamespace/GsBackdropView;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p0

    iget-object p1, v3, Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;->N:Lcom/zayon/optimize/ui/gamespace/GsBackdropView;

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    if-lez p0, :cond_4

    if-gtz p1, :cond_3

    goto :goto_2

    :cond_3
    :goto_1
    move v5, p0

    move v6, p1

    goto :goto_3

    :cond_4
    :goto_2
    invoke-virtual {v3}, Lk6;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v3}, Lk6;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->heightPixels:I

    goto :goto_1

    :goto_3
    iget-object v4, v1, Ln30;->b:Landroid/graphics/Bitmap;

    invoke-static {v3}, Lj00;->b(Landroid/content/Context;)Lj00;

    move-result-object p0

    new-instance v2, Lk10;

    const/4 v7, 0x0

    invoke-direct/range {v2 .. v7}, Lk10;-><init>(Ljava/lang/Object;Landroid/graphics/Bitmap;III)V

    new-instance p1, La10;

    const/4 v0, 0x1

    invoke-direct {p1, v3, v1, v0}, La10;-><init>(Lcom/zayon/optimize/ui/gamespace/GameSpaceActivity;Ln30;I)V

    iget-object v0, p0, Lj00;->b:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lz4;

    const/4 v3, 0x4

    invoke-direct {v1, v3, p0, v2, p1}, Lz4;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_5
    :goto_4
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
