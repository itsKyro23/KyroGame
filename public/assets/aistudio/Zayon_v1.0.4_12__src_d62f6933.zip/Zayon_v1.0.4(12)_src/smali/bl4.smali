.class public final Lbl4;
.super Llt4;
.source "SourceFile"


# static fields
.field private static final zzb:Lbl4;


# instance fields
.field private zzd:I

.field private zze:I

.field private zzf:Lci4;

.field private zzg:Lok4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lbl4;

    invoke-direct {v0}, Llt4;-><init>()V

    sput-object v0, Lbl4;->zzb:Lbl4;

    const-class v1, Lbl4;

    invoke-static {v1, v0}, Llt4;->k(Ljava/lang/Class;Llt4;)V

    return-void
.end method


# virtual methods
.method public final f(I)Ljava/lang/Object;
    .locals 3

    add-int/lit8 p1, p1, -0x1

    if-eqz p1, :cond_4

    const/4 p0, 0x2

    if-eq p1, p0, :cond_3

    const/4 p0, 0x3

    if-eq p1, p0, :cond_2

    const/4 p0, 0x4

    if-eq p1, p0, :cond_1

    const/4 p0, 0x5

    if-ne p1, p0, :cond_0

    sget-object p0, Lbl4;->zzb:Lbl4;

    return-object p0

    :cond_0
    const/4 p0, 0x0

    throw p0

    :cond_1
    new-instance p0, Lr64;

    sget-object p1, Lbl4;->zzb:Lbl4;

    invoke-direct {p0, p1}, Ljt4;-><init>(Llt4;)V

    return-object p0

    :cond_2
    new-instance p0, Lbl4;

    invoke-direct {p0}, Llt4;-><init>()V

    return-object p0

    :cond_3
    sget-object p0, Lq24;->r:Lq24;

    const-string p1, "zzf"

    const-string v0, "zzg"

    const-string v1, "zzd"

    const-string v2, "zze"

    filled-new-array {v1, v2, p0, p1, v0}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lbl4;->zzb:Lbl4;

    new-instance v0, Lxu4;

    const-string v1, "\u0004\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u180c\u0000\u0002\u1009\u0001\u0003\u1009\u0002"

    invoke-direct {v0, p1, v1, p0}, Lxu4;-><init>(Los4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v0

    :cond_4
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
