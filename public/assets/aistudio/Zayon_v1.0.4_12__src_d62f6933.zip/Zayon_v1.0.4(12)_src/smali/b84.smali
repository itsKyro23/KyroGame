.class public final Lb84;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzd:Lb84;


# instance fields
.field private zza:I

.field private zzb:I

.field private zzc:Ld84;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lb84;

    invoke-direct {v0}, Lng4;-><init>()V

    sput-object v0, Lb84;->zzd:Lb84;

    const-class v1, Lb84;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public static A(Lyf4;Lgg4;)Lb84;
    .locals 1

    sget-object v0, Lb84;->zzd:Lb84;

    invoke-static {v0, p0, p1}, Lng4;->l(Lng4;Lyf4;Lgg4;)Lng4;

    move-result-object p0

    check-cast p0, Lb84;

    return-object p0
.end method

.method public static B()La84;
    .locals 1

    sget-object v0, Lb84;->zzd:Lb84;

    invoke-virtual {v0}, Lng4;->o()Lkg4;

    move-result-object v0

    check-cast v0, La84;

    return-object v0
.end method


# virtual methods
.method public final synthetic C(I)V
    .locals 0

    iput p1, p0, Lb84;->zzb:I

    return-void
.end method

.method public final synthetic D(Ld84;)V
    .locals 0

    iput-object p1, p0, Lb84;->zzc:Ld84;

    iget p1, p0, Lb84;->zza:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lb84;->zza:I

    return-void
.end method

.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, La84;

    sget-object p1, Lb84;->zzd:Lb84;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, Lb84;

    invoke-direct {p0}, Lng4;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zzb"

    const-string p1, "zzc"

    const-string p2, "zza"

    filled-new-array {p2, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lb84;->zzd:Lb84;

    new-instance p2, Llh4;

    const-string v0, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u1009\u0000"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method

.method public final y()I
    .locals 0

    iget p0, p0, Lb84;->zzb:I

    return p0
.end method

.method public final z()Ld84;
    .locals 0

    iget-object p0, p0, Lb84;->zzc:Ld84;

    if-nez p0, :cond_0

    invoke-static {}, Ld84;->A()Ld84;

    move-result-object p0

    :cond_0
    return-object p0
.end method
