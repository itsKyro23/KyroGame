.class public interface abstract Laj;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract build()Ldj;
.end method

.method public abstract g(Landroid/net/Uri;)V
.end method

.method public abstract i(I)V
.end method

.method public abstract setExtras(Landroid/os/Bundle;)V
.end method
