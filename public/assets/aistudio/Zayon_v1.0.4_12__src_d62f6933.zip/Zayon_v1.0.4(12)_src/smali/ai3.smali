.class public final Lai3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:Li14;


# instance fields
.field public final a:Lzi2;

.field public final b:Ljava/util/concurrent/ScheduledExecutorService;

.field public final c:Lzh3;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, Li14;->i:Li14;

    sput-object v0, Lai3;->d:Li14;

    return-void
.end method

.method public constructor <init>(Lzi2;Ljava/util/concurrent/ScheduledExecutorService;Lzh3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lai3;->a:Lzi2;

    iput-object p2, p0, Lai3;->b:Ljava/util/concurrent/ScheduledExecutorService;

    iput-object p3, p0, Lai3;->c:Lzh3;

    return-void
.end method


# virtual methods
.method public final a(Lna0;Ljava/lang/Object;)Lfu1;
    .locals 7

    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    new-instance v0, Lfu1;

    const/4 v3, 0x0

    move-object v6, p1

    move-object v1, p0

    move-object v4, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v6}, Lfu1;-><init>(Lai3;Ljava/lang/Object;Ljava/lang/String;Lna0;Ljava/util/List;Lna0;)V

    return-object v0
.end method
