.class public final Lbq2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ln92;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcq2;


# direct methods
.method public synthetic constructor <init>(Lcq2;I)V
    .locals 0

    iput p2, p0, Lbq2;->a:I

    iput-object p1, p0, Lbq2;->b:Lcq2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/util/Map;)V
    .locals 2

    iget p1, p0, Lbq2;->a:I

    const-string v0, "hashCode"

    iget-object v1, p0, Lbq2;->b:Lcq2;

    packed-switch p1, :pswitch_data_0

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_1

    iget-object p2, v1, Lcq2;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    new-instance p1, Lzm2;

    const/4 p2, 0x4

    invoke-direct {p1, p2, p0}, Lzm2;-><init>(ILjava/lang/Object;)V

    iget-object p0, v1, Lcq2;->c:Lzi2;

    invoke-virtual {p0, p1}, Lzi2;->execute(Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    if-nez p2, :cond_2

    goto :goto_1

    :cond_2
    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_3

    iget-object p2, v1, Lcq2;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    new-instance p1, Lzm2;

    const/4 p2, 0x3

    invoke-direct {p1, p2, p0}, Lzm2;-><init>(ILjava/lang/Object;)V

    iget-object p0, v1, Lcq2;->c:Lzi2;

    invoke-virtual {p0, p1}, Lzi2;->execute(Ljava/lang/Runnable;)V

    :cond_3
    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
