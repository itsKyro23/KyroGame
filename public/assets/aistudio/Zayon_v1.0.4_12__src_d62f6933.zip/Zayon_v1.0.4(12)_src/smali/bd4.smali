.class public final Lbd4;
.super Lnd4;
.source "SourceFile"


# instance fields
.field public final o:Lzc4;

.field public final p:Ljava/math/BigInteger;

.field public final q:Lxe4;

.field public final r:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Lzc4;Ljava/math/BigInteger;Lxe4;Ljava/lang/Integer;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbd4;->o:Lzc4;

    iput-object p2, p0, Lbd4;->p:Ljava/math/BigInteger;

    iput-object p3, p0, Lbd4;->q:Lxe4;

    iput-object p4, p0, Lbd4;->r:Ljava/lang/Integer;

    return-void
.end method


# virtual methods
.method public final H()Lxe4;
    .locals 0

    iget-object p0, p0, Lbd4;->q:Lxe4;

    return-object p0
.end method

.method public final synthetic n()Lk24;
    .locals 0

    iget-object p0, p0, Lbd4;->o:Lzc4;

    return-object p0
.end method

.method public final s()Ljava/lang/Integer;
    .locals 0

    iget-object p0, p0, Lbd4;->r:Ljava/lang/Integer;

    return-object p0
.end method
