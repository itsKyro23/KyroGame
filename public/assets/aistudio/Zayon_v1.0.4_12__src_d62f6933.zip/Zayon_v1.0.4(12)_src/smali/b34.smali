.class public final Lb34;
.super Llt4;
.source "SourceFile"


# static fields
.field private static final zzb:Lb34;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lb34;

    invoke-direct {v0}, Llt4;-><init>()V

    sput-object v0, Lb34;->zzb:Lb34;

    const-class v1, Lb34;

    invoke-static {v1, v0}, Llt4;->k(Ljava/lang/Class;Llt4;)V

    return-void
.end method


# virtual methods
.method public final f(I)Ljava/lang/Object;
    .locals 2

    add-int/lit8 p1, p1, -0x1

    if-eqz p1, :cond_4

    const/4 p0, 0x2

    const/4 v0, 0x0

    if-eq p1, p0, :cond_3

    const/4 p0, 0x3

    if-eq p1, p0, :cond_2

    const/4 p0, 0x4

    if-eq p1, p0, :cond_1

    const/4 p0, 0x5

    if-ne p1, p0, :cond_0

    sget-object p0, Lb34;->zzb:Lb34;

    return-object p0

    :cond_0
    throw v0

    :cond_1
    new-instance p0, Lh53;

    sget-object p1, Lb34;->zzb:Lb34;

    invoke-direct {p0, p1}, Ljt4;-><init>(Llt4;)V

    return-object p0

    :cond_2
    new-instance p0, Lb34;

    invoke-direct {p0}, Llt4;-><init>()V

    return-object p0

    :cond_3
    sget-object p0, Lb34;->zzb:Lb34;

    new-instance p1, Lxu4;

    const-string v1, "\u0004\u0000"

    invoke-direct {p1, p0, v1, v0}, Lxu4;-><init>(Los4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p1

    :cond_4
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
