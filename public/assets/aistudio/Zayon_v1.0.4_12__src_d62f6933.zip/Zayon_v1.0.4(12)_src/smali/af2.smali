.class public final synthetic Laf2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Ll23;


# direct methods
.method public synthetic constructor <init>(Ll23;I)V
    .locals 0

    iput p2, p0, Laf2;->h:I

    iput-object p1, p0, Laf2;->i:Ll23;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Laf2;->h:I

    iget-object p0, p0, Laf2;->i:Ll23;

    packed-switch v0, :pswitch_data_0

    new-instance v0, Laf2;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Laf2;-><init>(Ll23;I)V

    iget-object p0, p0, Ll23;->b:Lzi2;

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Ll23;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Ll23;->f:Landroid/webkit/WebView;

    if-nez v1, :cond_0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :try_start_1
    sget-object v2, Lcw4;->B:Lcw4;

    iget-object v2, v2, Lcw4;->c:Lzu4;

    invoke-virtual {v1}, Landroid/webkit/WebView;->getWebViewClient()Landroid/webkit/WebViewClient;

    move-result-object v2
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-ne v2, p0, :cond_1

    :try_start_2
    monitor-exit v0

    goto :goto_0

    :cond_1
    if-eqz v2, :cond_2

    iput-object v2, p0, Ll23;->e:Landroid/webkit/WebViewClient;

    :cond_2
    invoke-virtual {v1, p0}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    invoke-virtual {p0}, Ll23;->x()V

    monitor-exit v0

    goto :goto_0

    :catch_0
    monitor-exit v0

    :goto_0
    return-void

    :goto_1
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
