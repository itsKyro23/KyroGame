.class public final synthetic La5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Le5;

.field public final synthetic j:Lwp0;


# direct methods
.method public synthetic constructor <init>(Le5;Lwp0;I)V
    .locals 0

    iput p3, p0, La5;->h:I

    iput-object p1, p0, La5;->i:Le5;

    iput-object p2, p0, La5;->j:Lwp0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    iget v0, p0, La5;->h:I

    const/4 v1, 0x0

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, La5;->i:Le5;

    iget-object p0, p0, La5;->j:Lwp0;

    iget-boolean v2, v0, Le5;->d:Z

    if-nez v2, :cond_2

    iget-boolean v2, v0, Le5;->h:Z

    if-eqz v2, :cond_0

    goto :goto_1

    :cond_0
    iget-boolean v2, v0, Le5;->d:Z

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    iput-boolean v2, v0, Le5;->d:Z

    new-instance v2, Ljava/lang/Thread;

    new-instance v3, La5;

    invoke-direct {v3, v0, p0, v1}, La5;-><init>(Le5;Lwp0;I)V

    const-string p0, "zayon-adb-reconnect"

    invoke-direct {v2, v3, p0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    :goto_0
    iget-object p0, v0, Le5;->b:Lu1;

    invoke-virtual {p0}, Lu1;->h()V

    :cond_2
    :goto_1
    return-void

    :pswitch_0
    iget-object v0, p0, La5;->i:Le5;

    iget-object p0, p0, La5;->j:Lwp0;

    invoke-virtual {v0}, Le5;->a()Z

    move-result v1

    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    iget-object v1, v0, Le5;->c:Landroid/os/Handler;

    new-instance v2, La5;

    const/4 v3, 0x2

    invoke-direct {v2, v0, p0, v3}, La5;-><init>(Le5;Lwp0;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_2
    return-void

    :pswitch_1
    iget-object v0, p0, La5;->i:Le5;

    iget-object p0, p0, La5;->j:Lwp0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v2, v0, Le5;->a:Landroid/content/Context;

    invoke-static {v2}, Ly4;->g(Landroid/content/Context;)Ly4;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {v0, v2, v3}, Le5;->h(Ly4;I)V

    iget-object v4, v0, Le5;->a:Landroid/content/Context;

    const-wide/16 v5, 0x7530

    invoke-virtual {v2, v4, v5, v6}, Lio/github/muntashirakon/adb/AbsAdbConnectionManager;->autoConnect(Landroid/content/Context;J)Z

    move-result v1

    if-eqz v1, :cond_4

    iput v3, v0, Le5;->e:I

    invoke-virtual {v0, v2}, Le5;->g(Ly4;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_3

    :catchall_0
    move-exception v2

    goto :goto_4

    :cond_4
    :goto_3
    iget-object v2, v0, Le5;->a:Landroid/content/Context;

    if-eqz v1, :cond_5

    :try_start_1
    invoke-static {v2}, Lck2;->p(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    const v3, 0x7f0f0323

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_5

    :cond_5
    invoke-static {v2}, Lck2;->p(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    const v3, 0x7f0f0324

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_5

    :goto_4
    invoke-virtual {v0, v2}, Le5;->k(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v2

    :goto_5
    invoke-virtual {v0, v1, v2, p0}, Le5;->e(ZLjava/lang/String;Ld5;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
