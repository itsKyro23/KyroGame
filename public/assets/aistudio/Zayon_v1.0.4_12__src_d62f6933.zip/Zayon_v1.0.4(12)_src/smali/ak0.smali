.class public final synthetic Lak0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Lvk0;

.field public final synthetic j:Lzl0;


# direct methods
.method public synthetic constructor <init>(Lvk0;Lzl0;I)V
    .locals 0

    iput p3, p0, Lak0;->h:I

    iput-object p1, p0, Lak0;->i:Lvk0;

    iput-object p2, p0, Lak0;->j:Lzl0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lak0;->h:I

    iget-object v1, p0, Lak0;->j:Lzl0;

    iget-object p0, p0, Lak0;->i:Lvk0;

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lvk0;->X:Lzl0;

    if-ne v0, v1, :cond_1

    iget-wide v2, v1, Lzl0;->p:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-ltz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Lvk0;->M(Landroid/view/View;)V

    const/4 v0, 0x0

    iput-object v0, p0, Lvk0;->X:Lzl0;

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lvk0;->l:Landroid/os/Handler;

    new-instance v2, Lak0;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v1, v3}, Lak0;-><init>(Lvk0;Lzl0;I)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
