.class public final Lbj1;
.super Lif2;
.source "SourceFile"


# static fields
.field public static final G:I


# instance fields
.field public A:Z

.field public B:Z

.field public C:Z

.field public D:Landroid/widget/Toolbar;

.field public E:I

.field public final synthetic F:I

.field public final i:Landroid/app/Activity;

.field public j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

.field public k:Lsl2;

.field public l:Lex4;

.field public m:Lsw4;

.field public n:Z

.field public o:Landroid/widget/FrameLayout;

.field public p:Landroid/webkit/WebChromeClient$CustomViewCallback;

.field public q:Z

.field public r:Z

.field public s:Led4;

.field public t:Z

.field public u:I

.field public final v:Ljava/lang/Object;

.field public final w:Lt2;

.field public x:Lzm2;

.field public y:Z

.field public z:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x0

    invoke-static {v0, v0, v0, v0}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    sput v0, Lbj1;->G:I

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;I)V
    .locals 3

    iput p2, p0, Lbj1;->F:I

    invoke-direct {p0}, Lif2;-><init>()V

    const/4 p2, 0x0

    iput-boolean p2, p0, Lbj1;->n:Z

    iput-boolean p2, p0, Lbj1;->q:Z

    iput-boolean p2, p0, Lbj1;->r:Z

    iput-boolean p2, p0, Lbj1;->t:Z

    const/4 v0, 0x1

    iput v0, p0, Lbj1;->E:I

    iput p2, p0, Lbj1;->u:I

    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lbj1;->v:Ljava/lang/Object;

    new-instance v1, Lt2;

    const/4 v2, 0x5

    invoke-direct {v1, v2, p0}, Lt2;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Lbj1;->w:Lt2;

    iput-boolean p2, p0, Lbj1;->A:Z

    iput-boolean p2, p0, Lbj1;->B:Z

    iput-boolean v0, p0, Lbj1;->C:Z

    iput-object p1, p0, Lbj1;->i:Landroid/app/Activity;

    return-void
.end method

.method public static final R3(Landroid/view/View;Lh73;)V
    .locals 2

    if-eqz p1, :cond_2

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v0, Lk52;->q6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p1, Lh73;->b:Lqh;

    iget-object v0, v0, Lqh;->n:Ljava/lang/Object;

    check-cast v0, Lok3;

    sget-object v1, Lok3;->i:Lok3;

    if-ne v0, v1, :cond_1

    return-void

    :cond_1
    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->w:Ljl2;

    iget-object p1, p1, Lh73;->a:Lpk3;

    invoke-static {p1, p0}, Ljl2;->m(Lpk3;Landroid/view/View;)V

    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final B()V
    .locals 3

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Lbj1;->n:Z

    if-eqz v1, :cond_0

    iget v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->q:I

    invoke-virtual {p0, v0}, Lbj1;->T(I)V

    :cond_0
    iget-object v0, p0, Lbj1;->o:Landroid/widget/FrameLayout;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    iget-object v2, p0, Lbj1;->s:Led4;

    invoke-virtual {v0, v2}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lbj1;->z:Z

    iget-object v0, p0, Lbj1;->o:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    iput-object v1, p0, Lbj1;->o:Landroid/widget/FrameLayout;

    :cond_1
    iget-object v0, p0, Lbj1;->p:Landroid/webkit/WebChromeClient$CustomViewCallback;

    if-eqz v0, :cond_2

    invoke-interface {v0}, Landroid/webkit/WebChromeClient$CustomViewCallback;->onCustomViewHidden()V

    iput-object v1, p0, Lbj1;->p:Landroid/webkit/WebChromeClient$CustomViewCallback;

    :cond_2
    const/4 v0, 0x0

    iput-boolean v0, p0, Lbj1;->n:Z

    return-void
.end method

.method public final E()V
    .locals 2

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lyt4;->U1()V

    :cond_0
    sget-object v0, Lk52;->f6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->l:Lex4;

    if-nez v0, :cond_2

    :cond_1
    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->onPause()V

    :cond_2
    invoke-virtual {p0}, Lbj1;->v()V

    return-void
.end method

.method public final P2(Landroid/os/Bundle;)V
    .locals 1

    const-string v0, "com.google.android.gms.ads.internal.overlay.hasResumed"

    iget-boolean p0, p0, Lbj1;->q:Z

    invoke-virtual {p1, v0, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method

.method public final P3()V
    .locals 5

    iget-boolean v0, p0, Lbj1;->B:Z

    if-eqz v0, :cond_0

    goto/16 :goto_1

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lbj1;->B:Z

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_4

    iget-object v1, p0, Lbj1;->s:Led4;

    invoke-interface {v0}, Lsl2;->j0()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v0, p0, Lbj1;->l:Lex4;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v2, p0, Lbj1;->k:Lsl2;

    iget-object v0, v0, Lex4;->j:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-interface {v2, v0}, Lsl2;->J0(Landroid/content/Context;)V

    iget-object v0, p0, Lbj1;->k:Lsl2;

    const/4 v2, 0x0

    invoke-interface {v0, v2}, Lsl2;->N0(Z)V

    sget-object v0, Lk52;->pe:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v2, p0, Lbj1;->k:Lsl2;

    invoke-interface {v2}, Lsl2;->j0()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    iget-object v0, p0, Lbj1;->l:Lex4;

    iget-object v0, v0, Lex4;->l:Ljava/lang/Object;

    check-cast v0, Landroid/view/ViewGroup;

    iget-object v2, p0, Lbj1;->k:Lsl2;

    invoke-interface {v2}, Lsl2;->j0()Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Lbj1;->l:Lex4;

    iget v4, v3, Lex4;->i:I

    iget-object v3, v3, Lex4;->k:Ljava/lang/Object;

    check-cast v3, Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v2, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    iput-object v1, p0, Lbj1;->l:Lex4;

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_3

    iget-object v2, p0, Lbj1;->k:Lsl2;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-interface {v2, v0}, Lsl2;->J0(Landroid/content/Context;)V

    :cond_3
    :goto_0
    iput-object v1, p0, Lbj1;->k:Lsl2;

    :cond_4
    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_5

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v0, :cond_5

    iget v1, p0, Lbj1;->E:I

    invoke-interface {v0, v1}, Lyt4;->V0(I)V

    :cond_5
    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_6

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v0, :cond_6

    invoke-interface {v0}, Lsl2;->I0()Lh73;

    move-result-object v0

    iget-object p0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object p0, p0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    invoke-interface {p0}, Lsl2;->j0()Landroid/view/View;

    move-result-object p0

    invoke-static {p0, v0}, Lbj1;->R3(Landroid/view/View;Lh73;)V

    :cond_6
    :goto_1
    return-void
.end method

.method public Q0(Landroid/os/Bundle;)V
    .locals 9

    iget v0, p0, Lbj1;->F:I

    const/4 v1, 0x4

    packed-switch v0, :pswitch_data_0

    iget-boolean v0, p0, Lbj1;->z:Z

    const/4 v2, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0, v2}, Landroid/app/Activity;->requestWindowFeature(I)Z

    :cond_0
    const/4 v0, 0x0

    if-eqz p1, :cond_1

    const-string v3, "com.google.android.gms.ads.internal.overlay.hasResumed"

    invoke-virtual {p1, v3, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_1

    move v3, v2

    goto :goto_0

    :cond_1
    move v3, v0

    :goto_0
    iput-boolean v3, p0, Lbj1;->q:Z

    :try_start_0
    iget-object v3, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v4

    invoke-static {v4}, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->a(Landroid/content/Intent;)Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    move-result-object v4

    iput-object v4, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v4, :cond_13

    iget-boolean v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->D:Z

    if-eqz v4, :cond_3

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1c

    if-lt v4, v5, :cond_2

    invoke-static {v3}, Lnr;->c(Landroid/app/Activity;)V

    goto :goto_1

    :catch_0
    move-exception p1

    goto/16 :goto_5

    :cond_2
    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    const/high16 v5, 0x80000

    invoke-virtual {v4, v5}, Landroid/view/Window;->addFlags(I)V

    :cond_3
    :goto_1
    iget-object v4, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->t:Lw61;

    iget v4, v4, Lw61;->j:I

    const v5, 0x7270e0

    if-le v4, v5, :cond_4

    iput v1, p0, Lbj1;->E:I

    :cond_4
    invoke-virtual {v3}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v4

    if-eqz v4, :cond_5

    invoke-virtual {v3}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v4

    const-string v5, "shouldCallOnOverlayOpened"

    invoke-virtual {v4, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v4

    iput-boolean v4, p0, Lbj1;->C:Z

    :cond_5
    iget-object v4, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v5, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->v:Lpo4;

    const/4 v6, 0x5

    if-eqz v5, :cond_6

    iget-boolean v7, v5, Lpo4;->h:Z

    iput-boolean v7, p0, Lbj1;->r:Z

    iget v8, v5, Lpo4;->l:F

    float-to-int v8, v8

    iput v8, p0, Lbj1;->u:I

    if-eqz v7, :cond_8

    goto :goto_2

    :cond_6
    iget v7, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-ne v7, v6, :cond_7

    iput-boolean v2, p0, Lbj1;->r:Z

    :goto_2
    iget v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-eq v4, v6, :cond_8

    iget v4, v5, Lpo4;->m:I

    const/4 v5, -0x1

    if-eq v4, v5, :cond_8

    new-instance v4, Lye2;

    invoke-direct {v4, p0}, Lye2;-><init>(Lbj1;)V

    invoke-virtual {v4}, Lfg4;->s1()Lna0;

    goto :goto_3

    :cond_7
    iput-boolean v0, p0, Lbj1;->r:Z

    :cond_8
    :goto_3
    if-nez p1, :cond_d

    iget-boolean p1, p0, Lbj1;->C:Z

    if-eqz p1, :cond_b

    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->A:Leu2;

    if-eqz p1, :cond_a

    monitor-enter p1
    :try_end_0
    .catch Lhy3; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-object v4, p1, Leu2;->k:Ljava/util/concurrent/ScheduledFuture;

    if-eqz v4, :cond_9

    invoke-interface {v4, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_9
    :try_start_2
    monitor-exit p1
    :try_end_2
    .catch Lhy3; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_4

    :catchall_0
    move-exception v0

    :try_start_3
    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw v0

    :cond_a
    :goto_4
    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz p1, :cond_b

    invoke-interface {p1}, Lyt4;->g()V

    :cond_b
    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v4, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-eq v4, v2, :cond_d

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->i:Lcf1;

    if-eqz p1, :cond_c

    invoke-interface {p1}, Lcf1;->n()V

    :cond_c
    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->B:Lpw2;

    if-eqz p1, :cond_d

    invoke-interface {p1}, Lpw2;->i0()V

    :cond_d
    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz p1, :cond_e

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz p1, :cond_e

    invoke-interface {p1}, Lyt4;->Y2()V

    :cond_e
    new-instance p1, Led4;

    iget-object v4, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v5, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->u:Ljava/lang/String;

    iget-object v7, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->t:Lw61;

    iget-object v7, v7, Lw61;->h:Ljava/lang/String;

    iget-object v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->z:Ljava/lang/String;

    invoke-direct {p1, v3, v5, v7, v4}, Led4;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iput-object p1, p0, Lbj1;->s:Led4;

    const/16 v4, 0x3e8

    invoke-virtual {p1, v4}, Landroid/view/View;->setId(I)V

    sget-object p1, Lcw4;->B:Lcw4;

    iget-object p1, p1, Lcw4;->f:Lne4;

    invoke-virtual {p1, v3}, Lne4;->e(Landroid/app/Activity;)V

    iget-object p1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v3, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-eq v3, v2, :cond_12

    const/4 v4, 0x2

    if-eq v3, v4, :cond_11

    const/4 p1, 0x3

    if-eq v3, p1, :cond_10

    if-ne v3, v6, :cond_f

    invoke-virtual {p0, v0}, Lbj1;->U3(Z)V

    goto :goto_6

    :cond_f
    new-instance p1, Lhy3;

    const-string v0, "Could not determine ad overlay type."

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_10
    invoke-virtual {p0, v2}, Lbj1;->U3(Z)V

    goto :goto_6

    :cond_11
    new-instance v2, Lex4;

    iget-object p1, p1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    invoke-direct {v2, p1}, Lex4;-><init>(Lsl2;)V

    iput-object v2, p0, Lbj1;->l:Lex4;

    invoke-virtual {p0, v0}, Lbj1;->U3(Z)V

    goto :goto_6

    :cond_12
    invoke-virtual {p0, v0}, Lbj1;->U3(Z)V

    goto :goto_6

    :cond_13
    new-instance p1, Lhy3;

    const-string v0, "Could not get info for ad overlay."

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_4
    .catch Lhy3; {:try_start_4 .. :try_end_4} :catch_0

    :goto_5
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    sget v0, Lj23;->b:I

    invoke-static {p1}, Lj23;->g(Ljava/lang/String;)V

    iput v1, p0, Lbj1;->E:I

    iget-object p0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_6
    return-void

    :pswitch_0
    const-string p1, "AdOverlayParcel is null or does not contain valid overlay type."

    invoke-static {p1}, Lj23;->a(Ljava/lang/String;)V

    iput v1, p0, Lbj1;->E:I

    iget-object p0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_0
    .end packed-switch
.end method

.method public final Q3(Landroid/view/View;)V
    .locals 3

    iget-object p0, p0, Lbj1;->k:Lsl2;

    if-nez p0, :cond_0

    goto :goto_1

    :cond_0
    sget-object v0, Lk52;->r6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-interface {p0}, Lsl2;->R0()Lg73;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    monitor-enter v0

    :try_start_0
    iget-object p0, v0, Lg73;->f:Luk3;

    if-eqz p0, :cond_2

    sget-object v1, Lcw4;->B:Lcw4;

    iget-object v1, v1, Lcw4;->w:Ljl2;

    new-instance v1, Lmo2;

    const/16 v2, 0xe

    invoke-direct {v1, p0, v2, p1}, Lmo2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v1}, Ljl2;->u(Ljava/lang/Runnable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-void

    :cond_2
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0

    :cond_3
    :goto_0
    sget-object v0, Lk52;->q6:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-interface {p0}, Lsl2;->I0()Lh73;

    move-result-object p0

    if-eqz p0, :cond_4

    iget-object v0, p0, Lh73;->b:Lqh;

    iget-object v0, v0, Lqh;->n:Ljava/lang/Object;

    check-cast v0, Lok3;

    sget-object v1, Lok3;->i:Lok3;

    if-ne v0, v1, :cond_4

    sget-object v0, Lcw4;->B:Lcw4;

    iget-object v0, v0, Lcw4;->w:Ljl2;

    iget-object p0, p0, Lh73;->a:Lpk3;

    new-instance v0, Lbk2;

    const/16 v1, 0x10

    invoke-direct {v0, p0, v1, p1}, Lbk2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {v0}, Ljl2;->u(Ljava/lang/Runnable;)V

    :cond_4
    :goto_1
    return-void
.end method

.method public final S3(Z)V
    .locals 6

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-boolean v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->D:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lk52;->h6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    sget-object v2, Lk52;->L1:Lg52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v1, :cond_1

    if-eqz p1, :cond_2

    :cond_1
    move v1, v3

    goto :goto_0

    :cond_2
    move v1, v2

    :goto_0
    new-instance v4, Lhb3;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    iput v2, v4, Lhb3;->a:I

    iput v2, v4, Lhb3;->b:I

    iput v2, v4, Lhb3;->c:I

    const/16 v5, 0x32

    iput v5, v4, Lhb3;->d:I

    if-eq v3, v1, :cond_3

    move v5, v2

    goto :goto_1

    :cond_3
    move v5, v0

    :goto_1
    iput v5, v4, Lhb3;->a:I

    if-eq v3, v1, :cond_4

    move v2, v0

    :cond_4
    iput v2, v4, Lhb3;->b:I

    iput v0, v4, Lhb3;->c:I

    new-instance v0, Lsw4;

    iget-object v2, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-direct {v0, v2, v4, p0}, Lsw4;-><init>(Landroid/content/Context;Lhb3;Lbj1;)V

    iput-object v0, p0, Lbj1;->m:Lsw4;

    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v0, v2, v2}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0xa

    invoke-virtual {v0, v2}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    if-eq v3, v1, :cond_5

    const/16 v1, 0x9

    goto :goto_2

    :cond_5
    const/16 v1, 0xb

    :goto_2
    invoke-virtual {v0, v1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    iget-object v1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-boolean v1, v1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->n:Z

    invoke-virtual {p0, p1, v1}, Lbj1;->T3(ZZ)V

    iget-object p1, p0, Lbj1;->s:Led4;

    iget-object v1, p0, Lbj1;->m:Lsw4;

    invoke-virtual {p1, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Lbj1;->m:Lsw4;

    invoke-virtual {p0, p1}, Lbj1;->Q3(Landroid/view/View;)V

    return-void
.end method

.method public final T(I)V
    .locals 4

    iget-object p0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    sget-object v1, Lk52;->Z6:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v3, v2, Lvx1;->c:Li52;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-lt v0, v1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    sget-object v1, Lk52;->a7:Lg52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-gt v0, v1, :cond_0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sget-object v1, Lk52;->b7:Lg52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-lt v0, v1, :cond_0

    sget-object v1, Lk52;->c7:Lg52;

    invoke-virtual {v2, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-gt v0, v1, :cond_0

    return-void

    :cond_0
    :try_start_0
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setRequestedOrientation(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    sget-object p1, Lcw4;->B:Lcw4;

    iget-object p1, p1, Lcw4;->h:Lui2;

    const-string v0, "AdOverlay.setRequestedOrientation"

    invoke-virtual {p1, v0, p0}, Lui2;->e(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public final T2(IILandroid/content/Intent;)V
    .locals 3

    const/16 v0, 0xec

    if-ne p1, v0, :cond_4

    sget-object p1, Lk52;->We:Lg52;

    sget-object v0, Lvx1;->e:Lvx1;

    iget-object v1, v0, Lvx1;->c:Li52;

    invoke-virtual {v1, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x42

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "Callback from intent launch with requestCode: 236 and resultCode: "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lj23;->a(Ljava/lang/String;)V

    iget-object v1, p0, Lbj1;->k:Lsl2;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {v1}, Lsl2;->b0()Lmm2;

    move-result-object v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Lsl2;->b0()Lmm2;

    move-result-object v1

    iget-object v1, v1, Lmm2;->G:Lu23;

    if-eqz v1, :cond_4

    iget-object p0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz p0, :cond_4

    iget-object v0, v0, Lvx1;->c:Li52;

    invoke-virtual {v0, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_4

    invoke-virtual {v1}, Lu23;->a()Lry2;

    move-result-object p1

    const-string v0, "action"

    const-string v1, "hilca"

    invoke-virtual {p1, v0, v1}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->x:Ljava/lang/String;

    if-nez p0, :cond_1

    const-string p0, ""

    :cond_1
    const-string v0, "gqi"

    invoke-virtual {p1, v0, p0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "hilr"

    invoke-virtual {p1, v0, p0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p0, -0x1

    if-ne p2, p0, :cond_3

    if-eqz p3, :cond_3

    const-string p0, "callerPackage"

    invoke-virtual {p3, p0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string p2, "loadingStage"

    invoke-virtual {p3, p2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    if-eqz p0, :cond_2

    const-string p3, "hilcp"

    invoke-virtual {p1, p3, p0}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    if-eqz p2, :cond_3

    const-string p0, "hills"

    invoke-virtual {p1, p0, p2}, Lry2;->K(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    invoke-virtual {p1}, Lry2;->O()V

    :cond_4
    :goto_0
    return-void
.end method

.method public final T3(ZZ)V
    .locals 9

    sget-object v0, Lk52;->J1:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v2, v1, Lvx1;->c:Li52;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->v:Lpo4;

    if-eqz v0, :cond_0

    iget-boolean v0, v0, Lpo4;->o:Z

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v3

    :goto_0
    sget-object v4, Lk52;->K1:Lg52;

    invoke-virtual {v1, v4}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_1

    iget-object v4, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v4, :cond_1

    iget-object v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->v:Lpo4;

    if-eqz v4, :cond_1

    iget-boolean v4, v4, Lpo4;->p:Z

    if-eqz v4, :cond_1

    move v4, v2

    goto :goto_1

    :cond_1
    move v4, v3

    :goto_1
    if-eqz p1, :cond_2

    if-eqz p2, :cond_2

    if-eqz v0, :cond_2

    if-nez v4, :cond_2

    iget-object p1, p0, Lbj1;->k:Lsl2;

    const-string v5, "useCustomClose"

    const-string v6, "Custom close has been disabled for interstitial ads in this ad slot."

    :try_start_0
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const-string v8, "message"

    invoke-virtual {v7, v8, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v6

    const-string v7, "action"

    invoke-virtual {v6, v7, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v5

    if-eqz p1, :cond_2

    const-string v6, "onError"

    invoke-interface {p1, v6, v5}, Lxa2;->c(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    sget p1, Lj23;->b:I

    invoke-static {}, Lj23;->e()V

    :cond_2
    :goto_2
    iget-object p0, p0, Lbj1;->m:Lsw4;

    if-eqz p0, :cond_6

    if-nez v4, :cond_4

    if-eqz p2, :cond_3

    if-nez v0, :cond_3

    goto :goto_3

    :cond_3
    move v2, v3

    :cond_4
    :goto_3
    iget-object p0, p0, Lsw4;->h:Landroid/widget/ImageButton;

    if-eqz v2, :cond_5

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    sget-object p1, Lk52;->N1:Lg52;

    invoke-virtual {v1, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const-wide/16 v0, 0x0

    cmp-long p1, p1, v0

    if-lez p1, :cond_6

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {p0}, Landroid/view/View;->clearAnimation()V

    return-void

    :cond_5
    invoke-virtual {p0, v3}, Landroid/view/View;->setVisibility(I)V

    :cond_6
    return-void
.end method

.method public final U()V
    .locals 2

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lyt4;->f3()V

    :cond_0
    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_1

    :try_start_0
    iget-object v1, p0, Lbj1;->s:Led4;

    invoke-interface {v0}, Lsl2;->j0()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    invoke-virtual {p0}, Lbj1;->v()V

    return-void
.end method

.method public final U3(Z)V
    .locals 47

    move-object/from16 v0, p0

    iget-object v2, v0, Lbj1;->i:Landroid/app/Activity;

    iget-boolean v1, v0, Lbj1;->z:Z

    const/4 v3, 0x1

    if-nez v1, :cond_0

    invoke-virtual {v2, v3}, Landroid/app/Activity;->requestWindowFeature(I)Z

    :cond_0
    invoke-virtual {v2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_1d

    iget-object v4, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v4, v4, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    const/4 v5, 0x0

    if-eqz v4, :cond_1

    invoke-interface {v4}, Lsl2;->b0()Lmm2;

    move-result-object v4

    goto :goto_0

    :cond_1
    move-object v4, v5

    :goto_0
    const/4 v6, 0x0

    if-eqz v4, :cond_2

    iget-object v7, v4, Lmm2;->k:Ljava/lang/Object;

    monitor-enter v7

    :try_start_0
    iget-boolean v4, v4, Lmm2;->x:Z

    monitor-exit v7

    if-eqz v4, :cond_2

    move v4, v3

    goto :goto_1

    :cond_2
    move v4, v6

    goto :goto_1

    :catchall_0
    move-exception v0

    monitor-exit v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :goto_1
    iput-boolean v6, v0, Lbj1;->t:Z

    if-eqz v4, :cond_6

    iget-object v7, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v7, v7, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->q:I

    const/4 v8, 0x6

    if-ne v7, v8, :cond_4

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v7

    iget v7, v7, Landroid/content/res/Configuration;->orientation:I

    if-ne v7, v3, :cond_3

    move v7, v3

    goto :goto_2

    :cond_3
    move v7, v6

    :goto_2
    iput-boolean v7, v0, Lbj1;->t:Z

    goto :goto_4

    :cond_4
    const/4 v8, 0x7

    if-ne v7, v8, :cond_6

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v7

    iget v7, v7, Landroid/content/res/Configuration;->orientation:I

    const/4 v8, 0x2

    if-ne v7, v8, :cond_5

    move v7, v3

    goto :goto_3

    :cond_5
    move v7, v6

    :goto_3
    iput-boolean v7, v0, Lbj1;->t:Z

    goto :goto_4

    :cond_6
    move v7, v6

    :goto_4
    invoke-static {v7}, Ljava/lang/String;->valueOf(Z)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    new-instance v9, Ljava/lang/StringBuilder;

    add-int/lit8 v8, v8, 0x29

    invoke-direct {v9, v8}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v8, "Delay onShow to next orientation change: "

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    sget v8, Lj23;->b:I

    invoke-static {v7}, Lj23;->c(Ljava/lang/String;)V

    iget-object v7, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v7, v7, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->q:I

    invoke-virtual {v0, v7}, Lbj1;->T(I)V

    const/high16 v7, 0x1000000

    invoke-virtual {v1, v7, v7}, Landroid/view/Window;->setFlags(II)V

    const-string v7, "Hardware acceleration on the AdActivity window enabled."

    invoke-static {v7}, Lj23;->c(Ljava/lang/String;)V

    iget-object v7, v0, Lbj1;->s:Led4;

    invoke-virtual {v2, v7}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    iput-boolean v3, v0, Lbj1;->z:Z

    iget-boolean v7, v0, Lbj1;->r:Z

    iget-object v8, v0, Lbj1;->s:Led4;

    const/16 v9, 0x1f

    if-nez v7, :cond_7

    const/high16 v7, -0x1000000

    invoke-virtual {v8, v7}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_5

    :cond_7
    sget v7, Lbj1;->G:I

    invoke-virtual {v8, v7}, Landroid/view/View;->setBackgroundColor(I)V

    sget-object v7, Lk52;->t1:Lg52;

    sget-object v8, Lvx1;->e:Lvx1;

    iget-object v8, v8, Lvx1;->c:Li52;

    invoke-virtual {v8, v7}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Boolean;

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v7

    if-eqz v7, :cond_8

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v7, v9, :cond_8

    iget v7, v0, Lbj1;->u:I

    invoke-static {v1, v7}, Ljz0;->t(Landroid/view/Window;I)V

    :cond_8
    :goto_5
    const/4 v7, 0x5

    if-eqz p1, :cond_f

    :try_start_1
    sget-object v8, Lcw4;->B:Lcw4;

    iget-object v8, v8, Lcw4;->d:Lok2;

    iget-object v8, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v8, v8, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v8, :cond_9

    invoke-interface {v8}, Lsl2;->u()Lxs0;

    move-result-object v8

    goto :goto_6

    :cond_9
    move-object v8, v5

    :goto_6
    iget-object v10, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v10, v10, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v10, :cond_a

    invoke-interface {v10}, Lsl2;->X()Ljava/lang/String;

    move-result-object v10

    goto :goto_7

    :cond_a
    move-object v10, v5

    :goto_7
    iget-object v11, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    move v12, v9

    iget-object v9, v11, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->t:Lw61;

    iget-object v11, v11, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v11, :cond_b

    invoke-interface {v11}, Lsl2;->i()Lxt3;

    move-result-object v11

    :goto_8
    move v13, v12

    goto :goto_9

    :cond_b
    move-object v11, v5

    goto :goto_8

    :goto_9
    new-instance v12, Lb32;

    invoke-direct {v12}, Lb32;-><init>()V

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v14, v5

    const/4 v5, 0x1

    move v15, v7

    const/4 v7, 0x0

    move/from16 v18, v3

    move-object v3, v8

    const/4 v8, 0x0

    move/from16 v19, v6

    move v6, v4

    move-object v4, v10

    const/4 v10, 0x0

    move/from16 v20, v13

    const/4 v13, 0x0

    move-object/from16 v21, v14

    const/4 v14, 0x0

    move/from16 v22, v15

    const/4 v15, 0x0

    move-object/from16 v18, v1

    move/from16 v1, v22

    invoke-static/range {v2 .. v17}, Lok2;->g(Landroid/content/Context;Lxs0;Ljava/lang/String;ZZLty1;Lz52;Lw61;Lxo3;Lxt3;Lb32;Lbg3;Ldg3;Lb73;Lpg3;Lu23;)Lsl2;

    move-result-object v3

    iput-object v3, v0, Lbj1;->k:Lsl2;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    invoke-interface {v3}, Lsl2;->b0()Lmm2;

    move-result-object v23

    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v4, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->w:Ld92;

    iget-object v5, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->l:Le92;

    iget-object v7, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->p:Lzg1;

    iget-object v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v3, :cond_c

    invoke-interface {v3}, Lsl2;->b0()Lmm2;

    move-result-object v3

    iget-object v3, v3, Lmm2;->D:Lmx1;

    move-object/from16 v31, v3

    goto :goto_a

    :cond_c
    const/16 v31, 0x0

    :goto_a
    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v29, 0x1

    const/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    move-object/from16 v25, v4

    move-object/from16 v27, v5

    move-object/from16 v28, v7

    invoke-virtual/range {v23 .. v46}, Lmm2;->q(Lcf1;Ld92;Lyt4;Le92;Lzg1;ZLp92;Lmx1;Lco2;Lqh2;Lv63;Lsj3;Lu23;Lo92;Lpw2;Lc92;Lc92;Lo92;Lkp2;Lg33;Lnt2;Lit2;Lht2;)V

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->b0()Lmm2;

    move-result-object v3

    new-instance v4, Lj93;

    invoke-direct {v4, v1, v0}, Lj93;-><init>(ILjava/lang/Object;)V

    iput-object v4, v3, Lmm2;->n:Lom2;

    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v4, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->s:Ljava/lang/String;

    if-eqz v4, :cond_d

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3, v4}, Lsl2;->loadUrl(Ljava/lang/String;)V

    goto :goto_b

    :cond_d
    iget-object v9, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->o:Ljava/lang/String;

    if-eqz v9, :cond_e

    iget-object v7, v0, Lbj1;->k:Lsl2;

    iget-object v8, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->m:Ljava/lang/String;

    const-string v10, "text/html"

    const-string v11, "UTF-8"

    const/4 v12, 0x0

    invoke-interface/range {v7 .. v12}, Lsl2;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_b
    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v3, :cond_10

    invoke-interface {v3, v0}, Lsl2;->q0(Lbj1;)V

    goto :goto_c

    :cond_e
    new-instance v0, Lhy3;

    const-string v1, "No URL or HTML to display in ad overlay."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_0
    move-exception v0

    invoke-static {}, Lj23;->e()V

    new-instance v1, Lhy3;

    const-string v2, "Could not obtain webview for the overlay."

    invoke-direct {v1, v2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_f
    move-object/from16 v18, v1

    move v6, v4

    move v1, v7

    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    iput-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3, v2}, Lsl2;->J0(Landroid/content/Context;)V

    :cond_10
    :goto_c
    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-boolean v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->D:Z

    if-eqz v3, :cond_12

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v3

    iget-object v4, v0, Lbj1;->k:Lsl2;

    invoke-interface {v4}, Lsl2;->k()Landroid/webkit/WebView;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/webkit/CookieManager;->setAcceptThirdPartyCookies(Landroid/webkit/WebView;Z)V

    sget-object v3, Lk52;->A1:Lg52;

    sget-object v4, Lvx1;->e:Lvx1;

    iget-object v7, v4, Lvx1;->c:Li52;

    invoke-virtual {v7, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_11

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1b

    if-lt v3, v7, :cond_11

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->k()Landroid/webkit/WebView;

    move-result-object v3

    invoke-static {v3}, Lnr;->d(Landroid/webkit/WebView;)V

    :cond_11
    sget-object v3, Lk52;->B1:Lg52;

    iget-object v4, v4, Lvx1;->c:Li52;

    invoke-virtual {v4, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_13

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->k()Landroid/webkit/WebView;

    move-result-object v3

    sget-object v4, Li23;->h:Li23;

    invoke-virtual {v3, v4}, Landroid/webkit/WebView;->setDownloadListener(Landroid/webkit/DownloadListener;)V

    goto :goto_d

    :cond_12
    const/4 v5, 0x0

    :cond_13
    :goto_d
    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3, v0}, Lsl2;->D0(Lbj1;)V

    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-object v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->k:Lsl2;

    if-eqz v3, :cond_14

    invoke-interface {v3}, Lsl2;->I0()Lh73;

    move-result-object v3

    iget-object v4, v0, Lbj1;->s:Led4;

    invoke-static {v4, v3}, Lbj1;->R3(Landroid/view/View;Lh73;)V

    :cond_14
    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-eq v3, v1, :cond_18

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    instance-of v4, v3, Landroid/view/ViewGroup;

    if-eqz v4, :cond_15

    check-cast v3, Landroid/view/ViewGroup;

    iget-object v4, v0, Lbj1;->k:Lsl2;

    invoke-interface {v4}, Lsl2;->j0()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_15
    iget-boolean v3, v0, Lbj1;->r:Z

    if-eqz v3, :cond_16

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->P()V

    sget-object v3, Lk52;->t1:Lg52;

    sget-object v4, Lvx1;->e:Lvx1;

    iget-object v4, v4, Lvx1;->c:Li52;

    invoke-virtual {v4, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_16

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1f

    if-lt v3, v12, :cond_16

    iget v3, v0, Lbj1;->u:I

    move-object/from16 v4, v18

    invoke-static {v4, v3}, Ljz0;->t(Landroid/view/Window;I)V

    :cond_16
    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget-boolean v3, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->D:Z

    const/4 v4, -0x1

    if-eqz v3, :cond_17

    new-instance v3, Landroid/widget/Toolbar;

    invoke-direct {v3, v2}, Landroid/widget/Toolbar;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v7

    invoke-virtual {v3, v7}, Landroid/view/View;->setId(I)V

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->j0()Landroid/view/View;

    move-result-object v3

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v7

    invoke-virtual {v3, v7}, Landroid/view/View;->setId(I)V

    iget-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    const v7, -0xbbbbbc

    invoke-virtual {v3, v7}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    :try_start_2
    sget-object v3, Lcw4;->B:Lcw4;

    iget-object v3, v3, Lcw4;->h:Lui2;

    invoke-virtual {v3}, Lui2;->c()Landroid/content/res/Resources;

    move-result-object v3

    const v7, 0x7f070054

    const/4 v14, 0x0

    invoke-virtual {v3, v7, v14}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    iget-object v7, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v7, v3}, Landroid/widget/Toolbar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V
    :try_end_2
    .catch Ljava/lang/NullPointerException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_e

    :catch_1
    invoke-static {}, Lj23;->b()Z

    :goto_e
    iget-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    iget-object v7, v0, Lbj1;->w:Lt2;

    invoke-virtual {v3, v7}, Landroid/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v3, v5}, Landroid/widget/Toolbar;->setTitleMarginStart(I)V

    new-instance v3, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0xa

    invoke-virtual {v3, v7}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    iget-object v7, v0, Lbj1;->s:Led4;

    iget-object v8, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v7, v8, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/RelativeLayout$LayoutParams;

    invoke-direct {v3, v4, v5}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    iget-object v4, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v4

    const/4 v5, 0x3

    invoke-virtual {v3, v5, v4}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    const/16 v4, 0xc

    invoke-virtual {v3, v4}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    iget-object v4, v0, Lbj1;->s:Led4;

    iget-object v5, v0, Lbj1;->k:Lsl2;

    invoke-interface {v5}, Lsl2;->j0()Landroid/view/View;

    move-result-object v5

    invoke-virtual {v4, v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v3, v0, Lbj1;->D:Landroid/widget/Toolbar;

    invoke-virtual {v0, v3}, Lbj1;->Q3(Landroid/view/View;)V

    goto :goto_f

    :cond_17
    iget-object v3, v0, Lbj1;->s:Led4;

    iget-object v5, v0, Lbj1;->k:Lsl2;

    invoke-interface {v5}, Lsl2;->j0()Landroid/view/View;

    move-result-object v5

    invoke-virtual {v3, v5, v4, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;II)V

    :cond_18
    :goto_f
    if-nez p1, :cond_19

    iget-boolean v3, v0, Lbj1;->t:Z

    if-nez v3, :cond_19

    sget-object v3, Lk52;->lg:Lg52;

    sget-object v4, Lvx1;->e:Lvx1;

    iget-object v4, v4, Lvx1;->c:Li52;

    invoke-virtual {v4, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_19

    iget-object v3, v0, Lbj1;->k:Lsl2;

    invoke-interface {v3}, Lsl2;->U()V

    :cond_19
    iget-object v3, v0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v4, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    if-eq v4, v1, :cond_1a

    invoke-virtual {v0, v6}, Lbj1;->S3(Z)V

    iget-object v1, v0, Lbj1;->k:Lsl2;

    invoke-interface {v1}, Lsl2;->Y0()Z

    move-result v1

    if-eqz v1, :cond_1b

    const/4 v1, 0x1

    invoke-virtual {v0, v6, v1}, Lbj1;->T3(ZZ)V

    return-void

    :cond_1a
    iget-object v1, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->x:Ljava/lang/String;

    iget-object v4, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->y:Ljava/lang/String;

    new-instance v5, Lu63;

    invoke-direct {v5, v2, v0, v1, v4}, Lu63;-><init>(Landroid/app/Activity;Lbj1;Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v3, :cond_1c

    :try_start_3
    iget-object v0, v3, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->C:Lie2;

    if-eqz v0, :cond_1c

    new-instance v1, Lui0;

    invoke-direct {v1, v5}, Lui0;-><init>(Ljava/lang/Object;)V

    invoke-interface {v0, v1}, Lie2;->S(Ll50;)V

    :cond_1b
    return-void

    :cond_1c
    new-instance v0, Lhy3;

    const-string v1, "noioou"

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_3
    .catch Lhy3; {:try_start_3 .. :try_end_3} :catch_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    move-exception v0

    goto :goto_10

    :catch_3
    move-exception v0

    :goto_10
    new-instance v1, Lhy3;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_1d
    new-instance v0, Lhy3;

    const-string v1, "Invalid activity, no window available."

    invoke-direct {v0, v1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final b()V
    .locals 0

    iget-object p0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz p0, :cond_0

    iget-object p0, p0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lyt4;->B2()V

    :cond_0
    return-void
.end method

.method public final c()Z
    .locals 3

    const/4 v0, 0x1

    iput v0, p0, Lbj1;->E:I

    iget-object v1, p0, Lbj1;->k:Lsl2;

    if-nez v1, :cond_0

    return v0

    :cond_0
    sget-object v0, Lk52;->ra:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Lbj1;->k:Lsl2;

    invoke-interface {p0}, Lsl2;->goBack()V

    const/4 p0, 0x0

    return p0

    :cond_1
    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->Q0()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object p0, p0, Lbj1;->k:Lsl2;

    const-string v1, "onbackblocked"

    sget-object v2, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    invoke-interface {p0, v1, v2}, Lxa2;->a(Ljava/lang/String;Ljava/util/Map;)V

    :cond_2
    return v0
.end method

.method public final c1()V
    .locals 1

    const/4 v0, 0x1

    iput-boolean v0, p0, Lbj1;->z:Z

    return-void
.end method

.method public final g()V
    .locals 0

    iget-object p0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz p0, :cond_0

    iget-object p0, p0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz p0, :cond_0

    invoke-interface {p0}, Lyt4;->A1()V

    :cond_0
    return-void
.end method

.method public final h()V
    .locals 6

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lyt4;->d1()V

    :cond_0
    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->v:Lpo4;

    if-eqz v0, :cond_1

    iget-boolean v0, v0, Lpo4;->n:Z

    if-eqz v0, :cond_1

    move v2, v1

    :cond_1
    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    sget-object v3, Lk52;->P1:Lg52;

    sget-object v4, Lvx1;->e:Lvx1;

    iget-object v5, v4, Lvx1;->c:Li52;

    iget-object v4, v4, Lvx1;->c:Li52;

    invoke-virtual {v5, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    if-eq v1, v2, :cond_2

    const/16 v1, 0x1504

    goto :goto_0

    :cond_2
    const/16 v1, 0x1706

    :goto_0
    invoke-virtual {v3, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    goto :goto_1

    :cond_3
    const/16 v1, 0x400

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    const/16 v1, 0x800

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    if-eqz v2, :cond_4

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    const/16 v2, 0x1002

    invoke-virtual {v1, v2}, Landroid/view/View;->setSystemUiVisibility(I)V

    :cond_4
    :goto_1
    sget-object v1, Lk52;->lf:Lg52;

    invoke-virtual {v4, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_5

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x22

    if-gt v1, v2, :cond_5

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_5

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    invoke-static {v1}, Ls11;->j(Landroid/view/WindowManager$LayoutParams;)V

    invoke-static {v0}, Lw93;->h(Landroid/view/Window;)V

    :cond_5
    sget-object v0, Lk52;->f6:Lg52;

    invoke-virtual {v4, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_7

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_6

    invoke-interface {v0}, Lsl2;->C()Z

    move-result v0

    if-nez v0, :cond_6

    iget-object p0, p0, Lbj1;->k:Lsl2;

    invoke-interface {p0}, Lsl2;->onResume()V

    return-void

    :cond_6
    sget p0, Lj23;->b:I

    const-string p0, "The webview does not exist. Ignoring action."

    invoke-static {p0}, Lj23;->g(Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method public final i()V
    .locals 2

    invoke-virtual {p0}, Lbj1;->B()V

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lyt4;->w3()V

    :cond_0
    sget-object v0, Lk52;->f6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->l:Lex4;

    if-nez v0, :cond_2

    :cond_1
    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->onPause()V

    :cond_2
    invoke-virtual {p0}, Lbj1;->v()V

    return-void
.end method

.method public final k()V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lbj1;->E:I

    return-void
.end method

.method public final l()V
    .locals 2

    sget-object v0, Lk52;->f6:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lsl2;->C()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lbj1;->k:Lsl2;

    invoke-interface {v0}, Lsl2;->onResume()V

    goto :goto_0

    :cond_0
    sget v0, Lj23;->b:I

    const-string v0, "The webview does not exist. Ignoring action."

    invoke-static {v0}, Lj23;->g(Ljava/lang/String;)V

    :cond_1
    :goto_0
    iget-object p0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz p0, :cond_2

    iget-object p0, p0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz p0, :cond_2

    invoke-interface {p0}, Lyt4;->Y()V

    :cond_2
    return-void
.end method

.method public final q()V
    .locals 3

    const/4 v0, 0x3

    iput v0, p0, Lbj1;->E:I

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    iget-object v1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v1, :cond_0

    iget v1, v1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    const/4 v2, 0x5

    if-ne v1, v2, :cond_0

    const/4 v1, 0x0

    invoke-virtual {v0, v1, v1}, Landroid/app/Activity;->overridePendingTransition(II)V

    iget-object p0, p0, Lbj1;->k:Lsl2;

    if-eqz p0, :cond_0

    const/4 v0, 0x0

    invoke-interface {p0, v0}, Lsl2;->D0(Lbj1;)V

    :cond_0
    return-void
.end method

.method public final q0(Ll50;)V
    .locals 0

    return-void
.end method

.method public final v()V
    .locals 4

    iget-object v0, p0, Lbj1;->i:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-boolean v0, p0, Lbj1;->A:Z

    if-eqz v0, :cond_0

    goto :goto_3

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lbj1;->A:Z

    iget-object v0, p0, Lbj1;->k:Lsl2;

    if-eqz v0, :cond_3

    iget v1, p0, Lbj1;->E:I

    add-int/lit8 v1, v1, -0x1

    invoke-interface {v0, v1}, Lsl2;->k0(I)V

    iget-object v0, p0, Lbj1;->v:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-boolean v1, p0, Lbj1;->y:Z

    if-nez v1, :cond_2

    iget-object v1, p0, Lbj1;->k:Lsl2;

    invoke-interface {v1}, Lsl2;->A0()Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object v1, Lk52;->e6:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v3, v2, Lvx1;->c:Li52;

    invoke-virtual {v3, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-boolean v1, p0, Lbj1;->B:Z

    if-nez v1, :cond_1

    iget-object v1, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    if-eqz v1, :cond_1

    iget-object v1, v1, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->j:Lyt4;

    if-eqz v1, :cond_1

    invoke-interface {v1}, Lyt4;->Z0()V

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    :goto_0
    new-instance v1, Lzm2;

    const/16 v3, 0x19

    invoke-direct {v1, v3, p0}, Lzm2;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Lbj1;->x:Lzm2;

    sget-object p0, Lzu4;->l:Lrc3;

    sget-object v3, Lk52;->I1:Lg52;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v3}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    monitor-exit v0

    return-void

    :cond_2
    monitor-exit v0

    goto :goto_2

    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0

    :cond_3
    :goto_2
    invoke-virtual {p0}, Lbj1;->P3()V

    :cond_4
    :goto_3
    return-void
.end method

.method public final x2(I[Ljava/lang/String;[I)V
    .locals 4

    const/16 v0, 0x3039

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lbj1;->i:Landroid/app/Activity;

    if-eqz p1, :cond_1

    iget-object v0, p0, Lbj1;->j:Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;

    iget v1, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->r:I

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    move-object p0, v3

    :goto_0
    new-instance v1, Lu63;

    invoke-direct {v1, p1, p0, v3, v3}, Lu63;-><init>(Landroid/app/Activity;Lbj1;Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    iget-object p0, v0, Lcom/google/android/gms/ads/internal/overlay/AdOverlayInfoParcel;->C:Lie2;

    new-instance p1, Lui0;

    invoke-direct {p1, v1}, Lui0;-><init>(Ljava/lang/Object;)V

    invoke-interface {p0, p2, p3, p1}, Lie2;->i3([Ljava/lang/String;[ILl50;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :cond_1
    const-string p0, "Null activity"

    invoke-static {p0}, Ls40;->l(Ljava/lang/String;)V

    :catch_0
    :cond_2
    return-void
.end method
