.class public final Lap;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/util/HashMap;

.field public static final b:Ljava/util/HashMap;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lap;->a:Ljava/util/HashMap;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lap;->b:Ljava/util/HashMap;

    sget-object v1, Lel0;->h:Lr;

    const-string v2, "RSASSA-PSS"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Ltr;->a:Lr;

    const-string v2, "ED25519"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Ltr;->b:Lr;

    const-string v2, "ED448"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    new-instance v1, Lr;

    const-string v2, "1.2.840.113549.1.1.5"

    invoke-direct {v1, v2}, Lr;-><init>(Ljava/lang/String;)V

    const-string v2, "SHA1WITHRSA"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lel0;->l:Lr;

    const-string v3, "SHA224WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lel0;->i:Lr;

    const-string v3, "SHA256WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lel0;->j:Lr;

    const-string v3, "SHA384WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lel0;->k:Lr;

    const-string v3, "SHA512WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lnb1;->d:Lr;

    const-string v3, "SHAKE128WITHRSAPSS"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lnb1;->e:Lr;

    const-string v3, "SHAKE256WITHRSAPSS"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lpk;->c:Lr;

    const-string v3, "GOST3411WITHGOST3410"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lpk;->d:Lr;

    const-string v3, "GOST3411WITHECGOST3410"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Ldu0;->c:Lr;

    const-string v3, "GOST3411-2012-256WITHECGOST3410-2012-256"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Ldu0;->d:Lr;

    const-string v3, "GOST3411-2012-512WITHECGOST3410-2012-512"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->a:Lr;

    const-string v3, "SHA1WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->b:Lr;

    const-string v3, "SHA224WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->c:Lr;

    const-string v3, "SHA256WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->d:Lr;

    const-string v3, "SHA384WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->e:Lr;

    const-string v3, "SHA512WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->g:Lr;

    const-string v3, "SHA3-224WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->h:Lr;

    const-string v3, "SHA3-256WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->i:Lr;

    const-string v3, "SHA3-384WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->j:Lr;

    const-string v3, "SHA3-512WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lwb;->f:Lr;

    const-string v3, "RIPEMD160WITHPLAIN-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lrr;->a:Lr;

    const-string v3, "SHA1WITHCVC-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lrr;->b:Lr;

    const-string v3, "SHA224WITHCVC-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lrr;->c:Lr;

    const-string v3, "SHA256WITHCVC-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lrr;->d:Lr;

    const-string v3, "SHA384WITHCVC-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lrr;->e:Lr;

    const-string v3, "SHA512WITHCVC-ECDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lw60;->a:Lr;

    const-string v3, "XMSS"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lw60;->b:Lr;

    const-string v3, "XMSSMT"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lm21;->e:Lr;

    const-string v3, "RIPEMD128WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lm21;->d:Lr;

    const-string v3, "RIPEMD160WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lm21;->f:Lr;

    const-string v3, "RIPEMD256WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    new-instance v1, Lr;

    const-string v3, "1.2.840.113549.1.1.4"

    invoke-direct {v1, v3}, Lr;-><init>(Ljava/lang/String;)V

    const-string v3, "MD5WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    new-instance v1, Lr;

    const-string v3, "1.2.840.113549.1.1.2"

    invoke-direct {v1, v3}, Lr;-><init>(Ljava/lang/String;)V

    const-string v3, "MD2WITHRSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    new-instance v1, Lr;

    const-string v3, "1.2.840.10040.4.3"

    invoke-direct {v1, v3}, Lr;-><init>(Ljava/lang/String;)V

    const-string v3, "SHA1WITHDSA"

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lob1;->a:Lr;

    const-string v4, "SHA1WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lob1;->b:Lr;

    const-string v4, "SHA224WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lob1;->c:Lr;

    const-string v4, "SHA256WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lob1;->d:Lr;

    const-string v4, "SHA384WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lob1;->e:Lr;

    const-string v4, "SHA512WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lnb1;->f:Lr;

    const-string v4, "SHAKE128WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lnb1;->g:Lr;

    const-string v4, "SHAKE256WITHECDSA"

    invoke-static {v1, v4}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lri0;->c:Lr;

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lri0;->b:Lr;

    invoke-static {v1, v3}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->v:Lr;

    const-string v2, "SHA224WITHDSA"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->w:Lr;

    const-string v2, "SHA256WITHDSA"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lel0;->y:Lr;

    const-string v2, "LMS"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->L:Lr;

    const-string v2, "ML-DSA-44"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->M:Lr;

    const-string v2, "ML-DSA-65"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->N:Lr;

    const-string v2, "ML-DSA-87"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->O:Lr;

    const-string v2, "ML-DSA-44-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->P:Lr;

    const-string v2, "ML-DSA-65-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->Q:Lr;

    const-string v2, "ML-DSA-87-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->R:Lr;

    const-string v2, "SLH-DSA-SHA2-128S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->S:Lr;

    const-string v2, "SLH-DSA-SHA2-128F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->T:Lr;

    const-string v2, "SLH-DSA-SHA2-192S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->U:Lr;

    const-string v2, "SLH-DSA-SHA2-192F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->V:Lr;

    const-string v2, "SLH-DSA-SHA2-256S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->W:Lr;

    const-string v2, "SLH-DSA-SHA2-256F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->X:Lr;

    const-string v2, "SLH-DSA-SHAKE-128S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->Y:Lr;

    const-string v2, "SLH-DSA-SHAKE-128F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->Z:Lr;

    const-string v2, "SLH-DSA-SHAKE-192S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->a0:Lr;

    const-string v2, "SLH-DSA-SHAKE-192F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->b0:Lr;

    const-string v2, "SLH-DSA-SHAKE-256S"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->c0:Lr;

    const-string v2, "SLH-DSA-SHAKE-256F"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->d0:Lr;

    const-string v2, "SLH-DSA-SHA2-128S-WITH-SHA256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->e0:Lr;

    const-string v2, "SLH-DSA-SHA2-128F-WITH-SHA256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->f0:Lr;

    const-string v2, "SLH-DSA-SHA2-192S-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->g0:Lr;

    const-string v2, "SLH-DSA-SHA2-192F-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->h0:Lr;

    const-string v2, "SLH-DSA-SHA2-256S-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->i0:Lr;

    const-string v2, "SLH-DSA-SHA2-256F-WITH-SHA512"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->j0:Lr;

    const-string v2, "SLH-DSA-SHAKE-128S-WITH-SHAKE128"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->k0:Lr;

    const-string v2, "SLH-DSA-SHAKE-128F-WITH-SHAKE128"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->l0:Lr;

    const-string v2, "SLH-DSA-SHAKE-192S-WITH-SHAKE256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->m0:Lr;

    const-string v2, "SLH-DSA-SHAKE-192F-WITH-SHAKE256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->n0:Lr;

    const-string v2, "SLH-DSA-SHAKE-256S-WITH-SHAKE256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lkg0;->o0:Lr;

    const-string v2, "SLH-DSA-SHAKE-256F-WITH-SHAKE256"

    invoke-static {v1, v2}, Lap;->a(Lr;Ljava/lang/String;)V

    sget-object v1, Lri0;->a:Lr;

    const-string v2, "SHA1"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->d:Lr;

    const-string v2, "SHA224"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->a:Lr;

    const-string v2, "SHA256"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->b:Lr;

    const-string v2, "SHA384"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->c:Lr;

    const-string v2, "SHA512"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->k:Lr;

    const-string v2, "SHAKE128"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->l:Lr;

    const-string v2, "SHAKE256"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->g:Lr;

    const-string v2, "SHA3-224"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->h:Lr;

    const-string v2, "SHA3-256"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->i:Lr;

    const-string v2, "SHA3-384"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lkg0;->j:Lr;

    const-string v2, "SHA3-512"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lm21;->b:Lr;

    const-string v2, "RIPEMD128"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lm21;->a:Lr;

    const-string v2, "RIPEMD160"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lm21;->c:Lr;

    const-string v2, "RIPEMD256"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static a(Lr;Ljava/lang/String;)V
    .locals 2

    sget-object v0, Lap;->a:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0, p0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_0
    const-string p0, "object identifier already present in addSignatureName"

    invoke-static {p0}, Lb;->d(Ljava/lang/String;)V

    return-void
.end method

.method public static b(Lr;)Ljava/lang/String;
    .locals 1

    sget-object v0, Lap;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Lr;->v()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
