.class public final La83;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk73;


# instance fields
.field public final a:Lyn2;

.field public final b:Landroid/content/Context;

.field public final c:Lh13;

.field public final d:Log3;

.field public final e:Ljava/util/concurrent/Executor;

.field public final f:Lnv3;

.field public final g:Ls23;


# direct methods
.method public constructor <init>(Lyn2;Landroid/content/Context;Ljava/util/concurrent/Executor;Lh13;Log3;Lnv3;Ls23;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La83;->b:Landroid/content/Context;

    iput-object p1, p0, La83;->a:Lyn2;

    iput-object p3, p0, La83;->e:Ljava/util/concurrent/Executor;

    iput-object p4, p0, La83;->c:Lh13;

    iput-object p5, p0, La83;->d:Log3;

    iput-object p6, p0, La83;->f:Lnv3;

    iput-object p7, p0, La83;->g:Ls23;

    return-void
.end method


# virtual methods
.method public final a(Lkg3;Lbg3;)Z
    .locals 0

    iget-object p0, p2, Lbg3;->s:Lfg3;

    if-eqz p0, :cond_0

    iget-object p0, p0, Lfg3;->a:Ljava/lang/String;

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method

.method public final b(Lkg3;Lbg3;)Lna0;
    .locals 3

    sget-object v0, Li14;->i:Li14;

    new-instance v1, Ldo1;

    const/4 v2, 0x5

    invoke-direct {v1, v2, p0, p1, p2}, Ldo1;-><init>(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p0, p0, La83;->e:Ljava/util/concurrent/Executor;

    invoke-static {v0, v1, p0}, Ln50;->J(Lna0;Lu04;Ljava/util/concurrent/Executor;)Lm04;

    move-result-object p0

    return-object p0
.end method
