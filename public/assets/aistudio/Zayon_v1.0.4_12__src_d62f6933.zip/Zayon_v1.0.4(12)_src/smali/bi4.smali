.class public final enum Lbi4;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum h:Lbi4;

.field public static final enum i:Lbi4;

.field public static final enum j:Lbi4;

.field public static final enum k:Lbi4;

.field public static final enum l:Lbi4;

.field public static final enum m:Lbi4;

.field public static final enum n:Lbi4;

.field public static final enum o:Lbi4;

.field public static final enum p:Lbi4;

.field public static final synthetic q:[Lbi4;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    new-instance v0, Lbi4;

    const-string v1, "INT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lbi4;->h:Lbi4;

    new-instance v1, Lbi4;

    const-string v2, "LONG"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lbi4;->i:Lbi4;

    new-instance v2, Lbi4;

    const-string v3, "FLOAT"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lbi4;->j:Lbi4;

    new-instance v3, Lbi4;

    const-string v4, "DOUBLE"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lbi4;->k:Lbi4;

    new-instance v4, Lbi4;

    const-string v5, "BOOLEAN"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Lbi4;->l:Lbi4;

    new-instance v5, Lbi4;

    const-string v6, "STRING"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lbi4;->m:Lbi4;

    new-instance v6, Lbi4;

    sget-object v7, Lyf4;->i:Lwf4;

    const-string v7, "BYTE_STRING"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lbi4;->n:Lbi4;

    new-instance v7, Lbi4;

    const-string v8, "ENUM"

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lbi4;->o:Lbi4;

    new-instance v8, Lbi4;

    const-string v9, "MESSAGE"

    const/16 v10, 0x8

    invoke-direct {v8, v9, v10}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lbi4;->p:Lbi4;

    filled-new-array/range {v0 .. v8}, [Lbi4;

    move-result-object v0

    sput-object v0, Lbi4;->q:[Lbi4;

    return-void
.end method

.method public static values()[Lbi4;
    .locals 1

    sget-object v0, Lbi4;->q:[Lbi4;

    invoke-virtual {v0}, [Lbi4;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lbi4;

    return-object v0
.end method
