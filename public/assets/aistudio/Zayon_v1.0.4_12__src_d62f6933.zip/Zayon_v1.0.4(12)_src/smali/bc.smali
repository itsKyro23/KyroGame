.class public interface abstract Lbc;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Z)V
.end method
