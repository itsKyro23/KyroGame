.class public final Lb02;
.super Lk02;
.source "SourceFile"


# instance fields
.field public final synthetic h:I

.field public final i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lmz1;Lbw1;ILandroid/view/View;)V
    .locals 8

    const/4 v0, 0x3

    iput v0, p0, Lb02;->h:I

    .line 19
    const-string v4, "hfynBEe6dOlNQP0Wi5l4Y33EmMRACcuQi8Wz4tphvls="

    const/16 v7, 0x39

    const-string v3, "VzDqK2Qhy8m7H6PB3RHMrYQm7t7BOqRME2wj8aNqSR2BjSd40n1j7ifz58mO7qiY"

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move v6, p3

    invoke-direct/range {v1 .. v7}, Lk02;-><init>(Lmz1;Ljava/lang/String;Ljava/lang/String;Lbw1;II)V

    iput-object p4, v1, Lb02;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lmz1;Lbw1;ILgq0;)V
    .locals 8

    const/4 v0, 0x1

    iput v0, p0, Lb02;->h:I

    const-string v4, "0ZzYmiv0qxgWNUCiGggnRm3zxanwNQmqihAv5i6tqkg="

    const/16 v7, 0x5e

    const-string v3, "GPSX0oVi73Ib8ecKWrSO3VUHY/Mu2TTTkcz/0tATF/nBEKf0stmuRgI/3NEubSXp"

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move v6, p3

    invoke-direct/range {v1 .. v7}, Lk02;-><init>(Lmz1;Ljava/lang/String;Ljava/lang/String;Lbw1;II)V

    iput-object p4, v1, Lb02;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lmz1;Lbw1;ILwi1;)V
    .locals 8

    const/4 v0, 0x0

    iput v0, p0, Lb02;->h:I

    .line 20
    const-string v4, "C6Zx/ReDfes3xuOLYM/P73Od5EVB6nq/3rtPt/P4yDY="

    const/16 v7, 0x55

    const-string v3, "E/sg0vUYFi5Bw2LDcnUx8YELJ5gJbWpKSsyXBS4wtTA0vM6aRXc8TfjEIpMXOBOU"

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move v6, p3

    invoke-direct/range {v1 .. v7}, Lk02;-><init>(Lmz1;Ljava/lang/String;Ljava/lang/String;Lbw1;II)V

    iput-object p4, v1, Lb02;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lmz1;Lbw1;I[Ljava/lang/StackTraceElement;)V
    .locals 8

    const/4 v0, 0x2

    iput v0, p0, Lb02;->h:I

    .line 21
    const-string v4, "O4B/kAjR/YQMOddpgzIrgUcoaK62iIn/Qlm3PN6Mw/o="

    const/16 v7, 0x2d

    const-string v3, "GZf/veAWBQM0/jbyrn8H67cJiuqpXpAd+9T53BBfmWzP5T3uqttu9ou0WokFZSq8"

    move-object v1, p0

    move-object v2, p1

    move-object v5, p2

    move v6, p3

    invoke-direct/range {v1 .. v7}, Lk02;-><init>(Lmz1;Ljava/lang/String;Ljava/lang/String;Lbw1;II)V

    iput-object p4, v1, Lb02;->i:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 10

    iget v0, p0, Lb02;->h:I

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lb02;->i:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_3

    sget-object v6, Lk52;->q4:Lg52;

    sget-object v7, Lvx1;->e:Lvx1;

    iget-object v8, v7, Lvx1;->c:Li52;

    invoke-virtual {v8, v6}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Boolean;

    sget-object v8, Lk52;->Ac:Lg52;

    iget-object v7, v7, Lvx1;->c:Li52;

    invoke-virtual {v7, v8}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Boolean;

    iget-object v8, p0, Lk02;->a:Lmz1;

    iget-object v8, v8, Lmz1;->a:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    invoke-virtual {v8}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v8

    iget-object v9, p0, Lk02;->e:Ljava/lang/reflect/Method;

    filled-new-array {v0, v8, v6, v7}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v9, v5, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v5, Loz1;

    const/16 v8, 0xc

    invoke-direct {v5, v8}, Lck2;-><init>(I)V

    invoke-static {v0}, Lck2;->y(Ljava/lang/String;)Ljava/util/HashMap;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    iput-object v3, v5, Loz1;->s:Ljava/lang/Long;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    iput-object v3, v5, Loz1;->t:Ljava/lang/Long;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Long;

    iput-object v2, v5, Loz1;->u:Ljava/lang/Long;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    iput-object v1, v5, Loz1;->v:Ljava/lang/Long;

    const/4 v1, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Long;

    iput-object v0, v5, Loz1;->w:Ljava/lang/Long;

    :cond_0
    invoke-static {}, Lrw1;->y()Lqw1;

    move-result-object v0

    iget-object v1, v5, Loz1;->s:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v3, v0, Lkg4;->i:Lng4;

    check-cast v3, Lrw1;

    invoke-virtual {v3, v1, v2}, Lrw1;->A(J)V

    iget-object v1, v5, Loz1;->t:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v3, v0, Lkg4;->i:Lng4;

    check-cast v3, Lrw1;

    invoke-virtual {v3, v1, v2}, Lrw1;->B(J)V

    iget-object v1, v5, Loz1;->u:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v3, v0, Lkg4;->i:Lng4;

    check-cast v3, Lrw1;

    invoke-virtual {v3, v1, v2}, Lrw1;->C(J)V

    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, v5, Loz1;->w:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v3, v0, Lkg4;->i:Lng4;

    check-cast v3, Lrw1;

    invoke-virtual {v3, v1, v2}, Lrw1;->z(J)V

    :cond_1
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, v5, Loz1;->v:Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v0}, Lkg4;->c()V

    iget-object v3, v0, Lkg4;->i:Lng4;

    check-cast v3, Lrw1;

    invoke-virtual {v3, v1, v2}, Lrw1;->D(J)V

    :cond_2
    iget-object p0, p0, Lk02;->d:Lbw1;

    invoke-virtual {v0}, Lkg4;->d()Lng4;

    move-result-object v0

    check-cast v0, Lrw1;

    invoke-virtual {p0}, Lkg4;->c()V

    iget-object p0, p0, Lkg4;->i:Lng4;

    check-cast p0, Lsw1;

    invoke-virtual {p0, v0}, Lsw1;->a0(Lrw1;)V

    :cond_3
    return-void

    :pswitch_0
    iget-object v0, p0, Lb02;->i:Ljava/lang/Object;

    check-cast v0, [Ljava/lang/StackTraceElement;

    if-eqz v0, :cond_6

    iget-object v3, p0, Lk02;->e:Ljava/lang/reflect/Method;

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v3, v5, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v3, Lwy1;

    invoke-direct {v3, v0}, Lwy1;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lk02;->d:Lbw1;

    monitor-enter p0

    :try_start_0
    iget-object v0, v3, Lwy1;->t:Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v0, p0, Lkg4;->i:Lng4;

    check-cast v0, Lsw1;

    invoke-virtual {v0, v5, v6}, Lsw1;->N(J)V

    iget-object v0, v3, Lwy1;->u:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, v3, Lwy1;->v:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_4

    move v2, v4

    :cond_4
    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v0, p0, Lkg4;->i:Lng4;

    check-cast v0, Lsw1;

    invoke-virtual {v0, v2}, Lsw1;->V(I)V

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_5
    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v0, p0, Lkg4;->i:Lng4;

    check-cast v0, Lsw1;

    invoke-virtual {v0, v1}, Lsw1;->V(I)V

    :goto_0
    monitor-exit p0

    goto :goto_2

    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0

    :cond_6
    :goto_2
    return-void

    :pswitch_1
    iget-object v0, p0, Lk02;->e:Ljava/lang/reflect/Method;

    iget-object v1, p0, Lb02;->i:Ljava/lang/Object;

    check-cast v1, Lgq0;

    iget-object v2, v1, Lgq0;->a:Ljava/util/List;

    sget-object v3, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object v3, v1, Lgq0;->a:Ljava/util/List;

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v5, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v1, p0, Lk02;->d:Lbw1;

    monitor-enter v1

    :try_start_1
    invoke-static {v0}, Lq60;->e(I)I

    move-result p0

    invoke-virtual {v1}, Lkg4;->c()V

    iget-object v0, v1, Lkg4;->i:Lng4;

    check-cast v0, Lsw1;

    invoke-virtual {v0, p0}, Lsw1;->t0(I)V

    monitor-exit v1

    return-void

    :catchall_1
    move-exception p0

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw p0

    :pswitch_2
    iget-object v0, p0, Lk02;->e:Ljava/lang/reflect/Method;

    iget-object v1, p0, Lb02;->i:Ljava/lang/Object;

    check-cast v1, Lwi1;

    iget-wide v6, v1, Lwi1;->c:J

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    iget-wide v6, v1, Lwi1;->d:J

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    iget-wide v7, v1, Lwi1;->e:J

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    iget-wide v8, v1, Lwi1;->f:J

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    filled-new-array {v2, v6, v7, v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v5, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [J

    iget-object p0, p0, Lk02;->d:Lbw1;

    monitor-enter p0

    :try_start_2
    aget-wide v1, v0, v3

    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v3, p0, Lkg4;->i:Lng4;

    check-cast v3, Lsw1;

    invoke-virtual {v3, v1, v2}, Lsw1;->o0(J)V

    aget-wide v1, v0, v4

    invoke-virtual {p0}, Lkg4;->c()V

    iget-object v0, p0, Lkg4;->i:Lng4;

    check-cast v0, Lsw1;

    invoke-virtual {v0, v1, v2}, Lsw1;->p0(J)V

    monitor-exit p0

    return-void

    :catchall_2
    move-exception v0

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    throw v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
