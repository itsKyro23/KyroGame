.class public final Lb62;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lc1;

.field public static final b:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb62;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    :cond_0
    sget-object p0, Lb62;->b:Ljava/lang/Object;

    monitor-enter p0

    :try_start_0
    sget-object v0, Lb62;->a:Lc1;

    if-nez v0, :cond_2

    invoke-static {p1}, Lk52;->a(Landroid/content/Context;)V

    sget-object v0, Lk52;->w5:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p1}, Lsv1;->y(Landroid/content/Context;)Lc1;

    move-result-object p1

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_1
    new-instance v0, Lso3;

    new-instance v1, Lpt;

    const/16 v2, 0x11

    invoke-direct {v1, v2}, Lpt;-><init>(I)V

    invoke-direct {v0, v1}, Lso3;-><init>(Lpt;)V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    new-instance v1, Llx2;

    const/16 v2, 0x15

    invoke-direct {v1, p1, v2}, Llx2;-><init>(Landroid/content/Context;I)V

    new-instance p1, Lc1;

    new-instance v2, Llt1;

    invoke-direct {v2, v1}, Llt1;-><init>(Llx2;)V

    invoke-direct {p1, v2, v0}, Lc1;-><init>(Llt1;Lso3;)V

    invoke-virtual {p1}, Lc1;->d()V

    :goto_0
    sput-object p1, Lb62;->a:Lc1;

    :cond_2
    monitor-exit p0

    return-void

    :goto_1
    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method


# virtual methods
.method public final a(ILjava/lang/String;Ljava/util/HashMap;[B)Lt22;
    .locals 13

    new-instance v5, Lt22;

    invoke-direct {v5}, Lfj2;-><init>()V

    new-instance v6, Lxt3;

    invoke-direct {v6, p0, p2, v5}, Lxt3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, Lmo4;

    invoke-direct {v9}, Lmo4;-><init>()V

    new-instance v1, Lf22;

    move-object v2, p0

    move v3, p1

    move-object v4, p2

    move-object/from16 v8, p3

    move-object/from16 v7, p4

    invoke-direct/range {v1 .. v9}, Lf22;-><init>(Lb62;ILjava/lang/String;Lt22;Lxt3;[BLjava/util/Map;Lmo4;)V

    move-object v0, v9

    invoke-static {}, Lmo4;->c()Z

    move-result v2

    if-eqz v2, :cond_2

    :try_start_0
    invoke-virtual {v1}, Lf22;->e()Ljava/util/Map;

    move-result-object v10

    if-nez p4, :cond_0

    const/4 v2, 0x0

    move-object v11, v2

    goto :goto_0

    :cond_0
    move-object/from16 v11, p4

    :goto_0
    invoke-static {}, Lmo4;->c()Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    const-string v9, "GET"

    new-instance v7, Ll41;

    const/16 v12, 0x1c

    move-object v8, p2

    invoke-direct/range {v7 .. v12}, Ll41;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v2, "onNetworkRequest"

    invoke-virtual {v0, v2, v7}, Lmo4;->e(Ljava/lang/String;Lym4;)V
    :try_end_0
    .catch Lps1; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    sget v2, Lj23;->b:I

    invoke-static {v0}, Lj23;->g(Ljava/lang/String;)V

    :cond_2
    :goto_1
    sget-object v0, Lb62;->a:Lc1;

    invoke-virtual {v0, v1}, Lc1;->e(Lbt1;)V

    return-object v5
.end method
