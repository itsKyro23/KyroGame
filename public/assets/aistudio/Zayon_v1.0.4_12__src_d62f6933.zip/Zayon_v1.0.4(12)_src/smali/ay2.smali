.class public final synthetic Lay2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:Lby2;

.field public final synthetic i:Landroid/view/View;

.field public final synthetic j:Z

.field public final synthetic k:I


# direct methods
.method public synthetic constructor <init>(Lby2;Landroid/view/View;ZI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lay2;->h:Lby2;

    iput-object p2, p0, Lay2;->i:Landroid/view/View;

    iput-boolean p3, p0, Lay2;->j:Z

    iput p4, p0, Lay2;->k:I

    return-void
.end method


# virtual methods
.method public final synthetic run()V
    .locals 8

    iget-object v0, p0, Lay2;->h:Lby2;

    iget-object v1, v0, Lby2;->w:Lhz2;

    if-nez v1, :cond_0

    sget p0, Lj23;->b:I

    const-string p0, "Ad should be associated with an ad view before calling performClickForCustomGesture()"

    invoke-static {p0}, Lj23;->c(Ljava/lang/String;)V

    return-void

    :cond_0
    move-object v2, v0

    iget-object v0, v2, Lby2;->n:Lly2;

    invoke-interface {v1}, Lhz2;->M1()Landroid/view/View;

    move-result-object v1

    iget-object v3, v2, Lby2;->w:Lhz2;

    invoke-interface {v3}, Lhz2;->g()Ljava/util/Map;

    move-result-object v3

    iget-object v4, v2, Lby2;->w:Lhz2;

    invoke-interface {v4}, Lhz2;->l()Ljava/util/Map;

    move-result-object v4

    invoke-virtual {v2}, Lby2;->k()Landroid/widget/ImageView$ScaleType;

    move-result-object v6

    move-object v2, v1

    iget-object v1, p0, Lay2;->i:Landroid/view/View;

    iget-boolean v5, p0, Lay2;->j:Z

    iget v7, p0, Lay2;->k:I

    invoke-interface/range {v0 .. v7}, Lly2;->i(Landroid/view/View;Landroid/view/View;Ljava/util/Map;Ljava/util/Map;ZLandroid/widget/ImageView$ScaleType;I)V

    return-void
.end method
