.class public final La05;
.super Lny4;
.source "SourceFile"


# instance fields
.field public final c:Lam1;


# direct methods
.method public constructor <init>(Ly02;Lam1;)V
    .locals 0

    invoke-direct {p0, p1}, Lny4;-><init>(Ly02;)V

    iput-object p2, p0, La05;->c:Lam1;

    return-void
.end method


# virtual methods
.method public final b(ILg02;J)Lg02;
    .locals 1

    iget-object v0, p0, Lny4;->b:Ly02;

    invoke-virtual {v0, p1, p2, p3, p4}, Ly02;->b(ILg02;J)Lg02;

    iget-object p0, p0, La05;->c:Lam1;

    iput-object p0, p2, Lg02;->b:Lam1;

    iget-object p0, p0, Lam1;->b:Lcj1;

    return-object p2
.end method
