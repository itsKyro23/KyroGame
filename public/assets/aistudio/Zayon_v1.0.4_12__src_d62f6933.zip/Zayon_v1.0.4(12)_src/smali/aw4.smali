.class public final Law4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public A:Z

.field public B:F

.field public C:[B

.field public D:I

.field public E:Lfd4;

.field public F:I

.field public G:I

.field public H:I

.field public I:I

.field public J:I

.field public K:I

.field public L:I

.field public M:I

.field public N:I

.field public O:I

.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Lmx3;

.field public d:Ljava/lang/String;

.field public e:I

.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:Ljava/lang/String;

.field public k:Lrp1;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:I

.field public p:I

.field public q:Ljava/util/List;

.field public r:Lat4;

.field public s:J

.field public t:Z

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public y:F

.field public z:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 164
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lmx3;->i:Lix3;

    .line 165
    sget-object v0, Lqy3;->l:Lqy3;

    .line 166
    iput-object v0, p0, Law4;->c:Lmx3;

    const/4 v0, -0x1

    iput v0, p0, Law4;->h:I

    iput v0, p0, Law4;->i:I

    iput v0, p0, Law4;->o:I

    iput v0, p0, Law4;->p:I

    const-wide v1, 0x7fffffffffffffffL

    iput-wide v1, p0, Law4;->s:J

    iput v0, p0, Law4;->u:I

    iput v0, p0, Law4;->v:I

    iput v0, p0, Law4;->w:I

    iput v0, p0, Law4;->x:I

    const/high16 v1, -0x40800000    # -1.0f

    iput v1, p0, Law4;->y:F

    const/high16 v1, 0x3f800000    # 1.0f

    iput v1, p0, Law4;->B:F

    iput v0, p0, Law4;->D:I

    iput v0, p0, Law4;->F:I

    iput v0, p0, Law4;->G:I

    iput v0, p0, Law4;->H:I

    iput v0, p0, Law4;->I:I

    iput v0, p0, Law4;->J:I

    iput v0, p0, Law4;->M:I

    const/4 v0, 0x1

    iput v0, p0, Law4;->N:I

    const/4 v0, 0x0

    iput v0, p0, Law4;->O:I

    iput v0, p0, Law4;->g:I

    return-void
.end method

.method public synthetic constructor <init>(Lfx4;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, Lfx4;->a:Ljava/lang/String;

    iput-object v0, p0, Law4;->a:Ljava/lang/String;

    iget-object v0, p1, Lfx4;->b:Ljava/lang/String;

    iput-object v0, p0, Law4;->b:Ljava/lang/String;

    iget-object v0, p1, Lfx4;->c:Lmx3;

    iput-object v0, p0, Law4;->c:Lmx3;

    iget-object v0, p1, Lfx4;->d:Ljava/lang/String;

    iput-object v0, p0, Law4;->d:Ljava/lang/String;

    iget v0, p1, Lfx4;->e:I

    iput v0, p0, Law4;->e:I

    iget v0, p1, Lfx4;->f:I

    iput v0, p0, Law4;->f:I

    iget v0, p1, Lfx4;->h:I

    iput v0, p0, Law4;->h:I

    iget v0, p1, Lfx4;->i:I

    iput v0, p0, Law4;->i:I

    iget-object v0, p1, Lfx4;->k:Ljava/lang/String;

    iput-object v0, p0, Law4;->j:Ljava/lang/String;

    iget-object v0, p1, Lfx4;->l:Lrp1;

    iput-object v0, p0, Law4;->k:Lrp1;

    iget-object v0, p1, Lfx4;->m:Ljava/lang/String;

    iput-object v0, p0, Law4;->l:Ljava/lang/String;

    iget-object v0, p1, Lfx4;->n:Ljava/lang/String;

    iput-object v0, p0, Law4;->m:Ljava/lang/String;

    iget-object v0, p1, Lfx4;->o:Ljava/lang/String;

    iput-object v0, p0, Law4;->n:Ljava/lang/String;

    iget v0, p1, Lfx4;->p:I

    iput v0, p0, Law4;->o:I

    iget v0, p1, Lfx4;->q:I

    iput v0, p0, Law4;->p:I

    iget-object v0, p1, Lfx4;->r:Ljava/util/List;

    iput-object v0, p0, Law4;->q:Ljava/util/List;

    iget-object v0, p1, Lfx4;->s:Lat4;

    iput-object v0, p0, Law4;->r:Lat4;

    iget-wide v0, p1, Lfx4;->t:J

    iput-wide v0, p0, Law4;->s:J

    iget-boolean v0, p1, Lfx4;->u:Z

    iput-boolean v0, p0, Law4;->t:Z

    iget v0, p1, Lfx4;->v:I

    iput v0, p0, Law4;->u:I

    iget v0, p1, Lfx4;->w:I

    iput v0, p0, Law4;->v:I

    iget v0, p1, Lfx4;->x:I

    iput v0, p0, Law4;->w:I

    iget v0, p1, Lfx4;->y:I

    iput v0, p0, Law4;->x:I

    iget v0, p1, Lfx4;->z:F

    iput v0, p0, Law4;->y:F

    iget v0, p1, Lfx4;->A:I

    iput v0, p0, Law4;->z:I

    iget-boolean v0, p1, Lfx4;->B:Z

    iput-boolean v0, p0, Law4;->A:Z

    iget v0, p1, Lfx4;->C:F

    iput v0, p0, Law4;->B:F

    iget-object v0, p1, Lfx4;->D:[B

    iput-object v0, p0, Law4;->C:[B

    iget v0, p1, Lfx4;->E:I

    iput v0, p0, Law4;->D:I

    iget-object v0, p1, Lfx4;->F:Lfd4;

    iput-object v0, p0, Law4;->E:Lfd4;

    iget v0, p1, Lfx4;->G:I

    iput v0, p0, Law4;->F:I

    iget v0, p1, Lfx4;->H:I

    iput v0, p0, Law4;->G:I

    iget v0, p1, Lfx4;->I:I

    iput v0, p0, Law4;->H:I

    iget v0, p1, Lfx4;->J:I

    iput v0, p0, Law4;->I:I

    iget v0, p1, Lfx4;->K:I

    iput v0, p0, Law4;->J:I

    iget v0, p1, Lfx4;->L:I

    iput v0, p0, Law4;->K:I

    iget v0, p1, Lfx4;->M:I

    iput v0, p0, Law4;->L:I

    iget v0, p1, Lfx4;->N:I

    iput v0, p0, Law4;->M:I

    iget v0, p1, Lfx4;->O:I

    iput v0, p0, Law4;->N:I

    iget p1, p1, Lfx4;->P:I

    iput p1, p0, Law4;->O:I

    return-void
.end method


# virtual methods
.method public final a()Lfx4;
    .locals 1

    new-instance v0, Lfx4;

    invoke-direct {v0, p0}, Lfx4;-><init>(Law4;)V

    return-object v0
.end method

.method public final b(I)V
    .locals 0

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Law4;->a:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .locals 0

    invoke-static {p1}, Lxr1;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Law4;->m:Ljava/lang/String;

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .locals 0

    invoke-static {p1}, Lxr1;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Law4;->n:Ljava/lang/String;

    return-void
.end method
