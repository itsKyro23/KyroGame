.class public final Lb04;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final h:Lg04;

.field public final i:Lna0;


# direct methods
.method public constructor <init>(Lg04;Lna0;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb04;->h:Lg04;

    iput-object p2, p0, Lb04;->i:Lna0;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lb04;->h:Lg04;

    iget-object v0, v0, Ll04;->h:Ljava/lang/Object;

    if-eq v0, p0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lb04;->i:Lna0;

    iget-object v1, p0, Lb04;->h:Lg04;

    invoke-static {v0}, Lg04;->i(Lna0;)Ljava/lang/Object;

    move-result-object v0

    sget-object v2, Ll04;->n:Lvm;

    invoke-virtual {v2, v1, p0, v0}, Lvm;->x(Ll04;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object p0, p0, Lb04;->h:Lg04;

    const/4 v0, 0x0

    invoke-static {p0, v0}, Lg04;->p(Lg04;Z)V

    :cond_1
    :goto_0
    return-void
.end method
