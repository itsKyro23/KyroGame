.class public abstract Lb50;
.super Lf12;
.source "SourceFile"

# interfaces
.implements Lc50;


# direct methods
.method public static asInterface(Landroid/os/IBinder;)Lc50;
    .locals 3

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "com.google.android.gms.ads.internal.client.hsdp.IHsdpDeepLinkServiceWrapper"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v1

    instance-of v2, v1, Lc50;

    if-eqz v2, :cond_1

    check-cast v1, Lc50;

    return-object v1

    :cond_1
    new-instance v1, La50;

    const/4 v2, 0x4

    invoke-direct {v1, p0, v0, v2}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    return-object v1
.end method


# virtual methods
.method public final O3(Landroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 12

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p3, v2, :cond_5

    const/4 v3, 0x2

    if-eq p3, v3, :cond_4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eq p3, v3, :cond_0

    return v4

    :cond_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    invoke-static {p3}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object v6

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v8

    sget-object p3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p1, p3}, Lg12;->b(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p3

    move-object v9, p3

    check-cast v9, Landroid/os/Bundle;

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p3

    if-eqz p3, :cond_1

    move v10, v2

    goto :goto_0

    :cond_1
    move v10, v4

    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p3

    if-nez p3, :cond_2

    :goto_1
    move-object v11, v1

    goto :goto_2

    :cond_2
    const-string v1, "com.google.android.gms.ads.internal.client.hsdp.IHsdpServiceCallback"

    invoke-interface {p3, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v3

    instance-of v4, v3, Lg50;

    if-eqz v4, :cond_3

    move-object v1, v3

    check-cast v1, Lg50;

    goto :goto_1

    :cond_3
    new-instance v3, Lf50;

    invoke-direct {v3, p3, v1, v0}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    move-object v11, v3

    :goto_2
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    move-object v5, p0

    invoke-interface/range {v5 .. v11}, Lc50;->open(Ll50;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;ZLg50;)V

    goto :goto_4

    :cond_4
    move-object v5, p0

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p0

    invoke-static {p0}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p0

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p3

    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {v5, p0, p3}, Lc50;->endSession(Ll50;Ljava/lang/String;)V

    goto :goto_4

    :cond_5
    move-object v5, p0

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p0

    invoke-static {p0}, Lui0;->Z0(Landroid/os/IBinder;)Ll50;

    move-result-object p0

    sget-object p3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-virtual {p1, p3}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p3

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v3

    if-nez v3, :cond_6

    goto :goto_3

    :cond_6
    const-string v1, "com.google.android.gms.ads.internal.client.hsdp.IHsdpPrewarmServiceCallback"

    invoke-interface {v3, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v4

    instance-of v6, v4, Le50;

    if-eqz v6, :cond_7

    move-object v1, v4

    check-cast v1, Le50;

    goto :goto_3

    :cond_7
    new-instance v4, Ld50;

    invoke-direct {v4, v3, v1, v0}, Ljd1;-><init>(Landroid/os/IBinder;Ljava/lang/String;I)V

    move-object v1, v4

    :goto_3
    invoke-static {p1}, Lg12;->f(Landroid/os/Parcel;)V

    invoke-interface {v5, p0, p3, v1}, Lc50;->prewarm(Ll50;Ljava/util/List;Le50;)V

    :goto_4
    invoke-virtual {p2}, Landroid/os/Parcel;->writeNoException()V

    return v2
.end method
