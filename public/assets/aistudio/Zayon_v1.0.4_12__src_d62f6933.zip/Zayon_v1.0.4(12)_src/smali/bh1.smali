.class public final synthetic Lbh1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic h:I

.field public final synthetic i:Llx2;


# direct methods
.method public synthetic constructor <init>(Llx2;I)V
    .locals 0

    .line 9
    iput p2, p0, Lbh1;->h:I

    iput-object p1, p0, Lbh1;->i:Llx2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Llx2;Lpb2;)V
    .locals 0

    const/4 p2, 0x2

    iput p2, p0, Lbh1;->h:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbh1;->i:Llx2;

    return-void
.end method


# virtual methods
.method public final synthetic run()V
    .locals 1

    iget v0, p0, Lbh1;->h:I

    iget-object p0, p0, Lbh1;->i:Llx2;

    packed-switch v0, :pswitch_data_0

    iget-object p0, p0, Llx2;->j:Ljava/lang/Object;

    check-cast p0, Lch1;

    iget-object p0, p0, Lch1;->i:Lpi1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_0
    iget-object p0, p0, Llx2;->j:Ljava/lang/Object;

    check-cast p0, Lch1;

    iget-object p0, p0, Lch1;->i:Lpi1;

    invoke-interface {p0}, Lpi1;->f()V

    return-void

    :pswitch_1
    iget-object p0, p0, Llx2;->j:Ljava/lang/Object;

    check-cast p0, Lch1;

    iget-object p0, p0, Lch1;->i:Lpi1;

    invoke-interface {p0}, Lpi1;->d()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
