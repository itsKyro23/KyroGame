.class public final La21;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Comparable;


# instance fields
.field public final h:I

.field public final i:I

.field public final j:Ljava/lang/String;

.field public final k:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p2, p0, La21;->h:I

    iput p4, p0, La21;->i:I

    iput-object p1, p0, La21;->j:Ljava/lang/String;

    iput-object p3, p0, La21;->k:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final compareTo(Ljava/lang/Object;)I
    .locals 2

    check-cast p1, La21;

    iget v0, p0, La21;->h:I

    iget v1, p1, La21;->h:I

    sub-int/2addr v0, v1

    if-nez v0, :cond_0

    iget p0, p0, La21;->i:I

    iget p1, p1, La21;->i:I

    sub-int/2addr p0, p1

    return p0

    :cond_0
    return v0
.end method
