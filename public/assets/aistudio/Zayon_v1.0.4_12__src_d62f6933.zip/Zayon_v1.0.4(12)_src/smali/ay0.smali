.class public final Lay0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public final synthetic h:I

.field public i:I

.field public j:Z

.field public k:Ljava/util/Iterator;

.field public final synthetic l:Ljava/util/AbstractMap;


# direct methods
.method public synthetic constructor <init>(Ljava/util/AbstractMap;I)V
    .locals 0

    iput p2, p0, Lay0;->h:I

    iput-object p1, p0, Lay0;->l:Ljava/util/AbstractMap;

    const/4 p1, -0x1

    iput p1, p0, Lay0;->i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()Ljava/util/Iterator;
    .locals 1

    iget-object v0, p0, Lay0;->k:Ljava/util/Iterator;

    if-nez v0, :cond_0

    iget-object v0, p0, Lay0;->l:Ljava/util/AbstractMap;

    check-cast v0, Lyx0;

    iget-object v0, v0, Lyx0;->i:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    iput-object v0, p0, Lay0;->k:Ljava/util/Iterator;

    :cond_0
    return-object v0
.end method

.method public b()Ljava/util/Iterator;
    .locals 1

    iget-object v0, p0, Lay0;->k:Ljava/util/Iterator;

    if-nez v0, :cond_0

    iget-object v0, p0, Lay0;->l:Ljava/util/AbstractMap;

    check-cast v0, Lev4;

    iget-object v0, v0, Lev4;->j:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    iput-object v0, p0, Lay0;->k:Ljava/util/Iterator;

    :cond_0
    return-object v0
.end method

.method public final hasNext()Z
    .locals 5

    iget v0, p0, Lay0;->h:I

    iget-object v1, p0, Lay0;->l:Ljava/util/AbstractMap;

    const/4 v2, 0x1

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_0

    iget v0, p0, Lay0;->i:I

    add-int/2addr v0, v2

    check-cast v1, Lev4;

    iget v4, v1, Lev4;->i:I

    if-lt v0, v4, :cond_1

    iget-object v0, v1, Lev4;->j:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lay0;->b()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    move v2, v3

    :cond_1
    :goto_0
    return v2

    :pswitch_0
    iget v0, p0, Lay0;->i:I

    add-int/2addr v0, v2

    check-cast v1, Lyx0;

    iget-object v4, v1, Lyx0;->h:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lt v0, v4, :cond_3

    iget-object v0, v1, Lyx0;->i:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Lay0;->a()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_2

    goto :goto_1

    :cond_2
    move v2, v3

    :cond_3
    :goto_1
    return v2

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final next()Ljava/lang/Object;
    .locals 3

    iget v0, p0, Lay0;->h:I

    iget-object v1, p0, Lay0;->l:Ljava/util/AbstractMap;

    const/4 v2, 0x1

    packed-switch v0, :pswitch_data_0

    iput-boolean v2, p0, Lay0;->j:Z

    iget v0, p0, Lay0;->i:I

    add-int/2addr v0, v2

    iput v0, p0, Lay0;->i:I

    check-cast v1, Lev4;

    iget v2, v1, Lev4;->i:I

    if-ge v0, v2, :cond_0

    iget-object p0, v1, Lev4;->h:[Ljava/lang/Object;

    aget-object p0, p0, v0

    check-cast p0, Lfv4;

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lay0;->b()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map$Entry;

    :goto_0
    return-object p0

    :pswitch_0
    iput-boolean v2, p0, Lay0;->j:Z

    iget v0, p0, Lay0;->i:I

    add-int/2addr v0, v2

    iput v0, p0, Lay0;->i:I

    check-cast v1, Lyx0;

    iget-object v2, v1, Lyx0;->h:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    iget-object v0, v1, Lyx0;->h:Ljava/util/List;

    iget p0, p0, Lay0;->i:I

    invoke-interface {v0, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map$Entry;

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lay0;->a()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map$Entry;

    :goto_1
    return-object p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final remove()V
    .locals 4

    iget v0, p0, Lay0;->h:I

    const-string v1, "remove() was called before next()"

    iget-object v2, p0, Lay0;->l:Ljava/util/AbstractMap;

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_0

    iget-boolean v0, p0, Lay0;->j:Z

    if-eqz v0, :cond_1

    iput-boolean v3, p0, Lay0;->j:Z

    check-cast v2, Lev4;

    sget v0, Lev4;->n:I

    invoke-virtual {v2}, Lev4;->g()V

    iget v0, p0, Lay0;->i:I

    iget v1, v2, Lev4;->i:I

    if-ge v0, v1, :cond_0

    add-int/lit8 v1, v0, -0x1

    iput v1, p0, Lay0;->i:I

    invoke-virtual {v2, v0}, Lev4;->e(I)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lay0;->b()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    goto :goto_0

    :cond_1
    invoke-static {v1}, Lb;->d(Ljava/lang/String;)V

    :goto_0
    return-void

    :pswitch_0
    check-cast v2, Lyx0;

    iget-boolean v0, p0, Lay0;->j:Z

    if-eqz v0, :cond_3

    iput-boolean v3, p0, Lay0;->j:Z

    sget v0, Lyx0;->m:I

    invoke-virtual {v2}, Lyx0;->b()V

    iget v0, p0, Lay0;->i:I

    iget-object v1, v2, Lyx0;->h:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_2

    iget v0, p0, Lay0;->i:I

    add-int/lit8 v1, v0, -0x1

    iput v1, p0, Lay0;->i:I

    invoke-virtual {v2, v0}, Lyx0;->h(I)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lay0;->a()Ljava/util/Iterator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    goto :goto_1

    :cond_3
    invoke-static {v1}, Lb;->d(Ljava/lang/String;)V

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
