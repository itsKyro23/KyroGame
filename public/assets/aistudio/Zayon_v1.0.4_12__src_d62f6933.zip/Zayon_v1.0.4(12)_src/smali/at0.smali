.class public final Lat0;
.super Lec0;
.source "SourceFile"
