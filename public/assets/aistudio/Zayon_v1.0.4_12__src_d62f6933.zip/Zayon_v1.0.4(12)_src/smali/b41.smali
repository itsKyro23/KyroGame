.class public final Lb41;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ld41;


# direct methods
.method public constructor <init>(Ld41;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb41;->a:Ld41;

    return-void
.end method

.method public static final a(Landroid/content/Context;)Lb41;
    .locals 7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v1, 0x0

    sget-object v2, Lq4;->a:Lq4;

    const/16 v3, 0x1e

    if-lt v0, v3, :cond_0

    invoke-virtual {v2}, Lq4;->a()I

    move-result v4

    goto :goto_0

    :cond_0
    move v4, v1

    :goto_0
    const/4 v5, 0x5

    const/4 v6, 0x0

    if-lt v4, v5, :cond_1

    new-instance v0, La41;

    invoke-static {}, Lm3;->B()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0}, Lm3;->i(Ljava/lang/Object;)Landroid/adservices/topics/TopicsManager;

    move-result-object p0

    invoke-direct {v0, p0}, Ld41;-><init>(Landroid/adservices/topics/TopicsManager;)V

    goto :goto_1

    :cond_1
    if-lt v0, v3, :cond_2

    invoke-virtual {v2}, Lq4;->a()I

    move-result v1

    :cond_2
    const/4 v0, 0x4

    if-ne v1, v0, :cond_3

    new-instance v0, Lz31;

    invoke-static {}, Lm3;->B()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0}, Lm3;->i(Ljava/lang/Object;)Landroid/adservices/topics/TopicsManager;

    move-result-object p0

    invoke-direct {v0, p0}, Ld41;-><init>(Landroid/adservices/topics/TopicsManager;)V

    goto :goto_1

    :cond_3
    move-object v0, v6

    :goto_1
    if-eqz v0, :cond_4

    new-instance p0, Lb41;

    invoke-direct {p0, v0}, Lb41;-><init>(Ld41;)V

    return-object p0

    :cond_4
    return-object v6
.end method


# virtual methods
.method public b(Lf20;)Lna0;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lf20;",
            ")",
            "Lna0;"
        }
    .end annotation

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lvq;->a:Lxo;

    sget-object v0, Loc0;->a:Lq30;

    invoke-static {v0}, Lhd1;->a(Lsj;)Lhj;

    move-result-object v0

    new-instance v1, Lwm;

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1, v2, v3}, Lwm;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljj;I)V

    invoke-static {v0, v1}, Lw93;->a(Lhj;Loz;)Lkp;

    move-result-object p0

    invoke-static {p0}, Lbo;->a(Lkp;)Lyd;

    move-result-object p0

    return-object p0
.end method
