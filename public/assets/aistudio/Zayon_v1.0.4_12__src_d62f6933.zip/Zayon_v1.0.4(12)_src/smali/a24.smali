.class public final La24;
.super Lng4;
.source "SourceFile"


# static fields
.field private static final zzb:La24;


# instance fields
.field private zza:Lug4;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La24;

    invoke-direct {v0}, La24;-><init>()V

    sput-object v0, La24;->zzb:La24;

    const-class v1, La24;

    invoke-static {v1, v0}, Lng4;->s(Ljava/lang/Class;Lng4;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Lng4;-><init>()V

    sget-object v0, Lkh4;->l:Lkh4;

    iput-object v0, p0, La24;->zza:Lug4;

    return-void
.end method

.method public static z()Lx14;
    .locals 1

    sget-object v0, La24;->zzb:La24;

    invoke-virtual {v0}, Lng4;->o()Lkg4;

    move-result-object v0

    check-cast v0, Lx14;

    return-object v0
.end method


# virtual methods
.method public final A(Lz14;)V
    .locals 2

    iget-object v0, p0, La24;->zza:Lug4;

    move-object v1, v0

    check-cast v1, Lrf4;

    iget-boolean v1, v1, Lrf4;->h:Z

    if-nez v1, :cond_0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    add-int/2addr v1, v1

    invoke-interface {v0, v1}, Lug4;->C(I)Lug4;

    move-result-object v0

    iput-object v0, p0, La24;->zza:Lug4;

    :cond_0
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final u(ILng4;)Ljava/lang/Object;
    .locals 1

    invoke-static {p1}, Loj;->x(I)I

    move-result p0

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1

    const/4 p1, 0x4

    if-eq p0, p1, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    new-instance p0, Lx14;

    sget-object p1, La24;->zzb:La24;

    invoke-direct {p0, p1}, Lkg4;-><init>(Lng4;)V

    return-object p0

    :cond_1
    new-instance p0, La24;

    invoke-direct {p0}, La24;-><init>()V

    return-object p0

    :cond_2
    const-string p0, "zza"

    const-class p1, Lz14;

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, La24;->zzb:La24;

    new-instance p2, Llh4;

    const-string v0, "\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b"

    invoke-direct {p2, p1, v0, p0}, Llh4;-><init>(Lqf4;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2
.end method

.method public final y()I
    .locals 0

    iget-object p0, p0, La24;->zza:Lug4;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    return p0
.end method
