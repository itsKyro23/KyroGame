.class public final Lb80;
.super Lhe;
.source "SourceFile"


# instance fields
.field public final p:Lug;


# direct methods
.method public constructor <init>(Ljj;Lug;)V
    .locals 1

    const/4 v0, 0x1

    invoke-direct {p0, v0, p1}, Lhe;-><init>(ILjj;)V

    iput-object p2, p0, Lb80;->p:Lug;

    return-void
.end method


# virtual methods
.method public final r(Le80;)Ljava/lang/Throwable;
    .locals 1

    iget-object p0, p0, Lb80;->p:Lug;

    invoke-virtual {p0}, Le80;->A()Ljava/lang/Object;

    move-result-object p0

    instance-of v0, p0, Ld80;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Ld80;

    invoke-virtual {v0}, Ld80;->c()Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    instance-of v0, p0, Lxg;

    if-eqz v0, :cond_1

    check-cast p0, Lxg;

    iget-object p0, p0, Lxg;->a:Ljava/lang/Throwable;

    return-object p0

    :cond_1
    invoke-virtual {p1}, Le80;->w()Ljava/util/concurrent/CancellationException;

    move-result-object p0

    return-object p0
.end method

.method public final y()Ljava/lang/String;
    .locals 0

    const-string p0, "AwaitContinuation"

    return-object p0
.end method
