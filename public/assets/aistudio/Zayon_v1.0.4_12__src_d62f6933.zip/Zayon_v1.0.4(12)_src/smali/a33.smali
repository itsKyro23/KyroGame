.class public final La33;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/HashMap;

.field public final b:Landroid/content/Context;

.field public final c:Lzi2;

.field public final d:Ltw4;

.field public final e:Z

.field public final f:Lh34;

.field public final g:Z

.field public final h:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final i:Ljava/util/concurrent/atomic/AtomicReference;


# direct methods
.method public constructor <init>(Lzi2;Ltw4;Lqa;Lh34;Landroid/content/Context;)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Ly91;->l:Lht1;

    invoke-virtual {v0}, Lht1;->v()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, La33;->a:Ljava/util/HashMap;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v1, p0, La33;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object v1, p0, La33;->i:Ljava/util/concurrent/atomic/AtomicReference;

    iput-object p1, p0, La33;->c:Lzi2;

    iput-object p2, p0, La33;->d:Ltw4;

    sget-object p1, Lk52;->H2:Lg52;

    sget-object p2, Lvx1;->e:Lvx1;

    iget-object v1, p2, Lvx1;->c:Li52;

    invoke-virtual {v1, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, La33;->e:Z

    iput-object p4, p0, La33;->f:Lh34;

    sget-object p1, Lk52;->Y7:Lg52;

    iget-object p4, p2, Lvx1;->c:Li52;

    invoke-virtual {p4, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iput-boolean p1, p0, La33;->g:Z

    iput-object p5, p0, La33;->b:Landroid/content/Context;

    iget-object p0, p3, Lqa;->m:Ljava/lang/Object;

    check-cast p0, Ljq;

    const-string p1, "s"

    const-string p5, "gmob_sdk"

    invoke-virtual {v0, p1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "v"

    const-string p5, "3"

    invoke-virtual {v0, p1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "os"

    sget-object p5, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v0, p1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "api_v"

    sget-object p5, Landroid/os/Build$VERSION;->SDK:Ljava/lang/String;

    invoke-virtual {v0, p1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lcw4;->B:Lcw4;

    iget-object p5, p1, Lcw4;->c:Lzu4;

    iget-object p1, p1, Lcw4;->h:Lui2;

    const-string p5, "device"

    invoke-static {}, Lzu4;->N()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p5, p3, Lqa;->h:Ljava/lang/Object;

    check-cast p5, Ljava/lang/String;

    const-string v1, "app"

    invoke-virtual {v0, v1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p5, p3, Lqa;->i:Ljava/lang/Object;

    check-cast p5, Landroid/content/Context;

    invoke-static {p5}, Lzu4;->f(Landroid/content/Context;)Z

    move-result v1

    const-string v2, "1"

    const-string v3, "0"

    const/4 v4, 0x1

    if-eq v4, v1, :cond_0

    move-object v1, v3

    goto :goto_0

    :cond_0
    move-object v1, v2

    :goto_0
    const-string v5, "is_lite_sdk"

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p2, Lvx1;->a:Lf02;

    invoke-virtual {p2}, Lf02;->c()Ljava/util/ArrayList;

    move-result-object p2

    sget-object v1, Lk52;->T7:Lg52;

    invoke-virtual {p4, v1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p1}, Lui2;->g()Lol4;

    move-result-object v1

    invoke-virtual {v1}, Lol4;->n()Lsi2;

    move-result-object v1

    iget-object v1, v1, Lsi2;->i:Ljava/util/ArrayList;

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_1
    const-string v1, ","

    invoke-static {v1, p2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p2

    const-string v1, "e"

    invoke-virtual {v0, v1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p3, Lqa;->j:Ljava/lang/Object;

    check-cast p2, Ljava/lang/String;

    const-string v1, "sdkVersion"

    invoke-virtual {v0, v1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p2, Lk52;->Uc:Lg52;

    invoke-virtual {p4, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_3

    invoke-static {p5}, Lzu4;->d(Landroid/content/Context;)Z

    move-result p2

    if-eq v4, p2, :cond_2

    move-object v2, v3

    :cond_2
    const-string p2, "is_bstar"

    invoke-virtual {v0, p2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    sget-object p2, Lk52;->Sa:Lg52;

    invoke-virtual {p4, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const-string p5, ""

    if-eqz p2, :cond_5

    sget-object p2, Lk52;->f3:Lg52;

    invoke-virtual {p4, p2}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_5

    iget-object p1, p1, Lui2;->g:Ljava/lang/String;

    if-nez p1, :cond_4

    move-object p1, p5

    :cond_4
    const-string p2, "plugin"

    invoke-virtual {v0, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_5
    sget-object p1, Lk52;->cd:Lg52;

    invoke-virtual {p4, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_7

    iget-object p1, p3, Lqa;->l:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_6

    goto :goto_1

    :cond_6
    move-object p5, p1

    :goto_1
    const-string p1, "uev"

    invoke-virtual {v0, p1, p5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7
    sget-object p1, Lk52;->Y2:Lg52;

    invoke-virtual {p4, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_8

    iget-object p1, p0, Ljq;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lgq;

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    const-string p2, "mem_tier"

    invoke-virtual {v0, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8
    sget-object p1, Lk52;->Z2:Lg52;

    invoke-virtual {p4, p1}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_9

    iget-object p0, p0, Ljq;->e:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Liq;

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    const-string p1, "proc_tier"

    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    sget-object p0, Lk52;->a3:Lg52;

    invoke-virtual {p4, p0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_a

    iget-object p0, p3, Lqa;->k:Ljava/lang/Object;

    check-cast p0, Landroid/content/pm/PackageInfo;

    if-eqz p0, :cond_a

    iget p1, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string p2, "vc"

    invoke-virtual {v0, p2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "vn"

    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a
    return-void
.end method


# virtual methods
.method public final a(Ljava/util/Map;)V
    .locals 4

    if-eqz p1, :cond_4

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_2

    :cond_0
    iget-object v0, p0, La33;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    iget-object v1, p0, La33;->i:Ljava/util/concurrent/atomic/AtomicReference;

    if-nez v0, :cond_2

    sget-object v0, Lk52;->bc:Lg52;

    sget-object v2, Lvx1;->e:Lvx1;

    iget-object v2, v2, Lvx1;->c:Li52;

    invoke-virtual {v2, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v2, Lbc2;

    invoke-direct {v2, v0, p0}, Lbc2;-><init>(Ljava/lang/String;La33;)V

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_1

    sget-object p0, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    goto :goto_0

    :cond_1
    iget-object p0, p0, La33;->b:Landroid/content/Context;

    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-interface {v3, v2}, Landroid/content/SharedPreferences;->registerOnSharedPreferenceChangeListener(Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;)V

    invoke-static {p0, v0}, Lbo;->w(Landroid/content/Context;Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p0

    :goto_0
    invoke-virtual {v1, p0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :cond_2
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/os/Bundle;

    invoke-virtual {p0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p1, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_3
    return-void

    :cond_4
    :goto_2
    sget p0, Lj23;->b:I

    const-string p0, "Empty or null paramMap."

    invoke-static {p0}, Lj23;->c(Ljava/lang/String;)V

    return-void
.end method

.method public final b(Ljava/util/Map;)V
    .locals 2

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    sget p0, Lj23;->b:I

    const-string p0, "Empty paramMap."

    invoke-static {p0}, Lj23;->c(Ljava/lang/String;)V

    return-void

    :cond_0
    invoke-virtual {p0, p1}, La33;->a(Ljava/util/Map;)V

    iget-object v0, p0, La33;->f:Lh34;

    invoke-virtual {v0, p1}, Lh34;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lj23;->a(Ljava/lang/String;)V

    const-string v1, "scar"

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    iget-boolean v1, p0, La33;->e:Z

    if-eqz v1, :cond_2

    if-eqz p1, :cond_1

    iget-boolean p1, p0, La33;->g:Z

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Lbk2;

    const/16 v1, 0xd

    invoke-direct {p1, p0, v1, v0}, Lbk2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-object p0, p0, La33;->c:Lzi2;

    invoke-virtual {p0, p1}, Lzi2;->execute(Ljava/lang/Runnable;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final c(Ljava/util/AbstractMap;)V
    .locals 2

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    sget p0, Lj23;->b:I

    const-string p0, "Empty paramMap."

    invoke-static {p0}, Lj23;->c(Ljava/lang/String;)V

    return-void

    :cond_0
    invoke-virtual {p0, p1}, La33;->a(Ljava/util/Map;)V

    iget-object v0, p0, La33;->f:Lh34;

    invoke-virtual {v0, p1}, Lh34;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lj23;->a(Ljava/lang/String;)V

    sget-object v0, Lk52;->Ye:Lg52;

    sget-object v1, Lvx1;->e:Lvx1;

    iget-object v1, v1, Lvx1;->c:Li52;

    invoke-virtual {v1, v0}, Li52;->a(Lg52;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_2

    iget-boolean v0, p0, La33;->e:Z

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    return-void

    :cond_2
    :goto_0
    new-instance v0, Lmo2;

    const/16 v1, 0x9

    invoke-direct {v0, p0, v1, p1}, Lmo2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    iget-object p0, p0, La33;->c:Lzi2;

    invoke-virtual {p0, v0}, Lzi2;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
