.class public interface abstract Lak;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Lsj;
.end method
