.class public interface abstract La93;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract n()V
.end method
