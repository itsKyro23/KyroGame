.class public final Lbq3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lnk4;

.field public final b:Lnk4;

.field public final c:Ljava/util/concurrent/ExecutorService;

.field public final d:Lnk4;

.field public e:Ln04;


# direct methods
.method public constructor <init>(Lnk4;Lnk4;Ljava/util/concurrent/ExecutorService;Lnk4;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lbq3;->e:Ln04;

    iput-object p1, p0, Lbq3;->a:Lnk4;

    iput-object p2, p0, Lbq3;->b:Lnk4;

    iput-object p3, p0, Lbq3;->c:Ljava/util/concurrent/ExecutorService;

    iput-object p4, p0, Lbq3;->d:Lnk4;

    return-void
.end method


# virtual methods
.method public final declared-synchronized a()Lna0;
    .locals 1

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lbq3;->e:Ln04;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-object v0

    :cond_0
    const/4 v0, 0x0

    :try_start_1
    throw v0

    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
