.class public final La81;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:Ld81;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Ld81;Landroid/view/View;)V
    .locals 0

    iput-object p1, p0, La81;->a:Ld81;

    iput-object p2, p0, La81;->b:Landroid/view/View;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, La81;->a:Ld81;

    invoke-interface {p0}, Ld81;->b()V

    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, La81;->a:Ld81;

    invoke-interface {p0}, Ld81;->a()V

    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .locals 0

    iget-object p0, p0, La81;->a:Ld81;

    invoke-interface {p0}, Ld81;->c()V

    return-void
.end method
