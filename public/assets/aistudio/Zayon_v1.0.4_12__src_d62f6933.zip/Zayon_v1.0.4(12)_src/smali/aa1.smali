.class public final Laa1;
.super Ly91;
.source "SourceFile"


# virtual methods
.method public final A(Z)V
    .locals 0

    iget-object p0, p0, Ly91;->j:Ljava/lang/Object;

    check-cast p0, Landroid/view/WindowInsetsController;

    if-eqz p1, :cond_0

    const/16 p1, 0x8

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-static {p0, p1}, Lz91;->u(Landroid/view/WindowInsetsController;I)V

    return-void
.end method

.method public final B()V
    .locals 0

    iget-object p0, p0, Ly91;->j:Ljava/lang/Object;

    check-cast p0, Landroid/view/WindowInsetsController;

    invoke-static {p0}, Lz91;->l(Landroid/view/WindowInsetsController;)V

    return-void
.end method

.method public final z(Z)V
    .locals 0

    iget-object p0, p0, Ly91;->j:Ljava/lang/Object;

    check-cast p0, Landroid/view/WindowInsetsController;

    if-eqz p1, :cond_0

    const/16 p1, 0x10

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-static {p0, p1}, Lz91;->s(Landroid/view/WindowInsetsController;I)V

    return-void
.end method
