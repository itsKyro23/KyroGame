.class public final La50;
.super Ljd1;
.source "SourceFile"

# interfaces
.implements Lc50;


# virtual methods
.method public final endSession(Ll50;Ljava/lang/String;)V
    .locals 1

    invoke-virtual {p0}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, p1}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 p1, 0x2

    invoke-virtual {p0, v0, p1}, Ljd1;->R0(Landroid/os/Parcel;I)V

    return-void
.end method

.method public final open(Ll50;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;ZLg50;)V
    .locals 1

    invoke-virtual {p0}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, p1}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-virtual {v0, p3}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    invoke-static {v0, p4}, Lg12;->c(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    invoke-virtual {v0, p5}, Landroid/os/Parcel;->writeInt(I)V

    invoke-static {v0, p6}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 p1, 0x3

    invoke-virtual {p0, v0, p1}, Ljd1;->R0(Landroid/os/Parcel;I)V

    return-void
.end method

.method public final prewarm(Ll50;Ljava/util/List;Le50;)V
    .locals 1

    invoke-virtual {p0}, Ljd1;->G0()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {v0, p1}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeTypedList(Ljava/util/List;)V

    invoke-static {v0, p3}, Lg12;->e(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 p1, 0x1

    invoke-virtual {p0, v0, p1}, Ljd1;->R0(Landroid/os/Parcel;I)V

    return-void
.end method
